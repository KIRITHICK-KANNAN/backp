// import React, { useMemo, useState, useEffect } from "react";
// import Modal from "react-bootstrap/Modal";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import { BsCalendar2Check } from "react-icons/bs";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { searchCases } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import * as XLSX from "xlsx";
// import excel from "../assets/excel.png";

// /* ===== Constants ===== */
// const ITEMS_PER_PAGE = 100;

// /* ===== Utils ===== */
// function toISTString(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
//   const ist = new Date(istMs);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// }

// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yyyy = d.getFullYear();
//   return `${dd}/${mm}/${yyyy}`;
// }

// function getReqId(obj) {
//   return (
//     obj?.reqId ??
//     obj?.request_id ??
//     obj?.req_id ??
//     obj?.reqid ??
//     obj?.requestId ??
//     obj?.reqIdFk ??
//     obj?.reqid_fk ??
//     null
//   );
// }

// /** Accepts raw API response and returns { rows:[{master,details[]}], total } */
// function normalizeResponse(res) {
//   if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
//     const byReq = res.details.reduce((acc, d) => {
//       const k = String(getReqId(d) ?? "");
//       (acc[k] ||= []).push(d);
//       return acc;
//     }, {});
//     const rows = res.master.map((m) => {
//       const mk = String(getReqId(m) ?? "");
//       return { master: m, details: byReq[mk] || [] };
//     });
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (Array.isArray(res)) {
//     const rows = res.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   if (res && Array.isArray(res.master)) {
//     const rows = res.master.map((m) => ({
//       master: m,
//       details: m.details || [],
//     }));
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (res && Array.isArray(res.data)) {
//     const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   return { rows: [], total: 0 };
// }

// /* ========================== Modal ========================== */
// function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
//   const roleId = Number(authData?.role_id);
//   const canEditRight = roleId == 2;

//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

//   // Use the clicked detail, fallback to first detail
//   const det =
//     row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};

//   // Helper values
//   const fullName = [
//     det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
//     det?.lName ??
//       det?.last_name ??
//       (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
//   ]
//     .filter(Boolean)
//     .join(" ");

//   const email =
//     row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";

//   const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
//   const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";

//   const dob = fmtDMY(det?.dob);
//   const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);

//   const submittedOn =
//     row?.master?.submitOn ??
//     row?.master?.submitted_on ??
//     det?.submitted_on ??
//     "";

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";

//   const vacName = getVacName(
//     det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
//   );

//   const statusList =
//     (statusOptions && statusOptions.length
//       ? statusOptions
//       : authData?.ajaxPayload?.master_status_list) || [];

//   const reasonList = authData?.ajaxPayload?.reason_list || [
//     { id: "", name: "---Select---" },
//     { id: "1", name: "Missing pages" },
//     { id: "2", name: "Illegible/blur" },
//     { id: "3", name: "Not applicable" },
//   ];

//   const [status, setStatus] = useState("");
//   const [reason, setReason] = useState("");
//   const [comments, setComments] = useState("");

//   useEffect(() => {
//     setTab("passport");
//     const currentStatus =
//       det?.dtlStatus ?? det?.status ?? row?.master?.status ?? "";
//     setStatus(String(currentStatus || ""));
//     setReason(
//       String(det?.reason_id ?? det?.reason ?? row?.master?.reason ?? "")
//     );
//     setComments(
//       String(
//         det?.comments ??
//           det?.remarks ??
//           row?.master?.comments ??
//           row?.master?.remarks ??
//           ""
//       )
//     );
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [row]);

//   function buildDocUrl(fileName) {
//     if (!fileName) return "";
//     if (!authData?.session_id || !authData?.document_key) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.document_key}_${fileName}`;
//   }

//   const requestId = String(row ? getReqId(row.master) ?? "" : "");

//   function pickDocName(which) {
//     const list = Array.isArray(documents) ? documents : [];
//     const hit =
//       list.find(
//         (d) =>
//           String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId &&
//           (which === "passport"
//             ? /pass|pp/i.test(String(d?.doc_name ?? d?.file_name ?? ""))
//             : /nulla|osta|no/i.test(String(d?.doc_name ?? d?.file_name ?? "")))
//       ) ||
//       list.find(
//         (d) => String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId
//       );

//     return hit?.file_name ?? hit?.doc_name ?? null;
//   }

//   const passportFile = pickDocName("passport");
//   const nullaFile = pickDocName("nulla");
//   const activeDocUrl =
//     tab === "passport"
//       ? buildDocUrl(passportFile)
//       : tab === "nulla"
//       ? buildDocUrl(nullaFile)
//       : "";

//   const passportHistory = row?.master?.pp_history || [];
//   const nullaHistory = row?.master?.nulla_history || [];

//   function handleSave() {
//     if (!canEditRight) return;
//     // TODO: wire to your update API
//     alert("Saved (stub). Wire this to your update API.");
//   }

//   const wrapStyle = {
//     display: "grid",
//     gridTemplateColumns: "1fr 430px",
//     gap: "16px",
//     minHeight: "65vh",
//   };
//   const leftStyle = {
//     overflow: "hidden",
//     borderRight: "1px solid #eee",
//     paddingRight: 8,
//   };
//   const rightStyle = {
//     borderLeft: "1px solid #eee",
//     paddingLeft: 16,
//     paddingRight: 8,
//     overflowY: "auto",
//   };

//   const tabButton = (id, label) => (
//     <button
//       key={id}
//       className={`btn ${tab === id ? "text-white" : ""}`}
//       style={{
//         backgroundColor: tab === id ? "#f26722" : "#f6e6df",
//         marginRight: 8,
//       }}
//       onClick={() => setTab(id)}
//     >
//       {label}
//     </button>
//   );

//   return (
//     <Modal show={show} onHide={onClose} backdrop="static" size="xl" centered>
//       <Modal.Header closeButton>
//         <Modal.Title>Reference ID - {requestId || "-"}</Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="mb-3">
//           {tabButton("passport", "Passport Document")}
//           {tabButton("nulla", "Nulla Osta Document")}
//           {tabButton("history", "Document History")}
//         </div>

//         <div style={wrapStyle}>
//           {/* LEFT */}
//           <div style={leftStyle}>
//             {tab !== "history" ? (
//               <div
//                 style={{
//                   height: "55vh",
//                   border: "1px solid #ddd",
//                   borderRadius: 6,
//                   overflow: "hidden",
//                   background: "#fff",
//                 }}
//               >
//                 {activeDocUrl ? (
//                   <iframe
//                     title="document-preview"
//                     src={activeDocUrl}
//                     style={{ width: "100%", height: "100%", border: 0 }}
//                   />
//                 ) : (
//                   <div className="p-3">File not found or inaccessible!</div>
//                 )}
//               </div>
//             ) : (
//               <div className="table-responsive">
//                 {/* Passport history */}
//                 <div className="mt-2">
//                   <div className="fw-semibold mb-2">Passport :{passportNo}</div>
//                   <table className="table table-bordered">
//                     <thead className="table-active">
//                       <tr>
//                         <th>#</th>
//                         <th>Action</th>
//                         <th>Actioned By</th>
//                         <th>Actioned On</th>
//                         <th>Uploaded Passport</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {passportHistory.length === 0 ? (
//                         <tr>
//                           <td colSpan={5} className="text-muted">
//                             —
//                           </td>
//                         </tr>
//                       ) : (
//                         passportHistory.map((h, i) => (
//                           <tr key={i}>
//                             <td>{i + 1}</td>
//                             <td>{h.action || "-"}</td>
//                             <td>{h.user || "-"}</td>
//                             <td>{toISTString(h.time) || "-"}</td>
//                             <td>{h.file || "-"}</td>
//                           </tr>
//                         ))
//                       )}
//                     </tbody>
//                   </table>
//                 </div>

//                 {/* Nulla history */}
//                 <div className="mt-3">
//                   <div className="fw-semibold mb-2">
//                     Nulla Osta No:{nullaOstaNo}
//                   </div>
//                   <table className="table table-bordered">
//                     <thead className="table-active">
//                       <tr>
//                         <th>#</th>
//                         <th>Action</th>
//                         <th>Actioned By</th>
//                         <th>Actioned On</th>
//                         <th>Uploaded Nulla Osta</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {nullaHistory.length === 0 ? (
//                         <tr>
//                           <td colSpan={5} className="text-muted">
//                             —
//                           </td>
//                         </tr>
//                       ) : (
//                         nullaHistory.map((h, i) => (
//                           <tr key={i}>
//                             <td>{i + 1}</td>
//                             <td>{h.action || "-"}</td>
//                             <td>{h.user || "-"}</td>
//                             <td>{toISTString(h.time) || "-"}</td>
//                             <td>{h.file || "-"}</td>
//                           </tr>
//                         ))
//                       )}
//                     </tbody>
//                   </table>
//                 </div>
//               </div>
//             )}
//           </div>

//           {/* RIGHT */}
//           <div style={rightStyle}>
//             <div className="fw-semibold mb-3">Customer Details :</div>

//             <div className="mb-3 d-flex justify-content-between">
//               <div className="text-muted">Issue Date</div>
//               <div className="fw-semibold">{issueDate || "-"}</div>
//             </div>

//             <div className="mb-3 d-flex justify-content-between">
//               <div className="text-muted">Submited On</div>
//               <div className="fw-semibold">
//                 {toISTString(submittedOn) || "-"}
//               </div>
//             </div>

//             <div className="mb-3 d-flex justify-content-between">
//               <div className="text-muted">VAC</div>
//               <div className="fw-semibold">{vacName}</div>
//             </div>

//             <div className="mb-3 d-flex justify-content-between">
//               <div className="text-muted">Full Name</div>
//               <div className="fw-semibold">{fullName || "-"}</div>
//             </div>
//             <div className="mb-3 d-flex justify-content-between">
//               <div className="text-muted">Email Id</div>
//               <div className="fw-semibold">{email || "-"}</div>
//             </div>
//             <div className="mb-3 d-flex justify-content-between">
//               <div className="text-muted">Passport Number</div>
//               <div className="fw-semibold">{passportNo || "-"}</div>
//             </div>
//             <div className="mb-3 d-flex justify-content-between">
//               <div className="text-muted">Nulla Osta No</div>
//               <div className="fw-semibold">{nullaOstaNo || "-"}</div>
//             </div>
//             <div className="mb-3 d-flex justify-content-between">
//               <div className="text-muted">DOB</div>
//               <div className="fw-semibold">{dob || "-"}</div>
//             </div>

//             <div className="mb-3">
//               <div className="text-muted mb-1">Status</div>
//               <select
//                 className="form-select"
//                 disabled={!canEditRight}
//                 value={status}
//                 onChange={(e) => setStatus(e.target.value)}
//               >
//                 <option value="">---Select---</option>
//                 {statusList.map((s) => (
//                   <option key={s.request_status_id} value={s.request_status_id}>
//                     {s.request_status_name}
//                   </option>
//                 ))}
//               </select>
//             </div>

//             <div className="mb-3">
//               <div className="text-muted mb-1">Reason</div>
//               <select
//                 className="form-select"
//                 disabled={!canEditRight}
//                 value={reason}
//                 onChange={(e) => setReason(e.target.value)}
//               >
//                 {reasonList.map((r) => (
//                   <option key={r.id} value={r.id}>
//                     {r.name}
//                   </option>
//                 ))}
//               </select>
//             </div>

//             <div className="mb-3">
//               <div className="text-muted mb-1">Comments :</div>
//               <textarea
//                 className="form-control"
//                 rows={6}
//                 disabled={!canEditRight}
//                 value={comments}
//                 onChange={(e) => setComments(e.target.value)}
//                 placeholder={canEditRight ? "" : "Read only"}
//               />
//             </div>

//             {canEditRight && (
//               <div className="text-end">
//                 <button
//                   className="btn text-white"
//                   style={{ backgroundColor: "#f26722" }}
//                   onClick={handleSave}
//                 >
//                   Save
//                 </button>
//               </div>
//             )}
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* ========================== Main ========================== */
// export default function CaseList() {
//   const { authData } = useAuth();

//   // Filters (all optional)
//   const [keyword, setKeyword] = useState("");
//   const [keyType, setKeyType] = useState("0");
//   const [dateType, setDateType] = useState("0");
//   const [vac, setVac] = useState("");
//   const [status, setStatus] = useState("0");
//   const [priority, setPriority] = useState("-1");

//   const [fromDate, setFromDate] = useState(null);
//   const [toDate, setToDate] = useState(null);

//   // Data/page
//   const [rows, setRows] = useState([]); // [{master, details[]}]
//   const [total, setTotal] = useState(0);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [expanded, setExpanded] = useState(null);
//   const [loading, setLoading] = useState(false);

//   // Modal
//   const [show, setShow] = useState(false);
//   const [activeRow, setActiveRow] = useState(null);
//   const [documents, setDocuments] = useState([]); // for modal

//   const minDate = useMemo(() => new Date("2000-01-01"), []);
//   const maxDate = useMemo(() => new Date(), []);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const statusOptions = authData?.ajaxPayload?.master_status_list || [];

//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";

//   const getStatusName = (id) =>
//     statusOptions.find((s) => String(s.request_status_id) === String(id))
//       ?.request_status_name ||
//     id ||
//     "-";

//   const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
//   const onView = (row) => {
//     setActiveRow(row);
//     setShow(true);
//   };

//   function validateFilters() {
//     // Only rule: if keyword typed, keyType must be selected
//     if (keyword.trim() && +keyType === 0)
//       return { ok: false, msg: "Choose a Keyword type." };
//     return { ok: true };
//   }

//   // Build API payload (legacy-compatible) — all filters optional
//   function buildPayload(page = 1) {
//     let pKeyType = keyType,
//       pKeyword = keyword,
//       pDateType = dateType,
//       pVac = vac,
//       pStatus = status,
//       pPri = priority;

//     // If user picked keyword+type, ignore other filters (legacy behavior)
//     if (+pKeyType > 0) {
//       pDateType = "0";
//       pVac = "0";
//       pStatus = "0";
//       pPri = "-1";
//     }

//     // If dates given but no dateType, default to "Submitted On" (2)
//     if (+pDateType === 0 && (fromDate || toDate)) {
//       pDateType = "2";
//     }

//     const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

//     return {
//       session_id: authData.session_id,
//       sessionToken: authData.session_token,
//       keyword: pKeyword.trim(),
//       keyType: pKeyType,
//       dateType: pDateType,
//       vac: pVac || "0",
//       status: pStatus,
//       from: fromDate ? fromDate.toISOString().split("T")[0] : "",
//       to: toDate ? toDate.toISOString().split("T")[0] : "",
//       priority: pPri,
//       startRecord,
//       rows: 1,
//       caseList: 1,
//       allSts: 1,
//     };
//   }

//   async function fetchPage(page = 1) {
//     setLoading(true);
//     try {
//       const res = await searchCases(buildPayload(page));
//       const { rows: normalized, total } = normalizeResponse(res);
//       setRows(normalized); // preserves master order from API
//       setTotal(total || 0);
//       setDocuments(res?.documents || []);
//       setExpanded(null);
//       setCurrentPage(page);
//     } catch (e) {
//       console.error("searchCases failed:", e);
//       setRows([]);
//       setTotal(0);
//       setExpanded(null);
//       setDocuments([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   // Auto-load on mount (no filters required)
//   useEffect(() => {
//     fetchPage(1);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const handleSearch = async () => {
//     const v = validateFilters();
//     if (!v.ok) {
//       alert(v.msg);
//       return;
//     }
//     await fetchPage(1);
//   };

//   const handlePrev = () => currentPage > 1 && fetchPage(currentPage - 1);
//   const handleNext = () => {
//     const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//     if (currentPage < totalPages) fetchPage(currentPage + 1);
//   };

//   // Export exactly what is currently in the table (no API)
//   const handleExcel = async () => {
//     try {
//       const flat = [];
//       for (const { master, details } of rows) {
//         const vacName = getVacName(master?.vac ?? master?.vac_id);
//         const statusName = getStatusName(master?.rStatus ?? master?.status);
//         const submittedOn = toISTString(
//           master?.submitOn ?? master?.submitted_on
//         );

//         const detailList = details && details.length ? details : [null];
//         for (const d of detailList) {
//           const issueDate = fmtDMY(d?.wpndt ?? d?.issue_date);
//           const dob = fmtDMY(d?.dob);
//           flat.push({
//             RequestID: getReqId(master),
//             IP: master?.IP ?? master?.ip ?? "",
//             FullName: [d?.fName ?? d?.first_name, d?.lName ?? d?.last_name]
//               .filter(Boolean)
//               .join(" "),
//             EmailId: master?.mailId ?? master?.email ?? d?.email ?? "",
//             PassportNo: d?.ppn ?? d?.passport_no ?? "",
//             NullaOstaNo: d?.wpn ?? d?.nulla_osta_no ?? "",
//             DOB: dob,
//             IssueDate: issueDate,
//             SubmitedOn: submittedOn,
//             VAC: vacName,
//             Status: statusName,
//           });
//         }
//       }
//       const ws = XLSX.utils.json_to_sheet(flat);
//       const wb = XLSX.utils.book_new();
//       XLSX.utils.book_append_sheet(wb, ws, "Cases");
//       XLSX.writeFile(wb, "Cases.xlsx");
//     } catch (e) {
//       console.error("excel export failed:", e);
//       alert("Excel export failed.");
//     }
//   };

//   return (
//     <AjaxValidation>
//       {/* Filters */}
//       <div className="box_card mb-3">
//         <div className="main_agent_form d-flex align-items-center flex-wrap">
//           <div className="one">
//             <input
//               className="form-control"
//               placeholder="Search Text"
//               value={keyword}
//               onChange={(e) => setKeyword(e.target.value)}
//             />
//           </div>

//           <div className="one">
//             <select
//               className="form-select form-control"
//               value={keyType}
//               onChange={(e) => setKeyType(e.target.value)}
//             >
//               <option value="0">---Keyword---</option>
//               <option value="1">Email Id</option>
//               <option value="2">Nulla Osta Reference Number</option>
//               <option value="3">Passport Number</option>
//               <option value="4">Mobile Number</option>
//               <option value="5">Request Id</option>
//               <option value="6">Name</option>
//             </select>
//           </div>

//           <div className="one">
//             <div className="input-group">
//               <DatePicker
//                 selected={fromDate}
//                 onChange={(d) => setFromDate(d)}
//                 className="form-control"
//                 placeholderText="From Date"
//                 dateFormat="yyyy-MM-dd"
//                 minDate={minDate}
//                 maxDate={maxDate}
//               />
//               <span className="input-group-text">
//                 <BsCalendar2Check />
//               </span>
//             </div>
//           </div>

//           <div className="one">
//             <div className="input-group">
//               <DatePicker
//                 selected={toDate}
//                 onChange={(d) => setToDate(d)}
//                 className="form-control"
//                 placeholderText="To Date"
//                 dateFormat="yyyy-MM-dd"
//                 minDate={minDate}
//                 maxDate={maxDate}
//               />
//               <span className="input-group-text">
//                 <BsCalendar2Check />
//               </span>
//             </div>
//           </div>

//           <div className="one">
//             <select
//               className="form-select form-control"
//               value={dateType}
//               onChange={(e) => setDateType(e.target.value)}
//             >
//               <option value="0">--Date Type--</option>
//               <option value="1">Added On</option>
//               <option value="2">Submitted On</option>
//             </select>
//           </div>

//           <div className="one">
//             <select
//               className="form-select form-control"
//               value={vac}
//               onChange={(e) => setVac(e.target.value)}
//             >
//               <option value="0">---Select VAC---</option>
//               {vacOptions.map((v) => (
//                 <option key={v.vac_id} value={v.vac_id}>
//                   {v.vac_name}
//                 </option>
//               ))}
//             </select>
//           </div>

//           <div className="one">
//             <select
//               className="form-select form-control"
//               value={status}
//               onChange={(e) => setStatus(e.target.value)}
//             >
//               <option value="0">---Select---</option>
//               {statusOptions
//                 .filter((s) => Number(s.request_status_id) > 1)
//                 .map((s) => (
//                   <option key={s.request_status_id} value={s.request_status_id}>
//                     {s.request_status_name}
//                   </option>
//                 ))}
//             </select>
//           </div>

//           <div className="one">
//             <select
//               className="form-select form-control"
//               value={priority}
//               onChange={(e) => setPriority(e.target.value)}
//             >
//               <option value="-1">---Priority---</option>
//               <option value="0">Normal</option>
//               <option value="1">Priority</option>
//             </select>
//           </div>

//           <div className="one">
//             <button
//               className="btn text-white"
//               style={{ backgroundColor: "#f26722" }}
//               onClick={handleSearch}
//             >
//               Search
//             </button>
//           </div>

//           <div className="ms-2">
//             <button
//               className="btn p-0"
//               style={{ background: "transparent" }}
//               onClick={handleExcel}
//               title="Export current table to Excel"
//             >
//               <img src={excel} alt="Excel" style={{ width: "32px" }} />
//             </button>
//           </div>
//         </div>
//       </div>

//       {/* Results */}
//       <div className="box_card">
//         <div className="table-responsive table-container">
//           {loading ? (
//             <div className="p-3 text-center">
//               {" "}
//               {loading && (
//                 <div
//                   style={{
//                     position: "fixed",
//                     inset: 0,
//                     background: "rgba(0,0,0,0.35)",
//                     zIndex: 1050,
//                     display: "grid",
//                     placeItems: "center",
//                   }}
//                 >
//                   <div className="spinner-border text-light" role="status" />
//                 </div>
//               )}
//             </div>
//           ) : rows.length === 0 ? (
//             <div className="p-3 text-center text-muted">No records found.</div>
//           ) : (
//             rows.map(({ master, details }, idx) => {
//               const rid = getReqId(master) ?? String(idx);
//               const addedOn = toISTString(master?.addOn ?? master?.added_on);
//               const submittedOn = toISTString(
//                 master?.submitOn ?? master?.submitted_on
//               );
//               const pr =
//                 master?.priority === 1 || master?.priority === "1"
//                   ? "Priority"
//                   : "Normal";
//               const vacName = getVacName(master?.vac ?? master?.vac_id);
//               const statusName = getStatusName(
//                 master?.rStatus ?? master?.status
//               );

//               return (
//                 <div key={rid} className="border">
//                   {/* master row */}
//                   <table className="table table-bordered mb-0">
//                     <thead className="main_heading_table">
//                       <tr>
//                         <th>{(currentPage - 1) * ITEMS_PER_PAGE + idx + 1}</th>
//                         <th>Request ID :</th>
//                         <th className={pr === "Priority" ? "priClr" : ""}>
//                           {rid}
//                         </th>
//                         <th>IP :</th>
//                         <th>{master?.IP ?? master?.ip ?? "-"}</th>
//                         <th>Added On :</th>
//                         <th>{addedOn || "-"}</th>
//                         <th>Submitted On :</th>
//                         <th>{submittedOn || "-"}</th>
//                         <th>No. Of Applicants :</th>
//                         <th>
//                           {master?.noOfUsr ?? master?.no_of_applicants ?? "-"}
//                         </th>
//                         <th>VAC :</th>
//                         <th>{vacName}</th>
//                         <th>Priority :</th>
//                         <th>{pr}</th>
//                         <th>Status :</th>
//                         <th>{statusName}</th>
//                         <th>
//                           <button
//                             className="btn-theam-filter"
//                             onClick={() => toggleExpand(String(rid))}
//                             title="Expand"
//                           >
//                             {expanded === String(rid) ? "▲" : "▼"}
//                           </button>
//                         </th>
//                       </tr>
//                     </thead>
//                   </table>

//                   {/* details table */}
//                   {expanded === String(rid) && (
//                     <table className="table table-bordered table-hover">
//                       <thead className="table-active">
//                         <tr>
//                           <th>Full Name</th>
//                           <th>Email Id</th>
//                           <th>Passport Number</th>
//                           <th>Nulla osta No</th>
//                           <th>DOB</th>
//                           <th>Issue Date</th>
//                           <th>Submitted On</th>
//                           <th>VAC</th>
//                           <th>Appointment On</th>
//                           <th>Status</th>
//                           <th>Action</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {(() => {
//                           const list = Array.isArray(details)
//                             ? details
//                             : details && typeof details === "object"
//                             ? Object.values(details)
//                             : [];

//                           if (list.length === 0) {
//                             return (
//                               <tr>
//                                 <td
//                                   colSpan={11}
//                                   className="text-center text-muted"
//                                 >
//                                   No details available for this request.
//                                 </td>
//                               </tr>
//                             );
//                           }

//                           return list.map((d, i) => {
//                             const fullName = [
//                               d?.fName ??
//                                 d?.first_name ??
//                                 d?.full_name?.split(" ")?.[0],
//                               d?.lName ??
//                                 d?.last_name ??
//                                 (d?.full_name
//                                   ? d.full_name.split(" ").slice(1).join(" ")
//                                   : null),
//                             ]
//                               .filter(Boolean)
//                               .join(" ");

//                             return (
//                               <tr key={`${rid}-detail-${i}`}>
//                                 <td>{fullName || "-"}</td>
//                                 <td>
//                                   {master?.mailId ??
//                                     master?.email ??
//                                     d?.email ??
//                                     "-"}
//                                 </td>
//                                 <td>{d?.ppn ?? d?.passport_no ?? "-"}</td>
//                                 <td>{d?.wpn ?? d?.nulla_osta_no ?? "-"}</td>
//                                 <td>{fmtDMY(d?.dob) || "-"}</td>
//                                 <td>
//                                   {fmtDMY(d?.wpndt ?? d?.issue_date) || "-"}
//                                 </td>
//                                 <td>{submittedOn || "-"}</td>
//                                 <td>
//                                   {getVacName(
//                                     d?.vac ?? master?.vac ?? master?.vac_id
//                                   )}
//                                 </td>
//                                 <td>
//                                   {toISTString(
//                                     d?.slotAt ?? d?.appointment_on
//                                   ) || "-"}
//                                 </td>
//                                 <td>
//                                   {getStatusName(
//                                     d?.dtlStatus ?? d?.status ?? master?.status
//                                   )}
//                                 </td>
//                                 <td>
//                                   <button
//                                     className="btnlink"
//                                     onClick={() =>
//                                       onView({ master, detail: d })
//                                     }
//                                   >
//                                     View
//                                   </button>
//                                 </td>
//                               </tr>
//                             );
//                           });
//                         })()}
//                       </tbody>
//                     </table>
//                   )}
//                 </div>
//               );
//             })
//           )}
//         </div>

//         {/* Pagination */}
//         {total > 0 && (
//           <div className="pagination d-flex align-items-center gap-2 p-2">
//             <p className="m-0">
//               Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1} to{" "}
//               {Math.min(currentPage * ITEMS_PER_PAGE, total)} of {total}
//             </p>
//             <button
//               id="btnPrevious"
//               className={`btn btn-sm ${currentPage === 1 ? "disabled" : ""}`}
//               onClick={handlePrev}
//             >
//               Previous
//             </button>
//             {Array.from(
//               { length: Math.max(1, Math.ceil(total / ITEMS_PER_PAGE)) },
//               (_, i) => (
//                 <button
//                   key={i + 1}
//                   id={`btn${i + 1}`}
//                   className={`btn btn-sm ${
//                     currentPage === i + 1 ? "active" : ""
//                   }`}
//                   onClick={() => fetchPage(i + 1)}
//                 >
//                   {i + 1}
//                 </button>
//               )
//             )}
//             <button
//               id="btnNext"
//               className={`btn btn-sm ${
//                 currentPage === Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
//                   ? "disabled"
//                   : ""
//               }`}
//               onClick={handleNext}
//             >
//               Next
//             </button>
//           </div>
//         )}
//       </div>

//       {/* The modal (force remount on row change to avoid stale state) */}
//       {show && activeRow && (
//         <CaseModal
//           key={String(getReqId(activeRow?.master))}
//           show={show}
//           onClose={() => setShow(false)}
//           row={activeRow}
//           documents={documents}
//           authData={authData}
//           statusOptions={statusOptions}
//         />
//       )}
//     </AjaxValidation>
//   );
// }

import React, { useMemo, useState, useEffect } from "react";
import Modal from "react-bootstrap/Modal";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { BsCalendar2Check } from "react-icons/bs";
import { FaEdit } from "react-icons/fa";
import AjaxValidation from "../hooks/AjaxValidation";
import { searchCases } from "../api/client";
import { useAuth } from "../context/AuthContext";
import * as XLSX from "xlsx";
import excel from "../assets/excel.png";

/* ===== Constants ===== */
const ITEMS_PER_PAGE = 10;

/* ===== Utils (unchanged) ===== */
function toISTString(dateLike) {
  if (!dateLike) return "";
  if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
  const d = new Date(dateLike);
  if (Number.isNaN(d.getTime())) return "";
  const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
  const ist = new Date(istMs);
  const dd = String(ist.getDate()).padStart(2, "0");
  const mm = String(ist.getMonth() + 1).padStart(2, "0");
  const yyyy = ist.getFullYear();
  const hh = String(ist.getHours()).padStart(2, "0");
  const mi = String(ist.getMinutes()).padStart(2, "0");
  return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
}
function fmtDMY(dateLike) {
  if (!dateLike) return "";
  if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
  const d = new Date(dateLike);
  if (Number.isNaN(d.getTime())) return "";
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}
function getReqId(obj) {
  return (
    obj?.reqId ??
    obj?.request_id ??
    obj?.req_id ??
    obj?.reqid ??
    obj?.requestId ??
    obj?.reqIdFk ??
    obj?.reqid_fk ??
    null
  );
}
/** Accepts raw API response and returns { rows:[{master,details[]}], total } */
function normalizeResponse(res) {
  if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
    const byReq = res.details.reduce((acc, d) => {
      const k = String(getReqId(d) ?? "");
      (acc[k] ||= []).push(d);
      return acc;
    }, {});
    const rows = res.master.map((m) => {
      const mk = String(getReqId(m) ?? "");
      return { master: m, details: byReq[mk] || [] };
    });
    return {
      rows,
      total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
    };
  }
  if (Array.isArray(res)) {
    const rows = res.map((m) => ({ master: m, details: m.details || [] }));
    return { rows, total: rows.length };
  }
  if (res && Array.isArray(res.master)) {
    const rows = res.master.map((m) => ({
      master: m,
      details: m.details || [],
    }));
    return {
      rows,
      total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
    };
  }
  if (res && Array.isArray(res.data)) {
    const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
    return { rows, total: rows.length };
  }
  return { rows: [], total: 0 };
}

/* ========================== Modal (UI-only updates) ========================== */
function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
  const roleId = Number(authData?.role_id);
  const canEditRight = roleId == 2;

  const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

  const det =
    row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};

  const fullName = [
    det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
    det?.lName ??
      det?.last_name ??
      (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
  ]
    .filter(Boolean)
    .join(" ");

  const email =
    row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";

  const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
  const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";

  const dob = fmtDMY(det?.dob);
  const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);

  const submittedOn =
    row?.master?.submitOn ??
    row?.master?.submitted_on ??
    det?.submitted_on ??
    "";

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const getVacName = (id) =>
    vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
    id ||
    "-";

  const vacName = getVacName(
    det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
  );

  const statusList =
    (statusOptions && statusOptions.length
      ? statusOptions
      : authData?.ajaxPayload?.master_status_list) || [];

  const reasonList = authData?.ajaxPayload?.reason_list || [
    { id: "", name: "---Select---" },
    { id: "1", name: "Missing pages" },
    { id: "2", name: "Illegible/blur" },
    { id: "3", name: "Not applicable" },
  ];

  const [status, setStatus] = useState("");
  const [reason, setReason] = useState("");
  const [comments, setComments] = useState("");

  useEffect(() => {
    setTab("passport");
    const currentStatus =
      det?.dtlStatus ?? det?.status ?? row?.master?.status ?? "";
    setStatus(String(currentStatus || ""));
    setReason(
      String(det?.reason_id ?? det?.reason ?? row?.master?.reason ?? "")
    );
    setComments(
      String(
        det?.comments ??
          det?.remarks ??
          row?.master?.comments ??
          row?.master?.remarks ??
          ""
      )
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [row]);

  function buildDocUrl(fileName) {
    if (!fileName) return "";
    if (!authData?.session_id || !authData?.document_key) return "";
    return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.document_key}_${fileName}`;
  }

  const requestId = String(row ? getReqId(row.master) ?? "" : "");

  function pickDocName(which) {
    const list = Array.isArray(documents) ? documents : [];
    const hit =
      list.find(
        (d) =>
          String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId &&
          (which === "passport"
            ? /pass|pp/i.test(String(d?.doc_name ?? d?.file_name ?? ""))
            : /nulla|osta|no/i.test(String(d?.doc_name ?? d?.file_name ?? "")))
      ) ||
      list.find(
        (d) => String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId
      );

    return hit?.file_name ?? hit?.doc_name ?? null;
  }

  const passportFile = pickDocName("passport");
  const nullaFile = pickDocName("nulla");
  const activeDocUrl =
    tab === "passport"
      ? buildDocUrl(passportFile)
      : tab === "nulla"
      ? buildDocUrl(nullaFile)
      : "";

  const passportHistory = row?.master?.pp_history || [];
  const nullaHistory = row?.master?.nulla_history || [];

  function handleSave() {
    if (!canEditRight) return;
    // TODO: connect to your update endpoint
    alert("Saved (stub). Wire this to your update API.");
  }

  return (
    <Modal
      show={show}
      onHide={onClose}
      backdrop="static"
      keyboard={false}
      className="newcase_modal-dialog"
      size="xl"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title>
          <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="model_dialog_list">
          <div className="row">
            {/* LEFT */}
            <div className="col-sm-8 border-right">
              {/* tab buttons styled similar to your palette */}
              <div className="mb-3 d-flex gap-1">
                <button
                  className={`btn ${tab === "passport" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
                    fontSize: "0.8rem",
                  }}
                  onClick={() => setTab("passport")}
                >
                  Passport Document
                </button>
                <button
                  className={`btn ${tab === "nulla" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
                    fontSize: "0.8rem",
                  }}
                  onClick={() => setTab("nulla")}
                >
                  Nulla Osta Document
                </button>
                <button
                  className={`btn ${tab === "history" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
                    fontSize: "0.8rem",
                  }}
                  onClick={() => setTab("history")}
                >
                  Document History
                </button>
              </div>

              {tab !== "history" ? (
                <div
                  style={{
                    height: "55vh",
                    border: "1px solid #ddd",
                    borderRadius: 6,
                    overflow: "hidden",
                    background: "#fff",
                  }}
                >
                  {activeDocUrl ? (
                    <iframe
                      title="document-preview"
                      src={activeDocUrl}
                      style={{ width: "100%", height: "100%", border: 0 }}
                    />
                  ) : (
                    <div className="p-3">File not found or inaccessible!</div>
                  )}
                </div>
              ) : (
                <div className="table-responsive">
                  {/* Passport history */}
                  <div className="mt-2">
                    <div className="fw-semibold mb-2">
                      Passport :{passportNo}
                    </div>
                    <table className="table table-bordered">
                      <thead className="table-active">
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Actioned By</th>
                          <th>Actioned On</th>
                          <th>Uploaded Passport</th>
                        </tr>
                      </thead>
                      <tbody>
                        {passportHistory.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-muted">
                              —
                            </td>
                          </tr>
                        ) : (
                          passportHistory.map((h, i) => (
                            <tr key={i}>
                              <td>{i + 1}</td>
                              <td>{h.action || "-"}</td>
                              <td>{h.user || "-"}</td>
                              <td>{toISTString(h.time) || "-"}</td>
                              <td>{h.file || "-"}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Nulla history */}
                  <div className="mt-3">
                    <div className="fw-semibold mb-2">
                      Nulla Osta No:{nullaOstaNo}
                    </div>
                    <table className="table table-bordered">
                      <thead className="table-active">
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Actioned By</th>
                          <th>Actioned On</th>
                          <th>Uploaded Nulla Osta</th>
                        </tr>
                      </thead>
                      <tbody>
                        {nullaHistory.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-muted">
                              —
                            </td>
                          </tr>
                        ) : (
                          nullaHistory.map((h, i) => (
                            <tr key={i}>
                              <td>{i + 1}</td>
                              <td>{h.action || "-"}</td>
                              <td>{h.user || "-"}</td>
                              <td>{toISTString(h.time) || "-"}</td>
                              <td>{h.file || "-"}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* RIGHT */}
            <div className="col-sm-4">
              <div className="accordion-body">
                <div className="form-group row">
                  <div className="col-sm-12">
                    <h6 className="modal-title mb-2">Customer Details :</h6>
                  </div>
                </div>

                <div className="newcase-container">
                  {/* pairs */}
                  {[
                    ["Issue Date", issueDate || "-"],
                    ["Submited On", toISTString(submittedOn) || "-"],
                    ["VAC", vacName],
                    ["Full Name", fullName || "-"],
                    ["Email Id", email || "-"],
                    ["Passport Number", passportNo || "-"],
                    ["Nulla osta No", nullaOstaNo || "-"],
                    ["DOB", dob || "-"],
                  ].map(([l, v], i) => (
                    <div className="form-group row border-bottom" key={i}>
                      <div className="col-sm-6">
                        <label className="form-label">{l}</label>
                      </div>
                      <div className="col-sm-6">
                        <label className="form-label">{v}</label>
                      </div>
                    </div>
                  ))}

                  {/* Status */}
                  <div className="form-group row border-bottom mb-2">
                    <div className="col-sm-6">
                      <label className="form-label">Status</label>
                    </div>
                    <div className="col-sm-6">
                      <select
                        className="form-select form-control"
                        disabled={!canEditRight}
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                      >
                        <option value="">---Select---</option>
                        {statusList.map((s) => (
                          <option
                            key={s.request_status_id}
                            value={s.request_status_id}
                          >
                            {s.request_status_name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Reason */}
                  <div className="form-group row border-bottom">
                    <div className="col-sm-6">
                      <label className="form-label">Reason</label>
                    </div>
                    <div className="col-sm-6">
                      <select
                        className="form-select form-control"
                        disabled={!canEditRight}
                        value={reason}
                        onChange={(e) => setReason(e.target.value)}
                      >
                        {reasonList.map((r) => (
                          <option key={r.id} value={r.id}>
                            {r.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Comments */}
                  <div className="form-group row border-bottom">
                    <div className="col-sm-12">
                      <label className="form-label">Comments</label>
                      <textarea
                        className="form-control"
                        rows={5}
                        value={comments}
                        onChange={(e) => setComments(e.target.value)}
                        disabled={!canEditRight}
                      />
                    </div>
                  </div>

                  {canEditRight && (
                    <div className="form-group row mt-3">
                      <div className="col-sm-6" />
                      <div className="col-sm-6">
                        <button
                          type="button"
                          className="btn login-btn w-100"
                          style={{ background: "#f26722", color: "#fff" }}
                          onClick={handleSave}
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

/* ========================== Main (logic unchanged, UI updated) ========================== */
export default function CaseList() {
  const { authData } = useAuth();

  // Filters
  const [keyword, setKeyword] = useState("");
  const [keyType, setKeyType] = useState("0");
  const [dateType, setDateType] = useState("0");
  const [vac, setVac] = useState("");
  const [status, setStatus] = useState("0");
  const [priority, setPriority] = useState("-1");

  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);

  // Data/page
  const [rows, setRows] = useState([]); // [{master, details[]}]
  const [total, setTotal] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [expanded, setExpanded] = useState(null);
  const [loading, setLoading] = useState(false);

  // Modal
  const [show, setShow] = useState(false);
  const [activeRow, setActiveRow] = useState(null);
  const [documents, setDocuments] = useState([]);

  const minDate = useMemo(() => new Date("2000-01-01"), []);
  const maxDate = useMemo(() => new Date(), []);

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const statusOptions = authData?.ajaxPayload?.master_status_list || [];

  const getVacName = (id) =>
    vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
    id ||
    "-";
  const getStatusName = (id) =>
    statusOptions.find((s) => String(s.request_status_id) === String(id))
      ?.request_status_name ||
    id ||
    "-";

  const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
  const onView = (row) => {
    setActiveRow(row);
    setShow(true);
  };

  function validateFilters() {
    if (keyword.trim() && +keyType === 0)
      return { ok: false, msg: "Choose a Keyword type." };
    return { ok: true };
  }

  function buildPayload(page = 1) {
    let pKeyType = keyType,
      pKeyword = keyword,
      pDateType = dateType,
      pVac = vac,
      pStatus = status,
      pPri = priority;

    if (+pKeyType > 0) {
      pDateType = "0";
      pVac = "0";
      pStatus = "0";
      pPri = "-1";
    }
    if (+pDateType === 0 && (fromDate || toDate)) {
      pDateType = "2";
    }
    const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

    return {
      session_id: authData.session_id,
      sessionToken: authData.session_token,
      keyword: pKeyword.trim(),
      keyType: pKeyType,
      dateType: pDateType,
      vac: pVac || "0",
      status: pStatus,
      from: fromDate ? fromDate.toISOString().split("T")[0] : "",
      to: toDate ? toDate.toISOString().split("T")[0] : "",
      priority: pPri,
      startRecord,
      rows: 1,
      caseList: 1,
      allSts: 1,
    };
  }

  async function fetchPage(page = 1) {
    setLoading(true);
    try {
      const res = await searchCases(buildPayload(page));
      const { rows: normalized, total } = normalizeResponse(res);
      setRows(normalized);
      setTotal(total || 0);
      setDocuments(res?.documents || []);
      setExpanded(null);
      setCurrentPage(page);
    } catch (e) {
      console.error("searchCases failed:", e);
      setRows([]);
      setTotal(0);
      setExpanded(null);
      setDocuments([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchPage(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSearch = async () => {
    const v = validateFilters();
    if (!v.ok) {
      alert(v.msg);
      return;
    }
    await fetchPage(1);
  };
  const handlePrev = () => currentPage > 1 && fetchPage(currentPage - 1);
  const handleNext = () => {
    const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
    if (currentPage < totalPages) fetchPage(currentPage + 1);
  };

  const handleExcel = async () => {
    try {
      const flat = [];
      for (const { master, details } of rows) {
        const vacName = getVacName(master?.vac ?? master?.vac_id);
        const statusName = getStatusName(master?.rStatus ?? master?.status);
        const submittedOn = toISTString(
          master?.submitOn ?? master?.submitted_on
        );
        const detailList = details && details.length ? details : [null];
        for (const d of detailList) {
          const issueDate = fmtDMY(d?.wpndt ?? d?.issue_date);
          const dob = fmtDMY(d?.dob);
          flat.push({
            RequestID: getReqId(master),
            IP: master?.IP ?? master?.ip ?? "",
            FullName: [d?.fName ?? d?.first_name, d?.lName ?? d?.last_name]
              .filter(Boolean)
              .join(" "),
            EmailId: master?.mailId ?? master?.email ?? d?.email ?? "",
            PassportNo: d?.ppn ?? d?.passport_no ?? "",
            NullaOstaNo: d?.wpn ?? d?.nulla_osta_no ?? "",
            DOB: dob,
            IssueDate: issueDate,
            SubmitedOn: submittedOn,
            VAC: vacName,
            Status: statusName,
          });
        }
      }
      const ws = XLSX.utils.json_to_sheet(flat);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Cases");
      XLSX.writeFile(wb, "Cases.xlsx");
    } catch (e) {
      console.error("excel export failed:", e);
      alert("Excel export failed.");
    }
  };
  const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
  const WINDOW = 4;

  function range(start, end) {
    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  }
  function getVisiblePages(current, total) {
    if (total <= WINDOW) return range(1, total);

    // Start: 1..4
    if (current <= WINDOW) return range(1, WINDOW);

    // End: last 4
    if (current > total - WINDOW) return range(total - WINDOW + 1, total);

    // Middle: current..current+3
    return range(current, current + WINDOW - 1);
  }

  return (
    <AjaxValidation>
      {/* Filters — NewPage layout, same bindings/logic */}
      <div className="mt-2">
        <div className="container-fluid">
          <h6>Case List</h6>

          <div class="row mt-2 mb-3">
            <div class="col-sm-12">
              <div className="box_card">
                <div className="form-group row">
                  <div className="col-sm-12">
                    <div className="main_agent_form">
                      <div className="one">
                        <input
                          className="form-control"
                          placeholder="Search"
                          value={keyword}
                          onChange={(e) => setKeyword(e.target.value)}
                        />
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={keyType}
                          onChange={(e) => setKeyType(e.target.value)}
                        >
                          <option value="0">--Keyword--</option>
                          <option value="1">Email Id</option>
                          <option value="2">Nulla Osta Reference Number</option>
                          <option value="3">Passport Number</option>
                          <option value="4">Mobile Number</option>
                          <option value="5">Request Id</option>
                          <option value="6">Name</option>
                        </select>
                      </div>
                      <div className="one">
                        <div
                          className="input-group date_pick"
                          style={{ flexWrap: "nowrap" }}
                        >
                          <DatePicker
                            selected={fromDate}
                            onChange={(d) => setFromDate(d)}
                            className="form-control border_right_radius"
                            placeholderText="From Date"
                            dateFormat="dd-MM-yyyy" /* visual only */
                            showMonthDropdown
                            showYearDropdown
                            dropdownMode="select"
                            scrollableYearDropdown
                            isClearable
                            minDate={minDate}
                            maxDate={maxDate}
                          />
                          <span className="input-group-text">
                            <BsCalendar2Check />
                          </span>
                        </div>
                      </div>
                      <div className="one">
                        <div
                          className="input-group date_pick"
                          style={{ flexWrap: "nowrap" }}
                        >
                          <DatePicker
                            selected={toDate}
                            onChange={(d) => setToDate(d)}
                            className="form-control border_right_radius"
                            placeholderText="To Date"
                            dateFormat="dd-MM-yyyy"
                            showMonthDropdown
                            showYearDropdown
                            dropdownMode="select"
                            scrollableYearDropdown
                            isClearable
                            minDate={minDate}
                            maxDate={maxDate}
                          />
                          <span className="input-group-text">
                            <BsCalendar2Check />
                          </span>
                        </div>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={dateType}
                          onChange={(e) => setDateType(e.target.value)}
                        >
                          <option value="0">--Date Type--</option>
                          <option value="1">Added On</option>
                          <option value="2">Submitted On</option>
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={dateType}
                          onChange={(e) => setDateType(e.target.value)}
                        >
                          <option value="0">--Date Type--</option>
                          <option value="1">Added On</option>
                          <option value="2">Submitted On</option>
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={vac}
                          onChange={(e) => setVac(e.target.value)}
                        >
                          <option value="0">--Select VAC--</option>
                          {vacOptions.map((v) => (
                            <option key={v.vac_id} value={v.vac_id}>
                              {v.vac_name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={status}
                          onChange={(e) => setStatus(e.target.value)}
                        >
                          <option value="0">--Select--</option>
                          {statusOptions
                            .filter((s) => Number(s.request_status_id) > 1)
                            .map((s) => (
                              <option
                                key={s.request_status_id}
                                value={s.request_status_id}
                              >
                                {s.request_status_name}
                              </option>
                            ))}
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={priority}
                          onChange={(e) => setPriority(e.target.value)}
                        >
                          <option value="-1">--Priority--</option>
                          <option value="0">Normal</option>
                          <option value="1">Priority</option>
                        </select>
                      </div>
                      <div className="one gap-2">
                        <button
                          className="btn-lg go-btn"
                          style={{ background: "#f26722", color: "#fff" }}
                          onClick={handleSearch}
                        >
                          Search
                        </button>
                        <img
                          src={excel}
                          className="common_excell_icon"
                          alt="Excel"
                          onClick={handleExcel}
                          style={{ width: "25px", cursor: "pointer" }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div class="dropdown-divider"></div>
                {/* Results */}
                <div className="">
                  <div className="table-responsive holiday-container">
                    {loading ? (
                      <div className="p-3 text-center">
                        <div
                          style={{
                            position: "fixed",
                            inset: 0,
                            background: "rgba(0,0,0,0.35)",
                            zIndex: 1050,
                            display: "grid",
                            placeItems: "center",
                          }}
                        >
                          <div
                            className="spinner-border text-light"
                            role="status"
                          />
                        </div>
                      </div>
                    ) : rows.length === 0 ? (
                      <div className="p-3 text-center text-muted">
                        No records found.
                      </div>
                    ) : (
                      rows.map(({ master, details }, idx) => {
                        const rid = getReqId(master) ?? String(idx);
                        const addedOn = toISTString(
                          master?.addOn ?? master?.added_on
                        );
                        const submittedOn = toISTString(
                          master?.submitOn ?? master?.submitted_on
                        );
                        const pr =
                          master?.priority === 1 || master?.priority === "1"
                            ? "Priority"
                            : "Normal";
                        const vacName = getVacName(
                          master?.vac ?? master?.vac_id
                        );
                        const statusName = getStatusName(
                          master?.rStatus ?? master?.status
                        );

                        return (
                          <div key={rid} className="border">
                            {/* master row */}
                            <table
                              className="table table-bordered mb-0"
                              style={{ tableLayout: "auto", width: "100%" }}
                            >
                              <thead className="main_heading_table">
                                <tr>
                                  {/* <th className="col-sn">
                                    {(currentPage - 1) * ITEMS_PER_PAGE +
                                      idx +
                                      1}
                                  </th> */}
                                  <th>Request ID :</th>
                                  <th
                                    className={
                                      pr === "Priority" ? "priClr" : "col-ad"
                                    }
                                  >
                                    {rid}
                                  </th>
                                  <th>IP :</th>
                                  <th className="col-ip">
                                    {master?.IP ?? master?.ip ?? "-"}
                                  </th>
                                  <th>Added On :</th>
                                  <th>{addedOn || "-"}</th>
                                  <th>Submitted On :</th>
                                  <th>{submittedOn || "-"}</th>
                                  <th>No. Of Applicants :</th>
                                  <th style={{ width: "60px" }}>
                                    {master?.noOfUsr ??
                                      master?.no_of_applicants ??
                                      "-"}
                                  </th>
                                  <th>VAC :</th>
                                  <th className="col-vac">
                                    <div className="d-flex gap-2 align-items-center">
                                      {vacName}
                                      <FaEdit
                                        style={{
                                          color: "green",
                                          fontSize: "0.8rem",
                                        }}
                                      />
                                    </div>
                                  </th>
                                  <th>Priority :</th>
                                  <th>{pr}</th>
                                  <th>Status :</th>
                                  <th className="col-status">{statusName}</th>
                                  <th>
                                    <button
                                      className="btn-theam-filter"
                                      onClick={() => toggleExpand(String(rid))}
                                      title="Expand"
                                    >
                                      {expanded === String(rid) ? "▲" : "▼"}
                                    </button>
                                  </th>
                                </tr>
                              </thead>
                            </table>

                            {/* detail table */}
                            {expanded === String(rid) && (
                              <table className="table table-bordered table-hover tableexpand">
                                <thead className="table-active tableexpand-head">
                                  <tr>
                                    <th>Full Name</th>
                                    <th>Email Id</th>
                                    <th>Passport Number</th>
                                    <th>Nulla osta No</th>
                                    <th>DOB</th>
                                    <th>Issue Date</th>
                                    <th>Submitted On</th>
                                    <th>VAC</th>
                                    <th>Appointment On</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {(() => {
                                    const list = Array.isArray(details)
                                      ? details
                                      : details && typeof details === "object"
                                      ? Object.values(details)
                                      : [];

                                    if (list.length === 0) {
                                      return (
                                        <tr>
                                          <td
                                            colSpan={11}
                                            className="text-center text-muted"
                                          >
                                            No details available for this
                                            request.
                                          </td>
                                        </tr>
                                      );
                                    }

                                    return list.map((d, i) => {
                                      const fullName = [
                                        d?.fName ??
                                          d?.first_name ??
                                          d?.full_name?.split(" ")?.[0],
                                        d?.lName ??
                                          d?.last_name ??
                                          (d?.full_name
                                            ? d.full_name
                                                .split(" ")
                                                .slice(1)
                                                .join(" ")
                                            : null),
                                      ]
                                        .filter(Boolean)
                                        .join(" ");

                                      return (
                                        <tr key={`${rid}-detail-${i}`}>
                                          <td>{fullName || "-"}</td>
                                          <td>
                                            {master?.mailId ??
                                              master?.email ??
                                              d?.email ??
                                              "-"}
                                          </td>
                                          <td>
                                            {d?.ppn ?? d?.passport_no ?? "-"}
                                          </td>
                                          <td>
                                            {d?.wpn ?? d?.nulla_osta_no ?? "-"}
                                          </td>
                                          <td>{fmtDMY(d?.dob) || "-"}</td>
                                          <td>
                                            {fmtDMY(
                                              d?.wpndt ?? d?.issue_date
                                            ) || "-"}
                                          </td>
                                          <td>{submittedOn || "-"}</td>
                                          <td>
                                            {getVacName(
                                              d?.vac ??
                                                master?.vac ??
                                                master?.vac_id
                                            )}
                                          </td>
                                          <td>
                                            {toISTString(
                                              d?.slotAt ?? d?.appointment_on
                                            ) || "-"}
                                          </td>
                                          <td>
                                            {getStatusName(
                                              d?.dtlStatus ??
                                                d?.status ??
                                                master?.status
                                            )}
                                          </td>
                                          <td>
                                            <button
                                              className="btnlink"
                                              onClick={() =>
                                                onView({ master, detail: d })
                                              }
                                            >
                                              View
                                            </button>
                                          </td>
                                        </tr>
                                      );
                                    });
                                  })()}
                                </tbody>
                              </table>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Pagination (unchanged) */}
                  {/* {total > 0 && (
              <div className="pagination-de">
                <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
                  <p className="m-0">
                    Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1} to{" "}
                    {Math.min(currentPage * ITEMS_PER_PAGE, total)} of {total}
                  </p>

                  <button
                    id="btnPrevious"
                    className={`btn btn-sm ${
                      currentPage === 1 ? "disabled" : ""
                    }`}
                    onClick={handlePrev}
                  >
                    Previous
                  </button>
                  {Array.from(
                    {
                      length: Math.max(1, Math.ceil(total / ITEMS_PER_PAGE)),
                    },
                    (_, i) => (
                      <button
                        key={i + 1}
                        id={`btn${i + 1}`}
                        className={`btn btn-sm ${
                          currentPage === i + 1 ? "active" : ""
                        }`}
                        onClick={() => fetchPage(i + 1)}
                      >
                        {i + 1}
                      </button>
                    )
                  )}
                  <button
                    id="btnNext"
                    className={`btn btn-sm ${
                      currentPage ===
                      Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
                        ? "disabled"
                        : ""
                    }`}
                    onClick={handleNext}
                  >
                    Next
                  </button>
                </div>
              </div>
            )} */}

                  {total > 0 && (
                    <div className="pagination-de">
                      <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
                        <button
                          id="btnPrevious"
                          className={`btn btn-sm ${
                            currentPage === 1 ? "disabled" : ""
                          }`}
                          onClick={handlePrev}
                        >
                          Previous
                        </button>

                        {(() => {
                          const pages = getVisiblePages(
                            currentPage,
                            totalPages
                          );
                          const hasLeftEllipsis = pages[0] > 1;
                          const hasRightEllipsis =
                            pages[pages.length - 1] < totalPages;

                          return (
                            <>
                              {hasLeftEllipsis && (
                                <span className="px-1">…</span>
                              )}

                              {pages.map((p) => (
                                <button
                                  key={p}
                                  id={`btn${p}`}
                                  className={`btn btn-sm ${
                                    currentPage === p ? "active" : ""
                                  }`}
                                  onClick={() => fetchPage(p)}
                                >
                                  {p}
                                </button>
                              ))}

                              {hasRightEllipsis && (
                                <span className="px-1">…</span>
                              )}
                            </>
                          );
                        })()}

                        <button
                          id="btnNext"
                          className={`btn btn-sm ${
                            currentPage === totalPages ? "disabled" : ""
                          }`}
                          onClick={handleNext}
                        >
                          Next
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal */}
      {show && activeRow && (
        <CaseModal
          key={String(getReqId(activeRow?.master))}
          show={show}
          onClose={() => setShow(false)}
          row={activeRow}
          documents={documents}
          authData={authData}
          statusOptions={statusOptions}
        />
      )}
    </AjaxValidation>
  );
}
