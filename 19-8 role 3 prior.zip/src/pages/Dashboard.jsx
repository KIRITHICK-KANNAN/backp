import React from "react";
import { useAuth } from "../context/AuthContext";
import AjaxValidation from "../hooks/AjaxValidation";
import { fetchDashboard } from "../api/client";

/* ---------- utils ---------- */
const toInt = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

export default function Dashboard() {
  const { authData } = useAuth();

  // Filters (UI state)
  const [vac, setVac] = React.useState(""); // "" -> all VACs
  const [priority, setPriority] = React.useState("0"); // "0" Normal by default

  // Data/UI
  const [rows, setRows] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const session_id = authData?.session_id || "";
  const session_token = authData?.session_token || "";
  const user_id_auth =
    authData?.user_id ?? authData?.userid ?? authData?.id ?? "";

  // Map labels to API keys
  const DEF = React.useMemo(
    () => [
      {
        label: "Pending for verification",
        key: "submit",
        ckey: "current_submit",
      },
      { label: "Rejected", key: "review", ckey: "current_review" },
      { label: "Blocked", key: "blocked", ckey: "current_blocked" },
      { label: "Re Submitted", key: "resubmit", ckey: "current_resubmit" },
      { label: "Verified", key: "verified", ckey: "current_verified" },
      {
        label: "Partially Verified",
        key: "pverified",
        ckey: "current_pverified",
      },
      { label: "Approved", key: "approved", ckey: "current_approved" },
      { label: "Declined", key: "declined", ckey: "current_declined" },
      { label: "Payment Failure", key: "pfailure", ckey: "current_pfailure" },
      {
        label: "Payment link expired",
        key: "paymentlink_expired",
        ckey: "current_paymentlink_expired",
      },
      { label: "Slot Alloted", key: "allotted", ckey: "current_allotted" },
      { label: "Paid slot not alloted", key: "paid", ckey: "current_paid" },
    ],
    []
  );

  /** Fetcher
   *  - initial=true  -> use payload you requested:
   *    { user_id:"", priority:"0", vac_id:"" }
   *  - initial=false -> use current form filters and logged-in user
   */
  const go = React.useCallback(
    async (initial = false) => {
      setLoading(true);
      setError("");

      try {
        const payload = {
          session_id,
          session_token,
          user_id: initial ? "" : user_id_auth || "", // <- empty on initial load
          priority: initial ? "0" : priority,
          vac_id: initial ? "" : vac || "",
        };

        const res = await fetchDashboard(payload);

        const totals =
          Array.isArray(res?.data) && res.data[0] ? res.data[0] : {};
        const current =
          Array.isArray(res?.current_data) && res.current_data[0]
            ? res.current_data[0]
            : {};

        const list = DEF.map((d) => ({
          label: d.label,
          value: toInt(totals[d.key]),
          current: toInt(current[d.ckey]),
        }));

        // First row sums
        const grand = list.reduce((s, r) => s + r.value, 0);
        const cgrand = list.reduce((s, r) => s + r.current, 0);

        setRows([
          {
            label: "The total number of entries received for verification",
            value: grand,
            current: cgrand,
            isTotal: true,
          },
          ...list,
        ]);
      } catch (e) {
        console.error("fetchDashboard failed:", e);
        setRows([]);
        setError(e?.message || "Failed to load dashboard.");
      } finally {
        setLoading(false);
      }
    },
    [session_id, session_token, user_id_auth, priority, vac, DEF]
  );

  // One-time initial load using the required payload
  const didInitial = React.useRef(false);
  React.useEffect(() => {
    if (!didInitial.current && session_id && session_token) {
      didInitial.current = true;
      go(true); // initial=true -> { user_id:"", priority:"0", vac_id:"" }
    }
  }, [session_id, session_token, go]);

  return (
    <AjaxValidation>
      <div className="container-fluid py-3">
        <div class="row">
          <div class="col-sm-6">
            <h6 className="m-0 pb-2">Dashboard</h6>
            <div className="box_card">
              {/*  */}
              <div className="holiday_list_status">
                <div className="holiday_list">
                  <div class="d-flex justify-content-start align-items-center gap-1">
                    <label for="" class="form-label m-0">
                      VAC
                    </label>
                    <select
                      className="form-select form-control"
                      value={vac}
                      onChange={(e) => setVac(e.target.value)}
                    >
                      <option value="">Select VAC</option>
                      {vacOptions.map((v) => (
                        <option key={v.vac_id} value={v.vac_id}>
                          {v.vac_name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="holiday_list">
                  <div class="d-flex justify-content-start align-items-center gap-2">
                    <label for="" class="form-label m-0">
                      Slot Type
                    </label>
                    <select
                      className="form-select form-control"
                      value={priority}
                      onChange={(e) => setPriority(e.target.value)}
                    >
                      <option value="0">Normal</option>
                      <option value="1">Priority</option>
                    </select>
                  </div>
                </div>
                <div className="holiday_list">
                  <button
                    className="btn-lg go-btn"
                    style={{
                      backgroundColor: "#f26722",
                      color: "#fff",
                      minWidth: 64,
                    }}
                    onClick={() => go(false)} // use current filters
                    disabled={loading}
                  >
                    Go
                  </button>
                </div>
              </div>
              {/*  */}

              <div class="dropdown-divider"></div>
              <div className="table-responsive">
                <div className="new_table_design holiday-container">
                  <table className="table table-bordered mb-0">
                    <thead className="table-light">
                      <tr>
                        <th style={{ width: 80 }}>Sr.No</th>
                        <th>Status</th>
                        <th style={{ width: 220 }}>
                          Total Records (Real time)
                        </th>
                        <th style={{ width: 280 }}>
                          Real time numbers current day
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr>
                          <td colSpan={4} className="text-center py-4">
                            Loading...
                          </td>
                        </tr>
                      ) : error ? (
                        <tr>
                          <td colSpan={4} className="text-danger">
                            {error}
                          </td>
                        </tr>
                      ) : rows.length === 0 ? (
                        <tr>
                          <td
                            colSpan={4}
                            className="text-center text-muted py-4"
                          >
                            No data.
                          </td>
                        </tr>
                      ) : (
                        rows.map((r, i) => (
                          <tr
                            key={i}
                            className={r.isTotal ? "table-row-total" : ""}
                          >
                            <td>{i + 1}</td>
                            <td>{r.label}</td>
                            <td>{r.value}</td>
                            <td>{r.current}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .table-row-total td {
          font-weight: 600;
          background: #f7f7f7;
        }
      `}</style>
    </AjaxValidation>
  );
}
