import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { logout } from "../api/auth";

export default function Sidebar() {
  const { setUser } = useAuth();

  const handleLogout = async () => {
    await logout();
    setUser(null);
  };

  return (
    <div className="bg-light border-right" id="sidebar-wrapper">
      <div className="list-group list-group-flush">
        <Link to="/dashboard" className="list-group-item">
          Dashboard
        </Link>
        <Link to="/normal-cases" className="list-group-item">
          Normal Cases
        </Link>
        <Link to="/priority-cases" className="list-group-item">
          Priority Cases
        </Link>
        <Link to="/case-list" className="list-group-item">
          Case List
        </Link>
        <Link to="/add-slot" className="list-group-item">
          Add Slot
        </Link>
        <Link to="/slot-list" className="list-group-item">
          Slot List
        </Link>
        <Link to="/holiday" className="list-group-item">
          Holiday
        </Link>
        <Link to="/manifest" className="list-group-item">
          Manifest
        </Link>
        <Link to="/agent-report" className="list-group-item">
          Agent Report
        </Link>
        <button onClick={handleLogout} className="list-group-item text-danger">
          Logout
        </button>
      </div>
    </div>
  );
}
