// // components/CustomDateInput.jsx
// import React from "react";
// import { BsCalendar2Check } from "react-icons/bs";

// const CustomDateInput = React.forwardRef(({ value, onClick }, ref) => (
//   <div
//     onClick={onClick}
//     ref={ref}
//     style={{
//       display: "flex",
//       alignItems: "center",
//       border: "1px solid #dee2e6",
//       padding: "6px 12px",
//       fontSize: "0.75rem",
//       borderRadius: "6px",
//       // width: "fit-content",
//       width: "100%",
//       cursor: "pointer",
//       backgroundColor: "#fff",
//       justifyContent: "space-between",
//     }}
//   >
//     <span style={{ marginRight: 8 }}>{value}</span>
//     <BsCalendar2Check color="#555" />
//   </div>
// ));

// export default CustomDateInput;

// components/CustomDateInput.jsx
import React from "react";
import { BsCalendar2Check } from "react-icons/bs";

const CustomDateInput = React.forwardRef(function CustomDateInput(props, ref) {
  const {
    value,
    onClick,
    className = "",
    style = {},
    placeholder = "Select Date",
    ...rest
  } = props;

  const isInvalid = className.includes("is-invalid");
  const mergedStyle = {
    display: "flex",
    alignItems: "center",
    border: "1px solid #dee2e6",
    padding: "6px 12px",
    fontSize: "0.75rem",
    borderRadius: "6px",
    width: "100%",
    cursor: "pointer",
    backgroundColor: "#fff",
    justifyContent: "space-between",
    ...(isInvalid ? { borderColor: "#dc3545" } : null),
    ...style,
  };

  return (
    <div
      onClick={onClick}
      ref={ref}
      className={className}
      style={mergedStyle}
      tabIndex={0}
      aria-invalid={isInvalid || undefined}
      {...rest}
    >
      <span style={{ marginRight: 8 }}>{value || placeholder}</span>
      <BsCalendar2Check color="#555" />
    </div>
  );
});

export default CustomDateInput;
