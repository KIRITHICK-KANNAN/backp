import React, { useEffect, useMemo, useState } from "react";
import Modal from "react-bootstrap/Modal";
import AjaxValidation from "../hooks/AjaxValidation";
import { useAuth } from "../context/AuthContext";
import {
  agentCases,
  agentCaseList,
  updtDocs,
  updtMastr,
  agentCaseList as getAgentCaseList,
  updtCase, // must be exported from ../api/client
  docHistory, // DocDtls API
} from "../api/client";

/* ---------------- helpers ---------------- */
const fmtDMY = (s) => {
  if (!s) return "";
  const d = new Date(s);
  if (Number.isNaN(d)) return "";
  return `${String(d.getDate()).padStart(2, "0")}/${String(
    d.getMonth() + 1
  ).padStart(2, "0")}/${d.getFullYear()}`;
};
const toIST = (s) => {
  if (!s) return "";
  const d = new Date(s);
  if (Number.isNaN(d)) return "";
  const ist = new Date(d.getTime() + 5.5 * 3600 * 1000);
  const dd = String(ist.getDate()).padStart(2, "0");
  const mm = String(ist.getMonth() + 1).padStart(2, "0");
  const yyyy = ist.getFullYear();
  const hh = String(ist.getHours()).padStart(2, "0");
  const mi = String(ist.getMinutes()).padStart(2, "0");
  return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
};

const statusText = (s) =>
  s === 6
    ? "Verified"
    : s === 4
    ? "Blocked"
    : s === 3
    ? "Rejected"
    : s === 5
    ? "Re‑Submitted"
    : s === 2
    ? "Submitted"
    : "Pending";

const statusIsFinal = (s) => s === 6 || s === 4 || s === 3;

const DOC = { NULLA: 1, PASS: 2 };
const statusMap = { verify: 6, reject: 3, block: 4 };

const PASSPORT_REASON_OPTIONS = [
  { id: 16, label: "NOT ELIGIBLE" },
  { id: 17, label: "DOCUMENT NOT CLEAR" },
  { id: 19, label: "DETAILS MISMATCH" },
  { id: 21, label: "DUPLICATE ENTRY" },
  { id: 22, label: "EXPIRED PASSPORT" },
  { id: 23, label: "INCOMPLETE PASSPORT" },
  { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
];
const NULLA_REASON_OPTIONS = [
  { id: 1, label: "NOT ELIGIBLE" },
  { id: 2, label: "NOT A NULLA OSTA" },
  { id: 3, label: "DOCUMENT NOT CLEAR" },
  { id: 4, label: "INCOMPLETE DOCUMENT" },
  { id: 5, label: "INVALID DATE OF ISSUE" },
  { id: 6, label: "DETAILS MISMATCH" },
  { id: 7, label: "BLOCKED ISSUE DATE" },
  { id: 8, label: "DUPLICATE ENTRY" },
];

const AUTO_COMMENTS = {
  1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
  2: "Not a Nulla Osta",
  3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
  4: "Nulla osta uploaded is not complete",
  5: "The date of issue is not correct for the attached Nulla Osta.",
  6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
  7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
  8: "The Nulla Osta and Passport have already been submitted for appointment",

  16: "NOT ELIGIBLE",
  17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
  18: "Document uploaded is not matching the format of a Passport",
  19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
  20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
  21: "The Nulla Osta and Passport have already been submitted for appointment",
  22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
  23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
  24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
  25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
  26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
};

/* ---------------- tiny helpers to compute finality ---------------- */
function getDoc(row, dtlId, type) {
  return (row?.documents || []).find(
    (d) => String(d.dtlId) === String(dtlId) && Number(d.type) === Number(type)
  );
}
function getDocStatus(row, dtlId, type) {
  const d = getDoc(row, dtlId, type);
  return d?.docStatus ?? 0;
}
function computeDtlStatusFromDocs(passSts, nullaSts) {
  if (!statusIsFinal(passSts) || !statusIsFinal(nullaSts)) return null;
  if (passSts === 4 || nullaSts === 4) return 4;
  if (passSts === 6 && nullaSts === 6) return 6;
  return 3;
}
function computeMasterStatus(allDtlStatuses) {
  const finals = allDtlStatuses.filter((s) => s !== null);
  if (finals.length !== allDtlStatuses.length) return null;
  const all6 = allDtlStatuses.every((s) => s === 6);
  const all4 = allDtlStatuses.every((s) => s === 4);
  if (all6) return 6;
  if (all4) return 4;
  return 7; // partially verified
}

/* =========================================================
   Modal
========================================================= */
function CaseModal({ show, onClose, row, onAfterChain }) {
  const { authData } = useAuth();
  const [tab, setTab] = useState("passport"); // passport|nulla|history
  const [act, setAct] = useState(""); // verify|reject|block
  const [reason, setReason] = useState("0");
  const [comments, setComments] = useState("");
  const [saving, setSaving] = useState(false);
  const [history, setHistory] = useState({ usr: [], cust: [] });
  const [loadingHistory, setLoadingHistory] = useState(false);

  const sessionToken =
    authData.session_token ||
    authData.sessionToken ||
    authData.Globalsessiontoken;

  const det = row?.detail || {};
  const reqId =
    row?.master?.reqId ||
    row?.master?.request_id ||
    row?.master?.reqid ||
    row?.master?.reqIdFk ||
    "";

  const passDoc =
    row?.documents?.find(
      (d) =>
        Number(d.type) === DOC.PASS && String(d.dtlId) === String(det?.dtlId)
    ) ||
    row?.documents?.find(
      (d) =>
        /pass/i.test(String(d.file)) && String(d.dtlId) === String(det?.dtlId)
    );

  const nullaDoc =
    row?.documents?.find(
      (d) =>
        Number(d.type) === DOC.NULLA && String(d.dtlId) === String(det?.dtlId)
    ) ||
    row?.documents?.find(
      (d) =>
        /nulla|osta/i.test(String(d.file)) &&
        String(d.dtlId) === String(det?.dtlId)
    );

  const activeDoc =
    tab === "passport" ? passDoc : tab === "nulla" ? nullaDoc : null;
  const activeDocStatus = activeDoc?.docStatus ?? 0;
  const isReadOnly = statusIsFinal(activeDocStatus);

  const buildOpenUrl = (fileName) =>
    fileName
      ? `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`
      : "";

  const iframeSrc =
    tab === "passport"
      ? buildOpenUrl(passDoc?.file)
      : tab === "nulla"
      ? buildOpenUrl(nullaDoc?.file)
      : "";

  useEffect(() => {
    setTab("passport");
    setAct("");
    setReason("0");
    setComments("");
    setHistory({ usr: [], cust: [] });
  }, [row]);

  useEffect(() => {
    if ((act === "reject" || act === "block") && reason !== "0") {
      const txt = AUTO_COMMENTS[Number(reason)];
      if (txt) setComments(txt);
    }
  }, [reason, act]);

  // Load history when tab is selected
  useEffect(() => {
    const loadHistory = async () => {
      if (tab !== "history") return;
      try {
        setLoadingHistory(true);
        // we show Nulla Osta doc on the right. For history we can fetch by docId if you prefer,
        // here we use nullaDoc?.docId if present, else passport
        const docId = nullaDoc?.docId || passDoc?.docId;
        if (!docId) {
          setHistory({ usr: [], cust: [] });
          return;
        }
        const res = await docHistory({
          session_id: authData.session_id,
          sessionToken,
          docId,
        });
        setHistory({
          usr: res?.UsrActivity || [],
          cust: res?.CustActivity || [],
        });
      } finally {
        setLoadingHistory(false);
      }
    };
    loadHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, nullaDoc?.docId, passDoc?.docId]);

  // ——— NO REFRESH AFTER UpdtDocs ———
  // We update local modal state, then only when *both docs* are final we:
  // UpdtCase -> AgentCaseList(reqId). If all applicants final -> UpdtMastr -> AgentCases().
  async function handleSave() {
    if (!activeDoc?.docId) {
      alert("No document found.");
      return;
    }
    if (!act) {
      alert("Choose Verify / Reject / Block.");
      return;
    }
    if ((act === "reject" || act === "block") && reason === "0") {
      alert("Select a reason.");
      return;
    }

    try {
      setSaving(true);

      // 1) Update only this doc on server
      await updtDocs({
        session_id: authData.session_id,
        sessionToken,
        reqId,
        dtlId: det?.dtlId,
        docId: activeDoc.docId,
        status: statusMap[act],
        reason: act === "verify" ? "0" : String(reason || "0"),
        comments: comments || "",
      });

      // 2) Update local doc status immediately (no refresh yet)
      const newRow = { ...row, documents: [...(row.documents || [])] };
      const idx = newRow.documents.findIndex(
        (d) => String(d.docId) === String(activeDoc.docId)
      );
      if (idx !== -1)
        newRow.documents[idx] = {
          ...newRow.documents[idx],
          docStatus: statusMap[act],
        };

      // 3) Check if both docs for this applicant are now final
      const pSts = getDocStatus(newRow, det?.dtlId, DOC.PASS);
      const nSts = getDocStatus(newRow, det?.dtlId, DOC.NULLA);
      const dtlFinal = computeDtlStatusFromDocs(pSts, nSts);

      if (dtlFinal !== null) {
        // 3a) UpdtCase for this applicant
        await updtCase({
          session_id: authData.session_id,
          sessionToken,
          reqId,
          dtlId: det?.dtlId,
          dtlStatus: dtlFinal,
        });

        // 3b) Now refresh *this request* from server
        const fresh = await getAgentCaseList({
          session_id: authData.session_id,
          sessionToken,
          reqId,
        });

        // 3c) If all applicants of this request are final -> UpdtMastr, then parent will reload AgentCases()
        const merged = {
          master:
            (fresh?.master || []).find(
              (m) => String(m.reqId) === String(reqId)
            ) || row.master,
          details: (fresh?.details || []).filter(
            (d) => String(d.reqId) === String(reqId)
          ),
          documents: (fresh?.documents || []).filter(
            (d) => String(d.reqId) === String(reqId)
          ),
        };
        const allDtl = merged.details.map((d) =>
          computeDtlStatusFromDocs(
            getDocStatus(merged, d.dtlId, DOC.PASS),
            getDocStatus(merged, d.dtlId, DOC.NULLA)
          )
        );

        let reqCompleted = false;
        if (allDtl.every((s) => s !== null)) {
          const reqStatus = computeMasterStatus(allDtl);
          if (reqStatus !== null) {
            await updtMastr({
              session_id: authData.session_id,
              sessionToken,
              reqId,
              reqStatus,
            });
            reqCompleted = true; // parent will call AgentCases()
          }
        }

        // 3d) inform parent with fresh status
        onAfterChain?.({ reqCompleted, reqId });
      } else {
        // still not final (must verify the other doc). Stay in modal, no refresh.
        onAfterChain?.({ reqCompleted: false, reqId: null });
      }

      alert("Saved.");
      // reset action panel but keep modal and current tab
      setAct("");
      setReason("0");
      setComments("");
    } catch (e) {
      console.error(e);
      alert(e?.message || "Server error while saving.");
    } finally {
      setSaving(false);
    }
  }

  const reasons =
    tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;
  const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();

  return (
    <Modal show={show} onHide={onClose} size="xl" centered backdrop="static">
      <Modal.Header closeButton>
        <Modal.Title>Reference ID - {reqId}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="row g-3">
          {/* Left: tabs + content */}
          <div className="col-sm-8">
            <div className="mb-2 d-flex gap-2 flex-wrap">
              <button
                className={`btn btn-sm ${
                  tab === "passport" ? "btn-primary" : "btn-outline-primary"
                }`}
                onClick={() => setTab("passport")}
              >
                Passport Document — {statusText(passDoc?.docStatus ?? 0)}
              </button>
              <button
                className={`btn btn-sm ${
                  tab === "nulla" ? "btn-primary" : "btn-outline-primary"
                }`}
                onClick={() => setTab("nulla")}
              >
                Nulla Osta Document — {statusText(nullaDoc?.docStatus ?? 0)}
              </button>
              <button
                className={`btn btn-sm ${
                  tab === "history" ? "btn-primary" : "btn-outline-primary"
                }`}
                onClick={() => setTab("history")}
                disabled={!nullaDoc?.docId && !passDoc?.docId}
              >
                Document History
              </button>
            </div>

            {/* Left body: For history we render the two small tables (like your screenshot) */}
            {tab === "history" ? (
              <div
                className="border rounded p-2"
                style={{ maxHeight: 520, overflow: "auto" }}
              >
                {loadingHistory ? (
                  <div className="p-3">Loading history…</div>
                ) : (
                  <>
                    <div className="mb-2 fw-semibold">
                      Passport : <span>{det?.ppn || "-"}</span>&nbsp;&nbsp;
                      Status :{" "}
                      <span>{statusText(passDoc?.docStatus ?? 0)}</span>
                    </div>
                    <div className="table-responsive">
                      <table className="table table-bordered table-sm">
                        <thead className="table-active">
                          <tr>
                            <th>#</th>
                            <th>Action</th>
                            <th>Actioned By</th>
                            <th>Actioned On</th>
                            <th>Uploaded Passport</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(history.usr || []).length === 0 ? (
                            <tr>
                              <td colSpan={5} className="text-muted">
                                —
                              </td>
                            </tr>
                          ) : (
                            history.usr.map((u, i) => (
                              <tr key={u.alog || i}>
                                <td>{i + 1}</td>
                                <td>{u.alog}</td>
                                <td>{u.user || "Applicant"}</td>
                                <td>{toIST(u.addOn)}</td>
                                <td>{u.file}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>

                    <div className="mb-2 fw-semibold mt-3">
                      Nulla Osta : <span>{det?.wpn || "-"}</span>&nbsp;&nbsp;
                      Status :{" "}
                      <span>{statusText(nullaDoc?.docStatus ?? 0)}</span>
                    </div>
                    <div className="table-responsive">
                      <table className="table table-bordered table-sm">
                        <thead className="table-active">
                          <tr>
                            <th>#</th>
                            <th>Action</th>
                            <th>Actioned By</th>
                            <th>Actioned On</th>
                            <th>Uploaded Nulla Osta</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(history.cust || []).length === 0 ? (
                            <tr>
                              <td colSpan={5} className="text-muted">
                                —
                              </td>
                            </tr>
                          ) : (
                            history.cust.map((c, i) => (
                              <tr key={c.dlog || i}>
                                <td>{i + 1}</td>
                                <td>{c.alog || "Submitted"}</td>
                                <td>{c.user || "Applicant"}</td>
                                <td>{toIST(c.addOn)}</td>
                                <td>{c.file}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div
                style={{
                  height: 520,
                  border: "1px solid #ddd",
                  borderRadius: 6,
                  overflow: "hidden",
                }}
              >
                {iframeSrc ? (
                  <iframe
                    title="doc"
                    src={iframeSrc}
                    width="100%"
                    height="100%"
                    frameBorder="0"
                  />
                ) : (
                  <div className="p-3 text-muted">No file found.</div>
                )}
              </div>
            )}
          </div>

          {/* Right: 
               - For history tab show the **Nulla Osta document** iframe (like your screenshot).
               - For doc tabs show the details + action controls. */}
          <div className="col-sm-4">
            {tab === "history" ? (
              <div className="border rounded p-2">
                <div className="mb-2 fw-semibold">Nulla Osta Document</div>
                <div
                  style={{
                    height: 520,
                    border: "1px solid #ddd",
                    borderRadius: 6,
                    overflow: "hidden",
                  }}
                >
                  {nullaDoc?.file ? (
                    <iframe
                      title="nulla-history"
                      src={buildOpenUrl(nullaDoc.file)}
                      width="100%"
                      height="100%"
                      frameBorder="0"
                    />
                  ) : (
                    <div className="p-3 text-muted">No Nulla Osta file.</div>
                  )}
                </div>
              </div>
            ) : (
              <div className="border rounded p-2">
                <div className="fw-semibold mb-2">Customer Details :</div>
                <div className="d-grid gap-1 small">
                  <div className="d-flex justify-content-between border-bottom py-1">
                    <span>Full Name</span>
                    <span>{fullName || "-"}</span>
                  </div>
                  <div className="d-flex justify-content-between border-bottom py-1">
                    <span>Email Id</span>
                    <span>{row?.master?.mailId || "-"}</span>
                  </div>
                  <div className="d-flex justify-content-between border-bottom py-1">
                    <span>Passport Number</span>
                    <span>{det?.ppn || "-"}</span>
                  </div>
                  <div className="d-flex justify-content-between border-bottom py-1">
                    <span>Nulla osta No</span>
                    <span>{det?.wpn || "-"}</span>
                  </div>
                  <div className="d-flex justify-content-between border-bottom py-1">
                    <span>DOB</span>
                    <span>{fmtDMY(det?.dob) || "-"}</span>
                  </div>
                  <div className="d-flex justify-content-between border-bottom py-1">
                    <span>Issue Date</span>
                    <span>{fmtDMY(det?.wpndt) || "-"}</span>
                  </div>
                  <div className="d-flex justify-content-between border-bottom py-1">
                    <span>Submited On</span>
                    <span>{toIST(row?.master?.submitOn) || "-"}</span>
                  </div>
                  <div className="d-flex justify-content-between border-bottom py-1">
                    <span>VAC</span>
                    <span>{row?.master?.vac || "-"}</span>
                  </div>
                  <div className="d-flex justify-content-between border-bottom py-1">
                    <span>Status</span>
                    <span>{statusText(activeDocStatus)}</span>
                  </div>
                </div>

                <div className="mt-3 small">
                  <div className="mb-2">Action</div>
                  <div className="d-flex gap-3">
                    <label className="d-flex align-items-center gap-1">
                      <input
                        type="radio"
                        name="act"
                        value="verify"
                        checked={act === "verify"}
                        onChange={() => {
                          setAct("verify");
                          setReason("0");
                        }}
                        disabled={isReadOnly}
                      />
                      Verify
                    </label>
                    <label className="d-flex align-items-center gap-1">
                      <input
                        type="radio"
                        name="act"
                        value="reject"
                        checked={act === "reject"}
                        onChange={() => setAct("reject")}
                        disabled={isReadOnly}
                      />
                      Reject
                    </label>
                    <label className="d-flex align-items-center gap-1">
                      <input
                        type="radio"
                        name="act"
                        value="block"
                        checked={act === "block"}
                        onChange={() => setAct("block")}
                        disabled={isReadOnly}
                      />
                      Block
                    </label>
                  </div>

                  {(act === "reject" || act === "block") && (
                    <div className="mt-2">
                      <div className="mb-1">Reason</div>
                      <select
                        className="form-select form-select-sm"
                        value={reason}
                        onChange={(e) => setReason(e.target.value)}
                        disabled={isReadOnly}
                      >
                        <option value="0">---Select---</option>
                        {(tab === "passport"
                          ? PASSPORT_REASON_OPTIONS
                          : NULLA_REASON_OPTIONS
                        ).map((r) => (
                          <option key={r.id} value={r.id}>
                            {r.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  <div className="mt-2">
                    <div className="mb-1">Comments :</div>
                    <textarea
                      className="form-control"
                      rows={5}
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      disabled={isReadOnly}
                    />
                  </div>

                  <div className="d-flex gap-2 mt-3">
                    <button
                      className="btn btn-secondary w-50"
                      onClick={onClose}
                    >
                      Close
                    </button>
                    <button
                      className="btn btn-primary w-50"
                      onClick={handleSave}
                      disabled={
                        isReadOnly ||
                        saving ||
                        !act ||
                        ((act === "reject" || act === "block") &&
                          reason === "0")
                      }
                    >
                      {saving ? "Saving…" : "Save"}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

/* =========================================================
   Single table (no expansion). Group rows by reqId, show
   Request Id & No. Of Applicants only on first row.
========================================================= */
export default function AgentNormalCases() {
  const { authData } = useAuth();
  const [groups, setGroups] = useState([]); // [{ master, details, documents }]
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(null); // { master, detail, documents }

  const sessionToken =
    authData.session_token ||
    authData.sessionToken ||
    authData.Globalsessiontoken;

  const cols = useMemo(
    () => [
      "Request Id",
      "No. Of Applicants",
      "Full Name",
      "Email Id",
      "Passport Number",
      "Nulla osta No",
      "DOB",
      "Issue Date",
      "Appointment On",
      "Submited On",
      "VAC",
      "Status",
      "Action",
    ],
    []
  );

  async function loadAgentCases() {
    setLoading(true);
    try {
      const res = await agentCases({
        session_id: authData.session_id,
        sessionToken,
        priority: 0,
      });

      if (Array.isArray(res?.master)) {
        const out = res.master.map((m) => ({
          master: m,
          details: (res.details || []).filter(
            (d) => String(d.reqId) === String(m.reqId)
          ),
          documents: (res.documents || []).filter(
            (d) => String(d.reqId) === String(m.reqId)
          ),
        }));
        setGroups(out);
      } else {
        setGroups([]);
      }
    } catch (e) {
      console.error(e);
      setGroups([]);
      alert("Failed to load cases.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAgentCases();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // If request completed -> reload AgentCases; else just refresh that request
  function onAfterChain({ reqCompleted, reqId }) {
    if (reqCompleted) {
      loadAgentCases();
    } else if (reqId) {
      refreshRequest(reqId);
    }
  }

  async function refreshRequest(reqId) {
    try {
      const fresh = await agentCaseList({
        session_id: authData.session_id,
        sessionToken,
        reqId,
      });
      setGroups((prev) =>
        prev.map((g) => {
          if (String(g.master.reqId) !== String(reqId)) return g;
          return {
            master:
              (fresh?.master || []).find(
                (m) => String(m.reqId) === String(reqId)
              ) || g.master,
            details: (fresh?.details || []).filter(
              (d) => String(d.reqId) === String(reqId)
            ),
            documents: (fresh?.documents || []).filter(
              (d) => String(d.reqId) === String(reqId)
            ),
          };
        })
      );
    } catch (e) {
      console.error("refreshRequest failed", e);
    }
  }

  return (
    <AjaxValidation>
      <div className="mt-2">
        <div className="container-fluid">
          <h6>Agent Normal Cases</h6>

          <div class="row mt-2 mb-3">
            <div class="col-sm-12">
              <div className="box_card">
                <div className="form-group row">
                  <div className="col-sm-12">
                    <div className="table-responsive holiday-container">
                      <table className="table table-bordered">
                        <thead className="table-light">
                          <tr>
                            {cols.map((c) => (
                              <th key={c}>{c}</th>
                            ))}
                          </tr>
                        </thead>

                        <tbody>
                          {loading ? (
                            <tr>
                              <td colSpan={cols.length}>Loading…</td>
                            </tr>
                          ) : groups.length === 0 ? (
                            <tr>
                              <td colSpan={cols.length} className="text-muted">
                                No records
                              </td>
                            </tr>
                          ) : (
                            groups.flatMap((grp) => {
                              const reqId = grp.master.reqId;
                              const total = grp.details?.length || 0;

                              return (grp.details || []).map((d, idx) => {
                                const firstRow = idx === 0;
                                const ps = getDocStatus(grp, d.dtlId, DOC.PASS);
                                const ns = getDocStatus(
                                  grp,
                                  d.dtlId,
                                  DOC.NULLA
                                );
                                const derived = computeDtlStatusFromDocs(
                                  ps,
                                  ns
                                );

                                return (
                                  <tr key={`${reqId}-${d.dtlId}`}>
                                    <td>{firstRow ? reqId : ""}</td>
                                    <td>{firstRow ? total : ""}</td>
                                    <td>
                                      {`${d.fName || ""} ${
                                        d.lName || ""
                                      }`.trim() || "-"}
                                    </td>
                                    <td>{grp.master.mailId || "-"}</td>
                                    <td>{d.ppn || "-"}</td>
                                    <td>{d.wpn || "-"}</td>
                                    <td>{fmtDMY(d.dob) || "-"}</td>
                                    <td>{fmtDMY(d.wpndt) || "-"}</td>
                                    <td>{toIST(d.slotAt) || "-"}</td>
                                    <td>
                                      {firstRow
                                        ? toIST(grp.master.submitOn) || "-"
                                        : ""}
                                    </td>
                                    <td>
                                      {firstRow ? grp.master.vac || "-" : ""}
                                    </td>
                                    <td>
                                      {derived === null
                                        ? "Pending"
                                        : statusText(derived)}
                                    </td>
                                    <td>
                                      <button
                                        className="btn btn-link p-0"
                                        onClick={() =>
                                          setActive({
                                            master: grp.master,
                                            detail: d,
                                            documents: grp.documents,
                                          })
                                        }
                                      >
                                        View
                                      </button>
                                    </td>
                                  </tr>
                                );
                              });
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {active && (
            <CaseModal
              show={!!active}
              row={active}
              onClose={() => setActive(null)}
              onAfterChain={onAfterChain}
            />
          )}
        </div>
      </div>
    </AjaxValidation>
  );
}
