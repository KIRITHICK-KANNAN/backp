// // src/components/NormalCases.jsx
// import React, { useEffect, useMemo, useState } from "react";
// import Modal from "react-bootstrap/Modal";
// import { useAuth } from "../context/AuthContext";
// import { adminCases, searchCasesNormal, updtVerdict } from "../api/client";
// import AjaxValidation from "../hooks/AjaxValidation";

// const ITEMS_PER_PAGE = 100;

// /* ========= helpers ========= */
// function toISTString(dateLike) {
//   if (!dateLike) return "";
//   const d = new Date(dateLike);
//   if (isNaN(d)) return "";
//   const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
//   const ist = new Date(istMs);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const min = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${min}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   const d = new Date(dateLike);
//   if (isNaN(d)) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yyyy = d.getFullYear();
//   return `${dd}/${mm}/${yyyy}`;
// }
// function getReqId(master) {
//   return (
//     master?.reqid ??
//     master?.request_id ??
//     master?.reqId ??
//     master?.RequestId ??
//     null
//   );
// }

// /** Accepts many API shapes → { rows:[{master,details[]}], documents } */
// function normalizeRowsPacket(data) {
//   let documents = data?.documents || data?.docs || [];
//   if (
//     Array.isArray(data) &&
//     data.length &&
//     (data[0].master || data[0].details)
//   ) {
//     const rows = data.map((r) => ({
//       master: r.master ?? r,
//       details: Array.isArray(r.details)
//         ? r.details
//         : r.detail
//         ? [r.detail]
//         : [],
//     }));
//     return { rows, documents };
//   }
//   if (Array.isArray(data?.master)) {
//     const masters = data.master;
//     const details = Array.isArray(data.details) ? data.details : [];
//     const byReq = new Map();
//     details.forEach((d) => {
//       const k = String(
//         d?.reqid ?? d?.request_id ?? d?.reqId ?? d?.RequestId ?? ""
//       );
//       (byReq.get(k) || byReq.set(k, []).get(k)).push(d);
//     });
//     const rows = masters.map((m) => {
//       const rq = String(getReqId(m) ?? "");
//       return { master: m, details: byReq.get(rq) || [] };
//     });
//     return { rows, documents };
//   }
//   if (Array.isArray(data)) {
//     const rows = data.map((m) => ({
//       master: m,
//       details: Array.isArray(m?.details) ? m.details : [],
//     }));
//     return { rows, documents };
//   }
//   if (data?.master) {
//     return {
//       rows: [{ master: data.master, details: data.details || [] }],
//       documents,
//     };
//   }
//   return { rows: [], documents: [] };
// }

// /** Find action-id used by UpdtVrdct */
// function getActionIdFromAny(obj) {
//   return (
//     obj?.dtId ||
//     obj?.dtlid ||
//     obj?.dltid ||
//     obj?.id ||
//     obj?.Id ||
//     obj?.detail_id ||
//     obj?.detailId ||
//     obj?.dtlId ||
//     null
//   );
// }
// /** Prefer a detail id; fall back to master fields */
// function getVerdictId(row) {
//   return (
//     getActionIdFromAny(row?.details?.[0]) ||
//     getActionIdFromAny(row?.master) ||
//     getReqId(row?.master)
//   );
// }

// /* ========= Main Component ========= */
// export default function NormalCases() {
//   const { authData } = useAuth();
//   const session_id = authData?.session_id || "";
//   const session_token = authData?.session_token || "";

//   // vac list from AjaxValidation payload
//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v?.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";

//   // data
//   const [rows, setRows] = useState([]); // [{master, details}]
//   const [documents, setDocuments] = useState([]); // for modal
//   const [total, setTotal] = useState(0);

//   // search/paging
//   const [currentPage, setCurrentPage] = useState(1);
//   const startRecord = useMemo(
//     () => (currentPage - 1) * ITEMS_PER_PAGE + 1,
//     [currentPage]
//   );
//   const [isSearching, setIsSearching] = useState(false);

//   // filters
//   const [keyword, setKeyword] = useState("");
//   const [keyType, setKeyType] = useState("0");
//   const [dateType, setDateType] = useState("0"); // user picks, auto → "2" if dates given
//   const [vac, setVac] = useState("0");
//   const [status, setStatus] = useState("0");
//   const [from, setFrom] = useState("");
//   const [to, setTo] = useState("");

//   // verdict state per visible row (1=Yes, 2=No); initially empty
//   const [verdictMap, setVerdictMap] = useState({});
//   const [yesAll, setYesAll] = useState(false);
//   const [noAll, setNoAll] = useState(false);

//   // modal
//   const [show, setShow] = useState(false);
//   const [activeRow, setActiveRow] = useState(null);

//   /* ====== AdminCases ONCE on mount ====== */
//   useEffect(() => {
//     if (!session_id || !session_token) return;
//     (async () => {
//       try {
//         const data = await adminCases({
//           session_id,
//           session_token,
//           priority: 0,
//         });
//         const { rows: rws, documents: docs } = normalizeRowsPacket(data);
//         setRows(rws);
//         setDocuments(Array.isArray(docs) ? docs : []);
//         setTotal(rws.length);
//         setCurrentPage(1);
//         setIsSearching(false); // admin mode
//         // verdicts start empty
//         setVerdictMap({});
//         setYesAll(false);
//         setNoAll(false);
//       } catch (e) {
//         console.error("AdminCases error", e);
//       }
//     })();
//   }, [session_id, session_token]);

//   /* ====== Search only on submit (and paging while in search mode) ====== */
//   async function handleSearch(e) {
//     e?.preventDefault?.();
//     if (!session_id || !session_token) return;

//     // If dates present and dateType === "0", force "2" (Submitted On)
//     const effectiveDateType =
//       (from || to) && String(dateType) === "0" ? "2" : dateType;

//     const page = e ? 1 : currentPage;
//     const start = (page - 1) * ITEMS_PER_PAGE + 1;

//     try {
//       const data = await searchCasesNormal({
//         session_id,
//         session_token,
//         keyword,
//         keyType,
//         dateType: effectiveDateType,
//         vac,
//         status,
//         from,
//         to,
//         startRecord: start,
//         rows: ITEMS_PER_PAGE,
//         priority: 0,
//       });

//       const { rows: rws, documents: docs } = normalizeRowsPacket(data);
//       setRows(rws);
//       setDocuments(Array.isArray(docs) ? docs : []);
//       setTotal(Number(data?.total) || rws.length);
//       setIsSearching(true);
//       if (e) setCurrentPage(1);

//       // keep existing bulk selection, otherwise leave empty
//       const next = {};
//       if (yesAll || noAll) {
//         rws.forEach((row) => {
//           const id = getVerdictId(row);
//           if (id != null) next[id] = yesAll ? 1 : 2;
//         });
//       }
//       setVerdictMap(next);
//     } catch (err) {
//       console.error("SearchCases error", err);
//     }
//   }

//   useEffect(() => {
//     if (isSearching) handleSearch();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [currentPage, isSearching]);

//   /* ====== Verdict handlers ====== */
//   function onToggleAll(which) {
//     const yes = which === "yes";
//     const wasActive = yes ? yesAll : noAll;
//     // Toggle off if the same select-all is clicked again
//     if (wasActive) {
//       setYesAll(false);
//       setNoAll(false);
//       setVerdictMap({});
//       return;
//     }
//     setYesAll(yes);
//     setNoAll(!yes);
//     const next = {};
//     rows.forEach((r) => {
//       const id = getVerdictId(r);
//       if (id != null) next[id] = yes ? 1 : 2;
//     });
//     setVerdictMap(next);
//   }

//   // Row Yes: set to 1, or clear if already 1
//   function onToggleYes(id) {
//     setVerdictMap((m) => {
//       const n = { ...m };
//       if (n[id] === 1) delete n[id];
//       else n[id] = 1;
//       return n;
//     });
//   }
//   // Row No: set to 2, or clear if already 2
//   function onToggleNo(id) {
//     setVerdictMap((m) => {
//       const n = { ...m };
//       if (n[id] === 2) delete n[id];
//       else n[id] = 2;
//       return n;
//     });
//   }

//   async function handleSubmitVerdict() {
//     if (!session_id || !session_token) return;
//     const actionIds = [];
//     rows.forEach((r) => {
//       const id = getVerdictId(r);
//       if (id != null && verdictMap[id])
//         actionIds.push({ Id: id, sts: verdictMap[id] }); // 1=yes, 2=no
//     });
//     if (!actionIds.length) return;

//     try {
//       await updtVerdict({ session_id, session_token, actionIds });

//       // Reload latest via AdminCases
//       const data = await adminCases({ session_id, session_token, priority: 0 });
//       const { rows: rws, documents: docs } = normalizeRowsPacket(data);
//       setRows(rws);
//       setDocuments(Array.isArray(docs) ? docs : []);
//       setTotal(rws.length);
//       setCurrentPage(1);
//       setIsSearching(false);
//       // clear selections again
//       setVerdictMap({});
//       setYesAll(false);
//       setNoAll(false);
//     } catch (e) {
//       console.error("UpdtVrdct error", e);
//     }
//   }

//   /* ====== Modal ====== */
//   function openModal(row) {
//     setActiveRow(row);
//     setShow(true);
//   }
//   function closeModal() {
//     setShow(false);
//   }

//   /* ====== paging controls ====== */
//   const lastPage = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//   const canPrev = isSearching && currentPage > 1;
//   const canNext = isSearching && currentPage < lastPage;

//   return (
//     <AjaxValidation>
//       <section className="container-fluid">
//         {/* FILTERS */}
//         <form className="row mt-2" onSubmit={handleSearch}>
//           <div className="col-md-2">
//             <input
//               className="form-control"
//               placeholder="Search Text"
//               value={keyword}
//               onChange={(e) => setKeyword(e.target.value)}
//             />
//           </div>
//           <div className="col-md-2">
//             <select
//               className="form-control"
//               value={keyType}
//               onChange={(e) => setKeyType(e.target.value)}
//             >
//               <option value="0">---Keyword---</option>
//               <option value="1">Email Id</option>
//               <option value="2">Nulla Osta Reference Number</option>
//               <option value="3">Passport Number</option>
//               <option value="4">Mobile Number</option>
//               <option value="5">Request Id</option>
//               <option value="6">Name</option>
//             </select>
//           </div>
//           <div className="col-md-2">
//             <input
//               type="date"
//               className="form-control"
//               value={from}
//               onChange={(e) => setFrom(e.target.value)}
//             />
//           </div>
//           <div className="col-md-2">
//             <input
//               type="date"
//               className="form-control"
//               value={to}
//               onChange={(e) => setTo(e.target.value)}
//             />
//           </div>
//           <div className="col-md-1">
//             <select
//               className="form-control"
//               value={dateType}
//               onChange={(e) => setDateType(e.target.value)}
//             >
//               <option value="0">--Date Type--</option>
//               <option value="1">Added On</option>
//               <option value="2">Submitted On</option>
//             </select>
//           </div>
//           <div className="col-md-1">
//             <select
//               className="form-control"
//               value={vac}
//               onChange={(e) => setVac(e.target.value)}
//             >
//               <option value="0">--VAC--</option>
//               {vacOptions.map((v) => (
//                 <option key={v.vac_id} value={v.vac_id}>
//                   {v.vac_name}
//                 </option>
//               ))}
//             </select>
//           </div>
//           <div className="col-md-1">
//             <select
//               className="form-control"
//               value={status}
//               onChange={(e) => setStatus(e.target.value)}
//             >
//               <option value="0">---Status---</option>
//               <option value="6">Verified</option>
//               <option value="7">Partially Verified</option>
//             </select>
//           </div>
//           <div className="col-md-1">
//             <button type="submit" className="btn btn-primary w-100">
//               Search
//             </button>
//           </div>
//         </form>

//         {/* YES/NO SELECT ALL */}
//         <div className="row mt-3">
//           <div className="col-sm-12">
//             <div className="ver_flex p-2" style={{ gap: "2rem" }}>
//               <span>
//                 <input
//                   type="checkbox"
//                   checked={yesAll}
//                   onChange={() => onToggleAll("yes")}
//                 />{" "}
//                 Yes
//               </span>
//               <span>
//                 <input
//                   type="checkbox"
//                   checked={noAll}
//                   onChange={() => onToggleAll("no")}
//                 />{" "}
//                 No
//               </span>
//             </div>
//           </div>
//         </div>

//         {/* LIST */}
//         <div className="row mb-4">
//           <div className="col-sm-12">
//             <div className="table-responsive">
//               <table className="table accordion table-bordered text-left">
//                 <thead>
//                   <tr>
//                     <th>#</th>
//                     <th>Yes</th>
//                     <th>No</th>
//                     <th>Request ID</th>
//                     <th>IP</th>
//                     <th>Added On</th>
//                     <th>Submitted On</th>
//                     <th>No. Of Applicants</th>
//                     <th>VAC</th>
//                     <th>Status</th>
//                     <th>Action</th>
//                   </tr>
//                 </thead>

//                 <tbody>
//                   {rows.length === 0 && (
//                     <tr>
//                       <td colSpan="11" className="text-center">
//                         No data
//                       </td>
//                     </tr>
//                   )}
//                   {rows.map((row, i) => {
//                     const m = row.master || {};
//                     const id = getVerdictId(row);
//                     const yesChecked = verdictMap[id] === 1;
//                     const noChecked = verdictMap[id] === 2;
//                     const vacName = getVacName(m.vac ?? m.vac_id);
//                     return (
//                       <tr key={getReqId(m) ?? id ?? i}>
//                         <td>{startRecord + i}</td>
//                         <td>
//                           <input
//                             type="checkbox"
//                             checked={!!yesChecked}
//                             onChange={() => onToggleYes(id)}
//                           />
//                         </td>
//                         <td>
//                           <input
//                             type="checkbox"
//                             checked={!!noChecked}
//                             onChange={() => onToggleNo(id)}
//                           />
//                         </td>
//                         <td>{getReqId(m) ?? "-"}</td>
//                         <td>{m.ip ?? m.IP ?? "-"}</td>
//                         <td>{toISTString(m.addon ?? m.added_on) || "-"}</td>
//                         <td>
//                           {toISTString(m.submitOn ?? m.submitted_on) || "-"}
//                         </td>
//                         <td>{m.no_of_applicants ?? m.noApplicants ?? "-"}</td>
//                         <td>{vacName}</td>
//                         <td>{m.status_text ?? m.status ?? "-"}</td>
//                         <td>
//                           <button
//                             className="btn btn-sm btn-link"
//                             onClick={() => openModal(row)}
//                           >
//                             View
//                           </button>
//                         </td>
//                       </tr>
//                     );
//                   })}
//                 </tbody>
//               </table>
//             </div>

//             {/* Pager (only while searching) + Submit */}
//             <div className="d-flex justify-content-between align-items-center">
//               <div className="d-flex align-items-center gap-2">
//                 <button
//                   className={`btn btn-sm ${!canPrev ? "disabled" : ""}`}
//                   onClick={() => canPrev && setCurrentPage((p) => p - 1)}
//                 >
//                   Previous
//                 </button>
//                 <span>
//                   Page {isSearching ? currentPage : 1} of{" "}
//                   {isSearching
//                     ? Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
//                     : 1}
//                 </span>
//                 <button
//                   className={`btn btn-sm ${!canNext ? "disabled" : ""}`}
//                   onClick={() => canNext && setCurrentPage((p) => p + 1)}
//                 >
//                   Next
//                 </button>
//               </div>
//               <button className="btn btn-primary" onClick={handleSubmitVerdict}>
//                 Submit
//               </button>
//             </div>
//           </div>
//         </div>

//         {/* MODAL */}
//         {show && activeRow && (
//           <CaseModal
//             key={String(getReqId(activeRow?.master))}
//             show={show}
//             onClose={closeModal}
//             row={activeRow}
//             documents={documents}
//             authData={authData}
//             statusOptions={authData?.ajaxPayload?.master_status_list || []}
//           />
//         )}
//       </section>
//     </AjaxValidation>
//   );
// }

// /* ========= Modal (RIGHT SIDE READ-ONLY) ========= */
// function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
//   // force read-only on the right side
//   const canEditRight = false;

//   const [tab, setTab] = useState("passport");

//   const det =
//     row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};
//   const fullName = [
//     det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
//     det?.lName ??
//       det?.last_name ??
//       (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
//   ]
//     .filter(Boolean)
//     .join(" ");

//   const email =
//     row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";

//   const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
//   const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";
//   const dob = fmtDMY(det?.dob);
//   const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);
//   const submittedOn =
//     row?.master?.submitOn ??
//     row?.master?.submitted_on ??
//     det?.submitted_on ??
//     "";

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const vacName = getVacName(
//     det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
//   );

//   const statusList =
//     (statusOptions && statusOptions.length
//       ? statusOptions
//       : authData?.ajaxPayload?.master_status_list) || [];

//   const reasonList = authData?.ajaxPayload?.reason_list || [
//     { id: "", name: "---Select---" },
//     { id: "1", name: "Missing pages" },
//     { id: "2", name: "Illegible/blur" },
//     { id: "3", name: "Not applicable" },
//   ];

//   const [status, setStatus] = useState("");
//   const [reason, setReason] = useState("");
//   const [comments, setComments] = useState("");

//   useEffect(() => {
//     setTab("passport");
//     const currentStatus =
//       det?.dtlStatus ?? det?.status ?? row?.master?.status ?? "";
//     setStatus(String(currentStatus || ""));
//     setReason(
//       String(det?.reason_id ?? det?.reason ?? row?.master?.reason ?? "")
//     );
//     setComments(
//       String(
//         det?.comments ??
//           det?.remarks ??
//           row?.master?.comments ??
//           row?.master?.remarks ??
//           ""
//       )
//     );
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [row]);

//   function buildDocUrl(fileName) {
//     if (!fileName) return "";
//     if (!authData?.session_id || !authData?.document_key) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.document_key}_${fileName}`;
//   }

//   const requestId = String(row ? getReqId(row.master) ?? "" : "");
//   function pickDocName(which) {
//     const list = Array.isArray(documents) ? documents : [];
//     const hit =
//       list.find(
//         (d) =>
//           String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId &&
//           (which === "passport"
//             ? /pass|pp/i.test(String(d?.doc_name ?? d?.file_name ?? ""))
//             : /nulla|osta|no/i.test(String(d?.doc_name ?? d?.file_name ?? "")))
//       ) ||
//       list.find(
//         (d) => String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId
//       );
//     return hit?.file_name ?? hit?.doc_name ?? null;
//   }
//   const passportFile = pickDocName("passport");
//   const nullaFile = pickDocName("nulla");
//   const activeDocUrl =
//     tab === "passport"
//       ? buildDocUrl(passportFile)
//       : tab === "nulla"
//       ? buildDocUrl(nullaFile)
//       : "";

//   const passportHistory = row?.master?.pp_history || [];
//   const nullaHistory = row?.master?.nulla_history || [];

//   return (
//     <Modal
//       show={show}
//       onHide={onClose}
//       backdrop="static"
//       keyboard={false}
//       className="newcase_modal-dialog"
//       size="xl"
//       centered
//     >
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
//         </Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="model_dialog_list">
//           <div className="row">
//             {/* LEFT */}
//             <div className="col-sm-8 border-right">
//               <div className="mb-3 d-flex gap-2">
//                 <button
//                   className={`btn ${tab === "passport" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
//                   }}
//                   onClick={() => setTab("passport")}
//                 >
//                   Passport Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "nulla" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
//                   }}
//                   onClick={() => setTab("nulla")}
//                 >
//                   Nulla Osta Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "history" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
//                   }}
//                   onClick={() => setTab("history")}
//                 >
//                   Document History
//                 </button>
//               </div>

//               {tab !== "history" ? (
//                 <div
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {activeDocUrl ? (
//                     <iframe
//                       title="document-preview"
//                       src={activeDocUrl}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">File not found or inaccessible!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="table-responsive">
//                   {/* Passport history */}
//                   <div className="mt-2">
//                     <div className="fw-semibold mb-2">
//                       Passport : {passportNo}
//                     </div>
//                     <table className="table table-bordered">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Passport</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {passportHistory.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           passportHistory.map((h, i) => (
//                             <tr key={i}>
//                               <td>{i + 1}</td>
//                               <td>{h.action || "-"}</td>
//                               <td>{h.user || "-"}</td>
//                               <td>{toISTString(h.time) || "-"}</td>
//                               <td>{h.file || "-"}</td>
//                             </tr>
//                           ))
//                         )}
//                       </tbody>
//                     </table>
//                   </div>

//                   {/* Nulla history */}
//                   <div className="mt-3">
//                     <div className="fw-semibold mb-2">
//                       Nulla Osta No: {nullaOstaNo}
//                     </div>
//                     <table className="table table-bordered">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Nulla Osta</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {nullaHistory.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           nullaHistory.map((h, i) => (
//                             <tr key={i}>
//                               <td>{i + 1}</td>
//                               <td>{h.action || "-"}</td>
//                               <td>{h.user || "-"}</td>
//                               <td>{toISTString(h.time) || "-"}</td>
//                               <td>{h.file || "-"}</td>
//                             </tr>
//                           ))
//                         )}
//                       </tbody>
//                     </table>
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* RIGHT (READ-ONLY) */}
//             <div className="col-sm-4">
//               <div className="accordion-body">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <h6 className="modal-title">Customer Details :</h6>
//                   </div>
//                 </div>

//                 <div className="newcase-container">
//                   {[
//                     ["Issue Date", issueDate || "-"],
//                     ["Submited On", toISTString(submittedOn) || "-"],
//                     ["VAC", vacName],
//                     ["Full Name", fullName || "-"],
//                     ["Email Id", email || "-"],
//                     ["Passport Number", passportNo || "-"],
//                     ["Nulla osta No", nullaOstaNo || "-"],
//                     ["DOB", dob || "-"],
//                   ].map(([l, v], i) => (
//                     <div className="form-group row border-bottom" key={i}>
//                       <div className="col-sm-6">
//                         <label className="form-label">{l}</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <label className="form-label">{v}</label>
//                       </div>
//                     </div>
//                   ))}

//                   {/* Keep controls visually, but disabled (read-only) */}
//                   <div className="form-group row border-bottom">
//                     <div className="col-sm-6">
//                       <label className="form-label">Status</label>
//                     </div>
//                     <div className="col-sm-6">
//                       <select
//                         className="form-select form-control"
//                         disabled
//                         value={status}
//                         onChange={() => {}}
//                       >
//                         <option value="">---Select---</option>
//                         {statusList.map((s) => (
//                           <option
//                             key={s.request_status_id}
//                             value={s.request_status_id}
//                           >
//                             {s.request_status_name}
//                           </option>
//                         ))}
//                       </select>
//                     </div>
//                   </div>

//                   <div className="form-group row border-bottom">
//                     <div className="col-sm-6">
//                       <label className="form-label">Reason</label>
//                     </div>
//                     <div className="col-sm-6">
//                       <select
//                         className="form-select form-control"
//                         disabled
//                         value={reason}
//                         onChange={() => {}}
//                       >
//                         {reasonList.map((r) => (
//                           <option key={r.id} value={r.id}>
//                             {r.name}
//                           </option>
//                         ))}
//                       </select>
//                     </div>
//                   </div>

//                   <div className="form-group row border-bottom">
//                     <div className="col-sm-12">
//                       <label className="form-label">Comments</label>
//                       <textarea
//                         className="form-control"
//                         rows={5}
//                         value={comments}
//                         onChange={() => {}}
//                         disabled
//                       />
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             {/* END RIGHT */}
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

import React, { useEffect, useMemo, useState } from "react";
import Modal from "react-bootstrap/Modal";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { BsCalendar2Check } from "react-icons/bs";
import { FaEdit } from "react-icons/fa";
import AjaxValidation from "../hooks/AjaxValidation";
import { adminCases, searchCasesNormal, updtVerdict } from "../api/client";
import { useAuth } from "../context/AuthContext";

/* ===== Constants ===== */
const ITEMS_PER_PAGE = 10;
const WINDOW = 4;

/* ===== Utils ===== */
function toISTString(dateLike) {
  if (!dateLike) return "";
  if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
  const d = new Date(dateLike);
  if (Number.isNaN(d.getTime())) return "";
  const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
  const ist = new Date(istMs);
  const dd = String(ist.getDate()).padStart(2, "0");
  const mm = String(ist.getMonth() + 1).padStart(2, "0");
  const yyyy = ist.getFullYear();
  const hh = String(ist.getHours()).padStart(2, "0");
  const mi = String(ist.getMinutes()).padStart(2, "0");
  return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
}
function fmtDMY(dateLike) {
  if (!dateLike) return "";
  if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
  const d = new Date(dateLike);
  if (Number.isNaN(d.getTime())) return "";
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}
function getReqId(obj) {
  return (
    obj?.reqId ??
    obj?.request_id ??
    obj?.req_id ??
    obj?.reqid ??
    obj?.requestId ??
    obj?.reqIdFk ??
    obj?.reqid_fk ??
    null
  );
}
function getDetailId(d) {
  return (
    d?.request_detail_id ??
    d?.reqDtlId ??
    d?.reqDetId ??
    d?.detail_id ??
    d?.details_id ??
    d?.id ??
    null
  );
}
function getPassport(d) {
  return d?.ppn ?? d?.passport_no ?? d?.passport ?? null;
}
/** Accept raw response and return { rows:[{master,details[]}], total, documents } */
function normalizeResponse(res) {
  if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
    const byReq = res.details.reduce((acc, d) => {
      const k = String(getReqId(d) ?? "");
      (acc[k] ||= []).push(d);
      return acc;
    }, {});
    const rows = res.master.map((m) => {
      const mk = String(getReqId(m) ?? "");
      return { master: m, details: byReq[mk] || [] };
    });
    return {
      rows,
      total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
      documents: Array.isArray(res.documents) ? res.documents : [],
    };
  }
  if (Array.isArray(res)) {
    const rows = res.map((m) => ({ master: m, details: m.details || [] }));
    return { rows, total: rows.length, documents: [] };
  }
  if (res && Array.isArray(res.data)) {
    const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
    return { rows, total: rows.length, documents: [] };
  }
  return { rows: [], total: 0, documents: [] };
}

/* ========================== Modal (READ-ONLY right side) ========================== */
function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
  const [tab, setTab] = useState("passport");
  const det =
    row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};

  const fullName = [
    det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
    det?.lName ??
      det?.last_name ??
      (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
  ]
    .filter(Boolean)
    .join(" ");

  const email =
    row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";
  const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
  const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";
  const dob = fmtDMY(det?.dob);
  const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);
  const submittedOn =
    row?.master?.submitOn ??
    row?.master?.submitted_on ??
    det?.submitted_on ??
    "";

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const getVacName = (id) =>
    vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
    id ||
    "-";
  const vacName = getVacName(
    det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
  );

  const statusList =
    (statusOptions?.length
      ? statusOptions
      : authData?.ajaxPayload?.master_status_list) || [];
  const currentStatusName =
    statusList.find(
      (s) =>
        String(s.request_status_id) ===
        String(det?.dtlStatus ?? det?.status ?? row?.master?.status ?? "")
    )?.request_status_name || "-";

  useEffect(() => {
    setTab("passport");
  }, [row]);

  function buildDocUrl(fileName) {
    if (!fileName) return "";
    if (!authData?.session_id || !authData?.document_key) return "";
    return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.document_key}_${fileName}`;
  }

  const requestId = String(row ? getReqId(row.master) ?? "" : "");
  function pickDocName(which) {
    const list = Array.isArray(documents) ? documents : [];
    const hit =
      list.find(
        (d) =>
          String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId &&
          (which === "passport"
            ? /pass|pp/i.test(String(d?.doc_name ?? d?.file_name ?? ""))
            : /nulla|osta|no/i.test(String(d?.doc_name ?? d?.file_name ?? "")))
      ) ||
      list.find(
        (d) => String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId
      );
    return hit?.file_name ?? hit?.doc_name ?? null;
  }

  const passportFile = pickDocName("passport");
  const nullaFile = pickDocName("nulla");
  const activeDocUrl =
    tab === "passport"
      ? buildDocUrl(passportFile)
      : tab === "nulla"
      ? buildDocUrl(nullaFile)
      : "";

  const passportHistory = row?.master?.pp_history || [];
  const nullaHistory = row?.master?.nulla_history || [];

  return (
    <Modal
      show={show}
      onHide={onClose}
      backdrop="static"
      keyboard={false}
      className="newcase_modal-dialog"
      size="xl"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title>
          <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="model_dialog_list">
          <div className="row">
            {/* LEFT */}
            <div className="col-sm-8 border-right">
              <div className="mb-3 d-flex gap-2">
                <button
                  className={`btn ${tab === "passport" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
                  }}
                  onClick={() => setTab("passport")}
                >
                  Passport Document
                </button>
                <button
                  className={`btn ${tab === "nulla" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
                  }}
                  onClick={() => setTab("nulla")}
                >
                  Nulla Osta Document
                </button>
                <button
                  className={`btn ${tab === "history" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
                  }}
                  onClick={() => setTab("history")}
                >
                  Document History
                </button>
              </div>

              {tab !== "history" ? (
                <div
                  style={{
                    height: "55vh",
                    border: "1px solid #ddd",
                    borderRadius: 6,
                    overflow: "hidden",
                    background: "#fff",
                  }}
                >
                  {activeDocUrl ? (
                    <iframe
                      title="document-preview"
                      src={activeDocUrl}
                      style={{ width: "100%", height: "100%", border: 0 }}
                    />
                  ) : (
                    <div className="p-3">File not found or inaccessible!</div>
                  )}
                </div>
              ) : (
                <div className="table-responsive">
                  {/* Passport history */}
                  <div className="mt-2">
                    <div className="fw-semibold mb-2">
                      Passport : {passportNo || "-"}
                    </div>
                    <table className="table table-bordered">
                      <thead className="table-active">
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Actioned By</th>
                          <th>Actioned On</th>
                          <th>Uploaded Passport</th>
                        </tr>
                      </thead>
                      <tbody>
                        {passportHistory.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-muted">
                              —
                            </td>
                          </tr>
                        ) : (
                          passportHistory.map((h, i) => (
                            <tr key={i}>
                              <td>{i + 1}</td>
                              <td>{h.action || "-"}</td>
                              <td>{h.user || "-"}</td>
                              <td>{toISTString(h.time) || "-"}</td>
                              <td>{h.file || "-"}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Nulla history */}
                  <div className="mt-3">
                    <div className="fw-semibold mb-2">
                      Nulla Osta No: {nullaOstaNo || "-"}
                    </div>
                    <table className="table table-bordered">
                      <thead className="table-active">
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Actioned By</th>
                          <th>Actioned On</th>
                          <th>Uploaded Nulla Osta</th>
                        </tr>
                      </thead>
                      <tbody>
                        {nullaHistory.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-muted">
                              —
                            </td>
                          </tr>
                        ) : (
                          nullaHistory.map((h, i) => (
                            <tr key={i}>
                              <td>{i + 1}</td>
                              <td>{h.action || "-"}</td>
                              <td>{h.user || "-"}</td>
                              <td>{toISTString(h.time) || "-"}</td>
                              <td>{h.file || "-"}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* RIGHT (READ-ONLY) */}
            <div className="col-sm-4">
              <div className="accordion-body">
                <div className="form-group row">
                  <div className="col-sm-12">
                    <h6 className="modal-title">Customer Details :</h6>
                  </div>
                </div>

                <div className="newcase-container">
                  {[
                    ["Issue Date", issueDate || "-"],
                    ["Submited On", toISTString(submittedOn) || "-"],
                    ["VAC", vacName],
                    ["Full Name", fullName || "-"],
                    ["Email Id", email || "-"],
                    ["Passport Number", passportNo || "-"],
                    ["Nulla osta No", nullaOstaNo || "-"],
                    ["DOB", dob || "-"],
                    ["Status", currentStatusName],
                  ].map(([l, v], i) => (
                    <div className="form-group row border-bottom" key={i}>
                      <div className="col-sm-6">
                        <label className="form-label">{l}</label>
                      </div>
                      <div className="col-sm-6">
                        <label className="form-label">{v}</label>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            {/* END RIGHT */}
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

/* ========================== Main (Normal Cases) ========================== */
export default function NormalCases() {
  const { authData } = useAuth();

  // false => adminCases; true => searchCasesNormal
  const [isSearching, setIsSearching] = useState(false);

  // Filters
  const [keyword, setKeyword] = useState("");
  const [keyType, setKeyType] = useState("0");
  const [dateType, setDateType] = useState("0");
  const [vac, setVac] = useState("0");
  const [status, setStatus] = useState("0");
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);

  // Data/page
  const [rows, setRows] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [total, setTotal] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [expanded, setExpanded] = useState(null);
  const [loading, setLoading] = useState(false);

  // Modal
  const [show, setShow] = useState(false);
  const [activeRow, setActiveRow] = useState(null);

  // Verdict selections
  const [verdict, setVerdict] = useState({});

  const minDate = useMemo(() => new Date("2000-01-01"), []);
  const maxDate = useMemo(() => new Date(), []);

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const statusOptions = authData?.ajaxPayload?.master_status_list || [];

  const getVacName = (id) =>
    vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
    id ||
    "-";
  const getStatusName = (id) =>
    statusOptions.find((s) => String(s.request_status_id) === String(id))
      ?.request_status_name ||
    id ||
    "-";

  const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
  const onView = (row) => {
    setActiveRow(row);
    setShow(true);
  };

  /* ---------- Validation helpers ---------- */
  const hasAnyFilter = () => {
    const hasKeyword = keyword.trim().length > 0 && Number(keyType) > 0;
    const hasDates = !!fromDate || !!toDate; // dateType must be picked if dates used
    const hasPicks =
      Number(vac) > 0 || Number(status) > 0 || Number(dateType) > 0;
    return hasKeyword || hasDates || hasPicks;
  };

  function validateFilters() {
    // if user typed keyword but didn't choose a type
    if (keyword.trim() && +keyType === 0) {
      return { ok: false, msg: "Choose a Keyword type." };
    }
    // if dates used, dateType is mandatory
    if ((fromDate || toDate) && +dateType === 0) {
      return {
        ok: false,
        msg: "Please choose a Date Type when using From/To dates.",
      };
    }
    // if nothing selected at all, don't call search API
    if (!hasAnyFilter()) {
      return {
        ok: false,
        msg: "Please choose at least one filter before searching.",
      };
    }
    return { ok: true };
  }

  /* ---------- Payload builder ---------- */
  function buildPayload(page = 1, forAdmin = false) {
    let pKeyType = keyType,
      pKeyword = keyword,
      pDateType = dateType,
      pVac = vac,
      pStatus = status;

    // If a keyword type is chosen, ignore other filters (back-end rule)
    if (+pKeyType > 0) {
      pDateType = "0";
      pVac = "0";
      pStatus = "0";
    }

    const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

    const base = {
      session_id: authData.session_id,
      sessionToken: authData.session_token,
      session_token: authData.session_token,
      priority: "0",
      startRecord,
      rows: ITEMS_PER_PAGE,
      caseList: 1,
      allSts: 1,
    };

    if (forAdmin) return base;

    return {
      ...base,
      keyword: String((pKeyword || "").trim()),
      keyType: String(pKeyType),
      dateType: String(pDateType),
      vac: String(pVac || "0"),
      status: String(pStatus || "0"),
      from: fromDate ? fromDate.toISOString().split("T")[0] : "",
      to: toDate ? toDate.toISOString().split("T")[0] : "",
    };
  }

  /* ---------- Fetcher ---------- */
  // Pass explicit "useSearch" flag so first search never races with setState
  async function fetchPage(page = 1, useSearch = isSearching) {
    setLoading(true);
    try {
      const payload = buildPayload(page, !useSearch);
      const res = useSearch
        ? await searchCasesNormal(payload)
        : await adminCases(payload);

      const { rows: normalized, total, documents } = normalizeResponse(res);
      setRows(normalized);
      setTotal(Number(total || 0));
      setDocuments(documents || []);
      setExpanded(null);
      setCurrentPage(page);
      setVerdict({});
    } catch (e) {
      console.error("NormalCases fetch failed:", e);
      setRows([]);
      setTotal(0);
      setDocuments([]);
      setExpanded(null);
      setVerdict({});
    } finally {
      setLoading(false);
    }
  }

  /* ---------- Lifecycle ---------- */
  useEffect(() => {
    // initial = adminCases
    setIsSearching(false);
    fetchPage(1, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- Handlers ---------- */
  const handleSearch = async () => {
    const v = validateFilters();
    if (!v.ok) {
      alert(v.msg);
      return; // DO NOT call search API
    }
    // Force search mode on this call to avoid first-click adminCases
    setIsSearching(true);
    await fetchPage(1, true);
  };

  const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
  const handlePrev = () =>
    currentPage > 1 && fetchPage(currentPage - 1, isSearching);
  const handleNext = () =>
    currentPage < totalPages && fetchPage(currentPage + 1, isSearching);

  /* ---------- Verdict helpers ---------- */
  const setVerdictFor = (reqId, detKey, val /* "1" | "0" */) => {
    setVerdict((p) => ({
      ...p,
      [reqId]: { ...(p[reqId] || {}), [detKey]: val },
    }));
  };
  const setAllForRequest = (reqId, details, val) => {
    const updates = {};
    (details || []).forEach((d, i) => {
      const dk = String(getDetailId(d) ?? i);
      updates[dk] = val;
    });
    setVerdict((p) => ({ ...p, [reqId]: updates }));
  };
  const setAllForPage = (rowsData, val) => {
    const next = {};
    (rowsData || []).forEach(({ master, details }) => {
      const reqId = String(getReqId(master) ?? "");
      const map = {};
      (details || []).forEach((d, i) => {
        const dk = String(getDetailId(d) ?? i);
        map[dk] = val;
      });
      next[reqId] = map;
    });
    setVerdict(next);
  };

  // NEW batched UpdtVrdct call
  async function handleSubmitVerdicts() {
    const actionIds = [];
    for (const { master, details } of rows) {
      const reqId = String(getReqId(master) ?? "");
      const selections = verdict[reqId] || {};
      (details || []).forEach((d, i) => {
        const dk = String(getDetailId(d) ?? i);
        const v = selections[dk];
        if (v === "1" || v === "0") {
          const detailId = getDetailId(d);
          actionIds.push({
            Id: String(detailId ?? reqId),
            sts: v,
          });
        }
      });
    }

    if (actionIds.length === 0) {
      alert("Please choose at least one Verdict (Yes/No) before submitting.");
      return;
    }

    try {
      const res = await updtVerdict({
        session_id: authData.session_id,
        session_token: authData.session_token,
        actionIds,
      });

      const ok =
        (Array.isArray(res?.results) &&
          res.results.every((r) => r?.status === 1)) ||
        res?.status === 1 ||
        res?.success === true;

      if (ok) {
        alert("Verdicts updated successfully!");
      } else {
        alert("Some verdicts may have failed to update.");
      }

      await fetchPage(currentPage, isSearching);
    } catch (e) {
      console.error("Submit verdicts failed:", e);
      alert("Submitting verdicts failed.");
    }
  }

  /* ===== Pagination helpers ===== */
  function range(start, end) {
    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  }
  function getVisiblePages(current, total) {
    if (total <= WINDOW) return range(1, total);
    if (current <= WINDOW) return range(1, WINDOW);
    if (current > total - WINDOW) return range(total - WINDOW + 1, total);
    return range(current, current + WINDOW - 1);
  }

  return (
    <AjaxValidation>
      <div className="mt-2">
        <div className="container-fluid">
          <h6>Normal Cases</h6>

          <div class="row mt-2 mb-3">
            <div class="col-sm-12">
              <div className="box_card">
                <div className="form-group row">
                  <div className="col-sm-12">
                    {/* Filters */}
                    <div className="main_agent_form">
                      <div className="one">
                        <input
                          className="form-control"
                          placeholder="Search"
                          value={keyword}
                          onChange={(e) => setKeyword(e.target.value)}
                        />
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={keyType}
                          onChange={(e) => setKeyType(e.target.value)}
                        >
                          <option value="0">--Keyword--</option>
                          <option value="1">Email Id</option>
                          <option value="2">Nulla Osta Reference Number</option>
                          <option value="3">Passport Number</option>
                          <option value="4">Mobile Number</option>
                          <option value="5">Request Id</option>
                          <option value="6">Name</option>
                        </select>
                      </div>
                      <div className="one">
                        <div
                          className="input-group date_pick"
                          style={{ flexWrap: "nowrap" }}
                        >
                          <DatePicker
                            selected={fromDate}
                            onChange={(d) => setFromDate(d)}
                            className="form-control border_right_radius"
                            placeholderText="From Date"
                            dateFormat="dd-MM-yyyy"
                            showMonthDropdown
                            showYearDropdown
                            dropdownMode="select"
                            scrollableYearDropdown
                            isClearable
                            minDate={minDate}
                            maxDate={maxDate}
                          />
                          <span className="input-group-text">
                            <BsCalendar2Check />
                          </span>
                        </div>
                      </div>
                      <div className="one">
                        <div
                          className="input-group date_pick"
                          style={{ flexWrap: "nowrap" }}
                        >
                          <DatePicker
                            selected={toDate}
                            onChange={(d) => setToDate(d)}
                            className="form-control border_right_radius"
                            placeholderText="To Date"
                            dateFormat="dd-MM-yyyy"
                            showMonthDropdown
                            showYearDropdown
                            dropdownMode="select"
                            scrollableYearDropdown
                            isClearable
                            minDate={minDate}
                            maxDate={maxDate}
                          />
                          <span className="input-group-text">
                            <BsCalendar2Check />
                          </span>
                        </div>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={dateType}
                          onChange={(e) => setDateType(e.target.value)}
                        >
                          <option value="0">--Date Type--</option>
                          <option value="1">Added On</option>
                          <option value="2">Submitted On</option>
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={vac}
                          onChange={(e) => setVac(e.target.value)}
                        >
                          <option value="0">--Select VAC--</option>
                          {vacOptions.map((v) => (
                            <option key={v.vac_id} value={v.vac_id}>
                              {v.vac_name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={status}
                          onChange={(e) => setStatus(e.target.value)}
                        >
                          <option value="0">--Select--</option>
                          {statusOptions
                            .filter((s) => Number(s.request_status_id) > 1)
                            .map((s) => (
                              <option
                                key={s.request_status_id}
                                value={s.request_status_id}
                              >
                                {s.request_status_name}
                              </option>
                            ))}
                        </select>
                      </div>
                      <div className="one">
                        <button
                          className="btn-lg go-btn"
                          style={{ background: "#f26722", color: "#fff" }}
                          onClick={handleSearch}
                        >
                          Search
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="form-group row">
                  <div className="col-sm-12">
                    {/* Page-level Yes/No */}
                    <div className="mt-2 mb-0">
                      <div
                        className="d-flex align-items-center ms-2"
                        style={{ gap: 10 }}
                      >
                        <label className="me-2" style={{ userSelect: "none" }}>
                          <input
                            type="checkbox"
                            checked={false}
                            onChange={() => setAllForPage(rows, "1")}
                          />{" "}
                          Yes
                        </label>
                        <label style={{ userSelect: "none" }}>
                          <input
                            type="checkbox"
                            checked={false}
                            onChange={() => setAllForPage(rows, "0")}
                          />{" "}
                          No
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="dropdown-divider"></div>
                {/* Results */}
                <div className="box_card">
                  <div className="table-responsive holiday-container">
                    {loading ? (
                      <div className="p-3 text-center">
                        <div
                          style={{
                            position: "fixed",
                            inset: 0,
                            background: "rgba(0,0,0,0.35)",
                            zIndex: 1050,
                            display: "grid",
                            placeItems: "center",
                          }}
                        >
                          <div
                            className="spinner-border text-light"
                            role="status"
                          />
                        </div>
                      </div>
                    ) : rows.length === 0 ? (
                      <div className="p-3 text-center text-muted">
                        No records found.
                      </div>
                    ) : (
                      rows.map(({ master, details }, idx) => {
                        const rid = String(getReqId(master) ?? idx);
                        const addedOn = toISTString(
                          master?.addOn ?? master?.added_on
                        );
                        const submittedOn = toISTString(
                          master?.submitOn ?? master?.submitted_on
                        );
                        const vacName = getVacName(
                          master?.vac ?? master?.vac_id
                        );
                        const statusName = getStatusName(
                          master?.rStatus ?? master?.status
                        );

                        const list = Array.isArray(details)
                          ? details
                          : details && typeof details === "object"
                          ? Object.values(details)
                          : [];

                        return (
                          <div key={rid} className="border">
                            {/* master row */}
                            <table
                              className="table table-bordered mb-0"
                              style={{ tableLayout: "auto", width: "100%" }}
                            >
                              <thead className="main_heading_table">
                                <tr>
                                  <th>
                                    <div className="">
                                      <label
                                        className="me-3"
                                        style={{ userSelect: "none" }}
                                      >
                                        <input
                                          type="checkbox"
                                          checked={false}
                                          onChange={() =>
                                            setAllForRequest(rid, list, "1")
                                          }
                                        />{" "}
                                        Yes
                                      </label>
                                      <label style={{ userSelect: "none" }}>
                                        <input
                                          type="checkbox"
                                          checked={false}
                                          onChange={() =>
                                            setAllForRequest(rid, list, "0")
                                          }
                                        />{" "}
                                        No
                                      </label>
                                    </div>
                                  </th>
                                  <th>Request ID :</th>
                                  <th className="priClr">{rid}</th>
                                  <th>IP :</th>
                                  <th className="col-ip">
                                    {master?.IP ?? master?.ip ?? "-"}
                                  </th>
                                  <th>Added On :</th>
                                  <th>{addedOn || "-"}</th>
                                  <th>Submitted On :</th>
                                  <th>{submittedOn || "-"}</th>
                                  <th>No. Of Applicants :</th>
                                  <th style={{ width: "60px" }}>
                                    {master?.noOfUsr ??
                                      master?.no_of_applicants ??
                                      "-"}
                                  </th>
                                  <th>VAC :</th>
                                  <th className="col-vac">
                                    <div className="d-flex gap-2 align-items-center">
                                      {vacName}
                                      <FaEdit
                                        style={{
                                          color: "green",
                                          fontSize: "0.8rem",
                                        }}
                                      />
                                    </div>
                                  </th>
                                  <th>Status :</th>
                                  <th className="col-status">{statusName}</th>
                                  <th>
                                    <button
                                      className="btn-theam-filter"
                                      onClick={() => toggleExpand(String(rid))}
                                      title="Expand"
                                    >
                                      {expanded === String(rid) ? "▲" : "▼"}
                                    </button>
                                  </th>
                                </tr>
                              </thead>
                            </table>

                            {/* detail table */}
                            {expanded === String(rid) && (
                              <div className="">
                                <table className="table table-bordered table-hover tableexpand">
                                  <thead className="table-active tableexpand-head">
                                    <tr>
                                      <th style={{ width: 120 }}>Verdict</th>
                                      <th>Full Name</th>
                                      <th>Email Id</th>
                                      <th>Passport Number</th>
                                      <th>Nulla osta No</th>
                                      <th>DOB</th>
                                      <th>Issue Date</th>
                                      <th>Submitted On</th>
                                      <th>VAC</th>
                                      <th>Appointment On</th>
                                      <th>Status</th>
                                      <th>Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {list.length === 0 ? (
                                      <tr>
                                        <td
                                          colSpan={12}
                                          className="text-center text-muted"
                                        >
                                          No details available for this request.
                                        </td>
                                      </tr>
                                    ) : (
                                      list.map((d, i) => {
                                        const full =
                                          [
                                            d?.fName ??
                                              d?.first_name ??
                                              d?.full_name?.split(" ")?.[0],
                                            d?.lName ??
                                              d?.last_name ??
                                              (d?.full_name
                                                ? d.full_name
                                                    .split(" ")
                                                    .slice(1)
                                                    .join(" ")
                                                : null),
                                          ]
                                            .filter(Boolean)
                                            .join(" ") || "-";

                                        const dk = String(getDetailId(d) ?? i);
                                        const sel = verdict[rid]?.[dk];

                                        return (
                                          <tr key={`${rid}-detail-${dk}`}>
                                            <td>
                                              <label
                                                className="me-3"
                                                style={{ userSelect: "none" }}
                                              >
                                                <input
                                                  type="checkbox"
                                                  checked={sel === "1"}
                                                  onChange={() =>
                                                    setVerdictFor(rid, dk, "1")
                                                  }
                                                />{" "}
                                                Yes
                                              </label>
                                              <label
                                                style={{ userSelect: "none" }}
                                              >
                                                <input
                                                  type="checkbox"
                                                  checked={sel === "0"}
                                                  onChange={() =>
                                                    setVerdictFor(rid, dk, "0")
                                                  }
                                                />{" "}
                                                No
                                              </label>
                                            </td>
                                            <td>{full}</td>
                                            <td>
                                              {master?.mailId ??
                                                master?.email ??
                                                d?.email ??
                                                "-"}
                                            </td>
                                            <td>{getPassport(d) || "-"}</td>
                                            <td>
                                              {d?.wpn ??
                                                d?.nulla_osta_no ??
                                                "-"}
                                            </td>
                                            <td>{fmtDMY(d?.dob) || "-"}</td>
                                            <td>
                                              {fmtDMY(
                                                d?.wpndt ?? d?.issue_date
                                              ) || "-"}
                                            </td>
                                            <td>
                                              {toISTString(
                                                master?.submitOn ??
                                                  master?.submitted_on
                                              ) || "-"}
                                            </td>
                                            <td>
                                              {getVacName(
                                                d?.vac ??
                                                  master?.vac ??
                                                  master?.vac_id
                                              )}
                                            </td>
                                            <td>
                                              {toISTString(
                                                d?.slotAt ?? d?.appointment_on
                                              ) || "-"}
                                            </td>
                                            <td>
                                              {getStatusName(
                                                d?.dtlStatus ??
                                                  d?.status ??
                                                  master?.status
                                              )}
                                            </td>
                                            <td>
                                              <button
                                                className="btnlink"
                                                onClick={() =>
                                                  onView({ master, detail: d })
                                                }
                                              >
                                                View
                                              </button>
                                            </td>
                                          </tr>
                                        );
                                      })
                                    )}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Submit + Pagination */}
                  <div className="d-flex justify-content-between align-items-center p-2">
                    <button
                      className="btn-lg go-btn"
                      onClick={handleSubmitVerdicts}
                    >
                      Submit
                    </button>

                    {total > 0 && (
                      <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
                        <button
                          id="btnPrevious"
                          className={`btn btn-sm ${
                            currentPage === 1 ? "disabled" : ""
                          }`}
                          onClick={handlePrev}
                        >
                          Previous
                        </button>

                        {(() => {
                          const pages = getVisiblePages(
                            currentPage,
                            totalPages
                          );
                          const hasLeftEllipsis = pages[0] > 1;
                          const hasRightEllipsis =
                            pages[pages.length - 1] < totalPages;
                          return (
                            <>
                              {hasLeftEllipsis && (
                                <span className="px-1">…</span>
                              )}
                              {pages.map((p) => (
                                <button
                                  key={p}
                                  id={`btn${p}`}
                                  className={`btn btn-sm ${
                                    currentPage === p ? "active" : ""
                                  }`}
                                  onClick={() => fetchPage(p, isSearching)}
                                >
                                  {p}
                                </button>
                              ))}
                              {hasRightEllipsis && (
                                <span className="px-1">…</span>
                              )}
                            </>
                          );
                        })()}

                        <button
                          id="btnNext"
                          className={`btn btn-sm ${
                            currentPage === totalPages ? "disabled" : ""
                          }`}
                          onClick={handleNext}
                        >
                          Next
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal */}
      {show && activeRow && (
        <CaseModal
          key={String(getReqId(activeRow?.master))}
          show={show}
          onClose={() => setShow(false)}
          row={activeRow}
          documents={documents}
          authData={authData}
          statusOptions={statusOptions}
        />
      )}
    </AjaxValidation>
  );
}
