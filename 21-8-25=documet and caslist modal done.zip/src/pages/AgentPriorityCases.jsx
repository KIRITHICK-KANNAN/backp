// import React, { useEffect, useMemo, useState } from "react";
// import Modal from "react-bootstrap/Modal";
// import { useAuth } from "../context/AuthContext";
// import {
//   agentCases, // ({ session_id, sessionToken, priority })
//   updtDocs, // ({ session_id, sessionToken, reqId, dtlId, docId, status, reason, comments })
//   updtMastr, // ({ session_id, sessionToken, reqId, reqStatus })
//   agentCaseList, // ({ session_id, sessionToken, reqId })  // optional refresh for a single case
//   docHistory, // ({ session_id, sessionToken, docId })
// } from "../api/client";
// import AjaxValidation from "../hooks/AjaxValidation";

// /* -------------------------------------------
//    Reason lists (Agent Priority: no filtering)
//    and auto-comments mapped from your DB
// --------------------------------------------*/
// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];

// // If you also want Nulla reasons selectable when tab is Nulla:
// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];

// // id -> reason_comments (from your screenshots + payload)
// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// /* ---------- tiny utils ---------- */
// const fmtDMY = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   return `${String(d.getDate()).padStart(2, "0")}/${String(
//     d.getMonth() + 1
//   ).padStart(2, "0")}/${d.getFullYear()}`;
// };
// const toIST = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   const ist = new Date(d.getTime() + 5.5 * 3600 * 1000);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// };
// const statusMap = { verify: 6, reject: 3, block: 4 };

// /* =========================================================
//    Modal
// ========================================================= */
// function CaseModal({ show, onClose, row, onSaved }) {
//   const { authData } = useAuth();
//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'
//   const [act, setAct] = useState(""); // 'verify' | 'reject' | 'block'
//   const [reason, setReason] = useState("0");
//   const [comments, setComments] = useState("");
//   const [saving, setSaving] = useState(false);
//   const sessionToken =
//     authData.session_token || // your context might use snake_case
//     authData.sessionToken || // or camelCase
//     authData.Globalsessiontoken;
//   const [history, setHistory] = useState({ usr: [], cust: [] });
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   const det = row?.details?.[0] || row?.detail || {};
//   const reqId =
//     row?.master?.reqId ||
//     row?.master?.request_id ||
//     row?.master?.reqid ||
//     row?.master?.reqIdFk ||
//     "";
//   const passDoc =
//     row?.documents?.find((d) => d.type === 2) ||
//     row?.documents?.find((d) => /pass/i.test(String(d.file)));
//   const nullaDoc =
//     row?.documents?.find((d) => d.type === 1) ||
//     row?.documents?.find((d) => /nulla|osta/i.test(String(d.file)));

//   const activeDoc = tab === "passport" ? passDoc : nullaDoc;
//   const docId = activeDoc?.docId;

//   const buildOpenUrl = (fileName) =>
//     fileName
//       ? `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.session_token}_${fileName}`
//       : "";

//   const iframeSrc = activeDoc ? buildOpenUrl(activeDoc.file) : "";

//   // reset when record changes
//   useEffect(() => {
//     setTab("passport");
//     setAct("");
//     setReason("0");
//     setComments("");
//     setHistory({ usr: [], cust: [] });
//   }, [row]);

//   // auto-fill comments on reason change
//   useEffect(() => {
//     if (reason && reason !== "0") {
//       const n = Number(reason);
//       const txt = AUTO_COMMENTS[n] || "";
//       setComments(txt);
//     }
//   }, [reason]);

//   // History tab load on demand
//   useEffect(() => {
//     const load = async () => {
//       if (tab !== "history" || !docId) return;
//       try {
//         setLoadingHistory(true);
//         const res = await docHistory({
//           session_id: authData.session_id,
//           sessionToken,
//           docId,
//         });
//         setHistory({
//           usr: res?.UsrActivity || [],
//           cust: res?.CustActivity || [],
//         });
//       } catch (e) {
//         console.error("history failed", e);
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     load();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, docId]);

//   const currentReasons =
//     tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;

//   async function handleSave() {
//     if (!act) {
//       alert("Please choose Verify / Reject / Block.");
//       return;
//     }
//     // as requested: no extra client validations; let server reply guide UX
//     try {
//       setSaving(true);

//       // updtDocs
//       await updtDocs({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         dtlId: det?.dtlId,
//         docId: docId,
//         status: statusMap[act],
//         reason: act === "verify" ? "0" : String(reason || "0"),
//         comments: comments || "",
//       });

//       // updtMastr (you asked to update master after doc)
//       await updtMastr({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         reqStatus: statusMap[act], // align with doc status
//       });

//       // optional: warm refresh of the case (not strictly required)
//       await agentCaseList({
//         session_id: authData.session_id,
//         sessionToken,

//         reqId,
//       });

//       alert("Saved.");
//       onSaved?.(); // parent will reload list
//       onClose();
//     } catch (e) {
//       // “after return alone”: just surface the server message
//       console.error(e);
//       alert(e?.message || "Server rejected the update.");
//     } finally {
//       setSaving(false);
//     }
//   }

//   const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();

//   return (
//     <Modal show={show} onHide={onClose} size="xl" centered backdrop="static">
//       <Modal.Header closeButton>
//         <Modal.Title>Reference ID - {reqId}</Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="row g-3">
//           {/* Left: tabs + iframe/history */}
//           <div className="col-sm-8">
//             <div className="mb-2 d-flex gap-2">
//               <button
//                 className={`btn btn-sm ${
//                   tab === "passport" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("passport")}
//               >
//                 Passport Document
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "nulla" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("nulla")}
//               >
//                 Nulla Osta Document
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "history" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("history")}
//               >
//                 Document History
//               </button>
//             </div>

//             {tab !== "history" ? (
//               <div
//                 style={{
//                   height: 520,
//                   border: "1px solid #ddd",
//                   borderRadius: 6,
//                   overflow: "hidden",
//                 }}
//               >
//                 {iframeSrc ? (
//                   <iframe
//                     title="doc"
//                     src={iframeSrc}
//                     width="100%"
//                     height="100%"
//                     frameBorder="0"
//                   />
//                 ) : (
//                   <div className="p-3 text-muted">No file found.</div>
//                 )}
//               </div>
//             ) : (
//               <div
//                 className="border rounded p-2"
//                 style={{ maxHeight: 520, overflow: "auto" }}
//               >
//                 {loadingHistory ? (
//                   <div className="p-3">Loading history…</div>
//                 ) : (
//                   <>
//                     <div className="mb-2 fw-semibold">User Activity</div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned On</th>
//                             <th>Reason</th>
//                             <th>Comments</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.usr || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.usr.map((u, i) => (
//                               <tr key={u.alog || i}>
//                                 <td>{i + 1}</td>
//                                 <td>{u.alog}</td>
//                                 <td>{toIST(u.addOn)}</td>
//                                 <td>{u.reason}</td>
//                                 <td>{u.remarks}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>

//                     <div className="mb-2 fw-semibold mt-3">
//                       Customer Activity
//                     </div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Uploaded File</th>
//                             <th>Actioned On</th>
//                             <th>Status</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.cust || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={4} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.cust.map((c, i) => (
//                               <tr key={c.dlog || i}>
//                                 <td>{i + 1}</td>
//                                 <td>{c.file}</td>
//                                 <td>{toIST(c.addOn)}</td>
//                                 <td>{c.docStatus}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>
//                   </>
//                 )}
//               </div>
//             )}
//           </div>

//           {/* Right: details + action */}
//           <div className="col-sm-4">
//             <div className="border rounded p-2">
//               <div className="fw-semibold mb-2">Customer Details :</div>
//               <div className="d-grid gap-1 small">
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Full Name</span>
//                   <span>{fullName || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Email Id</span>
//                   <span>{row?.master?.mailId || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Passport Number</span>
//                   <span>{det?.ppn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Nulla osta No</span>
//                   <span>{det?.wpn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>DOB</span>
//                   <span>{fmtDMY(det?.dob) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Issue Date</span>
//                   <span>{fmtDMY(det?.wpndt) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Submited On</span>
//                   <span>{toIST(row?.master?.submitOn) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>VAC</span>
//                   <span>{row?.master?.vac || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Status</span>
//                   <span>Submitted</span>
//                 </div>
//               </div>

//               <div className="mt-3 small">
//                 <div className="mb-2">Action</div>
//                 <div className="d-flex gap-3">
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="verify"
//                       checked={act === "verify"}
//                       onChange={() => {
//                         setAct("verify");
//                         setReason("0");
//                       }}
//                     />
//                     Verify
//                   </label>
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="reject"
//                       checked={act === "reject"}
//                       onChange={() => setAct("reject")}
//                     />
//                     Reject
//                   </label>
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="block"
//                       checked={act === "block"}
//                       onChange={() => setAct("block")}
//                     />
//                     Block
//                   </label>
//                 </div>

//                 {(act === "reject" || act === "block") && (
//                   <div className="mt-2">
//                     <div className="mb-1">Reason</div>
//                     <select
//                       className="form-select form-select-sm"
//                       value={reason}
//                       onChange={(e) => setReason(e.target.value)}
//                     >
//                       <option value="0">---Select---</option>
//                       {currentReasons.map((r) => (
//                         <option key={r.id} value={r.id}>
//                           {r.label}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                 )}

//                 <div className="mt-2">
//                   <div className="mb-1">Comments :</div>
//                   <textarea
//                     className="form-control"
//                     rows={5}
//                     value={comments}
//                     onChange={(e) => setComments(e.target.value)}
//                   />
//                 </div>

//                 <div className="d-flex gap-2 mt-3">
//                   <button
//                     className="btn btn-secondary w-50"
//                     onClick={onClose}
//                     disabled={saving}
//                   >
//                     Close
//                   </button>
//                   <button
//                     className="btn btn-primary w-50"
//                     onClick={handleSave}
//                     disabled={saving}
//                   >
//                     {saving ? "Saving…" : "Save Doc"}
//                   </button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* =========================================================
//    Main: Priority Cases
// ========================================================= */
// export default function AgentPriorityCases() {
//   const { authData } = useAuth();
//   const [rows, setRows] = useState([]); // each: { master, details:[], documents:[] }
//   const [loading, setLoading] = useState(false);
//   const [active, setActive] = useState(null); // row for modal
//   console.log("AgentPriorityCases", authData);
//   const sessionToken =
//     authData.session_token || // your context might use snake_case
//     authData.sessionToken || // or camelCase
//     authData.Globalsessiontoken;
//   const columns = useMemo(
//     () => [
//       "#",
//       "Request Id",
//       "No. Of Applicants",
//       "Full Name",
//       "Email Id",
//       "Passport Number",
//       "Nulla osta No",
//       "DOB",
//       "Issue Date",
//       "Submited On",
//       "VAC",
//       "Status",
//       "Action",
//     ],
//     []
//   );

//   async function load() {
//     setLoading(true);
//     try {
//       const res = await agentCases({
//         session_id: authData.session_id,
//         sessionToken,
//         priority: 0,
//       });
//       // keep the raw structure you showed
//       if (res?.master?.length) {
//         const out = res.master.map((m) => ({
//           master: m,
//           details: (res.details || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//           documents: (res.documents || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//         }));
//         setRows(out);
//       } else {
//         setRows([]);
//       }
//     } catch (e) {
//       console.error(e);
//       setRows([]);
//       alert("Failed to load cases.");
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     load(); /* on mount */ // eslint-disable-next-line
//   }, []);

//   return (
//     <AjaxValidation>
//       <div className="container mt-3">
//         <h5>Agent Priority Cases</h5>

//         <div className="table-responsive mt-3">
//           <table className="table table-bordered">
//             <thead>
//               <tr>
//                 {columns.map((c) => (
//                   <th key={c}>{c}</th>
//                 ))}
//               </tr>
//             </thead>
//             <tbody>
//               {loading ? (
//                 <tr>
//                   <td colSpan={columns.length}>Loading…</td>
//                 </tr>
//               ) : rows.length === 0 ? (
//                 <tr>
//                   <td colSpan={columns.length} className="text-muted">
//                     No records
//                   </td>
//                 </tr>
//               ) : (
//                 rows.map((r, i) => {
//                   const d = r.details?.[0] || {};
//                   return (
//                     <tr key={r.master.reqId}>
//                       <td>{i + 1}</td>
//                       <td>{r.master.reqId}</td>
//                       <td>{r.master.noOfUsr}</td>
//                       <td>{`${d.fName || ""} ${d.lName || ""}`.trim()}</td>
//                       <td>{r.master.mailId}</td>
//                       <td>{d.ppn}</td>
//                       <td>{d.wpn}</td>
//                       <td>{fmtDMY(d.dob)}</td>
//                       <td>{fmtDMY(d.wpndt)}</td>
//                       <td>{toIST(r.master.submitOn)}</td>
//                       <td>{r.master.vac}</td>
//                       <td>Submitted</td>
//                       <td>
//                         <button
//                           className="btn btn-link p-0"
//                           onClick={() => setActive(r)}
//                         >
//                           View
//                         </button>
//                       </td>
//                     </tr>
//                   );
//                 })
//               )}
//             </tbody>
//           </table>
//         </div>

//         {active && (
//           <CaseModal
//             show={!!active}
//             row={active}
//             onClose={() => setActive(null)}
//             onSaved={() => load()}
//           />
//         )}
//       </div>
//     </AjaxValidation>
//   );
// }

// import React, { useEffect, useMemo, useState } from "react";
// import Modal from "react-bootstrap/Modal";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { useAuth } from "../context/AuthContext";
// import {
//   agentCases,
//   updtDocs,
//   updtMastr,
//   agentCaseList,
//   docHistory,
// } from "../api/client";

// /* ---------------- helpers ---------------- */
// const fmtDMY = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   return `${String(d.getDate()).padStart(2, "0")}/${String(
//     d.getMonth() + 1
//   ).padStart(2, "0")}/${d.getFullYear()}`;
// };
// const toIST = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   const ist = new Date(d.getTime() + 5.5 * 3600 * 1000);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// };

// /* ---------------- reasons / comments ---------------- */
// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];

// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];

// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// const statusMap = { verify: 6, reject: 3, block: 4 };

// /* =========================================================
//    Inline CaseModal
// ========================================================= */
// function CaseModal({ show, onClose, row, onSaved }) {
//   const { authData } = useAuth();
//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'
//   const [act, setAct] = useState(""); // 'verify' | 'reject' | 'block'
//   const [reason, setReason] = useState("0");
//   const [comments, setComments] = useState("");
//   const [saving, setSaving] = useState(false);
//   const [history, setHistory] = useState({ usr: [], cust: [] });
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const det = row?.detail || row?.details?.[0] || {};
//   const reqId =
//     row?.master?.reqId ||
//     row?.master?.request_id ||
//     row?.master?.reqid ||
//     row?.master?.reqIdFk ||
//     "";

//   const passDoc =
//     row?.documents?.find((d) => d.type === 2) ||
//     row?.documents?.find((d) => /pass/i.test(String(d.file)));
//   const nullaDoc =
//     row?.documents?.find((d) => d.type === 1) ||
//     row?.documents?.find((d) => /nulla|osta/i.test(String(d.file)));

//   const activeDoc = tab === "passport" ? passDoc : nullaDoc;
//   const docId = activeDoc?.docId;

//   const buildOpenUrl = (fileName) =>
//     fileName
//       ? `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`
//       : "";

//   const iframeSrc = activeDoc ? buildOpenUrl(activeDoc.file) : "";

//   useEffect(() => {
//     setTab("passport");
//     setAct("");
//     setReason("0");
//     setComments("");
//     setHistory({ usr: [], cust: [] });
//   }, [row]);

//   useEffect(() => {
//     if (reason && reason !== "0") {
//       setComments(AUTO_COMMENTS[Number(reason)] || "");
//     }
//   }, [reason]);

//   useEffect(() => {
//     const loadHis = async () => {
//       if (tab !== "history" || !docId) return;
//       try {
//         setLoadingHistory(true);
//         const res = await docHistory({
//           session_id: authData.session_id,
//           sessionToken,
//           docId,
//         });
//         setHistory({
//           usr: res?.UsrActivity || [],
//           cust: res?.CustActivity || [],
//         });
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     loadHis();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, docId]);

//   const currentReasons =
//     tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;

//   async function handleSave() {
//     if (!act) {
//       alert("Please choose Verify / Reject / Block.");
//       return;
//     }
//     try {
//       setSaving(true);

//       // 1) Update the document
//       await updtDocs({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         dtlId: det?.dtlId,
//         docId,
//         status: statusMap[act],
//         reason: act === "verify" ? "0" : String(reason || "0"),
//         comments: comments || "",
//       });

//       // 2) Update master status
//       await updtMastr({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         reqStatus: statusMap[act],
//       });

//       // 3) Warm refresh (optional)
//       await agentCaseList({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//       });

//       alert("Saved.");
//       onSaved?.();
//       onClose();
//     } catch (e) {
//       console.error(e);
//       alert(e?.message || "Server rejected the update.");
//     } finally {
//       setSaving(false);
//     }
//   }

//   const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();

//   return (
//     <Modal show={show} onHide={onClose} size="xl" centered backdrop="static">
//       <Modal.Header closeButton>
//         <Modal.Title>Reference ID - {reqId}</Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="row g-3">
//           {/* Left: tabs + iframe/history */}
//           <div className="col-sm-8">
//             <div className="mb-2 d-flex gap-2">
//               <button
//                 className={`btn btn-sm ${
//                   tab === "passport" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("passport")}
//               >
//                 Passport Document
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "nulla" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("nulla")}
//               >
//                 Nulla Osta Document
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "history" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("history")}
//               >
//                 Document History
//               </button>
//             </div>

//             {tab !== "history" ? (
//               <div
//                 style={{
//                   height: 520,
//                   border: "1px solid #ddd",
//                   borderRadius: 6,
//                   overflow: "hidden",
//                 }}
//               >
//                 {iframeSrc ? (
//                   <iframe
//                     title="doc"
//                     src={iframeSrc}
//                     width="100%"
//                     height="100%"
//                     frameBorder="0"
//                   />
//                 ) : (
//                   <div className="p-3 text-muted">No file found.</div>
//                 )}
//               </div>
//             ) : (
//               <div
//                 className="border rounded p-2"
//                 style={{ maxHeight: 520, overflow: "auto" }}
//               >
//                 {loadingHistory ? (
//                   <div className="p-3">Loading history…</div>
//                 ) : (
//                   <>
//                     <div className="mb-2 fw-semibold">User Activity</div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned On</th>
//                             <th>Reason</th>
//                             <th>Comments</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.usr || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.usr.map((u, i) => (
//                               <tr key={u.alog || i}>
//                                 <td>{i + 1}</td>
//                                 <td>{u.alog}</td>
//                                 <td>{toIST(u.addOn)}</td>
//                                 <td>{u.reason}</td>
//                                 <td>{u.remarks}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>

//                     <div className="mb-2 fw-semibold mt-3">
//                       Customer Activity
//                     </div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Uploaded File</th>
//                             <th>Actioned On</th>
//                             <th>Status</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.cust || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={4} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.cust.map((c, i) => (
//                               <tr key={c.dlog || i}>
//                                 <td>{i + 1}</td>
//                                 <td>{c.file}</td>
//                                 <td>{toIST(c.addOn)}</td>
//                                 <td>{c.docStatus}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>
//                   </>
//                 )}
//               </div>
//             )}
//           </div>

//           {/* Right: details + action */}
//           <div className="col-sm-4">
//             <div className="border rounded p-2">
//               <div className="fw-semibold mb-2">Customer Details :</div>
//               <div className="d-grid gap-1 small">
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Full Name</span>
//                   <span>{fullName || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Email Id</span>
//                   <span>{row?.master?.mailId || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Passport Number</span>
//                   <span>{det?.ppn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Nulla osta No</span>
//                   <span>{det?.wpn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>DOB</span>
//                   <span>{fmtDMY(det?.dob) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Issue Date</span>
//                   <span>{fmtDMY(det?.wpndt) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Submited On</span>
//                   <span>{toIST(row?.master?.submitOn) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>VAC</span>
//                   <span>{row?.master?.vac || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Status</span>
//                   <span>Submitted</span>
//                 </div>
//               </div>

//               <div className="mt-3 small">
//                 <div className="mb-2">Action</div>
//                 <div className="d-flex gap-3">
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="verify"
//                       checked={act === "verify"}
//                       onChange={() => {
//                         setAct("verify");
//                         setReason("0");
//                       }}
//                     />
//                     Verify
//                   </label>
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="reject"
//                       checked={act === "reject"}
//                       onChange={() => setAct("reject")}
//                     />
//                     Reject
//                   </label>
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="block"
//                       checked={act === "block"}
//                       onChange={() => setAct("block")}
//                     />
//                     Block
//                   </label>
//                 </div>

//                 {(act === "reject" || act === "block") && (
//                   <div className="mt-2">
//                     <div className="mb-1">Reason</div>
//                     <select
//                       className="form-select form-select-sm"
//                       value={reason}
//                       onChange={(e) => setReason(e.target.value)}
//                     >
//                       <option value="0">---Select---</option>
//                       {(tab === "passport"
//                         ? PASSPORT_REASON_OPTIONS
//                         : NULLA_REASON_OPTIONS
//                       ).map((r) => (
//                         <option key={r.id} value={r.id}>
//                           {r.label}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                 )}

//                 <div className="mt-2">
//                   <div className="mb-1">Comments :</div>
//                   <textarea
//                     className="form-control"
//                     rows={5}
//                     value={comments}
//                     onChange={(e) => setComments(e.target.value)}
//                   />
//                 </div>

//                 <div className="d-flex gap-2 mt-3">
//                   <button
//                     className="btn btn-secondary w-50"
//                     onClick={onClose}
//                     disabled={saving}
//                   >
//                     Close
//                   </button>
//                   <button
//                     className="btn btn-primary w-50"
//                     onClick={handleSave}
//                     disabled={saving}
//                   >
//                     {saving ? "Saving…" : "Save Doc"}
//                   </button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* =========================================================
//    Main list with expandable children
// ========================================================= */
// export default function AgentPriorityCases() {
//   const { authData } = useAuth();
//   const [rows, setRows] = useState([]); // [{ master, details:[], documents:[] }]
//   const [loading, setLoading] = useState(false);
//   const [active, setActive] = useState(null); // row for modal (per applicant)
//   const [expanded, setExpanded] = useState({}); // reqId -> bool

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const cols = useMemo(
//     () => [
//       "#",
//       "Request Id",
//       "No. Of Applicants",
//       "Full Name",
//       "Email Id",
//       "Passport Number",
//       "Nulla osta No",
//       "DOB",
//       "Issue Date",
//       "Submited On",
//       "VAC",
//       "Status",
//       "Action",
//     ],
//     []
//   );

//   const toggle = (reqId) => setExpanded((p) => ({ ...p, [reqId]: !p[reqId] }));

//   async function load() {
//     setLoading(true);
//     try {
//       const res = await agentCases({
//         session_id: authData.session_id,
//         sessionToken,
//         priority: 0,
//       });

//       if (Array.isArray(res?.master)) {
//         const out = res.master.map((m) => ({
//           master: m,
//           details: (res.details || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//           documents: (res.documents || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//         }));
//         setRows(out);
//       } else {
//         setRows([]);
//       }
//     } catch (e) {
//       console.error(e);
//       setRows([]);
//       alert("Failed to load cases.");
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     load();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   return (
//     <AjaxValidation>
//       <div className=" mt-3">
//         <h5>Agent Priority Cases</h5>

//         <div className="table-responsive mt-3">
//           <table className="table table-bordered">
//             <thead>
//               <tr>
//                 {cols.map((c) => (
//                   <th key={c}>{c}</th>
//                 ))}
//               </tr>
//             </thead>

//             <tbody>
//               {loading ? (
//                 <tr>
//                   <td colSpan={cols.length}>Loading…</td>
//                 </tr>
//               ) : rows.length === 0 ? (
//                 <tr>
//                   <td colSpan={cols.length} className="text-muted">
//                     No records
//                   </td>
//                 </tr>
//               ) : (
//                 rows.map((r, i) => {
//                   const reqId = r.master.reqId;
//                   const first = r.details?.[0] ?? {};
//                   const isOpen = !!expanded[reqId];

//                   return (
//                     <React.Fragment key={reqId}>
//                       {/* master row */}
//                       <tr>
//                         <td>
//                           <button
//                             className="btn btn-sm btn-link p-0"
//                             onClick={() => toggle(reqId)}
//                             title={isOpen ? "Collapse" : "Expand"}
//                           >
//                             {isOpen ? "▾" : "▸"}
//                           </button>{" "}
//                           {i + 1}
//                         </td>
//                         <td>{reqId}</td>
//                         <td>{r.master.noOfUsr ?? r.details?.length ?? "-"}</td>
//                         <td>
//                           {`${first.fName || ""} ${first.lName || ""}`.trim() ||
//                             "-"}
//                         </td>
//                         <td>{r.master.mailId || "-"}</td>
//                         <td>{first.ppn || "-"}</td>
//                         <td>{first.wpn || "-"}</td>
//                         <td>{fmtDMY(first.dob) || "-"}</td>
//                         <td>{fmtDMY(first.wpndt) || "-"}</td>
//                         <td>{toIST(r.master.submitOn) || "-"}</td>
//                         <td>{r.master.vac || "-"}</td>
//                         <td>Submitted</td>
//                         <td>
//                           <button
//                             className="btn btn-link p-0"
//                             onClick={() =>
//                               setActive({
//                                 master: r.master,
//                                 detail: first,
//                                 documents: r.documents,
//                               })
//                             }
//                           >
//                             View
//                           </button>
//                         </td>
//                       </tr>

//                       {/* expanded child with ALL applicants */}
//                       {isOpen && (
//                         <tr>
//                           <td
//                             colSpan={cols.length}
//                             style={{ background: "#fafafa" }}
//                           >
//                             <div className="table-responsive">
//                               <table className="table table-sm table-bordered mb-0">
//                                 <thead className="table-active">
//                                   <tr>
//                                     <th>#</th>
//                                     <th>Full Name</th>
//                                     <th>Passport Number</th>
//                                     <th>Nulla osta No</th>
//                                     <th>DOB</th>
//                                     <th>Issue Date</th>
//                                     <th>Appointment On</th>
//                                     <th>Status</th>
//                                     <th>Action</th>
//                                   </tr>
//                                 </thead>
//                                 <tbody>
//                                   {(r.details || []).map((d, idx) => (
//                                     <tr key={`${reqId}-${idx}`}>
//                                       <td>{idx + 1}</td>
//                                       <td>
//                                         {`${d.fName || ""} ${
//                                           d.lName || ""
//                                         }`.trim() || "-"}
//                                       </td>
//                                       <td>{d.ppn || "-"}</td>
//                                       <td>{d.wpn || "-"}</td>
//                                       <td>{fmtDMY(d.dob) || "-"}</td>
//                                       <td>{fmtDMY(d.wpndt) || "-"}</td>
//                                       <td>{toIST(d.slotAt) || "-"}</td>
//                                       <td>Submitted</td>
//                                       <td>
//                                         <button
//                                           className="btn btn-link p-0"
//                                           onClick={() =>
//                                             setActive({
//                                               master: r.master,
//                                               detail: d, // open modal per applicant
//                                               documents: r.documents,
//                                             })
//                                           }
//                                         >
//                                           View
//                                         </button>
//                                       </td>
//                                     </tr>
//                                   ))}
//                                   {(!r.details || r.details.length === 0) && (
//                                     <tr>
//                                       <td colSpan={9} className="text-muted">
//                                         No applicants found for this request.
//                                       </td>
//                                     </tr>
//                                   )}
//                                 </tbody>
//                               </table>
//                             </div>
//                           </td>
//                         </tr>
//                       )}
//                     </React.Fragment>
//                   );
//                 })
//               )}
//             </tbody>
//           </table>
//         </div>

//         {active && (
//           <CaseModal
//             show={!!active}
//             row={active}
//             onClose={() => setActive(null)}
//             onSaved={() => {
//               setActive(null);
//               load();
//             }}
//           />
//         )}
//       </div>
//     </AjaxValidation>
//   );
// }

// import React, { useEffect, useMemo, useState } from "react";
// import Modal from "react-bootstrap/Modal";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { useAuth } from "../context/AuthContext";
// import {
//   agentCases,
//   updtDocs,
//   updtMastr,
//   agentCaseList,
//   docHistory,
// } from "../api/client";

// /* ---------------- helpers ---------------- */
// const fmtDMY = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   return `${String(d.getDate()).padStart(2, "0")}/${String(
//     d.getMonth() + 1
//   ).padStart(2, "0")}/${d.getFullYear()}`;
// };
// const toIST = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   const ist = new Date(d.getTime() + 5.5 * 3600 * 1000);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// };

// /* ---------------- reasons / comments ---------------- */
// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];

// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];

// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// const statusMap = { verify: 6, reject: 3, block: 4 };
// // server doc status meanings we care about
// const isSubmittedLike = (s) => s === 2 || s === 5; // Submitted / Resubmitted

// /* tiny helper */
// const safeStr = (v) => (v == null ? "" : String(v));

// /* =========================================================
//    Inline CaseModal
// ========================================================= */
// function CaseModal({ show, onClose, row, onRowRefresh }) {
//   const { authData } = useAuth();
//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'
//   const [act, setAct] = useState(""); // 'verify' | 'reject' | 'block'
//   const [reason, setReason] = useState("0");
//   const [comments, setComments] = useState("");
//   const [saving, setSaving] = useState(false);
//   const [history, setHistory] = useState({ usr: [], cust: [] });
//   const [loadingHistory, setLoadingHistory] = useState(false);
//   const [uiLocked, setUiLocked] = useState(false); // lock the action UI on this tab

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const det = row?.detail || row?.details?.[0] || {};
//   const reqId =
//     row?.master?.reqId ||
//     row?.master?.request_id ||
//     row?.master?.reqid ||
//     row?.master?.reqIdFk ||
//     "";

//   const passDoc =
//     row?.documents?.find((d) => d.type === 2 && d.dtlId === det?.dtlId) ||
//     row?.documents?.find((d) => d.type === 2) ||
//     row?.documents?.find((d) => /pass/i.test(safeStr(d.file)));
//   const nullaDoc =
//     row?.documents?.find((d) => d.type === 1 && d.dtlId === det?.dtlId) ||
//     row?.documents?.find((d) => d.type === 1) ||
//     row?.documents?.find((d) => /nulla|osta/i.test(safeStr(d.file)));

//   const activeDoc = tab === "passport" ? passDoc : nullaDoc;
//   const docId = activeDoc?.docId;
//   const currentDocStatus = activeDoc?.docStatus;

//   const buildOpenUrl = (fileName) =>
//     fileName
//       ? `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`
//       : "";

//   const iframeSrc = activeDoc ? buildOpenUrl(activeDoc.file) : "";

//   // reset when switching rows
//   useEffect(() => {
//     setTab("passport");
//     setAct("");
//     setReason("0");
//     setComments("");
//     setHistory({ usr: [], cust: [] });
//   }, [row]);

//   // auto-fill comments when reason picked
//   useEffect(() => {
//     if (reason && reason !== "0") {
//       setComments(AUTO_COMMENTS[Number(reason)] || "");
//     } else if (reason === "0" && (act === "reject" || act === "block")) {
//       setComments("");
//     }
//   }, [reason, act]);

//   // load activity history for the current doc
//   useEffect(() => {
//     const loadHis = async () => {
//       if (tab !== "history" || !docId) return;
//       try {
//         setLoadingHistory(true);
//         const res = await docHistory({
//           session_id: authData.session_id,
//           sessionToken,
//           docId,
//         });
//         setHistory({
//           usr: res?.UsrActivity || [],
//           cust: res?.CustActivity || [],
//         });
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     loadHis();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, docId]);

//   // determine/indicate action + lock UI based on current doc status
//   useEffect(() => {
//     // default unlocked
//     let locked = false;
//     let nextAct = "";
//     let nextReason = "0";
//     let nextComments = "";

//     const status = currentDocStatus;

//     if (status === 6) {
//       // Verified
//       locked = true;
//       nextAct = "verify";
//     } else if (status === 3) {
//       // Rejected
//       locked = true;
//       nextAct = "reject";
//     } else if (status === 4) {
//       // Blocked
//       locked = true;
//       nextAct = "block";
//     } else if (isSubmittedLike(status)) {
//       // Submitted/ReSubmitted -> per request, read-only
//       locked = true;
//       nextAct = "";
//     } else {
//       // anything else -> editable
//       locked = false;
//       nextAct = "";
//     }

//     // fill reason/comments from doc if they exist
//     if (activeDoc?.reason) {
//       nextReason = String(activeDoc.reason);
//     }
//     if (safeStr(activeDoc?.remarks)) {
//       nextComments = safeStr(activeDoc.remarks);
//     }

//     setUiLocked(!!locked);
//     setAct(nextAct);
//     setReason(nextReason || "0");
//     setComments(nextComments || "");
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, currentDocStatus, activeDoc?.reason, activeDoc?.remarks]);

//   const currentReasons =
//     tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;

//   async function refreshRowFromServer() {
//     // fetch the latest for this reqId and wire back into the modal without closing
//     const res = await agentCaseList({
//       session_id: authData.session_id,
//       sessionToken,
//       reqId,
//     });

//     // Expecting shape: { master, details, documents }
//     const master =
//       res?.master?.find?.((m) => String(m.reqId) === String(reqId)) ||
//       res?.master ||
//       row.master;

//     const details =
//       res?.details?.filter?.((d) => String(d.reqId) === String(reqId)) ||
//       res?.details ||
//       row.details ||
//       (row.detail ? [row.detail] : []);

//     const documents =
//       res?.documents?.filter?.((d) => String(d.reqId) === String(reqId)) ||
//       res?.documents ||
//       row.documents;

//     const sameDetail =
//       details?.find?.((d) => String(d.dtlId) === String(det?.dtlId)) || det;

//     const updatedRow = {
//       master,
//       detail: sameDetail,
//       details,
//       documents,
//     };

//     // bubble to parent (so list view can also refresh if they want)
//     onRowRefresh?.(updatedRow);
//   }

//   async function handleSave() {
//     if (!act) {
//       alert("Please choose Verify / Reject / Block.");
//       return;
//     }
//     try {
//       setSaving(true);

//       // 1) Update the document
//       await updtDocs({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         dtlId: det?.dtlId,
//         docId,
//         status: statusMap[act],
//         reason: act === "verify" ? "0" : String(reason || "0"),
//         comments: comments || "",
//       });

//       // 2) Update master status (your backend flow expects this right after)
//       await updtMastr({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         reqStatus: statusMap[act],
//       });

//       // 3) Refresh the row in-place and lock the UI
//       await refreshRowFromServer();

//       alert("Saved.");

//       // ensure lock now (e.g., verified/submitted)
//       setUiLocked(true);
//     } catch (e) {
//       console.error(e);
//       alert(e?.message || "Server rejected the update.");
//     } finally {
//       setSaving(false);
//     }
//   }

//   const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();

//   const readOnly = uiLocked || saving;

//   return (
//     <Modal show={show} onHide={onClose} size="xl" centered backdrop="static">
//       <Modal.Header closeButton>
//         <Modal.Title>Reference ID - {reqId}</Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="row g-3">
//           {/* Left: tabs + iframe/history */}
//           <div className="col-sm-8">
//             <div className="mb-2 d-flex gap-2">
//               <button
//                 className={`btn btn-sm ${
//                   tab === "passport" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("passport")}
//               >
//                 Passport Document
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "nulla" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("nulla")}
//               >
//                 Nulla Osta Document
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "history" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("history")}
//               >
//                 Document History
//               </button>
//             </div>

//             {tab !== "history" ? (
//               <div
//                 style={{
//                   height: 520,
//                   border: "1px solid #ddd",
//                   borderRadius: 6,
//                   overflow: "hidden",
//                 }}
//               >
//                 {iframeSrc ? (
//                   <iframe
//                     title="doc"
//                     src={iframeSrc}
//                     width="100%"
//                     height="100%"
//                     frameBorder="0"
//                   />
//                 ) : (
//                   <div className="p-3 text-muted">No file found.</div>
//                 )}
//               </div>
//             ) : (
//               <div
//                 className="border rounded p-2"
//                 style={{ maxHeight: 520, overflow: "auto" }}
//               >
//                 {loadingHistory ? (
//                   <div className="p-3">Loading history…</div>
//                 ) : (
//                   <>
//                     <div className="mb-2 fw-semibold">User Activity</div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned On</th>
//                             <th>Reason</th>
//                             <th>Comments</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.usr || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.usr.map((u, i) => (
//                               <tr key={u.alog || i}>
//                                 <td>{i + 1}</td>
//                                 <td>{u.alog}</td>
//                                 <td>{toIST(u.addOn)}</td>
//                                 <td>{u.reason}</td>
//                                 <td>{u.remarks}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>

//                     <div className="mb-2 fw-semibold mt-3">
//                       Customer Activity
//                     </div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Uploaded File</th>
//                             <th>Actioned On</th>
//                             <th>Status</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.cust || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={4} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.cust.map((c, i) => (
//                               <tr key={c.dlog || i}>
//                                 <td>{i + 1}</td>
//                                 <td>{c.file}</td>
//                                 <td>{toIST(c.addOn)}</td>
//                                 <td>{c.docStatus}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>
//                   </>
//                 )}
//               </div>
//             )}
//           </div>

//           {/* Right: details + action */}
//           <div className="col-sm-4">
//             <div className="border rounded p-2">
//               <div className="fw-semibold mb-2">Customer Details :</div>
//               <div className="d-grid gap-1 small">
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Full Name</span>
//                   <span>{fullName || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Email Id</span>
//                   <span>{row?.master?.mailId || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Passport Number</span>
//                   <span>{det?.ppn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Nulla osta No</span>
//                   <span>{det?.wpn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>DOB</span>
//                   <span>{fmtDMY(det?.dob) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Issue Date</span>
//                   <span>{fmtDMY(det?.wpndt) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Submited On</span>
//                   <span>{toIST(row?.master?.submitOn) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>VAC</span>
//                   <span>{row?.master?.vac || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Status</span>
//                   <span>Submitted</span>
//                 </div>
//               </div>

//               <div className="mt-3 small">
//                 <div className="mb-2">Action</div>
//                 <div className="d-flex gap-3">
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="verify"
//                       checked={act === "verify"}
//                       onChange={() => {
//                         setAct("verify");
//                         setReason("0");
//                       }}
//                       disabled={readOnly}
//                     />
//                     Verify
//                   </label>
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="reject"
//                       checked={act === "reject"}
//                       onChange={() => setAct("reject")}
//                       disabled={readOnly}
//                     />
//                     Reject
//                   </label>
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="block"
//                       checked={act === "block"}
//                       onChange={() => setAct("block")}
//                       disabled={readOnly}
//                     />
//                     Block
//                   </label>
//                 </div>

//                 {(act === "reject" || act === "block") && (
//                   <div className="mt-2">
//                     <div className="mb-1">Reason</div>
//                     <select
//                       className="form-select form-select-sm"
//                       value={reason}
//                       onChange={(e) => setReason(e.target.value)}
//                       disabled={readOnly}
//                     >
//                       <option value="0">---Select---</option>
//                       {(tab === "passport"
//                         ? PASSPORT_REASON_OPTIONS
//                         : NULLA_REASON_OPTIONS
//                       ).map((r) => (
//                         <option key={r.id} value={r.id}>
//                           {r.label}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                 )}

//                 <div className="mt-2">
//                   <div className="mb-1">Comments :</div>
//                   <textarea
//                     className="form-control"
//                     rows={5}
//                     value={comments}
//                     onChange={(e) => setComments(e.target.value)}
//                     disabled={readOnly}
//                   />
//                 </div>

//                 <div className="d-flex gap-2 mt-3">
//                   <button
//                     className="btn btn-secondary w-50"
//                     onClick={onClose}
//                     disabled={saving}
//                   >
//                     Close
//                   </button>
//                   {/* Hide Save when locked */}
//                   {!uiLocked && (
//                     <button
//                       className="btn btn-primary w-50"
//                       onClick={handleSave}
//                       disabled={
//                         saving || !act || (act !== "verify" && reason === "0")
//                       }
//                       title={
//                         saving
//                           ? "Saving…"
//                           : !act
//                           ? "Choose an action"
//                           : act !== "verify" && reason === "0"
//                           ? "Select a reason"
//                           : "Save"
//                       }
//                     >
//                       {saving ? "Saving…" : "Save Doc"}
//                     </button>
//                   )}
//                 </div>

//                 {/* subtle hint badge when locked */}
//                 {uiLocked && (
//                   <div className="mt-2 text-muted">
//                     <span className="badge bg-light text-dark">
//                       This document is read-only (
//                       {[
//                         "",
//                         "Submitted",
//                         "Submitted",
//                         "Rejected",
//                         "Blocked",
//                         "Re-submitted",
//                         "Verified",
//                       ][currentDocStatus] || "Actioned"}
//                       )
//                     </span>
//                   </div>
//                 )}
//               </div>
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* =========================================================
//    Main list with expandable children
// ========================================================= */
// export default function AgentPriorityCases() {
//   const { authData } = useAuth();
//   const [rows, setRows] = useState([]); // [{ master, details:[], documents:[] }]
//   const [loading, setLoading] = useState(false);
//   const [active, setActive] = useState(null); // row for modal (per applicant)
//   const [expanded, setExpanded] = useState({}); // reqId -> bool

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const cols = useMemo(
//     () => [
//       "#",
//       "Request Id",
//       "No. Of Applicants",
//       "Full Name",
//       "Email Id",
//       "Passport Number",
//       "Nulla osta No",
//       "DOB",
//       "Issue Date",
//       "Submited On",
//       "VAC",
//       "Status",
//       "Action",
//     ],
//     []
//   );

//   const toggle = (reqId) => setExpanded((p) => ({ ...p, [reqId]: !p[reqId] }));

//   async function load() {
//     setLoading(true);
//     try {
//       const res = await agentCases({
//         session_id: authData.session_id,
//         sessionToken,
//         priority: 0,
//       });

//       if (Array.isArray(res?.master)) {
//         const out = res.master.map((m) => ({
//           master: m,
//           details: (res.details || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//           documents: (res.documents || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//         }));
//         setRows(out);
//       } else {
//         setRows([]);
//       }
//     } catch (e) {
//       console.error(e);
//       setRows([]);
//       alert("Failed to load cases.");
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     load();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   // helper to update a single row after modal save/refresh
//   function patchRow(updatedRow) {
//     setRows((prev) =>
//       prev.map((r) =>
//         String(r.master?.reqId) === String(updatedRow.master?.reqId)
//           ? {
//               master: updatedRow.master ?? r.master,
//               details: updatedRow.details ?? r.details,
//               documents: updatedRow.documents ?? r.documents,
//             }
//           : r
//       )
//     );
//     // keep modal open with fresh data
//     setActive((prev) =>
//       prev
//         ? {
//             ...prev,
//             master: updatedRow.master ?? prev.master,
//             detail:
//               updatedRow.details?.find?.(
//                 (d) => String(d.dtlId) === String(prev.detail?.dtlId)
//               ) || prev.detail,
//             details: updatedRow.details ?? prev.details,
//             documents: updatedRow.documents ?? prev.documents,
//           }
//         : prev
//     );
//   }

//   return (
//     <AjaxValidation>
//       <div className=" mt-3">
//         <h5>Agent Priority Cases</h5>

//         <div className="table-responsive mt-3">
//           <table className="table table-bordered">
//             <thead>
//               <tr>
//                 {cols.map((c) => (
//                   <th key={c}>{c}</th>
//                 ))}
//               </tr>
//             </thead>

//             <tbody>
//               {loading ? (
//                 <tr>
//                   <td colSpan={cols.length}>Loading…</td>
//                 </tr>
//               ) : rows.length === 0 ? (
//                 <tr>
//                   <td colSpan={cols.length} className="text-muted">
//                     No records
//                   </td>
//                 </tr>
//               ) : (
//                 rows.map((r, i) => {
//                   const reqId = r.master.reqId;
//                   const first = r.details?.[0] ?? {};
//                   const isOpen = !!expanded[reqId];

//                   return (
//                     <React.Fragment key={reqId}>
//                       {/* master row */}
//                       <tr>
//                         <td>
//                           <button
//                             className="btn btn-sm btn-link p-0"
//                             onClick={() => toggle(reqId)}
//                             title={isOpen ? "Collapse" : "Expand"}
//                           >
//                             {isOpen ? "▾" : "▸"}
//                           </button>{" "}
//                           {i + 1}
//                         </td>
//                         <td>{reqId}</td>
//                         <td>{r.master.noOfUsr ?? r.details?.length ?? "-"}</td>
//                         <td>
//                           {`${first.fName || ""} ${first.lName || ""}`.trim() ||
//                             "-"}
//                         </td>
//                         <td>{r.master.mailId || "-"}</td>
//                         <td>{first.ppn || "-"}</td>
//                         <td>{first.wpn || "-"}</td>
//                         <td>{fmtDMY(first.dob) || "-"}</td>
//                         <td>{fmtDMY(first.wpndt) || "-"}</td>
//                         <td>{toIST(r.master.submitOn) || "-"}</td>
//                         <td>{r.master.vac || "-"}</td>
//                         <td>Submitted</td>
//                         <td>
//                           <button
//                             className="btn btn-link p-0"
//                             onClick={() =>
//                               setActive({
//                                 master: r.master,
//                                 detail: first,
//                                 details: r.details,
//                                 documents: r.documents,
//                               })
//                             }
//                           >
//                             View
//                           </button>
//                         </td>
//                       </tr>

//                       {/* expanded child with ALL applicants */}
//                       {isOpen && (
//                         <tr>
//                           <td
//                             colSpan={cols.length}
//                             style={{ background: "#fafafa" }}
//                           >
//                             <div className="table-responsive">
//                               <table className="table table-sm table-bordered mb-0">
//                                 <thead className="table-active">
//                                   <tr>
//                                     <th>#</th>
//                                     <th>Full Name</th>
//                                     <th>Passport Number</th>
//                                     <th>Nulla osta No</th>
//                                     <th>DOB</th>
//                                     <th>Issue Date</th>
//                                     <th>Appointment On</th>
//                                     <th>Status</th>
//                                     <th>Action</th>
//                                   </tr>
//                                 </thead>
//                                 <tbody>
//                                   {(r.details || []).map((d, idx) => (
//                                     <tr key={`${reqId}-${idx}`}>
//                                       <td>{idx + 1}</td>
//                                       <td>
//                                         {`${d.fName || ""} ${
//                                           d.lName || ""
//                                         }`.trim() || "-"}
//                                       </td>
//                                       <td>{d.ppn || "-"}</td>
//                                       <td>{d.wpn || "-"}</td>
//                                       <td>{fmtDMY(d.dob) || "-"}</td>
//                                       <td>{fmtDMY(d.wpndt) || "-"}</td>
//                                       <td>{toIST(d.slotAt) || "-"}</td>
//                                       <td>Submitted</td>
//                                       <td>
//                                         <button
//                                           className="btn btn-link p-0"
//                                           onClick={() =>
//                                             setActive({
//                                               master: r.master,
//                                               detail: d, // open modal per applicant
//                                               details: r.details,
//                                               documents: r.documents,
//                                             })
//                                           }
//                                         >
//                                           View
//                                         </button>
//                                       </td>
//                                     </tr>
//                                   ))}
//                                   {(!r.details || r.details.length === 0) && (
//                                     <tr>
//                                       <td colSpan={9} className="text-muted">
//                                         No applicants found for this request.
//                                       </td>
//                                     </tr>
//                                   )}
//                                 </tbody>
//                               </table>
//                             </div>
//                           </td>
//                         </tr>
//                       )}
//                     </React.Fragment>
//                   );
//                 })
//               )}
//             </tbody>
//           </table>
//         </div>

//         {active && (
//           <CaseModal
//             show={!!active}
//             row={active}
//             onClose={() => setActive(null)}
//             onRowRefresh={(updatedRow) => {
//               // keep the modal open, patch current row + outer list
//               patchRow(updatedRow);
//             }}
//           />
//         )}
//       </div>
//     </AjaxValidation>
//   );
// }

// // AgentPriorityCases.jsx
// import React, { useEffect, useMemo, useState } from "react";
// import Modal from "react-bootstrap/Modal";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { useAuth } from "../context/AuthContext";
// import {
//   agentCases,
//   updtDocs,
//   updtMastr,
//   agentCaseList,
//   updtCase, // <- make sure your ../api/client exports this
//   docHistory,
// } from "../api/client";

// /* ---------------- helpers ---------------- */
// const fmtDMY = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   return `${String(d.getDate()).padStart(2, "0")}/${String(
//     d.getMonth() + 1
//   ).padStart(2, "0")}/${d.getFullYear()}`;
// };
// const toIST = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   const ist = new Date(d.getTime() + 5.5 * 3600 * 1000);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// };

// const statusText = (s) =>
//   s === 6
//     ? "Verified"
//     : s === 4
//     ? "Blocked"
//     : s === 3
//     ? "Rejected"
//     : s === 5
//     ? "Re‑Submitted"
//     : s === 2
//     ? "Submitted"
//     : "-";

// const statusIsFinal = (s) => s === 6 || s === 4 || s === 3;

// const docType = {
//   NULLA: 1,
//   PASS: 2,
// };

// /* ---------------- reasons / comments ---------------- */
// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];

// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];

// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// const statusMap = { verify: 6, reject: 3, block: 4 };

// /* ---------------- utilities to evaluate statuses ---------------- */
// function getDoc(rowsRow, dtlId, type) {
//   return (rowsRow?.documents || []).find(
//     (d) => String(d.dtlId) === String(dtlId) && Number(d.type) === Number(type)
//   );
// }
// function getDocStatus(rowsRow, dtlId, type) {
//   const d = getDoc(rowsRow, dtlId, type);
//   return d?.docStatus ?? 0;
// }
// function computeDtlStatusFromDocs(passSts, nullaSts) {
//   if (!statusIsFinal(passSts) || !statusIsFinal(nullaSts)) return null; // not ready
//   if (passSts === 4 || nullaSts === 4) return 4; // any Block => Block
//   if (passSts === 6 && nullaSts === 6) return 6; // both verified
//   return 3; // otherwise rejected/review mix (final but not 4/6 together)
// }
// function computeMasterStatus(allDtlStatuses) {
//   // all final?
//   const finals = allDtlStatuses.filter(statusIsFinal);
//   if (finals.length !== allDtlStatuses.length) return null; // not ready
//   const has6 = allDtlStatuses.some((s) => s === 6);
//   const has4 = allDtlStatuses.some((s) => s === 4);
//   const has3 = allDtlStatuses.some((s) => s === 3);
//   if (allDtlStatuses.every((s) => s === 6)) return 6;
//   if (allDtlStatuses.every((s) => s === 4)) return 4;
//   if (has6 && has4) return 7; // Partially Verified
//   if (has3 && !has4) return 3;
//   // fallback
//   return 7;
// }

// /* =========================================================
//    Inline CaseModal
// ========================================================= */
// function CaseModal({ show, onClose, row, onSaved, refreshRow }) {
//   const { authData } = useAuth();
//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'
//   const [act, setAct] = useState(""); // 'verify' | 'reject' | 'block'
//   const [reason, setReason] = useState("0");
//   const [comments, setComments] = useState("");
//   const [saving, setSaving] = useState(false);
//   const [history, setHistory] = useState({ usr: [], cust: [] });
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const det = row?.detail || row?.details?.[0] || {};
//   const reqId =
//     row?.master?.reqId ||
//     row?.master?.request_id ||
//     row?.master?.reqid ||
//     row?.master?.reqIdFk ||
//     "";

//   const passDoc =
//     row?.documents?.find(
//       (d) => Number(d.type) === 2 && String(d.dtlId) === String(det?.dtlId)
//     ) ||
//     row?.documents?.find(
//       (d) =>
//         /pass/i.test(String(d.file)) && String(d.dtlId) === String(det?.dtlId)
//     );
//   const nullaDoc =
//     row?.documents?.find(
//       (d) => Number(d.type) === 1 && String(d.dtlId) === String(det?.dtlId)
//     ) ||
//     row?.documents?.find(
//       (d) =>
//         /nulla|osta/i.test(String(d.file)) &&
//         String(d.dtlId) === String(det?.dtlId)
//     );

//   const activeDoc = tab === "passport" ? passDoc : nullaDoc;
//   const docId = activeDoc?.docId;

//   const buildOpenUrl = (fileName) =>
//     fileName
//       ? `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`
//       : "";

//   const iframeSrc = activeDoc ? buildOpenUrl(activeDoc.file) : "";

//   const currentReasons =
//     tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;

//   const activeDocStatus = activeDoc?.docStatus ?? 0;
//   const isReadOnly = statusIsFinal(activeDocStatus);

//   // little chip beside tab label
//   const tabLabel = (name, s) => `${name} ${s ? `— ${statusText(s)}` : ""}`;

//   useEffect(() => {
//     setTab("passport");
//     setAct("");
//     setReason("0");
//     setComments("");
//     setHistory({ usr: [], cust: [] });
//   }, [row]);

//   useEffect(() => {
//     if (reason && reason !== "0") {
//       setComments(AUTO_COMMENTS[Number(reason)] || "");
//     }
//   }, [reason]);

//   useEffect(() => {
//     const loadHis = async () => {
//       if (tab !== "history" || !docId) return;
//       try {
//         setLoadingHistory(true);
//         const res = await docHistory({
//           session_id: authData.session_id,
//           sessionToken,
//           docId,
//         });
//         setHistory({
//           usr: res?.UsrActivity || [],
//           cust: res?.CustActivity || [],
//         });
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     loadHis();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, docId]);

//   async function afterSaveChain(savedDocType) {
//     // Re-fetch this request to get fresh statuses
//     const fresh = await agentCaseList({
//       session_id: authData.session_id,
//       sessionToken,
//       reqId,
//     });

//     // Build a fresh row-like shape for this req
//     const mergedRow = {
//       master:
//         (fresh?.master || []).find((m) => String(m.reqId) === String(reqId)) ||
//         row.master,
//       details: (fresh?.details || []).filter(
//         (d) => String(d.reqId) === String(reqId)
//       ),
//       documents: (fresh?.documents || []).filter(
//         (d) => String(d.reqId) === String(reqId)
//       ),
//     };

//     // Figure out applicant doc finality for this dtlId
//     const dId = det?.dtlId;
//     const pSts = getDocStatus(mergedRow, dId, docType.PASS);
//     const nSts = getDocStatus(mergedRow, dId, docType.NULLA);
//     const dtlFinal = computeDtlStatusFromDocs(pSts, nSts);

//     // If both docs are now final (any of 6/4/3), call UpdtCase for that dtlId
//     if (dtlFinal !== null) {
//       await updtCase({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         dtlId: dId,
//         dtlStatus: dtlFinal,
//       });
//     }

//     // If ALL applicants are final, update master once
//     const allDtlStatuses = mergedRow.details.map((d) => {
//       const ps = getDocStatus(mergedRow, d.dtlId, docType.PASS);
//       const ns = getDocStatus(mergedRow, d.dtlId, docType.NULLA);
//       return computeDtlStatusFromDocs(ps, ns);
//     });

//     if (allDtlStatuses.every((s) => s !== null)) {
//       const mas = computeMasterStatus(allDtlStatuses);
//       if (mas !== null) {
//         await updtMastr({
//           session_id: authData.session_id,
//           sessionToken,
//           reqId,
//           reqStatus: mas,
//         });
//       }
//     }

//     // Ask parent to refresh the table row data, and also refresh inside modal
//     await refreshRow?.(reqId);
//   }

//   async function handleSave() {
//     if (!act) {
//       alert("Please choose Verify / Reject / Block.");
//       return;
//     }
//     if (!activeDoc?.docId) {
//       alert("No document found to update.");
//       return;
//     }
//     try {
//       setSaving(true);

//       // 1) Update this document only
//       await updtDocs({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         dtlId: det?.dtlId,
//         docId: activeDoc.docId,
//         status: statusMap[act],
//         reason: act === "verify" ? "0" : String(reason || "0"),
//         comments: comments || "",
//       });

//       // 2) Chain of post-save decisions (UpdtCase and maybe UpdtMastr)
//       await afterSaveChain(activeDoc?.type);

//       alert("Saved.");
//       onSaved?.(); // parent will reload all rows
//       // Keep modal open so agents can immediately move to other doc/tab if needed
//     } catch (e) {
//       console.error(e);
//       alert(e?.message || "Server rejected the update.");
//     } finally {
//       setSaving(false);
//     }
//   }

//   const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();

//   return (
//     <Modal show={show} onHide={onClose} size="xl" centered backdrop="static">
//       <Modal.Header closeButton>
//         <Modal.Title>Reference ID - {reqId}</Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="row g-3">
//           {/* Left: tabs + iframe/history */}
//           <div className="col-sm-8">
//             <div className="mb-2 d-flex gap-2 flex-wrap">
//               <button
//                 className={`btn btn-sm ${
//                   tab === "passport" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("passport")}
//               >
//                 {tabLabel("Passport Document", passDoc?.docStatus)}
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "nulla" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("nulla")}
//               >
//                 {tabLabel("Nulla Osta Document", nullaDoc?.docStatus)}
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "history" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("history")}
//               >
//                 Document History
//               </button>
//             </div>

//             {tab !== "history" ? (
//               <div
//                 style={{
//                   height: 520,
//                   border: "1px solid #ddd",
//                   borderRadius: 6,
//                   overflow: "hidden",
//                 }}
//               >
//                 {iframeSrc ? (
//                   <iframe
//                     title="doc"
//                     src={iframeSrc}
//                     width="100%"
//                     height="100%"
//                     frameBorder="0"
//                   />
//                 ) : (
//                   <div className="p-3 text-muted">No file found.</div>
//                 )}
//               </div>
//             ) : (
//               <div
//                 className="border rounded p-2"
//                 style={{ maxHeight: 520, overflow: "auto" }}
//               >
//                 {loadingHistory ? (
//                   <div className="p-3">Loading history…</div>
//                 ) : (
//                   <>
//                     <div className="mb-2 fw-semibold">User Activity</div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned On</th>
//                             <th>Reason</th>
//                             <th>Comments</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.usr || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.usr.map((u, i) => (
//                               <tr key={u.alog || i}>
//                                 <td>{i + 1}</td>
//                                 <td>{u.alog}</td>
//                                 <td>{toIST(u.addOn)}</td>
//                                 <td>{u.reason}</td>
//                                 <td>{u.remarks}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>

//                     <div className="mb-2 fw-semibold mt-3">
//                       Customer Activity
//                     </div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Uploaded File</th>
//                             <th>Actioned On</th>
//                             <th>Status</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.cust || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={4} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.cust.map((c, i) => (
//                               <tr key={c.dlog || i}>
//                                 <td>{i + 1}</td>
//                                 <td>{c.file}</td>
//                                 <td>{toIST(c.addOn)}</td>
//                                 <td>{c.docStatus}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>
//                   </>
//                 )}
//               </div>
//             )}
//           </div>

//           {/* Right: details + action */}
//           <div className="col-sm-4">
//             <div className="border rounded p-2">
//               <div className="fw-semibold mb-2">Customer Details :</div>
//               <div className="d-grid gap-1 small">
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Full Name</span>
//                   <span>{fullName || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Email Id</span>
//                   <span>{row?.master?.mailId || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Passport Number</span>
//                   <span>{det?.ppn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Nulla osta No</span>
//                   <span>{det?.wpn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>DOB</span>
//                   <span>{fmtDMY(det?.dob) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Issue Date</span>
//                   <span>{fmtDMY(det?.wpndt) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Submited On</span>
//                   <span>{toIST(row?.master?.submitOn) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>VAC</span>
//                   <span>{row?.master?.vac || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Status</span>
//                   <span>{statusText(activeDocStatus)}</span>
//                 </div>
//               </div>

//               <div className="mt-3 small">
//                 <div className="mb-2">Action</div>

//                 <div className="d-flex gap-3">
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="verify"
//                       checked={act === "verify"}
//                       onChange={() => {
//                         setAct("verify");
//                         setReason("0");
//                       }}
//                       disabled={isReadOnly}
//                     />
//                     Verify
//                   </label>
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="reject"
//                       checked={act === "reject"}
//                       onChange={() => setAct("reject")}
//                       disabled={isReadOnly}
//                     />
//                     Reject
//                   </label>
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="block"
//                       checked={act === "block"}
//                       onChange={() => setAct("block")}
//                       disabled={isReadOnly}
//                     />
//                     Block
//                   </label>
//                 </div>

//                 {(act === "reject" || act === "block") && (
//                   <div className="mt-2">
//                     <div className="mb-1">Reason</div>
//                     <select
//                       className="form-select form-select-sm"
//                       value={reason}
//                       onChange={(e) => setReason(e.target.value)}
//                       disabled={isReadOnly}
//                     >
//                       <option value="0">---Select---</option>
//                       {(tab === "passport"
//                         ? PASSPORT_REASON_OPTIONS
//                         : NULLA_REASON_OPTIONS
//                       ).map((r) => (
//                         <option key={r.id} value={r.id}>
//                           {r.label}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                 )}

//                 <div className="mt-2">
//                   <div className="mb-1">Comments :</div>
//                   <textarea
//                     className="form-control"
//                     rows={5}
//                     value={comments}
//                     onChange={(e) => setComments(e.target.value)}
//                     disabled={isReadOnly}
//                   />
//                 </div>

//                 <div className="d-flex gap-2 mt-3">
//                   <button className="btn btn-secondary w-50" onClick={onClose}>
//                     Close
//                   </button>
//                   <button
//                     className="btn btn-primary w-50"
//                     onClick={handleSave}
//                     disabled={
//                       isReadOnly ||
//                       saving ||
//                       !act ||
//                       ((act === "reject" || act === "block") && reason === "0")
//                     }
//                   >
//                     {saving
//                       ? "Saving…"
//                       : reason !== "0"
//                       ? "Submit"
//                       : "Save Doc"}
//                   </button>
//                 </div>

//                 {/* verify button hidden when reason chosen (your rule) */}
//                 {!(act === "verify" && reason !== "0") ? null : (
//                   <div className="text-danger mt-2">
//                     Verify is disabled when a reason is selected.
//                   </div>
//                 )}
//               </div>
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* =========================================================
//    Main list with expandable children
// ========================================================= */
// export default function AgentPriorityCases() {
//   const { authData } = useAuth();
//   const [rows, setRows] = useState([]); // [{ master, details:[], documents:[] }]
//   const [loading, setLoading] = useState(false);
//   const [active, setActive] = useState(null); // row for modal (per applicant)
//   const [expanded, setExpanded] = useState({}); // reqId -> bool

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const cols = useMemo(
//     () => [
//       "#",
//       "Request Id",
//       "No. Of Applicants",
//       "Full Name",
//       "Email Id",
//       "Passport Number",
//       "Nulla osta No",
//       "DOB",
//       "Issue Date",
//       "Submited On",
//       "VAC",
//       "Status",
//       "Action",
//     ],
//     []
//   );

//   const toggle = (reqId) => setExpanded((p) => ({ ...p, [reqId]: !p[reqId] }));

//   async function load() {
//     setLoading(true);
//     try {
//       const res = await agentCases({
//         session_id: authData.session_id,
//         sessionToken,
//         priority: 0,
//       });

//       if (Array.isArray(res?.master)) {
//         const out = res.master.map((m) => ({
//           master: m,
//           details: (res.details || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//           documents: (res.documents || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//         }));
//         setRows(out);
//       } else {
//         setRows([]);
//       }
//     } catch (e) {
//       console.error(e);
//       setRows([]);
//       alert("Failed to load cases.");
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     load();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const refreshRow = async (reqId) => {
//     try {
//       const fresh = await agentCaseList({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//       });
//       setRows((prev) =>
//         prev.map((r) => {
//           if (String(r.master.reqId) !== String(reqId)) return r;
//           return {
//             master:
//               (fresh?.master || []).find(
//                 (m) => String(m.reqId) === String(reqId)
//               ) || r.master,
//             details: (fresh?.details || []).filter(
//               (d) => String(d.reqId) === String(reqId)
//             ),
//             documents: (fresh?.documents || []).filter(
//               (d) => String(d.reqId) === String(reqId)
//             ),
//           };
//         })
//       );
//     } catch (e) {
//       console.error("refreshRow failed", e);
//     }
//   };

//   return (
//     <AjaxValidation>
//       <div className=" mt-3">
//         <h5>Agent Priority Cases</h5>

//         <div className="table-responsive mt-3">
//           <table className="table table-bordered">
//             <thead>
//               <tr>
//                 {cols.map((c) => (
//                   <th key={c}>{c}</th>
//                 ))}
//               </tr>
//             </thead>

//             <tbody>
//               {loading ? (
//                 <tr>
//                   <td colSpan={cols.length}>Loading…</td>
//                 </tr>
//               ) : rows.length === 0 ? (
//                 <tr>
//                   <td colSpan={cols.length} className="text-muted">
//                     No records
//                   </td>
//                 </tr>
//               ) : (
//                 rows.map((r, i) => {
//                   const reqId = r.master.reqId;
//                   const first = r.details?.[0] ?? {};
//                   const isOpen = !!expanded[reqId];

//                   return (
//                     <React.Fragment key={reqId}>
//                       {/* master row */}
//                       <tr>
//                         <td>
//                           <button
//                             className="btn btn-sm btn-link p-0"
//                             onClick={() => toggle(reqId)}
//                             title={isOpen ? "Collapse" : "Expand"}
//                           >
//                             {isOpen ? "▾" : "▸"}
//                           </button>{" "}
//                           {i + 1}
//                         </td>
//                         <td>{reqId}</td>
//                         <td>{r.master.noOfUsr ?? r.details?.length ?? "-"}</td>
//                         <td>
//                           {`${first.fName || ""} ${first.lName || ""}`.trim() ||
//                             "-"}
//                         </td>
//                         <td>{r.master.mailId || "-"}</td>
//                         <td>{first.ppn || "-"}</td>
//                         <td>{first.wpn || "-"}</td>
//                         <td>{fmtDMY(first.dob) || "-"}</td>
//                         <td>{fmtDMY(first.wpndt) || "-"}</td>
//                         <td>{toIST(r.master.submitOn) || "-"}</td>
//                         <td>{r.master.vac || "-"}</td>
//                         <td>Submitted</td>
//                         <td>
//                           <button
//                             className="btn btn-link p-0"
//                             onClick={() =>
//                               setActive({
//                                 master: r.master,
//                                 detail: first,
//                                 documents: r.documents,
//                               })
//                             }
//                           >
//                             View
//                           </button>
//                         </td>
//                       </tr>

//                       {/* expanded child with ALL applicants */}
//                       {isOpen && (
//                         <tr>
//                           <td
//                             colSpan={cols.length}
//                             style={{ background: "#fafafa" }}
//                           >
//                             <div className="table-responsive">
//                               <table className="table table-sm table-bordered mb-0">
//                                 <thead className="table-active">
//                                   <tr>
//                                     <th>#</th>
//                                     <th>Full Name</th>
//                                     <th>Passport Number</th>
//                                     <th>Nulla osta No</th>
//                                     <th>DOB</th>
//                                     <th>Issue Date</th>
//                                     <th>Appointment On</th>
//                                     <th>Status (derived)</th>
//                                     <th>Action</th>
//                                   </tr>
//                                 </thead>
//                                 <tbody>
//                                   {(r.details || []).map((d, idx) => {
//                                     const ps = getDocStatus(
//                                       r,
//                                       d.dtlId,
//                                       docType.PASS
//                                     );
//                                     const ns = getDocStatus(
//                                       r,
//                                       d.dtlId,
//                                       docType.NULLA
//                                     );
//                                     const derived = computeDtlStatusFromDocs(
//                                       ps,
//                                       ns
//                                     );
//                                     return (
//                                       <tr key={`${reqId}-${idx}`}>
//                                         <td>{idx + 1}</td>
//                                         <td>
//                                           {`${d.fName || ""} ${
//                                             d.lName || ""
//                                           }`.trim() || "-"}
//                                         </td>
//                                         <td>{d.ppn || "-"}</td>
//                                         <td>{d.wpn || "-"}</td>
//                                         <td>{fmtDMY(d.dob) || "-"}</td>
//                                         <td>{fmtDMY(d.wpndt) || "-"}</td>
//                                         <td>{toIST(d.slotAt) || "-"}</td>
//                                         <td>
//                                           {derived === null
//                                             ? "Pending"
//                                             : statusText(derived)}
//                                         </td>
//                                         <td>
//                                           <button
//                                             className="btn btn-link p-0"
//                                             onClick={() =>
//                                               setActive({
//                                                 master: r.master,
//                                                 detail: d, // open modal per applicant
//                                                 documents: r.documents,
//                                               })
//                                             }
//                                           >
//                                             View
//                                           </button>
//                                         </td>
//                                       </tr>
//                                     );
//                                   })}
//                                   {(!r.details || r.details.length === 0) && (
//                                     <tr>
//                                       <td colSpan={9} className="text-muted">
//                                         No applicants found for this request.
//                                       </td>
//                                     </tr>
//                                   )}
//                                 </tbody>
//                               </table>
//                             </div>
//                           </td>
//                         </tr>
//                       )}
//                     </React.Fragment>
//                   );
//                 })
//               )}
//             </tbody>
//           </table>
//         </div>

//         {active && (
//           <CaseModal
//             show={!!active}
//             row={active}
//             onClose={() => setActive(null)}
//             onSaved={() => {
//               load();
//             }}
//             refreshRow={refreshRow}
//           />
//         )}
//       </div>
//     </AjaxValidation>
//   );
// }

// import React, { useEffect, useMemo, useState } from "react";
// import Modal from "react-bootstrap/Modal";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { useAuth } from "../context/AuthContext";
// import {
//   agentCases,
//   agentCaseList,
//   updtDocs,
//   updtCase,
//   updtMastr,
//   docHistory,
// } from "../api/client";

// /* ======================= helpers ======================= */
// const fmtDMY = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   return `${String(d.getDate()).padStart(2, "0")}/${String(
//     d.getMonth() + 1
//   ).padStart(2, "0")}/${d.getFullYear()}`;
// };
// const toIST = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   const ist = new Date(d.getTime() + 5.5 * 3600 * 1000);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// };
// const statusText = (s) =>
//   s === 6
//     ? "Verified"
//     : s === 4
//     ? "Blocked"
//     : s === 3
//     ? "Rejected"
//     : s === 5
//     ? "Re‑Submitted"
//     : s === 2
//     ? "Submitted"
//     : "Pending";

// const statusIsFinal = (s) => s === 6 || s === 4 || s === 3;

// const DOC = { NULLA: 1, PASS: 2 };
// const statusMap = { verify: 6, reject: 3, block: 4 };

// /* ===== reasons & auto-comments ===== */
// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];
// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];
// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// /* ============ tiny utilities to read/derive statuses ============ */
// function getDoc(row, dtlId, type) {
//   return (row?.documents || []).find(
//     (d) => String(d.dtlId) === String(dtlId) && Number(d.type) === Number(type)
//   );
// }
// function getDocStatus(row, dtlId, type) {
//   const d = getDoc(row, dtlId, type);
//   return d?.docStatus ?? 0;
// }
// function computeDtlStatusFromDocs(passSts, nullaSts) {
//   // final only when BOTH docs are final (Verify/Reject/Block)
//   if (!statusIsFinal(passSts) || !statusIsFinal(nullaSts)) return null;
//   if (passSts === 4 || nullaSts === 4) return 4; // any Block -> Block
//   if (passSts === 6 && nullaSts === 6) return 6; // both verified
//   return 3; // otherwise a final Rejected/Verified mix
// }
// function computeMasterStatus(allDtlStatuses) {
//   const finals = allDtlStatuses.filter((s) => s !== null);
//   if (finals.length !== allDtlStatuses.length) return null;
//   const all6 = allDtlStatuses.every((s) => s === 6);
//   const all4 = allDtlStatuses.every((s) => s === 4);
//   if (all6) return 6;
//   if (all4) return 4;
//   return 7; // Partially Verified
// }

// /* =========================================================
//    Case Modal (kept open after each save)
// ========================================================= */
// function CaseModal({ show, onClose, row, onAfterAnySave }) {
//   const { authData } = useAuth();
//   const [tab, setTab] = useState("passport"); // passport | nulla | history
//   const [act, setAct] = useState(""); // verify | reject | block
//   const [reason, setReason] = useState("0");
//   const [comments, setComments] = useState("");
//   const [saving, setSaving] = useState(false);
//   const [history, setHistory] = useState({ usr: [], cust: [] });
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const det = row?.detail || {};
//   const reqId =
//     row?.master?.reqId ?? row?.master?.reqIdFk ?? row?.master?.reqid;

//   const passDoc =
//     row?.documents?.find(
//       (d) =>
//         Number(d.type) === DOC.PASS && String(d.dtlId) === String(det?.dtlId)
//     ) ||
//     row?.documents?.find(
//       (d) =>
//         /pass/i.test(String(d.file)) && String(d.dtlId) === String(det?.dtlId)
//     );
//   const nullaDoc =
//     row?.documents?.find(
//       (d) =>
//         Number(d.type) === DOC.NULLA && String(d.dtlId) === String(det?.dtlId)
//     ) ||
//     row?.documents?.find(
//       (d) =>
//         /nulla|osta/i.test(String(d.file)) &&
//         String(d.dtlId) === String(det?.dtlId)
//     );

//   const activeDoc =
//     tab === "passport" ? passDoc : tab === "nulla" ? nullaDoc : null;
//   const docId = activeDoc?.docId;
//   const activeDocStatus = activeDoc?.docStatus ?? 0;
//   const isReadOnly = statusIsFinal(activeDocStatus);

//   const buildOpenUrl = (fileName) =>
//     fileName
//       ? `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`
//       : "";

//   const iframeSrc =
//     tab === "history" ? "" : activeDoc ? buildOpenUrl(activeDoc.file) : "";

//   useEffect(() => {
//     setTab("passport");
//     setAct("");
//     setReason("0");
//     setComments("");
//     setHistory({ usr: [], cust: [] });
//   }, [row]);

//   useEffect(() => {
//     if ((act === "reject" || act === "block") && reason !== "0") {
//       const txt = AUTO_COMMENTS[Number(reason)];
//       if (txt) setComments(txt);
//     }
//   }, [reason, act]);

//   useEffect(() => {
//     const loadHistory = async () => {
//       if (tab !== "history" || !docId) return;
//       try {
//         setLoadingHistory(true);
//         const res = await docHistory({
//           session_id: authData.session_id,
//           sessionToken,
//           docId,
//         });
//         setHistory({
//           usr: res?.UsrActivity || [],
//           cust: res?.CustActivity || [],
//         });
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     loadHistory();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, docId]);

//   async function refreshAndCascade() {
//     // 1) Refresh the whole request
//     const fresh = await agentCaseList({
//       session_id: authData.session_id,
//       sessionToken,
//       reqId,
//     });

//     const merged = {
//       master:
//         (fresh?.master || []).find((m) => String(m.reqId) === String(reqId)) ||
//         row.master,
//       details: (fresh?.details || []).filter(
//         (d) => String(d.reqId) === String(reqId)
//       ),
//       documents: (fresh?.documents || []).filter(
//         (d) => String(d.reqId) === String(reqId)
//       ),
//     };

//     // 2) If both docs for CURRENT applicant are final -> UpdtCase
//     const dId = det?.dtlId;
//     const pSts = getDocStatus(merged, dId, DOC.PASS);
//     const nSts = getDocStatus(merged, dId, DOC.NULLA);
//     const dtlFinal = computeDtlStatusFromDocs(pSts, nSts);
//     if (dtlFinal !== null) {
//       await updtCase({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         dtlId: dId,
//         dtlStatus: dtlFinal,
//       });
//     }

//     // 3) If ALL applicants are final -> UpdtMastr once, then tell parent to reload AgentCases
//     const allDtl = merged.details.map((d) =>
//       computeDtlStatusFromDocs(
//         getDocStatus(merged, d.dtlId, DOC.PASS),
//         getDocStatus(merged, d.dtlId, DOC.NULLA)
//       )
//     );
//     if (allDtl.every((s) => s !== null)) {
//       const reqStatus = computeMasterStatus(allDtl);
//       if (reqStatus !== null) {
//         await updtMastr({
//           session_id: authData.session_id,
//           sessionToken,
//           reqId,
//           reqStatus,
//         });
//         // tell parent request is fully completed so it can fetch next batch/case
//         onAfterAnySave?.({ reqCompleted: true, reqId });
//         return;
//       }
//     }

//     // otherwise just refresh the row in parent (so next applicant shows updated)
//     onAfterAnySave?.({ reqCompleted: false, reqId });
//   }

//   async function handleSave() {
//     if (!activeDoc?.docId) {
//       alert("No document found.");
//       return;
//     }
//     if (!act) {
//       alert("Choose Verify / Reject / Block.");
//       return;
//     }
//     if ((act === "reject" || act === "block") && reason === "0") {
//       alert("Select a reason.");
//       return;
//     }

//     try {
//       setSaving(true);
//       // UpdtDocs for the selected tab/document only
//       await updtDocs({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         dtlId: det?.dtlId,
//         docId: activeDoc.docId,
//         status: statusMap[act],
//         reason: act === "verify" ? "0" : String(reason || "0"),
//         comments: comments || "",
//       });

//       // chain (AgentCaseList -> UpdtCase if needed -> UpdtMastr if completed)
//       await refreshAndCascade();

//       // keep modal open
//       alert("Saved.");
//       // reset action controls, but stay on the current tab
//       setAct("");
//       setReason("0");
//       setComments("");
//     } catch (e) {
//       console.error(e);
//       alert(e?.message || "Server error while saving.");
//     } finally {
//       setSaving(false);
//     }
//   }

//   const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();
//   const reasons =
//     tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;

//   return (
//     <Modal show={show} onHide={onClose} size="xl" centered backdrop="static">
//       <Modal.Header closeButton>
//         <Modal.Title>Reference ID - {reqId}</Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="row g-3">
//           {/* Left side: tabs + content */}
//           <div className="col-sm-8">
//             <div className="mb-2 d-flex gap-2 flex-wrap">
//               <button
//                 className={`btn btn-sm ${
//                   tab === "passport" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("passport")}
//               >
//                 Passport Document — {statusText(passDoc?.docStatus ?? 0)}
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "nulla" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("nulla")}
//               >
//                 Nulla Osta Document — {statusText(nullaDoc?.docStatus ?? 0)}
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "history" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("history")}
//                 disabled={!activeDoc?.docId}
//               >
//                 Document History
//               </button>
//             </div>

//             {tab !== "history" ? (
//               <div
//                 style={{
//                   height: 520,
//                   border: "1px solid #ddd",
//                   borderRadius: 6,
//                   overflow: "hidden",
//                 }}
//               >
//                 {iframeSrc ? (
//                   <iframe
//                     title="doc"
//                     src={iframeSrc}
//                     width="100%"
//                     height="100%"
//                     frameBorder="0"
//                   />
//                 ) : (
//                   <div className="p-3 text-muted">No file found.</div>
//                 )}
//               </div>
//             ) : (
//               <div
//                 className="border rounded p-2"
//                 style={{ maxHeight: 520, overflow: "auto" }}
//               >
//                 {loadingHistory ? (
//                   <div className="p-3">Loading history…</div>
//                 ) : (
//                   <>
//                     <div className="mb-2 fw-semibold">User Activity</div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>Action</th>
//                             <th>Actioned On</th>
//                             <th>Reason</th>
//                             <th>Comments</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.usr || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={4} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.usr.map((u, i) => (
//                               <tr key={u.alog || i}>
//                                 <td>{u.alog}</td>
//                                 <td>{toIST(u.addOn)}</td>
//                                 <td>{u.reason}</td>
//                                 <td>{u.remarks}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>

//                     <div className="mb-2 fw-semibold mt-3">
//                       Customer Activity
//                     </div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>Uploaded File</th>
//                             <th>Actioned On</th>
//                             <th>Status</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.cust || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={3} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.cust.map((c, i) => (
//                               <tr key={c.dlog || i}>
//                                 <td>{c.file}</td>
//                                 <td>{toIST(c.addOn)}</td>
//                                 <td>{statusText(c.docStatus)}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>
//                   </>
//                 )}
//               </div>
//             )}
//           </div>

//           {/* Right side: details + action */}
//           <div className="col-sm-4">
//             <div className="border rounded p-2">
//               <div className="fw-semibold mb-2">Customer Details :</div>
//               <div className="d-grid gap-1 small">
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Full Name</span>
//                   <span>{fullName || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Email Id</span>
//                   <span>{row?.master?.mailId || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Passport Number</span>
//                   <span>{det?.ppn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Nulla osta No</span>
//                   <span>{det?.wpn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>DOB</span>
//                   <span>{fmtDMY(det?.dob) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Issue Date</span>
//                   <span>{fmtDMY(det?.wpndt) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Submited On</span>
//                   <span>{toIST(row?.master?.submitOn) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>VAC</span>
//                   <span>{row?.master?.vac || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Status</span>
//                   <span>{statusText(activeDocStatus)}</span>
//                 </div>
//               </div>

//               <div className="mt-3 small">
//                 <div className="mb-2">Action</div>
//                 <div className="d-flex gap-3">
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="verify"
//                       checked={act === "verify"}
//                       onChange={() => {
//                         setAct("verify");
//                         setReason("0");
//                       }}
//                       disabled={isReadOnly}
//                     />
//                     Verify
//                   </label>
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="reject"
//                       checked={act === "reject"}
//                       onChange={() => setAct("reject")}
//                       disabled={isReadOnly}
//                     />
//                     Reject
//                   </label>
//                   <label className="d-flex align-items-center gap-1">
//                     <input
//                       type="radio"
//                       name="act"
//                       value="block"
//                       checked={act === "block"}
//                       onChange={() => setAct("block")}
//                       disabled={isReadOnly}
//                     />
//                     Block
//                   </label>
//                 </div>

//                 {(act === "reject" || act === "block") && (
//                   <div className="mt-2">
//                     <div className="mb-1">Reason</div>
//                     <select
//                       className="form-select form-select-sm"
//                       value={reason}
//                       onChange={(e) => setReason(e.target.value)}
//                       disabled={isReadOnly}
//                     >
//                       <option value="0">---Select---</option>
//                       {reasons.map((r) => (
//                         <option key={r.id} value={r.id}>
//                           {r.label}
//                         </option>
//                       ))}
//                     </select>
//                   </div>
//                 )}

//                 <div className="mt-2">
//                   <div className="mb-1">Comments :</div>
//                   <textarea
//                     className="form-control"
//                     rows={5}
//                     value={comments}
//                     onChange={(e) => setComments(e.target.value)}
//                     disabled={isReadOnly}
//                   />
//                 </div>

//                 <div className="d-flex gap-2 mt-3">
//                   <button className="btn btn-secondary w-50" onClick={onClose}>
//                     Close
//                   </button>
//                   <button
//                     className="btn btn-primary w-50"
//                     onClick={handleSave}
//                     disabled={
//                       isReadOnly ||
//                       saving ||
//                       !act ||
//                       ((act === "reject" || act === "block") && reason === "0")
//                     }
//                   >
//                     {saving ? "Saving…" : "Save"}
//                   </button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* =========================================================
//    Single-table view (no expansion). Group rows by reqId.
//    - Remove '#' column.
//    - Show Request Id & No. of Applicants ONLY on the first row of each group.
// ========================================================= */
// export default function AgentPriorityCases() {
//   const { authData } = useAuth();
//   const [groups, setGroups] = useState([]); // [{ master, details:[], documents:[] }]
//   const [loading, setLoading] = useState(false);
//   const [active, setActive] = useState(null); // { master, detail, documents }

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const cols = useMemo(
//     () => [
//       "Request Id",
//       "No. Of Applicants",
//       "Full Name",
//       "Email Id",
//       "Passport Number",
//       "Nulla osta No",
//       "DOB",
//       "Issue Date",
//       "Appointment On",
//       "Submited On",
//       "VAC",
//       "Status",
//       "Action",
//     ],
//     []
//   );

//   async function loadAgentCases() {
//     setLoading(true);
//     try {
//       const res = await agentCases({
//         session_id: authData.session_id,
//         sessionToken,
//         priority: 1,
//       });

//       if (Array.isArray(res?.master)) {
//         const out = res.master.map((m) => ({
//           master: m,
//           details: (res.details || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//           documents: (res.documents || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//         }));
//         setGroups(out);
//       } else {
//         setGroups([]);
//       }
//     } catch (e) {
//       console.error(e);
//       setGroups([]);
//       alert("Failed to load cases.");
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     loadAgentCases();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   // Refresh a single request's rows via AgentCaseList (called after saving one doc/applicant)
//   const refreshRequest = async (reqId) => {
//     try {
//       const fresh = await agentCaseList({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//       });
//       setGroups((prev) =>
//         prev.map((g) => {
//           if (String(g.master.reqId) !== String(reqId)) return g;
//           return {
//             master:
//               (fresh?.master || []).find(
//                 (m) => String(m.reqId) === String(reqId)
//               ) || g.master,
//             details: (fresh?.details || []).filter(
//               (d) => String(d.reqId) === String(reqId)
//             ),
//             documents: (fresh?.documents || []).filter(
//               (d) => String(d.reqId) === String(reqId)
//             ),
//           };
//         })
//       );
//     } catch (e) {
//       console.error("refreshRequest failed", e);
//     }
//   };

//   // Called after any UpdtDocs save inside the modal:
//   // - If reqCompleted => reload AgentCases to fetch the next request/case
//   // - Else => just refresh that request block rows
//   function onAfterAnySave({ reqCompleted, reqId }) {
//     if (reqCompleted) {
//       loadAgentCases(); // finished one request fully; fetch the next case list
//     } else {
//       refreshRequest(reqId);
//     }
//   }

//   return (
//     <AjaxValidation>
//       <div className="mt-3">
//         <h5>Agent Priority Cases</h5>

//         <div className="table-responsive mt-3">
//           <table className="table table-bordered">
//             <thead>
//               <tr>
//                 {cols.map((c) => (
//                   <th key={c}>{c}</th>
//                 ))}
//               </tr>
//             </thead>

//             <tbody>
//               {loading ? (
//                 <tr>
//                   <td colSpan={cols.length}>Loading…</td>
//                 </tr>
//               ) : groups.length === 0 ? (
//                 <tr>
//                   <td colSpan={cols.length} className="text-muted">
//                     No records
//                   </td>
//                 </tr>
//               ) : (
//                 groups.map((grp) => {
//                   const reqId = grp.master.reqId;
//                   const total = grp.details?.length || 0;

//                   return (grp.details || []).map((d, idx) => {
//                     const firstRow = idx === 0;

//                     // derived applicant status (for convenience on the list)
//                     const ps = getDocStatus(grp, d.dtlId, DOC.PASS);
//                     const ns = getDocStatus(grp, d.dtlId, DOC.NULLA);
//                     const derived = computeDtlStatusFromDocs(ps, ns);

//                     return (
//                       <tr key={`${reqId}-${d.dtlId}`}>
//                         {/* Request Id & No. of Applicants only for first row */}
//                         <td>{firstRow ? reqId : ""}</td>
//                         <td>{firstRow ? total : ""}</td>

//                         {/* Applicant fields */}
//                         <td>
//                           {`${d.fName || ""} ${d.lName || ""}`.trim() || "-"}
//                         </td>
//                         <td>{grp.master.mailId || "-"}</td>
//                         <td>{d.ppn || "-"}</td>
//                         <td>{d.wpn || "-"}</td>
//                         <td>{fmtDMY(d.dob) || "-"}</td>
//                         <td>{fmtDMY(d.wpndt) || "-"}</td>
//                         <td>{toIST(d.slotAt) || "-"}</td>

//                         {/* Master-only fields (show on first row for aesthetics) */}
//                         <td>
//                           {firstRow ? toIST(grp.master.submitOn) || "-" : ""}
//                         </td>
//                         <td>{firstRow ? grp.master.vac || "-" : ""}</td>

//                         {/* Derived status for each applicant */}
//                         <td>
//                           {derived === null ? "Pending" : statusText(derived)}
//                         </td>

//                         <td>
//                           <button
//                             className="btn btn-link p-0"
//                             onClick={() =>
//                               setActive({
//                                 master: grp.master,
//                                 detail: d,
//                                 documents: grp.documents,
//                               })
//                             }
//                           >
//                             View
//                           </button>
//                         </td>
//                       </tr>
//                     );
//                   });
//                 })
//               )}
//             </tbody>
//           </table>
//         </div>

//         {active && (
//           <CaseModal
//             show={!!active}
//             row={active}
//             onClose={() => setActive(null)}
//             onAfterAnySave={onAfterAnySave}
//           />
//         )}
//       </div>
//     </AjaxValidation>
//   );
// }

import React, { useEffect, useMemo, useState } from "react";
import Modal from "react-bootstrap/Modal";
import AjaxValidation from "../hooks/AjaxValidation";
import { useAuth } from "../context/AuthContext";
import {
  agentCases,
  updtDocs,
  updtMastr,
  agentCaseList,
  updtCase,
  docHistory,
} from "../api/client";

/* ---------- tiny utils ---------- */
const fmtDMY = (s) => {
  if (!s) return "";
  const d = new Date(s);
  if (Number.isNaN(d)) return "";
  return `${String(d.getDate()).padStart(2, "0")}/${String(
    d.getMonth() + 1
  ).padStart(2, "0")}/${d.getFullYear()}`;
};
const toIST = (s) => {
  if (!s) return "";
  const d = new Date(s);
  if (Number.isNaN(d)) return "";
  const ist = new Date(d.getTime() + 5.5 * 3600 * 1000);
  const dd = String(ist.getDate()).padStart(2, "0");
  const mm = String(ist.getMonth() + 1).padStart(2, "0");
  const yyyy = ist.getFullYear();
  const hh = String(ist.getHours()).padStart(2, "0");
  const mi = String(ist.getMinutes()).padStart(2, "0");
  return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
};
const statusText = (s) =>
  s === 6
    ? "Verified"
    : s === 4
    ? "Blocked"
    : s === 3
    ? "Rejected"
    : s === 5
    ? "Re‑Submitted"
    : s === 2
    ? "Submitted"
    : "-";
const statusIsFinal = (s) => s === 6 || s === 4 || s === 3;
const statusMap = { verify: 6, reject: 3, block: 4 };
const docType = { NULLA: 1, PASS: 2 };

const PASSPORT_REASON_OPTIONS = [
  { id: 16, label: "NOT ELIGIBLE" },
  { id: 17, label: "DOCUMENT NOT CLEAR" },
  { id: 19, label: "DETAILS MISMATCH" },
  { id: 21, label: "DUPLICATE ENTRY" },
  { id: 22, label: "EXPIRED PASSPORT" },
  { id: 23, label: "INCOMPLETE PASSPORT" },
  { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
];
const NULLA_REASON_OPTIONS = [
  { id: 1, label: "NOT ELIGIBLE" },
  { id: 2, label: "NOT A NULLA OSTA" },
  { id: 3, label: "DOCUMENT NOT CLEAR" },
  { id: 4, label: "INCOMPLETE DOCUMENT" },
  { id: 5, label: "INVALID DATE OF ISSUE" },
  { id: 6, label: "DETAILS MISMATCH" },
  { id: 7, label: "BLOCKED ISSUE DATE" },
  { id: 8, label: "DUPLICATE ENTRY" },
];
const AUTO_COMMENTS = {
  1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
  2: "Not a Nulla Osta",
  3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
  4: "Nulla osta uploaded is not complete",
  5: "The date of issue is not correct for the attached Nulla Osta.",
  6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
  7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
  8: "The Nulla Osta and Passport have already been submitted for appointment",

  16: "NOT ELIGIBLE",
  17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
  18: "Document uploaded is not matching the format of a Passport",
  19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
  20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
  21: "The Nulla Osta and Passport have already been submitted for appointment",
  22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
  23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
  24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
  25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
  26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
};

/* ---------------- doc helpers ---------------- */
const getDoc = (row, dtlId, type) =>
  (row?.documents || []).find(
    (d) => String(d.dtlId) === String(dtlId) && Number(d.type) === Number(type)
  );
const getDocStatus = (row, dtlId, type) =>
  getDoc(row, dtlId, type)?.docStatus ?? 0;

const computeDtlStatusFromDocs = (passSts, nullaSts) => {
  if (!statusIsFinal(passSts) || !statusIsFinal(nullaSts)) return null;
  if (passSts === 4 || nullaSts === 4) return 4;
  if (passSts === 6 && nullaSts === 6) return 6;
  return 3;
};
const computeMasterStatus = (allDtlStatuses) => {
  const finals = allDtlStatuses.filter(statusIsFinal);
  if (finals.length !== allDtlStatuses.length) return null;
  const all6 = allDtlStatuses.every((s) => s === 6);
  const all4 = allDtlStatuses.every((s) => s === 4);
  if (all6) return 6;
  if (all4) return 4;
  return 7; // partially verified / mixed
};

/* =========================================================
   Modal
========================================================= */
// function CaseModal({ show, onClose, row, onWholeListRefresh, refreshRow }) {
//   const { authData } = useAuth();
//   const [tab, setTab] = useState("passport"); // passport | nulla | history
//   const [saving, setSaving] = useState(false);

//   // keep each doc’s chosen act/reason/comments & lock state so they don’t clear
//   // key = `${dtlId}:${type}`
//   const [docUiState, setDocUiState] = useState({});

//   // history
//   const [history, setHistory] = useState({ usr: [], cust: [] });
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const det = row?.detail || {};
//   const reqId =
//     row?.master?.reqId ||
//     row?.master?.request_id ||
//     row?.master?.reqid ||
//     row?.master?.reqIdFk ||
//     "";

//   const passDoc =
//     row?.documents?.find(
//       (d) => Number(d.type) === 2 && String(d.dtlId) === String(det?.dtlId)
//     ) ||
//     row?.documents?.find(
//       (d) =>
//         /pass/i.test(String(d.file)) && String(d.dtlId) === String(det?.dtlId)
//     );
//   const nullaDoc =
//     row?.documents?.find(
//       (d) => Number(d.type) === 1 && String(d.dtlId) === String(det?.dtlId)
//     ) ||
//     row?.documents?.find(
//       (d) =>
//         /nulla|osta/i.test(String(d.file)) &&
//         String(d.dtlId) === String(det?.dtlId)
//     );

//   const activeType = tab === "passport" ? docType.PASS : docType.NULLA;
//   const activeDoc = tab === "passport" ? passDoc : nullaDoc;
//   const activeKey = `${det?.dtlId}:${activeType}`;

//   const current = docUiState[activeKey] || {
//     act: "",
//     reason: "0",
//     comments: "",
//     locked: statusIsFinal(activeDoc?.docStatus),
//   };

//   // if server already final, lock it immediately
//   useEffect(() => {
//     setDocUiState((p) => ({
//       ...p,
//       [`${det?.dtlId}:${docType.PASS}`]: {
//         ...(p[`${det?.dtlId}:${docType.PASS}`] || {
//           act: "",
//           reason: "0",
//           comments: "",
//         }),
//         locked: statusIsFinal(passDoc?.docStatus),
//       },
//       [`${det?.dtlId}:${docType.NULLA}`]: {
//         ...(p[`${det?.dtlId}:${docType.NULLA}`] || {
//           act: "",
//           reason: "0",
//           comments: "",
//         }),
//         locked: statusIsFinal(nullaDoc?.docStatus),
//       },
//     }));
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [det?.dtlId, passDoc?.docStatus, nullaDoc?.docStatus]);

//   // auto-fill comments on reason change
//   useEffect(() => {
//     if (current.act !== "reject" && current.act !== "block") return;
//     if (current.reason && current.reason !== "0") {
//       const auto = AUTO_COMMENTS[Number(current.reason)] || "";
//       setDocUiState((p) => ({
//         ...p,
//         [activeKey]: { ...current, comments: auto },
//       }));
//     }
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [current.reason, activeKey]);

//   // document history loads when tab === 'history'
//   useEffect(() => {
//     const load = async () => {
//       if (tab !== "history") return;
//       const docId = nullaDoc?.docId || passDoc?.docId; // we’ll still show history for both in tables
//       if (!docId) return;
//       try {
//         setLoadingHistory(true);
//         const res = await docHistory({
//           session_id: authData.session_id,
//           sessionToken,
//           docId, // BE returns both UsrActivity & CustActivity for the docId family
//         });
//         setHistory({
//           usr: res?.UsrActivity || [],
//           cust: res?.CustActivity || [],
//         });
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     load();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab]);

//   const buildOpenUrl = (fileName) =>
//     fileName
//       ? `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`
//       : "";

//   const activeIframeSrc =
//     tab === "history"
//       ? buildOpenUrl(nullaDoc?.file) // show Nulla Osta doc on right in History tab
//       : buildOpenUrl(activeDoc?.file);

//   const currentReasons =
//     tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;

//   const setAct = (v) =>
//     setDocUiState((p) => ({
//       ...p,
//       [activeKey]: {
//         ...current,
//         act: v,
//         reason: v === "verify" ? "0" : current.reason,
//       },
//     }));
//   const setReason = (v) =>
//     setDocUiState((p) => ({
//       ...p,
//       [activeKey]: { ...current, reason: v },
//     }));
//   const setComments = (v) =>
//     setDocUiState((p) => ({
//       ...p,
//       [activeKey]: { ...current, comments: v },
//     }));

//   const disableInputs = !!current.locked;

//   async function maybeAdvanceStatusesAfterDocs() {
//     // get fresh data for this req only once both docs of this dtlId are final
//     const fresh = await agentCaseList({
//       session_id: authData.session_id,
//       sessionToken,
//       reqId,
//     });

//     const mergedRow = {
//       master:
//         (fresh?.master || []).find((m) => String(m.reqId) === String(reqId)) ||
//         row.master,
//       details: (fresh?.details || []).filter(
//         (d) => String(d.reqId) === String(reqId)
//       ),
//       documents: (fresh?.documents || []).filter(
//         (d) => String(d.reqId) === String(reqId)
//       ),
//     };

//     const dId = det?.dtlId;
//     const pSts = getDocStatus(mergedRow, dId, docType.PASS);
//     const nSts = getDocStatus(mergedRow, dId, docType.NULLA);
//     const dtlFinal = computeDtlStatusFromDocs(pSts, nSts);

//     // only now call UpdtCase for this applicant
//     if (dtlFinal !== null) {
//       await updtCase({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         dtlId: dId,
//         dtlStatus: dtlFinal,
//       });
//       await refreshRow?.(reqId);
//     }

//     // if *all* applicants are final → UpdtMastr once, then reload list
//     const allDtlStatuses = mergedRow.details.map((d) => {
//       const ps = getDocStatus(mergedRow, d.dtlId, docType.PASS);
//       const ns = getDocStatus(mergedRow, d.dtlId, docType.NULLA);
//       return computeDtlStatusFromDocs(ps, ns);
//     });

//     if (allDtlStatuses.every((s) => s !== null)) {
//       const mas = computeMasterStatus(allDtlStatuses);
//       if (mas !== null) {
//         await updtMastr({
//           session_id: authData.session_id,
//           sessionToken,
//           reqId,
//           reqStatus: mas,
//         });
//         await onWholeListRefresh?.(); // pull next case after finishing one
//       }
//     }
//   }

//   async function handleSave() {
//     const { act, reason, comments } = current;
//     if (!act) {
//       alert("Please choose Verify / Reject / Block.");
//       return;
//     }
//     if (!activeDoc?.docId) {
//       alert("No document found to update.");
//       return;
//     }
//     try {
//       setSaving(true);

//       // 1) Update THIS doc only (no immediate list refresh)
//       await updtDocs({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         dtlId: det?.dtlId,
//         docId: activeDoc.docId,
//         status: statusMap[act],
//         reason: act === "verify" ? "0" : String(reason || "0"),
//         comments: comments || "",
//       });

//       // 2) Lock inputs for THIS doc and keep chosen values visible
//       setDocUiState((p) => ({
//         ...p,
//         [activeKey]: { ...p[activeKey], locked: true },
//       }));

//       // 3) Now check if both docs of this applicant are final, then chain calls
//       await maybeAdvanceStatusesAfterDocs();

//       // remain in modal
//     } catch (e) {
//       console.error(e);
//       alert(e?.message || "Server rejected the update.");
//     } finally {
//       setSaving(false);
//     }
//   }

//   const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();

//   return (
//     <Modal show={show} onHide={onClose} size="xl" centered backdrop="static">
//       <Modal.Header closeButton>
//         <Modal.Title>Reference ID - {reqId}</Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="row g-3">
//           {/* left */}
//           <div className="col-sm-8">
//             <div className="mb-2 d-flex gap-2 flex-wrap">
//               <button
//                 className={`btn btn-sm ${
//                   tab === "passport" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("passport")}
//               >
//                 Passport Document — {statusText(passDoc?.docStatus)}
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "nulla" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("nulla")}
//               >
//                 Nulla Osta Document — {statusText(nullaDoc?.docStatus)}
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "history" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("history")}
//               >
//                 Document History
//               </button>
//             </div>

//             {tab !== "history" ? (
//               <div
//                 style={{
//                   height: 520,
//                   border: "1px solid #ddd",
//                   borderRadius: 6,
//                   overflow: "hidden",
//                 }}
//               >
//                 {activeIframeSrc ? (
//                   <iframe
//                     title="doc"
//                     src={activeIframeSrc}
//                     width="100%"
//                     height="100%"
//                     frameBorder="0"
//                   />
//                 ) : (
//                   <div className="p-3 text-muted">No file found.</div>
//                 )}
//               </div>
//             ) : (
//               <div
//                 className="border rounded p-2"
//                 style={{ maxHeight: 520, overflow: "auto" }}
//               >
//                 {loadingHistory ? (
//                   <div className="p-3">Loading history…</div>
//                 ) : (
//                   <>
//                     {/* Passport history */}
//                     <div className="d-flex justify-content-between align-items-center border p-2 mb-2">
//                       <div>Passport : {det?.ppn || "-"}</div>
//                       <div>Status : {statusText(passDoc?.docStatus)}</div>
//                     </div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>Action</th>
//                             <th>Actioned By</th>
//                             <th>Actioned On</th>
//                             <th>Uploaded Passport</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.usr || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={4} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.usr.map((u, i) => (
//                               <tr key={`p-${i}`}>
//                                 <td>{u.alog}</td>
//                                 <td>{u.remarks}</td>
//                                 <td>{toIST(u.addOn)}</td>
//                                 <td>{u.file || "-"}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>

//                     {/* Nulla history */}
//                     <div className="d-flex justify-content-between align-items-center border p-2 mt-3 mb-2">
//                       <div>Nulla Osta : {det?.wpn || "-"}</div>
//                       <div>Status : {statusText(nullaDoc?.docStatus)}</div>
//                     </div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>Action</th>
//                             <th>Actioned By</th>
//                             <th>Actioned On</th>
//                             <th>Uploaded Nulla Osta</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.cust || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={4} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.cust.map((c, i) => (
//                               <tr key={`n-${i}`}>
//                                 <td>{c.dlog}</td>
//                                 <td>{c.remarks}</td>
//                                 <td>{toIST(c.addOn)}</td>
//                                 <td>{c.file || "-"}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>
//                   </>
//                 )}
//               </div>
//             )}
//           </div>

//           {/* right */}
//           <div className="col-sm-4">
//             <div className="border rounded p-2">
//               <div className="fw-semibold mb-2">Customer Details :</div>
//               <div className="d-grid gap-1 small">
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Full Name</span>
//                   <span>{fullName || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Email Id</span>
//                   <span>{row?.master?.mailId || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Passport Number</span>
//                   <span>{det?.ppn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Nulla osta No</span>
//                   <span>{det?.wpn || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>DOB</span>
//                   <span>{fmtDMY(det?.dob) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Issue Date</span>
//                   <span>{fmtDMY(det?.wpndt) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Submited On</span>
//                   <span>{toIST(row?.master?.submitOn) || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>VAC</span>
//                   <span>{row?.master?.vac || "-"}</span>
//                 </div>
//                 <div className="d-flex justify-content-between border-bottom py-1">
//                   <span>Status</span>
//                   <span>{statusText(activeDoc?.docStatus)}</span>
//                 </div>
//               </div>

//               {tab !== "history" && (
//                 <div className="mt-3 small">
//                   <div className="mb-2">Action</div>
//                   <div className="d-flex gap-3">
//                     <label className="d-flex align-items-center gap-1">
//                       <input
//                         type="radio"
//                         name={`act-${activeKey}`}
//                         value="verify"
//                         checked={current.act === "verify"}
//                         onChange={() => setAct("verify")}
//                         disabled={disableInputs}
//                       />
//                       Verify
//                     </label>
//                     <label className="d-flex align-items-center gap-1">
//                       <input
//                         type="radio"
//                         name={`act-${activeKey}`}
//                         value="reject"
//                         checked={current.act === "reject"}
//                         onChange={() => setAct("reject")}
//                         disabled={disableInputs}
//                       />
//                       Reject
//                     </label>
//                     <label className="d-flex align-items-center gap-1">
//                       <input
//                         type="radio"
//                         name={`act-${activeKey}`}
//                         value="block"
//                         checked={current.act === "block"}
//                         onChange={() => setAct("block")}
//                         disabled={disableInputs}
//                       />
//                       Block
//                     </label>
//                   </div>

//                   {(current.act === "reject" || current.act === "block") && (
//                     <div className="mt-2">
//                       <div className="mb-1">Reason</div>
//                       <select
//                         className="form-select form-select-sm"
//                         value={current.reason}
//                         onChange={(e) => setReason(e.target.value)}
//                         disabled={disableInputs}
//                       >
//                         <option value="0">---Select---</option>
//                         {currentReasons.map((r) => (
//                           <option key={r.id} value={r.id}>
//                             {r.label}
//                           </option>
//                         ))}
//                       </select>
//                     </div>
//                   )}

//                   <div className="mt-2">
//                     <div className="mb-1">Comments :</div>
//                     <textarea
//                       className="form-control"
//                       rows={5}
//                       value={current.comments}
//                       onChange={(e) => setComments(e.target.value)}
//                       disabled={disableInputs}
//                     />
//                   </div>

//                   <div className="d-flex gap-2 mt-3">
//                     <button
//                       className="btn btn-secondary w-50"
//                       onClick={onClose}
//                     >
//                       Close
//                     </button>
//                     <button
//                       className="btn btn-primary w-50"
//                       onClick={handleSave}
//                       disabled={
//                         disableInputs ||
//                         saving ||
//                         !current.act ||
//                         ((current.act === "reject" ||
//                           current.act === "block") &&
//                           current.reason === "0")
//                       }
//                     >
//                       {saving ? "Saving…" : "Submit"}
//                     </button>
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }
function CaseModal({ show, onClose, row, onWholeListRefresh, refreshRow }) {
  const { authData } = useAuth();
  const [tab, setTab] = useState("passport"); // passport | nulla | history
  const [saving, setSaving] = useState(false);

  // keep each doc’s chosen act/reason/comments & lock state so they don’t clear
  const [docUiState, setDocUiState] = useState({});
  const [history, setHistory] = useState({ usr: [], cust: [] });
  const [loadingHistory, setLoadingHistory] = useState(false);

  const sessionToken =
    authData.session_token ||
    authData.sessionToken ||
    authData.Globalsessiontoken;

  const det = row?.detail || {};
  const reqId =
    row?.master?.reqId ||
    row?.master?.request_id ||
    row?.master?.reqid ||
    row?.master?.reqIdFk ||
    "";

  const passDoc =
    row?.documents?.find(
      (d) => Number(d.type) === 2 && String(d.dtlId) === String(det?.dtlId)
    ) ||
    row?.documents?.find(
      (d) =>
        /pass/i.test(String(d.file)) && String(d.dtlId) === String(det?.dtlId)
    );
  const nullaDoc =
    row?.documents?.find(
      (d) => Number(d.type) === 1 && String(d.dtlId) === String(det?.dtlId)
    ) ||
    row?.documents?.find(
      (d) =>
        /nulla|osta/i.test(String(d.file)) &&
        String(d.dtlId) === String(det?.dtlId)
    );

  const buildOpenUrl = (fileName) =>
    fileName
      ? `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`
      : "";

  const activeType = tab === "passport" ? docType.PASS : docType.NULLA;
  const activeDoc = tab === "passport" ? passDoc : nullaDoc;
  const activeKey = `${det?.dtlId}:${activeType}`;

  // iframe src for normal tabs
  const activeIframeSrc =
    tab === "history" ? "" : buildOpenUrl(activeDoc?.file);

  // NEW: iframe src for the History tab (always show Nulla Osta on the right)
  const historyIframeSrc = buildOpenUrl(nullaDoc?.file);

  const current = docUiState[activeKey] || {
    act: "",
    reason: "0",
    comments: "",
    locked: statusIsFinal(activeDoc?.docStatus),
  };

  useEffect(() => {
    setDocUiState((p) => ({
      ...p,
      [`${det?.dtlId}:${docType.PASS}`]: {
        ...(p[`${det?.dtlId}:${docType.PASS}`] || {
          act: "",
          reason: "0",
          comments: "",
        }),
        locked: statusIsFinal(passDoc?.docStatus),
      },
      [`${det?.dtlId}:${docType.NULLA}`]: {
        ...(p[`${det?.dtlId}:${docType.NULLA}`] || {
          act: "",
          reason: "0",
          comments: "",
        }),
        locked: statusIsFinal(nullaDoc?.docStatus),
      },
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [det?.dtlId, passDoc?.docStatus, nullaDoc?.docStatus]);

  useEffect(() => {
    if (current.act !== "reject" && current.act !== "block") return;
    if (current.reason && current.reason !== "0") {
      const auto = AUTO_COMMENTS[Number(current.reason)] || "";
      setDocUiState((p) => ({
        ...p,
        [activeKey]: { ...current, comments: auto },
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current.reason, activeKey]);

  useEffect(() => {
    const load = async () => {
      if (tab !== "history") return;
      const docId = nullaDoc?.docId || passDoc?.docId;
      if (!docId) return;
      try {
        setLoadingHistory(true);
        const res = await docHistory({
          session_id: authData.session_id,
          sessionToken,
          docId,
        });
        setHistory({
          usr: res?.UsrActivity || [],
          cust: res?.CustActivity || [],
        });
      } finally {
        setLoadingHistory(false);
      }
    };
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const currentReasons =
    tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;

  const setAct = (v) =>
    setDocUiState((p) => ({
      ...p,
      [activeKey]: {
        ...current,
        act: v,
        reason: v === "verify" ? "0" : current.reason,
      },
    }));
  const setReason = (v) =>
    setDocUiState((p) => ({
      ...p,
      [activeKey]: { ...current, reason: v },
    }));
  const setComments = (v) =>
    setDocUiState((p) => ({
      ...p,
      [activeKey]: { ...current, comments: v },
    }));

  const disableInputs = !!current.locked;

  async function maybeAdvanceStatusesAfterDocs() {
    const fresh = await agentCaseList({
      session_id: authData.session_id,
      sessionToken,
      reqId,
    });

    const mergedRow = {
      master:
        (fresh?.master || []).find((m) => String(m.reqId) === String(reqId)) ||
        row.master,
      details: (fresh?.details || []).filter(
        (d) => String(d.reqId) === String(reqId)
      ),
      documents: (fresh?.documents || []).filter(
        (d) => String(d.reqId) === String(reqId)
      ),
    };

    const dId = det?.dtlId;
    const pSts = getDocStatus(mergedRow, dId, docType.PASS);
    const nSts = getDocStatus(mergedRow, dId, docType.NULLA);
    const dtlFinal = computeDtlStatusFromDocs(pSts, nSts);

    if (dtlFinal !== null) {
      await updtCase({
        session_id: authData.session_id,
        sessionToken,
        reqId,
        dtlId: dId,
        dtlStatus: dtlFinal,
      });
      await refreshRow?.(reqId);
    }

    const allDtlStatuses = mergedRow.details.map((d) => {
      const ps = getDocStatus(mergedRow, d.dtlId, docType.PASS);
      const ns = getDocStatus(mergedRow, d.dtlId, docType.NULLA);
      return computeDtlStatusFromDocs(ps, ns);
    });

    if (allDtlStatuses.every((s) => s !== null)) {
      const mas = computeMasterStatus(allDtlStatuses);
      if (mas !== null) {
        await updtMastr({
          session_id: authData.session_id,
          sessionToken,
          reqId,
          reqStatus: mas,
        });
        await onWholeListRefresh?.();
      }
    }
  }

  async function handleSave() {
    const { act, reason, comments } = current;
    if (!act) {
      alert("Please choose Verify / Reject / Block.");
      return;
    }
    if (!activeDoc?.docId) {
      alert("No document found to update.");
      return;
    }
    try {
      setSaving(true);

      await updtDocs({
        session_id: authData.session_id,
        sessionToken,
        reqId,
        dtlId: det?.dtlId,
        docId: activeDoc.docId,
        status: statusMap[act],
        reason: act === "verify" ? "0" : String(reason || "0"),
        comments: comments || "",
      });

      setDocUiState((p) => ({
        ...p,
        [activeKey]: { ...p[activeKey], locked: true },
      }));

      await maybeAdvanceStatusesAfterDocs();
    } catch (e) {
      console.error(e);
      alert(e?.message || "Server rejected the update.");
    } finally {
      setSaving(false);
    }
  }

  const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();

  return (
    <>
      <div className="priority-case-modal"></div>

      <Modal
        show={show}
        onHide={onClose}
        size="xl"
        centered
        className="newcase_modal-dialog"
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            <h6 class="fs-6">Reference ID - {reqId}</h6>
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <div className="row g-3">
            {/* Left side */}
            <div className="col-sm-8">
              <div className="mb-2 d-flex gap-2 flex-wrap">
                <button
                  className={`btn btn-sm ${
                    tab === "passport" ? "btn-primary" : "btn-outline-primary"
                  }`}
                  onClick={() => setTab("passport")}
                >
                  Passport Document — {statusText(passDoc?.docStatus)}
                </button>
                <button
                  className={`btn btn-sm ${
                    tab === "nulla" ? "btn-primary" : "btn-outline-primary"
                  }`}
                  onClick={() => setTab("nulla")}
                >
                  Nulla Osta Document — {statusText(nullaDoc?.docStatus)}
                </button>
                <button
                  className={`btn btn-sm ${
                    tab === "history" ? "btn-primary" : "btn-outline-primary"
                  }`}
                  onClick={() => setTab("history")}
                >
                  Document History
                </button>
              </div>

              {tab !== "history" ? (
                <div
                  style={{
                    height: 520,
                    border: "1px solid #ddd",
                    borderRadius: 6,
                    overflow: "hidden",
                  }}
                >
                  {activeIframeSrc ? (
                    <iframe
                      title="doc"
                      src={activeIframeSrc}
                      width="100%"
                      height="100%"
                      frameBorder="0"
                    />
                  ) : (
                    <div className="p-3 text-muted">No file found.</div>
                  )}
                </div>
              ) : (
                <div
                  className="border rounded p-2"
                  style={{ maxHeight: 520, overflow: "auto" }}
                >
                  {loadingHistory ? (
                    <div className="p-3">Loading history…</div>
                  ) : (
                    <>
                      <div className="d-flex justify-content-between align-items-center border p-2 mb-2">
                        <div>Passport : {det?.ppn || "-"}</div>
                        <div>Status : {statusText(passDoc?.docStatus)}</div>
                      </div>
                      <div className="table-responsive">
                        <table className="table table-bordered table-sm">
                          <thead className="table-active">
                            <tr>
                              <th>Action</th>
                              <th>Actioned By</th>
                              <th>Actioned On</th>
                              <th>Uploaded Passport</th>
                            </tr>
                          </thead>
                          <tbody>
                            {(history.usr || []).length === 0 ? (
                              <tr>
                                <td colSpan={4} className="text-muted">
                                  —
                                </td>
                              </tr>
                            ) : (
                              history.usr.map((u, i) => (
                                <tr key={`p-${i}`}>
                                  <td>{u.alog}</td>
                                  <td>{u.remarks}</td>
                                  <td>{toIST(u.addOn)}</td>
                                  <td>{u.file || "-"}</td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>

                      <div className="d-flex justify-content-between align-items-center border p-2 mt-3 mb-2">
                        <div>Nulla Osta : {det?.wpn || "-"}</div>
                        <div>Status : {statusText(nullaDoc?.docStatus)}</div>
                      </div>
                      <div className="table-responsive">
                        <table className="table table-bordered table-sm">
                          <thead className="table-active">
                            <tr>
                              <th>Action</th>
                              <th>Actioned By</th>
                              <th>Actioned On</th>
                              <th>Uploaded Nulla Osta</th>
                            </tr>
                          </thead>
                          <tbody>
                            {(history.cust || []).length === 0 ? (
                              <tr>
                                <td colSpan={4} className="text-muted">
                                  —
                                </td>
                              </tr>
                            ) : (
                              history.cust.map((c, i) => (
                                <tr key={`n-${i}`}>
                                  <td>{c.dlog}</td>
                                  <td>{c.remarks}</td>
                                  <td>{toIST(c.addOn)}</td>
                                  <td>{c.file || "-"}</td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Right side */}
            <div className="col-sm-4">
              {tab === "history" ? (
                // SHOW NULLA OSTA DOCUMENT HERE (per your request)
                <div
                  className="img_view text-center"
                  style={{
                    height: 520,
                    border: "1px solid #ddd",
                    borderRadius: 6,
                    overflow: "hidden",
                  }}
                >
                  {historyIframeSrc ? (
                    <iframe
                      title="nulla-history"
                      src={historyIframeSrc}
                      width="100%"
                      height="100%"
                      frameBorder="0"
                    />
                  ) : (
                    <div className="p-3 text-muted">
                      No Nulla Osta file found.
                    </div>
                  )}
                </div>
              ) : (
                <div className="border rounded p-2">
                  <div className="fw-semibold mb-2">Customer Details :</div>
                  <div className="newcase-container">
                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label class="form-label">Full Name</label>
                      </div>
                      <div className="col-sm-6">
                        <label class="form-label">{fullName || "-"}</label>
                      </div>
                    </div>
                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label class="form-label">Email Id</label>
                      </div>
                      <div className="col-sm-6">
                        <label class="form-label">
                          {row?.master?.mailId || "-"}
                        </label>
                      </div>
                    </div>
                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label class="form-label">Passport Number</label>
                      </div>
                      <div className="col-sm-6">
                        <label class="form-label">{det?.ppn || "-"}</label>
                      </div>
                    </div>
                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label class="form-label">Nulla osta No</label>
                      </div>
                      <div className="col-sm-6">
                        <label class="form-label">{det?.wpn || "-"}</label>
                      </div>
                    </div>
                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label class="form-label">DOB</label>
                      </div>
                      <div className="col-sm-6">
                        <label class="form-label">
                          {fmtDMY(det?.dob) || "-"}
                        </label>
                      </div>
                    </div>

                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label class="form-label">Issue Date</label>
                      </div>
                      <div className="col-sm-6">
                        <label class="form-label">
                          {fmtDMY(det?.wpndt) || "-"}
                        </label>
                      </div>
                    </div>
                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label class="form-label">Submited On</label>
                      </div>
                      <div className="col-sm-6">
                        <label class="form-label">
                          {toIST(row?.master?.submitOn) || "-"}
                        </label>
                      </div>
                    </div>
                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label class="form-label">VAC</label>
                      </div>
                      <div className="col-sm-6">
                        <label class="form-label">
                          {row?.master?.vac || "-"}
                        </label>
                      </div>
                    </div>
                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label class="form-label">Status</label>
                      </div>
                      <div className="col-sm-6">
                        <label class="form-label">
                          {statusText(activeDoc?.docStatus)}
                        </label>
                      </div>
                    </div>

                    {/* actions (hidden on history) */}
                    {tab !== "history" && (
                      <div className="form-group row">
                        <div className="col-sm-12">
                          <div className="mt-2 small">
                            <div className="mb-2">Action</div>
                            <div className="d-flex gap-3">
                              <label className="d-flex align-items-center gap-1">
                                <input
                                  type="radio"
                                  name={`act-${activeKey}`}
                                  value="verify"
                                  checked={current.act === "verify"}
                                  onChange={() => setAct("verify")}
                                  disabled={disableInputs}
                                />
                                Verify
                              </label>
                              <label className="d-flex align-items-center gap-1">
                                <input
                                  type="radio"
                                  name={`act-${activeKey}`}
                                  value="reject"
                                  checked={current.act === "reject"}
                                  onChange={() => setAct("reject")}
                                  disabled={disableInputs}
                                />
                                Reject
                              </label>
                              <label className="d-flex align-items-center gap-1">
                                <input
                                  type="radio"
                                  name={`act-${activeKey}`}
                                  value="block"
                                  checked={current.act === "block"}
                                  onChange={() => setAct("block")}
                                  disabled={disableInputs}
                                />
                                Block
                              </label>
                            </div>

                            {(current.act === "reject" ||
                              current.act === "block") && (
                              <div className="mt-2">
                                <div className="mb-1">Reason</div>
                                <select
                                  className="form-select form-select-sm"
                                  value={current.reason}
                                  onChange={(e) => setReason(e.target.value)}
                                  disabled={disableInputs}
                                >
                                  <option value="0">---Select---</option>
                                  {currentReasons.map((r) => (
                                    <option key={r.id} value={r.id}>
                                      {r.label}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            )}

                            <div className="mt-2">
                              <div className="mb-1">Comments :</div>
                              <textarea
                                className="form-control"
                                rows={5}
                                value={current.comments}
                                onChange={(e) => setComments(e.target.value)}
                                disabled={disableInputs}
                              />
                            </div>

                            <div className="d-flex gap-2 mt-3">
                              <button
                                className="btn-lg go-btn"
                                onClick={onClose}
                              >
                                Close
                              </button>
                              <button
                                className="btn-lg go-btn"
                                onClick={handleSave}
                                disabled={
                                  disableInputs ||
                                  saving ||
                                  !current.act ||
                                  ((current.act === "reject" ||
                                    current.act === "block") &&
                                    current.reason === "0")
                                }
                              >
                                {saving ? "Saving…" : "Submit"}
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}

/* =========================================================
   Main (flat table, no expansion)
========================================================= */
export default function AgentPriorityCases() {
  const { authData } = useAuth();
  const [rows, setRows] = useState([]); // array of {master, details[], documents[]}
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(null); // {master, detail, documents}

  const sessionToken =
    authData.session_token ||
    authData.sessionToken ||
    authData.Globalsessiontoken;

  const cols = useMemo(
    () => [
      "Request Id",
      "No. Of Applicants",
      "Full Name",
      "Email Id",
      "Passport Number",
      "Nulla osta No",
      "DOB",
      "Issue Date",
      "Submited On",
      "VAC",
      "Status",
      "Action",
    ],
    []
  );

  async function load() {
    setLoading(true);
    try {
      const res = await agentCases({
        session_id: authData.session_id,
        sessionToken,
        priority: 1,
      });

      if (Array.isArray(res?.master)) {
        const out = res.master.map((m) => ({
          master: m,
          details: (res.details || []).filter(
            (d) => String(d.reqId) === String(m.reqId)
          ),
          documents: (res.documents || []).filter(
            (d) => String(d.reqId) === String(m.reqId)
          ),
        }));
        setRows(out);
      } else {
        setRows([]);
      }
    } catch (e) {
      console.error(e);
      setRows([]);
      alert("Failed to load cases.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refreshRow = async (reqId) => {
    try {
      const fresh = await agentCaseList({
        session_id: authData.session_id,
        sessionToken,
        reqId,
      });
      setRows((prev) =>
        prev.map((r) => {
          if (String(r.master.reqId) !== String(reqId)) return r;
          return {
            master:
              (fresh?.master || []).find(
                (m) => String(m.reqId) === String(reqId)
              ) || r.master,
            details: (fresh?.details || []).filter(
              (d) => String(d.reqId) === String(reqId)
            ),
            documents: (fresh?.documents || []).filter(
              (d) => String(d.reqId) === String(reqId)
            ),
          };
        })
      );
    } catch (e) {
      console.error("refreshRow failed", e);
    }
  };

  // flatten rows for table; hold reqId/noOfUsr only on first row for that request
  const flat = [];
  rows.forEach((r) => {
    const n = r.details?.length || 0;
    (r.details || []).forEach((d, idx) => {
      flat.push({
        reqId: idx === 0 ? r.master.reqId : "",
        noOfUsr: idx === 0 ? n : "",
        master: r.master,
        detail: d,
        documents: r.documents,
      });
    });
  });

  return (
    <AjaxValidation>
      <div className="mt-2">
        <div className="container-fluid">
          <h6>Agent Priority Cases</h6>

          <div class="row mt-2 mb-3">
            <div class="col-sm-12">
              <div className="box_card">
                <div className="form-group row">
                  <div className="col-sm-12">
                    <div className="table-responsive holiday-container">
                      <table className="table table-bordered">
                        <thead className="table-light">
                          <tr>
                            {cols.map((c) => (
                              <th key={c}>{c}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {loading ? (
                            <tr>
                              <td colSpan={cols.length}>Loading…</td>
                            </tr>
                          ) : flat.length === 0 ? (
                            <tr>
                              <td colSpan={cols.length} className="text-muted">
                                No records
                              </td>
                            </tr>
                          ) : (
                            flat.map((r, i) => {
                              const first = r.detail || {};
                              return (
                                <tr
                                  key={`${r.master?.reqId}-${first?.dtlId}-${i}`}
                                >
                                  <td>{r.reqId}</td>
                                  <td>{r.noOfUsr}</td>
                                  <td>
                                    {`${first.fName || ""} ${
                                      first.lName || ""
                                    }`.trim() || "-"}
                                  </td>
                                  <td>{r.master?.mailId || "-"}</td>
                                  <td>{first.ppn || "-"}</td>
                                  <td>{first.wpn || "-"}</td>
                                  <td>{fmtDMY(first.dob) || "-"}</td>
                                  <td>{fmtDMY(first.wpndt) || "-"}</td>
                                  <td>{toIST(r.master?.submitOn) || "-"}</td>
                                  <td>{r.master?.vac || "-"}</td>
                                  <td>Submitted</td>
                                  <td>
                                    <button
                                      className="btnlink"
                                      onClick={() =>
                                        setActive({
                                          master: r.master,
                                          detail: r.detail,
                                          documents: r.documents,
                                        })
                                      }
                                    >
                                      View
                                    </button>
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {active && (
            <CaseModal
              show={!!active}
              row={active}
              onClose={() => setActive(null)}
              onWholeListRefresh={load}
              refreshRow={refreshRow}
            />
          )}
        </div>
      </div>
    </AjaxValidation>
  );
}
