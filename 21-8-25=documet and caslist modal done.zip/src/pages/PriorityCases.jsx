// import React, { useMemo, useState, useEffect } from "react";
// import Modal from "react-bootstrap/Modal";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import { BsCalendar2Check } from "react-icons/bs";
// import { FaEdit } from "react-icons/fa";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { adminCases, searchCasesNormal, updtVerdict } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import * as XLSX from "xlsx"; // optional export

// /* ===== Constants ===== */
// const ITEMS_PER_PAGE = 10;
// const WINDOW = 4;

// /* ===== Utils ===== */
// function toISTString(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
//   const ist = new Date(istMs);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yyyy = d.getFullYear();
//   return `${dd}/${mm}/${yyyy}`;
// }
// function getReqId(obj) {
//   return (
//     obj?.reqId ??
//     obj?.request_id ??
//     obj?.req_id ??
//     obj?.reqid ??
//     obj?.requestId ??
//     obj?.reqIdFk ??
//     obj?.reqid_fk ??
//     null
//   );
// }
// /** Common “detail id” guesses used by various backends */
// function getDetailId(d) {
//   return (
//     d?.request_detail_id ??
//     d?.reqDtlId ??
//     d?.reqDetId ??
//     d?.detail_id ??
//     d?.details_id ??
//     d?.id ??
//     null
//   );
// }
// function getPassport(d) {
//   return d?.ppn ?? d?.passport_no ?? d?.passport ?? null;
// }
// /** Accept raw response and return { rows:[{master,details[]}], total, documents } */
// function normalizeResponse(res) {
//   if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
//     const byReq = res.details.reduce((acc, d) => {
//       const k = String(getReqId(d) ?? "");
//       (acc[k] ||= []).push(d);
//       return acc;
//     }, {});
//     const rows = res.master.map((m) => {
//       const mk = String(getReqId(m) ?? "");
//       return { master: m, details: byReq[mk] || [] };
//     });
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//       documents: Array.isArray(res.documents) ? res.documents : [],
//     };
//   }
//   if (Array.isArray(res)) {
//     const rows = res.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length, documents: [] };
//   }
//   if (res && Array.isArray(res.master)) {
//     const rows = res.master.map((m) => ({
//       master: m,
//       details: m.details || [],
//     }));
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//       documents: Array.isArray(res.documents) ? res.documents : [],
//     };
//   }
//   if (res && Array.isArray(res.data)) {
//     const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
//     return {
//       rows,
//       total: rows.length,
//       documents: Array.isArray(res.documents) ? res.documents : [],
//     };
//   }
//   return { rows: [], total: 0, documents: [] };
// }

// /* ========================== Modal (READ-ONLY right side) ========================== */
// function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
//   const [tab, setTab] = useState("passport");
//   const det =
//     row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};

//   const fullName = [
//     det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
//     det?.lName ??
//       det?.last_name ??
//       (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
//   ]
//     .filter(Boolean)
//     .join(" ");

//   const email =
//     row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";
//   const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
//   const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";
//   const dob = fmtDMY(det?.dob);
//   const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);
//   const submittedOn =
//     row?.master?.submitOn ??
//     row?.master?.submitted_on ??
//     det?.submitted_on ??
//     "";

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const vacName = getVacName(
//     det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
//   );

//   const statusList =
//     (statusOptions?.length
//       ? statusOptions
//       : authData?.ajaxPayload?.master_status_list) || [];
//   const currentStatusName =
//     statusList.find(
//       (s) =>
//         String(s.request_status_id) ===
//         String(det?.dtlStatus ?? det?.status ?? row?.master?.status ?? "")
//     )?.request_status_name || "-";

//   useEffect(() => {
//     setTab("passport");
//   }, [row]);

//   function buildDocUrl(fileName) {
//     if (!fileName) return "";
//     if (!authData?.session_id || !authData?.document_key) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.document_key}_${fileName}`;
//   }

//   const requestId = String(row ? getReqId(row.master) ?? "" : "");
//   function pickDocName(which) {
//     const list = Array.isArray(documents) ? documents : [];
//     const hit =
//       list.find(
//         (d) =>
//           String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId &&
//           (which === "passport"
//             ? /pass|pp/i.test(String(d?.doc_name ?? d?.file_name ?? ""))
//             : /nulla|osta|no/i.test(String(d?.doc_name ?? d?.file_name ?? "")))
//       ) ||
//       list.find(
//         (d) => String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId
//       );
//     return hit?.file_name ?? hit?.doc_name ?? null;
//   }

//   const passportFile = pickDocName("passport");
//   const nullaFile = pickDocName("nulla");
//   const activeDocUrl =
//     tab === "passport"
//       ? buildDocUrl(passportFile)
//       : tab === "nulla"
//       ? buildDocUrl(nullaFile)
//       : "";

//   const passportHistory = row?.master?.pp_history || [];
//   const nullaHistory = row?.master?.nulla_history || [];

//   return (
//     <Modal
//       show={show}
//       onHide={onClose}
//       backdrop="static"
//       keyboard={false}
//       className="newcase_modal-dialog"
//       size="xl"
//       centered
//     >
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
//         </Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="model_dialog_list">
//           <div className="row">
//             {/* LEFT */}
//             <div className="col-sm-8 border-right">
//               <div className="mb-3 d-flex gap-2">
//                 <button
//                   className={`btn ${tab === "passport" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
//                   }}
//                   onClick={() => setTab("passport")}
//                 >
//                   Passport Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "nulla" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
//                   }}
//                   onClick={() => setTab("nulla")}
//                 >
//                   Nulla Osta Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "history" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
//                   }}
//                   onClick={() => setTab("history")}
//                 >
//                   Document History
//                 </button>
//               </div>

//               {tab !== "history" ? (
//                 <div
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {activeDocUrl ? (
//                     <iframe
//                       title="document-preview"
//                       src={activeDocUrl}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">File not found or inaccessible!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="table-responsive">
//                   {/* Passport history */}
//                   <div className="mt-2">
//                     <div className="fw-semibold mb-2">
//                       Passport : {passportNo}
//                     </div>
//                     <table className="table table-bordered">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Passport</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {passportHistory.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           passportHistory.map((h, i) => (
//                             <tr key={i}>
//                               <td>{i + 1}</td>
//                               <td>{h.action || "-"}</td>
//                               <td>{h.user || "-"}</td>
//                               <td>{toISTString(h.time) || "-"}</td>
//                               <td>{h.file || "-"}</td>
//                             </tr>
//                           ))
//                         )}
//                       </tbody>
//                     </table>
//                   </div>

//                   {/* Nulla history */}
//                   <div className="mt-3">
//                     <div className="fw-semibold mb-2">
//                       Nulla Osta No: {nullaOstaNo}
//                     </div>
//                     <table className="table table-bordered">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Nulla Osta</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {nullaHistory.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           nullaHistory.map((h, i) => (
//                             <tr key={i}>
//                               <td>{i + 1}</td>
//                               <td>{h.action || "-"}</td>
//                               <td>{h.user || "-"}</td>
//                               <td>{toISTString(h.time) || "-"}</td>
//                               <td>{h.file || "-"}</td>
//                             </tr>
//                           ))
//                         )}
//                       </tbody>
//                     </table>
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* RIGHT (READ-ONLY) */}
//             <div className="col-sm-4">
//               <div className="accordion-body">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <h6 className="modal-title">Customer Details :</h6>
//                   </div>
//                 </div>

//                 <div className="newcase-container">
//                   {[
//                     ["Issue Date", issueDate || "-"],
//                     ["Submited On", toISTString(submittedOn) || "-"],
//                     ["VAC", vacName],
//                     ["Full Name", fullName || "-"],
//                     ["Email Id", email || "-"],
//                     ["Passport Number", passportNo || "-"],
//                     ["Nulla osta No", nullaOstaNo || "-"],
//                     ["DOB", dob || "-"],
//                     ["Status", currentStatusName],
//                   ].map(([l, v], i) => (
//                     <div className="form-group row border-bottom" key={i}>
//                       <div className="col-sm-6">
//                         <label className="form-label">{l}</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <label className="form-label">{v}</label>
//                       </div>
//                     </div>
//                   ))}
//                 </div>
//               </div>
//             </div>
//             {/* END RIGHT */}
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* ========================== Main with VERDICT logic ========================== */
// export default function PriorityCases() {
//   const { authData } = useAuth();

//   // Filters (priority locked to 1)
//   const [keyword, setKeyword] = useState("");
//   const [keyType, setKeyType] = useState("0");
//   const [dateType, setDateType] = useState("0");
//   const [vac, setVac] = useState("");
//   const [status, setStatus] = useState("0");
//   const [fromDate, setFromDate] = useState(null);
//   const [toDate, setToDate] = useState(null);

//   // Data/page
//   const [rows, setRows] = useState([]);
//   const [total, setTotal] = useState(0);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [expanded, setExpanded] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [documents, setDocuments] = useState([]);

//   // Modal
//   const [show, setShow] = useState(false);
//   const [activeRow, setActiveRow] = useState(null);

//   // Verdict selections: { [reqId]: { [detailKey]: "1" | "0" } }
//   const [verdict, setVerdict] = useState({});

//   // Are we in "search" mode? (if false -> adminCases)
//   const [isSearching, setIsSearching] = useState(false);

//   const minDate = useMemo(() => new Date("2000-01-01"), []);
//   const maxDate = useMemo(() => new Date(), []);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const statusOptions = authData?.ajaxPayload?.master_status_list || [];

//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const getStatusName = (id) =>
//     statusOptions.find((s) => String(s.request_status_id) === String(id))
//       ?.request_status_name ||
//     id ||
//     "-";

//   const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
//   const onView = (row) => {
//     setActiveRow(row);
//     setShow(true);
//   };

//   function validateFilters() {
//     // If keyword entered but no key type chosen
//     if (keyword.trim() && +keyType === 0) {
//       return { ok: false, msg: "Choose a Keyword type." };
//     }
//     // If any date picked, Date Type is mandatory
//     if ((fromDate || toDate) && +dateType === 0) {
//       return { ok: false, msg: "Choose a Date Type for the selected dates." };
//     }
//     return { ok: true };
//   }

//   // Build payload; include BOTH sessionToken (camel) and session_token (snake)
//   function buildPayload(page = 1) {
//     let pKeyType = keyType,
//       pKeyword = keyword,
//       pDateType = dateType,
//       pVac = vac,
//       pStatus = status;

//     // If a keyword type is chosen, ignore other filters
//     if (+pKeyType > 0) {
//       pDateType = "0";
//       pVac = "0";
//       pStatus = "0";
//     }

//     const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

//     return {
//       session_id: authData.session_id,
//       sessionToken: authData.session_token,
//       session_token: authData.session_token, // some backends expect this

//       keyword: String((pKeyword || "").trim()),
//       keyType: String(pKeyType),
//       dateType: String(pDateType),
//       vac: String(pVac || "0"),
//       status: String(pStatus || "0"),
//       from: fromDate ? fromDate.toISOString().split("T")[0] : "",
//       to: toDate ? toDate.toISOString().split("T")[0] : "",
//       priority: "1", // Priority
//       startRecord: Number(startRecord),
//       rows: ITEMS_PER_PAGE,
//       caseList: 1,
//       allSts: 1,
//     };
//   }

//   // IMPORTANT: decide API by explicit "source" to avoid async state races
//   async function fetchPage(page = 1, { source } = {}) {
//     setLoading(true);
//     try {
//       const payload = buildPayload(page);
//       const which = source ?? (isSearching ? "search" : "admin");
//       const res =
//         which === "search"
//           ? await searchCasesNormal(payload)
//           : await adminCases(payload);

//       const { rows: normalized, total, documents } = normalizeResponse(res);
//       setRows(normalized);
//       setTotal(total || 0);
//       setDocuments(documents || res?.documents || []);
//       setExpanded(null);
//       setCurrentPage(page);
//       setVerdict({});
//     } catch (e) {
//       console.error("fetchPage failed:", e);
//       setRows([]);
//       setTotal(0);
//       setExpanded(null);
//       setDocuments([]);
//       setVerdict({});
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     // initial load via adminCases
//     setIsSearching(false);
//     fetchPage(1, { source: "admin" });
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const handleSearch = async () => {
//     const v = validateFilters();
//     if (!v.ok) {
//       alert(v.msg);
//       return;
//     }
//     // switch to search mode and explicitly use searchCasesNormal
//     setIsSearching(true);
//     await fetchPage(1, { source: "search" });
//   };

//   const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//   const handlePrev = () =>
//     currentPage > 1 &&
//     fetchPage(currentPage - 1, { source: isSearching ? "search" : "admin" });
//   const handleNext = () =>
//     currentPage < totalPages &&
//     fetchPage(currentPage + 1, { source: isSearching ? "search" : "admin" });

//   // --- verdict helpers/derivers ---
//   function detailKeyOf(d, i) {
//     return String(getDetailId(d) ?? i);
//   }
//   function areAll(details, verdictMapForReq, want /* "1" | "0" */) {
//     const list = Array.isArray(details) ? details : [];
//     if (list.length === 0) return false;
//     return list.every((d, i) => verdictMapForReq?.[detailKeyOf(d, i)] === want);
//   }
//   function pageAll(rows, verdictState, want /* "1" | "0" */) {
//     const list = Array.isArray(rows) ? rows : [];
//     if (list.length === 0) return false;
//     return list.every(({ master, details }) => {
//       const rid = String(getReqId(master) ?? "");
//       return areAll(details, verdictState[rid], want);
//     });
//   }

//   /* ===== Verdict helpers ===== */
//   const setVerdictFor = (reqId, detKey, val /* "1" | "0" */) => {
//     setVerdict((p) => ({
//       ...p,
//       [reqId]: { ...(p[reqId] || {}), [detKey]: val },
//     }));
//   };
//   const setAllForRequest = (reqId, details, val) => {
//     const updates = {};
//     (details || []).forEach((d, i) => {
//       const dk = String(getDetailId(d) ?? i);
//       updates[dk] = val;
//     });
//     setVerdict((p) => ({ ...p, [reqId]: updates }));
//   };
//   const setAllForPage = (rowsData, val) => {
//     const next = {};
//     (rowsData || []).forEach(({ master, details }) => {
//       const reqId = String(getReqId(master) ?? "");
//       const map = {};
//       (details || []).forEach((d, i) => {
//         const dk = String(getDetailId(d) ?? i);
//         map[dk] = val;
//       });
//       next[reqId] = map;
//     });
//     setVerdict(next);
//   };

//   async function handleSubmitVerdicts() {
//     const actionIds = [];
//     for (const { master, details } of rows) {
//       const reqId = String(getReqId(master) ?? "");
//       const selections = verdict[reqId] || {};
//       (details || []).forEach((d, i) => {
//         const dk = detailKeyOf(d, i);
//         const v = selections[dk];
//         if (v === "1" || v === "0") {
//           const detId = getDetailId(d);
//           actionIds.push({
//             Id: String(detId ?? reqId), // prefer detail id; fallback to request id
//             sts: v,
//           });
//         }
//       });
//     }

//     if (actionIds.length === 0) {
//       alert("Please choose at least one Verdict (Yes/No) before submitting.");
//       return;
//     }

//     try {
//       const res = await updtVerdict({
//         session_id: authData.session_id,
//         session_token: authData.session_token, // backend expects camel key "sessionToken" inside the API
//         actionIds, // [{ Id, sts }]
//       });

//       const ok =
//         (Array.isArray(res?.results) &&
//           res.results.every((r) => r?.status === 1)) ||
//         res?.status === 1 ||
//         res?.success === true;

//       if (ok) {
//         alert("Verdicts updated successfully.");
//       } else {
//         alert("Some verdicts may have failed to update.");
//       }

//       await fetchPage(currentPage, {
//         source: isSearching ? "search" : "admin",
//       });
//     } catch (e) {
//       console.error("Submit verdicts failed:", e);
//       alert("Submitting verdicts failed.");
//     }
//   }

//   /* ===== Pagination helpers ===== */
//   function range(start, end) {
//     return Array.from({ length: end - start + 1 }, (_, i) => start + i);
//   }
//   function getVisiblePages(current, total) {
//     if (total <= WINDOW) return range(1, total);
//     if (current <= WINDOW) return range(1, WINDOW);
//     if (current > total - WINDOW) return range(total - WINDOW + 1, total);
//     return range(current, current + WINDOW - 1);
//   }

//   return (
//     <AjaxValidation>
//       <div className="mt-2">
//         <div className="container-fluid">
//           <h6>Priority Cases</h6>

//           {/* Filters */}
//           <div className="box_card mb-3">
//             <div className="main_agent_form d-flex align-items-center flex-wrap">
//               <div className="one">
//                 <input
//                   className="form-control"
//                   placeholder="Search"
//                   value={keyword}
//                   onChange={(e) => setKeyword(e.target.value)}
//                 />
//               </div>

//               <div className="one">
//                 <select
//                   className="form-select form-control"
//                   value={keyType}
//                   onChange={(e) => setKeyType(e.target.value)}
//                 >
//                   <option value="0">--Keyword--</option>
//                   <option value="1">Email Id</option>
//                   <option value="2">Nulla Osta Reference Number</option>
//                   <option value="3">Passport Number</option>
//                   <option value="4">Mobile Number</option>
//                   <option value="5">Request Id</option>
//                   <option value="6">Name</option>
//                 </select>
//               </div>

//               <div className="one">
//                 <div className="input-group">
//                   <DatePicker
//                     selected={fromDate}
//                     onChange={(d) => setFromDate(d)}
//                     className="form-control date-border"
//                     placeholderText="From Date"
//                     dateFormat="dd-MM-yyyy"
//                     showMonthDropdown
//                     showYearDropdown
//                     dropdownMode="select"
//                     scrollableYearDropdown
//                     isClearable
//                     minDate={minDate}
//                     maxDate={maxDate}
//                   />
//                   <span className="input-group-text">
//                     <BsCalendar2Check />
//                   </span>
//                 </div>
//               </div>

//               <div className="one">
//                 <div className="input-group">
//                   <DatePicker
//                     selected={toDate}
//                     onChange={(d) => setToDate(d)}
//                     className="form-control date-border"
//                     placeholderText="To Date"
//                     dateFormat="dd-MM-yyyy"
//                     showMonthDropdown
//                     showYearDropdown
//                     dropdownMode="select"
//                     scrollableYearDropdown
//                     isClearable
//                     minDate={minDate}
//                     maxDate={maxDate}
//                   />
//                   <span className="input-group-text">
//                     <BsCalendar2Check />
//                   </span>
//                 </div>
//               </div>

//               <div className="one">
//                 <select
//                   className="form-select form-control"
//                   value={dateType}
//                   onChange={(e) => setDateType(e.target.value)}
//                 >
//                   <option value="0">--Date Type--</option>
//                   <option value="1">Added On</option>
//                   <option value="2">Submitted On</option>
//                 </select>
//               </div>

//               <div className="one">
//                 <select
//                   className="form-select form-control"
//                   value={vac}
//                   onChange={(e) => setVac(e.target.value)}
//                 >
//                   <option value="0">--Select VAC--</option>
//                   {vacOptions.map((v) => (
//                     <option key={v.vac_id} value={v.vac_id}>
//                       {v.vac_name}
//                     </option>
//                   ))}
//                 </select>
//               </div>

//               <div className="one">
//                 <select
//                   className="form-select form-control"
//                   value={status}
//                   onChange={(e) => setStatus(e.target.value)}
//                 >
//                   <option value="0">--Select--</option>
//                   {statusOptions
//                     .filter((s) => Number(s.request_status_id) > 1)
//                     .map((s) => (
//                       <option
//                         key={s.request_status_id}
//                         value={s.request_status_id}
//                       >
//                         {s.request_status_name}
//                       </option>
//                     ))}
//                 </select>
//               </div>

//               <div className="one go_btn_flex">
//                 <button
//                   className="login-btn w-100"
//                   style={{ background: "#f26722", color: "#fff" }}
//                   onClick={handleSearch}
//                 >
//                   Search
//                 </button>
//               </div>
//             </div>

//             {/* Page-level Yes/No */}
//             {/* Page-level Yes/No */}
//             <div className="d-flex align-items-center ms-2" style={{ gap: 10 }}>
//               <label className="me-2" style={{ userSelect: "none" }}>
//                 <input
//                   type="checkbox"
//                   checked={pageAll(rows, verdict, "1")}
//                   onChange={() => setAllForPage(rows, "1")}
//                 />{" "}
//                 Yes
//               </label>
//               <label style={{ userSelect: "none" }}>
//                 <input
//                   type="checkbox"
//                   checked={pageAll(rows, verdict, "0")}
//                   onChange={() => setAllForPage(rows, "0")}
//                 />{" "}
//                 No
//               </label>
//             </div>
//           </div>

//           {/* Results */}
//           <div className="box_card">
//             <div className="table-responsive table-container">
//               {loading ? (
//                 <div className="p-3 text-center">
//                   <div
//                     style={{
//                       position: "fixed",
//                       inset: 0,
//                       background: "rgba(0,0,0,0.35)",
//                       zIndex: 1050,
//                       display: "grid",
//                       placeItems: "center",
//                     }}
//                   >
//                     <div className="spinner-border text-light" role="status" />
//                   </div>
//                 </div>
//               ) : rows.length === 0 ? (
//                 <div className="p-3 text-center text-muted">
//                   No records found.
//                 </div>
//               ) : (
//                 rows.map(({ master, details }, idx) => {
//                   const rid = String(getReqId(master) ?? idx);
//                   const addedOn = toISTString(
//                     master?.addOn ?? master?.added_on
//                   );
//                   const submittedOn = toISTString(
//                     master?.submitOn ?? master?.submitted_on
//                   );
//                   const vacName = getVacName(master?.vac ?? master?.vac_id);
//                   const statusName = getStatusName(
//                     master?.rStatus ?? master?.status
//                   );

//                   const list = Array.isArray(details)
//                     ? details
//                     : details && typeof details === "object"
//                     ? Object.values(details)
//                     : [];

//                   return (
//                     <div key={rid} className="border">
//                       {/* master row */}
//                       <table
//                         className="table table-bordered mb-0"
//                         style={{ tableLayout: "auto", width: "100%" }}
//                       >
//                         <thead className="main_heading_table">
//                           <tr>
//                             <th>
//                               <div className="mb-2">
//                                 <label
//                                   className="me-3"
//                                   style={{ userSelect: "none" }}
//                                 >
//                                   <input
//                                     type="checkbox"
//                                     checked={areAll(list, verdict[rid], "1")}
//                                     onChange={() =>
//                                       setAllForRequest(rid, list, "1")
//                                     }
//                                   />{" "}
//                                   Yes
//                                 </label>
//                                 <label style={{ userSelect: "none" }}>
//                                   <input
//                                     type="checkbox"
//                                     checked={areAll(list, verdict[rid], "0")}
//                                     onChange={() =>
//                                       setAllForRequest(rid, list, "0")
//                                     }
//                                   />{" "}
//                                   No
//                                 </label>
//                               </div>
//                             </th>

//                             <th>Request ID :</th>
//                             <th className="priClr">{rid}</th>
//                             <th>IP :</th>
//                             <th className="col-ip">
//                               {master?.IP ?? master?.ip ?? "-"}
//                             </th>
//                             <th>Added On :</th>
//                             <th>{addedOn || "-"}</th>
//                             <th>Submitted On :</th>
//                             <th>{submittedOn || "-"}</th>
//                             <th>No. Of Applicants :</th>
//                             <th style={{ width: "60px" }}>
//                               {master?.noOfUsr ??
//                                 master?.no_of_applicants ??
//                                 "-"}
//                             </th>
//                             <th>VAC :</th>
//                             <th className="col-vac">
//                               <div className="d-flex gap-2 align-items-center">
//                                 {vacName}
//                                 <FaEdit
//                                   style={{ color: "green", fontSize: "0.8rem" }}
//                                 />
//                               </div>
//                             </th>
//                             <th>Priority :</th>
//                             <th>Priority</th>
//                             <th>Status :</th>
//                             <th className="col-status">{statusName}</th>
//                             <th>
//                               <button
//                                 className="btn-theam-filter"
//                                 onClick={() => toggleExpand(String(rid))}
//                                 title="Expand"
//                               >
//                                 {expanded === String(rid) ? "▲" : "▼"}
//                               </button>
//                             </th>
//                           </tr>
//                         </thead>
//                       </table>

//                       {/* detail table */}
//                       {expanded === String(rid) && (
//                         <div className="p-2">
//                           <table className="table table-bordered table-hover tableexpand">
//                             <thead className="table-active tableexpand-head">
//                               <tr>
//                                 <th style={{ width: 120 }}>Verdict</th>
//                                 <th>Full Name</th>
//                                 <th>Email Id</th>
//                                 <th>Passport Number</th>
//                                 <th>Nulla osta No</th>
//                                 <th>DOB</th>
//                                 <th>Issue Date</th>
//                                 <th>Submitted On</th>
//                                 <th>VAC</th>
//                                 <th>Appointment On</th>
//                                 <th>Status</th>
//                                 <th>Action</th>
//                               </tr>
//                             </thead>
//                             <tbody>
//                               {list.length === 0 ? (
//                                 <tr>
//                                   <td
//                                     colSpan={12}
//                                     className="text-center text-muted"
//                                   >
//                                     No details available for this request.
//                                   </td>
//                                 </tr>
//                               ) : (
//                                 list.map((d, i) => {
//                                   const full =
//                                     [
//                                       d?.fName ??
//                                         d?.first_name ??
//                                         d?.full_name?.split(" ")?.[0],
//                                       d?.lName ??
//                                         d?.last_name ??
//                                         (d?.full_name
//                                           ? d.full_name
//                                               .split(" ")
//                                               .slice(1)
//                                               .join(" ")
//                                           : null),
//                                     ]
//                                       .filter(Boolean)
//                                       .join(" ") || "-";

//                                   const dk = String(getDetailId(d) ?? i);
//                                   const sel = verdict[rid]?.[dk]; // "1" | "0" | undefined

//                                   return (
//                                     <tr key={`${rid}-detail-${dk}`}>
//                                       <td>
//                                         <label
//                                           className="me-3"
//                                           style={{ userSelect: "none" }}
//                                         >
//                                           <input
//                                             type="checkbox"
//                                             checked={sel === "1"}
//                                             onChange={() =>
//                                               setVerdictFor(rid, dk, "1")
//                                             }
//                                           />{" "}
//                                           Yes
//                                         </label>
//                                         <label style={{ userSelect: "none" }}>
//                                           <input
//                                             type="checkbox"
//                                             checked={sel === "0"}
//                                             onChange={() =>
//                                               setVerdictFor(rid, dk, "0")
//                                             }
//                                           />{" "}
//                                           No
//                                         </label>
//                                       </td>
//                                       <td>{full}</td>
//                                       <td>
//                                         {master?.mailId ??
//                                           master?.email ??
//                                           d?.email ??
//                                           "-"}
//                                       </td>
//                                       <td>{getPassport(d) || "-"}</td>
//                                       <td>
//                                         {d?.wpn ?? d?.nulla_osta_no ?? "-"}
//                                       </td>
//                                       <td>{fmtDMY(d?.dob) || "-"}</td>
//                                       <td>
//                                         {fmtDMY(d?.wpndt ?? d?.issue_date) ||
//                                           "-"}
//                                       </td>
//                                       <td>
//                                         {toISTString(
//                                           master?.submitOn ??
//                                             master?.submitted_on
//                                         ) || "-"}
//                                       </td>
//                                       <td>
//                                         {getVacName(
//                                           d?.vac ??
//                                             master?.vac ??
//                                             master?.vac_id
//                                         )}
//                                       </td>
//                                       <td>
//                                         {toISTString(
//                                           d?.slotAt ?? d?.appointment_on
//                                         ) || "-"}
//                                       </td>
//                                       <td>
//                                         {getStatusName(
//                                           d?.dtlStatus ??
//                                             d?.status ??
//                                             master?.status
//                                         )}
//                                       </td>
//                                       <td>
//                                         <button
//                                           className="btnlink"
//                                           onClick={() =>
//                                             onView({ master, detail: d })
//                                           }
//                                         >
//                                           View
//                                         </button>
//                                       </td>
//                                     </tr>
//                                   );
//                                 })
//                               )}
//                             </tbody>
//                           </table>
//                         </div>
//                       )}
//                     </div>
//                   );
//                 })
//               )}
//             </div>

//             {/* Submit verdicts + Pagination */}
//             <div className="d-flex justify-content-between align-items-center p-2">
//               <button
//                 className="btn btn-primary"
//                 style={{ background: "#f26722", borderColor: "#f26722" }}
//                 onClick={handleSubmitVerdicts}
//               >
//                 Submit
//               </button>

//               {total > 0 && (
//                 <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
//                   <button
//                     id="btnPrevious"
//                     className={`btn btn-sm ${
//                       currentPage === 1 ? "disabled" : ""
//                     }`}
//                     onClick={handlePrev}
//                   >
//                     Previous
//                   </button>

//                   {(() => {
//                     const totalPages = Math.max(
//                       1,
//                       Math.ceil(total / ITEMS_PER_PAGE)
//                     );
//                     const pages = getVisiblePages(currentPage, totalPages);
//                     const hasLeftEllipsis = pages[0] > 1;
//                     const hasRightEllipsis =
//                       pages[pages.length - 1] < totalPages;
//                     return (
//                       <>
//                         {hasLeftEllipsis && <span className="px-1">…</span>}
//                         {pages.map((p) => (
//                           <button
//                             key={p}
//                             id={`btn${p}`}
//                             className={`btn btn-sm ${
//                               currentPage === p ? "active" : ""
//                             }`}
//                             onClick={() =>
//                               fetchPage(p, {
//                                 source: isSearching ? "search" : "admin",
//                               })
//                             }
//                           >
//                             {p}
//                           </button>
//                         ))}
//                         {hasRightEllipsis && <span className="px-1">…</span>}
//                       </>
//                     );
//                   })()}

//                   <button
//                     id="btnNext"
//                     className={`btn btn-sm ${
//                       currentPage ===
//                       Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
//                         ? "disabled"
//                         : ""
//                     }`}
//                     onClick={handleNext}
//                   >
//                     Next
//                   </button>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Modal */}
//       {show && activeRow && (
//         <CaseModal
//           key={String(getReqId(activeRow?.master))}
//           show={show}
//           onClose={() => setShow(false)}
//           row={activeRow}
//           documents={documents}
//           authData={authData}
//           statusOptions={statusOptions}
//         />
//       )}
//     </AjaxValidation>
//   );
// }

import React, { useMemo, useState, useEffect } from "react";
import Modal from "react-bootstrap/Modal";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { BsCalendar2Check } from "react-icons/bs";
import { FaEdit } from "react-icons/fa";
import AjaxValidation from "../hooks/AjaxValidation";
import { adminCases, searchCasesNormal, updtVerdict } from "../api/client";
import { useAuth } from "../context/AuthContext";
import * as XLSX from "xlsx"; // optional export

/* ===== Constants ===== */
const ITEMS_PER_PAGE = 10;
const WINDOW = 4;

/* ===== Utils ===== */
function toISTString(dateLike) {
  if (!dateLike) return "";
  if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
  const d = new Date(dateLike);
  if (Number.isNaN(d.getTime())) return "";
  const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
  const ist = new Date(istMs);
  const dd = String(ist.getDate()).padStart(2, "0");
  const mm = String(ist.getMonth() + 1).padStart(2, "0");
  const yyyy = ist.getFullYear();
  const hh = String(ist.getHours()).padStart(2, "0");
  const mi = String(ist.getMinutes()).padStart(2, "0");
  return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
}
function fmtDMY(dateLike) {
  if (!dateLike) return "";
  if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
  const d = new Date(dateLike);
  if (Number.isNaN(d.getTime())) return "";
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}
function getReqId(obj) {
  return (
    obj?.reqId ??
    obj?.request_id ??
    obj?.req_id ??
    obj?.reqid ??
    obj?.requestId ??
    obj?.reqIdFk ??
    obj?.reqid_fk ??
    null
  );
}
/** Common “detail id” guesses used by various backends */
function getDetailId(d) {
  return (
    d?.request_detail_id ??
    d?.reqDtlId ??
    d?.reqDetId ??
    d?.detail_id ??
    d?.details_id ??
    d?.id ??
    null
  );
}
function getPassport(d) {
  return d?.ppn ?? d?.passport_no ?? d?.passport ?? null;
}
/** Accept raw response and return { rows:[{master,details[]}], total, documents } */
function normalizeResponse(res) {
  if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
    const byReq = res.details.reduce((acc, d) => {
      const k = String(getReqId(d) ?? "");
      (acc[k] ||= []).push(d);
      return acc;
    }, {});
    const rows = res.master.map((m) => {
      const mk = String(getReqId(m) ?? "");
      return { master: m, details: byReq[mk] || [] };
    });
    return {
      rows,
      total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
      documents: Array.isArray(res.documents) ? res.documents : [],
    };
  }
  if (Array.isArray(res)) {
    const rows = res.map((m) => ({ master: m, details: m.details || [] }));
    return { rows, total: rows.length, documents: [] };
  }
  if (res && Array.isArray(res.master)) {
    const rows = res.master.map((m) => ({
      master: m,
      details: m.details || [],
    }));
    return {
      rows,
      total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
      documents: Array.isArray(res.documents) ? res.documents : [],
    };
  }
  if (res && Array.isArray(res.data)) {
    const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
    return {
      rows,
      total: rows.length,
      documents: Array.isArray(res.documents) ? res.documents : [],
    };
  }
  return { rows: [], total: 0, documents: [] };
}

/* ========================== Modal (READ-ONLY right side) ========================== */
function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
  const [tab, setTab] = useState("passport");
  const det =
    row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};

  const fullName = [
    det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
    det?.lName ??
      det?.last_name ??
      (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
  ]
    .filter(Boolean)
    .join(" ");

  const email =
    row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";
  const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
  const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";
  const dob = fmtDMY(det?.dob);
  const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);
  const submittedOn =
    row?.master?.submitOn ??
    row?.master?.submitted_on ??
    det?.submitted_on ??
    "";

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const getVacName = (id) =>
    vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
    id ||
    "-";
  const vacName = getVacName(
    det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
  );

  const statusList =
    (statusOptions?.length
      ? statusOptions
      : authData?.ajaxPayload?.master_status_list) || [];
  const currentStatusName =
    statusList.find(
      (s) =>
        String(s.request_status_id) ===
        String(det?.dtlStatus ?? det?.status ?? row?.master?.status ?? "")
    )?.request_status_name || "-";

  useEffect(() => {
    setTab("passport");
  }, [row]);

  function buildDocUrl(fileName) {
    if (!fileName) return "";
    if (!authData?.session_id || !authData?.document_key) return "";
    return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.document_key}_${fileName}`;
  }

  const requestId = String(row ? getReqId(row.master) ?? "" : "");
  function pickDocName(which) {
    const list = Array.isArray(documents) ? documents : [];
    const hit =
      list.find(
        (d) =>
          String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId &&
          (which === "passport"
            ? /pass|pp/i.test(String(d?.doc_name ?? d?.file_name ?? ""))
            : /nulla|osta|no/i.test(String(d?.doc_name ?? d?.file_name ?? "")))
      ) ||
      list.find(
        (d) => String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId
      );
    return hit?.file_name ?? hit?.doc_name ?? null;
  }

  const passportFile = pickDocName("passport");
  const nullaFile = pickDocName("nulla");
  const activeDocUrl =
    tab === "passport"
      ? buildDocUrl(passportFile)
      : tab === "nulla"
      ? buildDocUrl(nullaFile)
      : "";

  const passportHistory = row?.master?.pp_history || [];
  const nullaHistory = row?.master?.nulla_history || [];

  return (
    <Modal
      show={show}
      onHide={onClose}
      backdrop="static"
      keyboard={false}
      className="newcase_modal-dialog"
      size="xl"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title>
          <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="model_dialog_list">
          <div className="row">
            {/* LEFT */}
            <div className="col-sm-8 border-right">
              <div className="mb-3 d-flex gap-2">
                <button
                  className={`btn ${tab === "passport" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
                  }}
                  onClick={() => setTab("passport")}
                >
                  Passport Document
                </button>
                <button
                  className={`btn ${tab === "nulla" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
                  }}
                  onClick={() => setTab("nulla")}
                >
                  Nulla Osta Document
                </button>
                <button
                  className={`btn ${tab === "history" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
                  }}
                  onClick={() => setTab("history")}
                >
                  Document History
                </button>
              </div>

              {tab !== "history" ? (
                <div
                  style={{
                    height: "55vh",
                    border: "1px solid #ddd",
                    borderRadius: 6,
                    overflow: "hidden",
                    background: "#fff",
                  }}
                >
                  {activeDocUrl ? (
                    <iframe
                      title="document-preview"
                      src={activeDocUrl}
                      style={{ width: "100%", height: "100%", border: 0 }}
                    />
                  ) : (
                    <div className="p-3">File not found or inaccessible!</div>
                  )}
                </div>
              ) : (
                <div className="table-responsive">
                  {/* Passport history */}
                  <div className="mt-2">
                    <div className="fw-semibold mb-2">
                      Passport : {passportNo}
                    </div>
                    <table className="table table-bordered">
                      <thead className="table-active">
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Actioned By</th>
                          <th>Actioned On</th>
                          <th>Uploaded Passport</th>
                        </tr>
                      </thead>
                      <tbody>
                        {passportHistory.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-muted">
                              —
                            </td>
                          </tr>
                        ) : (
                          passportHistory.map((h, i) => (
                            <tr key={i}>
                              <td>{i + 1}</td>
                              <td>{h.action || "-"}</td>
                              <td>{h.user || "-"}</td>
                              <td>{toISTString(h.time) || "-"}</td>
                              <td>{h.file || "-"}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Nulla history */}
                  <div className="mt-3">
                    <div className="fw-semibold mb-2">
                      Nulla Osta No: {nullaOstaNo}
                    </div>
                    <table className="table table-bordered">
                      <thead className="table-active">
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Actioned By</th>
                          <th>Actioned On</th>
                          <th>Uploaded Nulla Osta</th>
                        </tr>
                      </thead>
                      <tbody>
                        {nullaHistory.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-muted">
                              —
                            </td>
                          </tr>
                        ) : (
                          nullaHistory.map((h, i) => (
                            <tr key={i}>
                              <td>{i + 1}</td>
                              <td>{h.action || "-"}</td>
                              <td>{h.user || "-"}</td>
                              <td>{toISTString(h.time) || "-"}</td>
                              <td>{h.file || "-"}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* RIGHT (READ-ONLY) */}
            <div className="col-sm-4">
              <div className="accordion-body">
                <div className="form-group row">
                  <div className="col-sm-12">
                    <h6 className="modal-title">Customer Details :</h6>
                  </div>
                </div>

                <div className="newcase-container">
                  {[
                    ["Issue Date", issueDate || "-"],
                    ["Submited On", toISTString(submittedOn) || "-"],
                    ["VAC", vacName],
                    ["Full Name", fullName || "-"],
                    ["Email Id", email || "-"],
                    ["Passport Number", passportNo || "-"],
                    ["Nulla osta No", nullaOstaNo || "-"],
                    ["DOB", dob || "-"],
                    ["Status", currentStatusName],
                  ].map(([l, v], i) => (
                    <div className="form-group row border-bottom" key={i}>
                      <div className="col-sm-6">
                        <label className="form-label">{l}</label>
                      </div>
                      <div className="col-sm-6">
                        <label className="form-label">{v}</label>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            {/* END RIGHT */}
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

/* ========================== Main with VERDICT logic ========================== */
export default function PriorityCases() {
  const { authData } = useAuth();

  // Filters (priority locked to 1)
  const [keyword, setKeyword] = useState("");
  const [keyType, setKeyType] = useState("0");
  const [dateType, setDateType] = useState("0");
  const [vac, setVac] = useState("");
  const [status, setStatus] = useState("0");
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);

  // Data/page
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [expanded, setExpanded] = useState(null);
  const [loading, setLoading] = useState(false);
  const [documents, setDocuments] = useState([]);

  // Modal
  const [show, setShow] = useState(false);
  const [activeRow, setActiveRow] = useState(null);

  // Verdict selections: { [reqId]: { [detailKey]: "1" | "0" } }
  const [verdict, setVerdict] = useState({});

  // Are we in "search" mode? (if false -> adminCases)
  const [isSearching, setIsSearching] = useState(false);

  const minDate = useMemo(() => new Date("2000-01-01"), []);
  const maxDate = useMemo(() => new Date(), []);

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const statusOptions = authData?.ajaxPayload?.master_status_list || [];

  const getVacName = (id) =>
    vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
    id ||
    "-";
  const getStatusName = (id) =>
    statusOptions.find((s) => String(s.request_status_id) === String(id))
      ?.request_status_name ||
    id ||
    "-";

  const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
  const onView = (row) => {
    setActiveRow(row);
    setShow(true);
  };

  function validateFilters() {
    // If keyword entered but no key type chosen
    if (keyword.trim() && +keyType === 0) {
      return { ok: false, msg: "Choose a Keyword type." };
    }
    // If any date picked, Date Type is mandatory
    if ((fromDate || toDate) && +dateType === 0) {
      return { ok: false, msg: "Choose a Date Type for the selected dates." };
    }
    return { ok: true };
  }

  // Build payload; include BOTH sessionToken (camel) and session_token (snake)
  function buildPayload(page = 1) {
    let pKeyType = keyType,
      pKeyword = keyword,
      pDateType = dateType,
      pVac = vac,
      pStatus = status;

    // If a keyword type is chosen, ignore other filters
    if (+pKeyType > 0) {
      pDateType = "0";
      pVac = "0";
      pStatus = "0";
    }

    const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

    return {
      session_id: authData.session_id,
      sessionToken: authData.session_token,
      session_token: authData.session_token, // some backends expect this

      keyword: String((pKeyword || "").trim()),
      keyType: String(pKeyType),
      dateType: String(pDateType),
      vac: String(pVac || "0"),
      status: String(pStatus || "0"),
      from: fromDate ? fromDate.toISOString().split("T")[0] : "",
      to: toDate ? toDate.toISOString().split("T")[0] : "",
      priority: "1", // Priority
      startRecord: Number(startRecord),
      rows: ITEMS_PER_PAGE,
      caseList: 1,
      allSts: 1,
    };
  }

  // IMPORTANT: decide API by explicit "source" to avoid async state races
  async function fetchPage(page = 1, { source } = {}) {
    setLoading(true);
    try {
      const payload = buildPayload(page);
      const which = source ?? (isSearching ? "search" : "admin");
      const res =
        which === "search"
          ? await searchCasesNormal(payload)
          : await adminCases(payload);

      const { rows: normalized, total, documents } = normalizeResponse(res);
      setRows(normalized);
      setTotal(total || 0);
      setDocuments(documents || res?.documents || []);
      setExpanded(null);
      setCurrentPage(page);
      setVerdict({});
    } catch (e) {
      console.error("fetchPage failed:", e);
      setRows([]);
      setTotal(0);
      setExpanded(null);
      setDocuments([]);
      setVerdict({});
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    // initial load via adminCases
    setIsSearching(false);
    fetchPage(1, { source: "admin" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSearch = async () => {
    const v = validateFilters();
    if (!v.ok) {
      alert(v.msg);
      return;
    }
    // switch to search mode and explicitly use searchCasesNormal
    setIsSearching(true);
    await fetchPage(1, { source: "search" });
  };

  const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
  const handlePrev = () =>
    currentPage > 1 &&
    fetchPage(currentPage - 1, { source: isSearching ? "search" : "admin" });
  const handleNext = () =>
    currentPage < totalPages &&
    fetchPage(currentPage + 1, { source: isSearching ? "search" : "admin" });

  // --- verdict helpers/derivers ---
  function detailKeyOf(d, i) {
    return String(getDetailId(d) ?? i);
  }
  function areAll(details, verdictMapForReq, want /* "1" | "0" */) {
    const list = Array.isArray(details) ? details : [];
    if (list.length === 0) return false;
    return list.every((d, i) => verdictMapForReq?.[detailKeyOf(d, i)] === want);
  }
  function pageAll(rows, verdictState, want /* "1" | "0" */) {
    const list = Array.isArray(rows) ? rows : [];
    if (list.length === 0) return false;
    return list.every(({ master, details }) => {
      const rid = String(getReqId(master) ?? "");
      return areAll(details, verdictState[rid], want);
    });
  }

  /* ===== Verdict helpers ===== */
  const setVerdictFor = (reqId, detKey, val /* "1" | "0" */) => {
    setVerdict((p) => ({
      ...p,
      [reqId]: { ...(p[reqId] || {}), [detKey]: val },
    }));
  };
  const setAllForRequest = (reqId, details, val) => {
    const updates = {};
    (details || []).forEach((d, i) => {
      const dk = String(getDetailId(d) ?? i);
      updates[dk] = val;
    });
    setVerdict((p) => ({ ...p, [reqId]: updates }));
  };
  const setAllForPage = (rowsData, val) => {
    const next = {};
    (rowsData || []).forEach(({ master, details }) => {
      const reqId = String(getReqId(master) ?? "");
      const map = {};
      (details || []).forEach((d, i) => {
        const dk = String(getDetailId(d) ?? i);
        map[dk] = val;
      });
      next[reqId] = map;
    });
    setVerdict(next);
  };

  async function handleSubmitVerdicts() {
    const actionIds = [];
    for (const { master, details } of rows) {
      const reqId = String(getReqId(master) ?? "");
      const selections = verdict[reqId] || {};
      (details || []).forEach((d, i) => {
        const dk = detailKeyOf(d, i);
        const v = selections[dk];
        if (v === "1" || v === "0") {
          const detId = getDetailId(d);
          actionIds.push({
            Id: String(detId ?? reqId), // prefer detail id; fallback to request id
            sts: v,
          });
        }
      });
    }

    if (actionIds.length === 0) {
      alert("Please choose at least one Verdict (Yes/No) before submitting.");
      return;
    }

    try {
      const res = await updtVerdict({
        session_id: authData.session_id,
        session_token: authData.session_token, // backend expects camel key "sessionToken" inside the API
        actionIds, // [{ Id, sts }]
      });

      const ok =
        (Array.isArray(res?.results) &&
          res.results.every((r) => r?.status === 1)) ||
        res?.status === 1 ||
        res?.success === true;

      if (ok) {
        alert("Verdicts updated successfully.");
      } else {
        alert("Some verdicts may have failed to update.");
      }

      await fetchPage(currentPage, {
        source: isSearching ? "search" : "admin",
      });
    } catch (e) {
      console.error("Submit verdicts failed:", e);
      alert("Submitting verdicts failed.");
    }
  }

  /* ===== Pagination helpers ===== */
  function range(start, end) {
    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  }
  function getVisiblePages(current, total) {
    if (total <= WINDOW) return range(1, total);
    if (current <= WINDOW) return range(1, WINDOW);
    if (current > total - WINDOW) return range(total - WINDOW + 1, total);
    return range(current, current + WINDOW - 1);
  }

  return (
    <AjaxValidation>
      <div className="mt-2">
        <div className="container-fluid">
          <h6>Priority Cases</h6>

          <div class="row mt-2 mb-3">
            <div class="col-sm-12">
              <div className="box_card">
                <div className="form-group row">
                  <div className="col-sm-12">
                    <div className="main_agent_form">
                      <div className="one">
                        <input
                          className="form-control"
                          placeholder="Search"
                          value={keyword}
                          onChange={(e) => setKeyword(e.target.value)}
                        />
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={keyType}
                          onChange={(e) => setKeyType(e.target.value)}
                        >
                          <option value="0">--Keyword--</option>
                          <option value="1">Email Id</option>
                          <option value="2">Nulla Osta Reference Number</option>
                          <option value="3">Passport Number</option>
                          <option value="4">Mobile Number</option>
                          <option value="5">Request Id</option>
                          <option value="6">Name</option>
                        </select>
                      </div>
                      <div className="one">
                        <div
                          className="input-group date_pick"
                          style={{ flexWrap: "nowrap" }}
                        >
                          <DatePicker
                            selected={fromDate}
                            onChange={(d) => setFromDate(d)}
                            className="form-control border_right_radius"
                            placeholderText="From Date"
                            dateFormat="dd-MM-yyyy"
                            showMonthDropdown
                            showYearDropdown
                            dropdownMode="select"
                            scrollableYearDropdown
                            isClearable
                            minDate={minDate}
                            maxDate={maxDate}
                          />
                          <span className="input-group-text">
                            <BsCalendar2Check />
                          </span>
                        </div>
                      </div>
                      <div className="one">
                        <div
                          className="input-group date_pick"
                          style={{ flexWrap: "nowrap" }}
                        >
                          <DatePicker
                            selected={toDate}
                            onChange={(d) => setToDate(d)}
                            className="form-control border_right_radius"
                            placeholderText="To Date"
                            dateFormat="dd-MM-yyyy"
                            showMonthDropdown
                            showYearDropdown
                            dropdownMode="select"
                            scrollableYearDropdown
                            isClearable
                            minDate={minDate}
                            maxDate={maxDate}
                          />
                          <span className="input-group-text">
                            <BsCalendar2Check />
                          </span>
                        </div>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={dateType}
                          onChange={(e) => setDateType(e.target.value)}
                        >
                          <option value="0">--Date Type--</option>
                          <option value="1">Added On</option>
                          <option value="2">Submitted On</option>
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={vac}
                          onChange={(e) => setVac(e.target.value)}
                        >
                          <option value="0">--Select VAC--</option>
                          {vacOptions.map((v) => (
                            <option key={v.vac_id} value={v.vac_id}>
                              {v.vac_name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={status}
                          onChange={(e) => setStatus(e.target.value)}
                        >
                          <option value="0">--Select--</option>
                          {statusOptions
                            .filter((s) => Number(s.request_status_id) > 1)
                            .map((s) => (
                              <option
                                key={s.request_status_id}
                                value={s.request_status_id}
                              >
                                {s.request_status_name}
                              </option>
                            ))}
                        </select>
                      </div>
                      <div className="one">
                        <button
                          className="btn-lg go-btn"
                          style={{ background: "#f26722", color: "#fff" }}
                          onClick={handleSearch}
                        >
                          Search
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="form-group row">
                  <div className="col-sm-12">
                    {/* Filters */}
                    <div className="mt-2 mb-0">
                      {/* Page-level Yes/No */}
                      {/* Page-level Yes/No */}
                      <div
                        className="d-flex align-items-center ms-2"
                        style={{ gap: 10 }}
                      >
                        <label className="me-2" style={{ userSelect: "none" }}>
                          <input
                            type="checkbox"
                            checked={pageAll(rows, verdict, "1")}
                            onChange={() => setAllForPage(rows, "1")}
                          />{" "}
                          Yes
                        </label>
                        <label style={{ userSelect: "none" }}>
                          <input
                            type="checkbox"
                            checked={pageAll(rows, verdict, "0")}
                            onChange={() => setAllForPage(rows, "0")}
                          />{" "}
                          No
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="dropdown-divider"></div>
                {/* Results */}
                <div className="box_card">
                  <div className="table-responsive holiday-container">
                    {loading ? (
                      <div className="p-3 text-center">
                        <div
                          style={{
                            position: "fixed",
                            inset: 0,
                            background: "rgba(0,0,0,0.35)",
                            zIndex: 1050,
                            display: "grid",
                            placeItems: "center",
                          }}
                        >
                          <div
                            className="spinner-border text-light"
                            role="status"
                          />
                        </div>
                      </div>
                    ) : rows.length === 0 ? (
                      <div className="p-3 text-center text-muted">
                        No records found.
                      </div>
                    ) : (
                      rows.map(({ master, details }, idx) => {
                        const rid = String(getReqId(master) ?? idx);
                        const addedOn = toISTString(
                          master?.addOn ?? master?.added_on
                        );
                        const submittedOn = toISTString(
                          master?.submitOn ?? master?.submitted_on
                        );
                        const vacName = getVacName(
                          master?.vac ?? master?.vac_id
                        );
                        const statusName = getStatusName(
                          master?.rStatus ?? master?.status
                        );

                        const list = Array.isArray(details)
                          ? details
                          : details && typeof details === "object"
                          ? Object.values(details)
                          : [];

                        return (
                          <div key={rid} className="border">
                            {/* master row */}
                            <table
                              className="table table-bordered mb-0"
                              style={{ tableLayout: "auto", width: "100%" }}
                            >
                              <thead className="main_heading_table">
                                <tr>
                                  <th>
                                    <div className="">
                                      <label
                                        className="me-3"
                                        style={{ userSelect: "none" }}
                                      >
                                        <input
                                          type="checkbox"
                                          checked={areAll(
                                            list,
                                            verdict[rid],
                                            "1"
                                          )}
                                          onChange={() =>
                                            setAllForRequest(rid, list, "1")
                                          }
                                        />{" "}
                                        Yes
                                      </label>
                                      <label style={{ userSelect: "none" }}>
                                        <input
                                          type="checkbox"
                                          checked={areAll(
                                            list,
                                            verdict[rid],
                                            "0"
                                          )}
                                          onChange={() =>
                                            setAllForRequest(rid, list, "0")
                                          }
                                        />{" "}
                                        No
                                      </label>
                                    </div>
                                  </th>

                                  <th>Request ID :</th>
                                  <th className="priClr">{rid}</th>
                                  <th>IP :</th>
                                  <th className="col-ip">
                                    {master?.IP ?? master?.ip ?? "-"}
                                  </th>
                                  <th>Added On :</th>
                                  <th>{addedOn || "-"}</th>
                                  <th>Submitted On :</th>
                                  <th>{submittedOn || "-"}</th>
                                  <th>No. Of Applicants :</th>
                                  <th style={{ width: "60px" }}>
                                    {master?.noOfUsr ??
                                      master?.no_of_applicants ??
                                      "-"}
                                  </th>
                                  <th>VAC :</th>
                                  <th className="col-vac">
                                    <div className="d-flex gap-2 align-items-center">
                                      {vacName}
                                      <FaEdit
                                        style={{
                                          color: "green",
                                          fontSize: "0.8rem",
                                        }}
                                      />
                                    </div>
                                  </th>
                                  <th>Priority :</th>
                                  <th>Priority</th>
                                  <th>Status :</th>
                                  <th className="col-status">{statusName}</th>
                                  <th>
                                    <button
                                      className="btn-theam-filter"
                                      onClick={() => toggleExpand(String(rid))}
                                      title="Expand"
                                    >
                                      {expanded === String(rid) ? "▲" : "▼"}
                                    </button>
                                  </th>
                                </tr>
                              </thead>
                            </table>

                            {/* detail table */}
                            {expanded === String(rid) && (
                              <div className="p-2">
                                <table className="table table-bordered table-hover tableexpand">
                                  <thead className="table-active tableexpand-head">
                                    <tr>
                                      <th style={{ width: 120 }}>Verdict</th>
                                      <th>Full Name</th>
                                      <th>Email Id</th>
                                      <th>Passport Number</th>
                                      <th>Nulla osta No</th>
                                      <th>DOB</th>
                                      <th>Issue Date</th>
                                      <th>Submitted On</th>
                                      <th>VAC</th>
                                      <th>Appointment On</th>
                                      <th>Status</th>
                                      <th>Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {list.length === 0 ? (
                                      <tr>
                                        <td
                                          colSpan={12}
                                          className="text-center text-muted"
                                        >
                                          No details available for this request.
                                        </td>
                                      </tr>
                                    ) : (
                                      list.map((d, i) => {
                                        const full =
                                          [
                                            d?.fName ??
                                              d?.first_name ??
                                              d?.full_name?.split(" ")?.[0],
                                            d?.lName ??
                                              d?.last_name ??
                                              (d?.full_name
                                                ? d.full_name
                                                    .split(" ")
                                                    .slice(1)
                                                    .join(" ")
                                                : null),
                                          ]
                                            .filter(Boolean)
                                            .join(" ") || "-";

                                        const dk = String(getDetailId(d) ?? i);
                                        const sel = verdict[rid]?.[dk]; // "1" | "0" | undefined

                                        return (
                                          <tr key={`${rid}-detail-${dk}`}>
                                            <td>
                                              <label
                                                className="me-3"
                                                style={{ userSelect: "none" }}
                                              >
                                                <input
                                                  type="checkbox"
                                                  checked={sel === "1"}
                                                  onChange={() =>
                                                    setVerdictFor(rid, dk, "1")
                                                  }
                                                />{" "}
                                                Yes
                                              </label>
                                              <label
                                                style={{ userSelect: "none" }}
                                              >
                                                <input
                                                  type="checkbox"
                                                  checked={sel === "0"}
                                                  onChange={() =>
                                                    setVerdictFor(rid, dk, "0")
                                                  }
                                                />{" "}
                                                No
                                              </label>
                                            </td>
                                            <td>{full}</td>
                                            <td>
                                              {master?.mailId ??
                                                master?.email ??
                                                d?.email ??
                                                "-"}
                                            </td>
                                            <td>{getPassport(d) || "-"}</td>
                                            <td>
                                              {d?.wpn ??
                                                d?.nulla_osta_no ??
                                                "-"}
                                            </td>
                                            <td>{fmtDMY(d?.dob) || "-"}</td>
                                            <td>
                                              {fmtDMY(
                                                d?.wpndt ?? d?.issue_date
                                              ) || "-"}
                                            </td>
                                            <td>
                                              {toISTString(
                                                master?.submitOn ??
                                                  master?.submitted_on
                                              ) || "-"}
                                            </td>
                                            <td>
                                              {getVacName(
                                                d?.vac ??
                                                  master?.vac ??
                                                  master?.vac_id
                                              )}
                                            </td>
                                            <td>
                                              {toISTString(
                                                d?.slotAt ?? d?.appointment_on
                                              ) || "-"}
                                            </td>
                                            <td>
                                              {getStatusName(
                                                d?.dtlStatus ??
                                                  d?.status ??
                                                  master?.status
                                              )}
                                            </td>
                                            <td>
                                              <button
                                                className="btnlink"
                                                onClick={() =>
                                                  onView({ master, detail: d })
                                                }
                                              >
                                                View
                                              </button>
                                            </td>
                                          </tr>
                                        );
                                      })
                                    )}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Submit verdicts + Pagination */}
                  <div className="d-flex justify-content-between align-items-center p-2">
                    <button
                      className="btn-lg go-btn"
                      onClick={handleSubmitVerdicts}
                    >
                      Submit
                    </button>

                    {total > 0 && (
                      <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
                        <button
                          id="btnPrevious"
                          className={`btn btn-sm ${
                            currentPage === 1 ? "disabled" : ""
                          }`}
                          onClick={handlePrev}
                        >
                          Previous
                        </button>

                        {(() => {
                          const totalPages = Math.max(
                            1,
                            Math.ceil(total / ITEMS_PER_PAGE)
                          );
                          const pages = getVisiblePages(
                            currentPage,
                            totalPages
                          );
                          const hasLeftEllipsis = pages[0] > 1;
                          const hasRightEllipsis =
                            pages[pages.length - 1] < totalPages;
                          return (
                            <>
                              {hasLeftEllipsis && (
                                <span className="px-1">…</span>
                              )}
                              {pages.map((p) => (
                                <button
                                  key={p}
                                  id={`btn${p}`}
                                  className={`btn btn-sm ${
                                    currentPage === p ? "active" : ""
                                  }`}
                                  onClick={() =>
                                    fetchPage(p, {
                                      source: isSearching ? "search" : "admin",
                                    })
                                  }
                                >
                                  {p}
                                </button>
                              ))}
                              {hasRightEllipsis && (
                                <span className="px-1">…</span>
                              )}
                            </>
                          );
                        })()}

                        <button
                          id="btnNext"
                          className={`btn btn-sm ${
                            currentPage ===
                            Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
                              ? "disabled"
                              : ""
                          }`}
                          onClick={handleNext}
                        >
                          Next
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal */}
      {show && activeRow && (
        <CaseModal
          key={String(getReqId(activeRow?.master))}
          show={show}
          onClose={() => setShow(false)}
          row={activeRow}
          documents={documents}
          authData={authData}
          statusOptions={statusOptions}
        />
      )}
    </AjaxValidation>
  );
}
