// import React, { useMemo, useState, useEffect } from "react";
// import Modal from "react-bootstrap/Modal";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import { BsCalendar2Check } from "react-icons/bs";
// import { FaEdit } from "react-icons/fa";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { searchCases } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import * as XLSX from "xlsx";
// import excel from "../assets/excel.png";

// /* ===== Constants ===== */
// const ITEMS_PER_PAGE = 10;

// /* ===== Utils (unchanged) ===== */
// function toISTString(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
//   const ist = new Date(istMs);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yyyy = d.getFullYear();
//   return `${dd}/${mm}/${yyyy}`;
// }
// function getReqId(obj) {
//   return (
//     obj?.reqId ??
//     obj?.request_id ??
//     obj?.req_id ??
//     obj?.reqid ??
//     obj?.requestId ??
//     obj?.reqIdFk ??
//     obj?.reqid_fk ??
//     null
//   );
// }
// /** Accepts raw API response and returns { rows:[{master,details[]}], total } */
// function normalizeResponse(res) {
//   if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
//     const byReq = res.details.reduce((acc, d) => {
//       const k = String(getReqId(d) ?? "");
//       (acc[k] ||= []).push(d);
//       return acc;
//     }, {});
//     const rows = res.master.map((m) => {
//       const mk = String(getReqId(m) ?? "");
//       return { master: m, details: byReq[mk] || [] };
//     });
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (Array.isArray(res)) {
//     const rows = res.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   if (res && Array.isArray(res.master)) {
//     const rows = res.master.map((m) => ({
//       master: m,
//       details: m.details || [],
//     }));
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (res && Array.isArray(res.data)) {
//     const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   return { rows: [], total: 0 };
// }

// /* ========================== Modal (UI-only updates) ========================== */
// function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
//   const roleId = Number(authData?.role_id);
//   const canEditRight = roleId == 2;

//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

//   const det =
//     row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};

//   const fullName = [
//     det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
//     det?.lName ??
//       det?.last_name ??
//       (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
//   ]
//     .filter(Boolean)
//     .join(" ");

//   const email =
//     row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";

//   const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
//   const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";

//   const dob = fmtDMY(det?.dob);
//   const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);

//   const submittedOn =
//     row?.master?.submitOn ??
//     row?.master?.submitted_on ??
//     det?.submitted_on ??
//     "";

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";

//   const vacName = getVacName(
//     det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
//   );

//   const statusList =
//     (statusOptions && statusOptions.length
//       ? statusOptions
//       : authData?.ajaxPayload?.master_status_list) || [];

//   const reasonList = authData?.ajaxPayload?.reason_list || [
//     { id: "", name: "---Select---" },
//     { id: "1", name: "Missing pages" },
//     { id: "2", name: "Illegible/blur" },
//     { id: "3", name: "Not applicable" },
//   ];

//   const [status, setStatus] = useState("");
//   const [reason, setReason] = useState("");
//   const [comments, setComments] = useState("");

//   useEffect(() => {
//     setTab("passport");
//     const currentStatus =
//       det?.dtlStatus ?? det?.status ?? row?.master?.status ?? "";
//     setStatus(String(currentStatus || ""));
//     setReason(
//       String(det?.reason_id ?? det?.reason ?? row?.master?.reason ?? "")
//     );
//     setComments(
//       String(
//         det?.comments ??
//           det?.remarks ??
//           row?.master?.comments ??
//           row?.master?.remarks ??
//           ""
//       )
//     );
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [row]);

//   function buildDocUrl(fileName) {
//     if (!fileName) return "";
//     if (!authData?.session_id || !authData?.document_key) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.document_key}_${fileName}`;
//   }

//   const requestId = String(row ? getReqId(row.master) ?? "" : "");

//   function pickDocName(which) {
//     const list = Array.isArray(documents) ? documents : [];
//     const hit =
//       list.find(
//         (d) =>
//           String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId &&
//           (which === "passport"
//             ? /pass|pp/i.test(String(d?.doc_name ?? d?.file_name ?? ""))
//             : /nulla|osta|no/i.test(String(d?.doc_name ?? d?.file_name ?? "")))
//       ) ||
//       list.find(
//         (d) => String(d?.request_id ?? d?.reqId ?? d?.reqid) === requestId
//       );

//     return hit?.file_name ?? hit?.doc_name ?? null;
//   }

//   const passportFile = pickDocName("passport");
//   const nullaFile = pickDocName("nulla");
//   const activeDocUrl =
//     tab === "passport"
//       ? buildDocUrl(passportFile)
//       : tab === "nulla"
//       ? buildDocUrl(nullaFile)
//       : "";

//   const passportHistory = row?.master?.pp_history || [];
//   const nullaHistory = row?.master?.nulla_history || [];

//   function handleSave() {
//     if (!canEditRight) return;
//     // TODO: connect to your update endpoint
//     alert("Saved (stub). Wire this to your update API.");
//   }

//   return (
//     <Modal
//       show={show}
//       onHide={onClose}
//       backdrop="static"
//       keyboard={false}
//       className="newcase_modal-dialog"
//       size="xl"
//       centered
//     >
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
//         </Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="model_dialog_list">
//           <div className="row">
//             {/* LEFT */}
//             <div className="col-sm-8 border-right">
//               {/* tab buttons styled similar to your palette */}
//               <div className="mb-3 d-flex gap-1">
//                 <button
//                   className={`btn ${tab === "passport" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("passport")}
//                 >
//                   Passport Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "nulla" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("nulla")}
//                 >
//                   Nulla Osta Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "history" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("history")}
//                 >
//                   Document History
//                 </button>
//               </div>

//               {tab !== "history" ? (
//                 <div
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {activeDocUrl ? (
//                     <iframe
//                       title="document-preview"
//                       src={activeDocUrl}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">File not found or inaccessible!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="table-responsive">
//                   {/* Passport history */}
//                   <div className="mt-2">
//                     <div className="fw-semibold mb-2">
//                       Passport :{passportNo}
//                     </div>
//                     <table className="table table-bordered">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Passport</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {passportHistory.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           passportHistory.map((h, i) => (
//                             <tr key={i}>
//                               <td>{i + 1}</td>
//                               <td>{h.action || "-"}</td>
//                               <td>{h.user || "-"}</td>
//                               <td>{toISTString(h.time) || "-"}</td>
//                               <td>{h.file || "-"}</td>
//                             </tr>
//                           ))
//                         )}
//                       </tbody>
//                     </table>
//                   </div>

//                   {/* Nulla history */}
//                   <div className="mt-3">
//                     <div className="fw-semibold mb-2">
//                       Nulla Osta No:{nullaOstaNo}
//                     </div>
//                     <table className="table table-bordered">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Nulla Osta</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {nullaHistory.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           nullaHistory.map((h, i) => (
//                             <tr key={i}>
//                               <td>{i + 1}</td>
//                               <td>{h.action || "-"}</td>
//                               <td>{h.user || "-"}</td>
//                               <td>{toISTString(h.time) || "-"}</td>
//                               <td>{h.file || "-"}</td>
//                             </tr>
//                           ))
//                         )}
//                       </tbody>
//                     </table>
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* RIGHT */}
//             <div className="col-sm-4">
//               <div className="accordion-body">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <h6 className="modal-title mb-2">Customer Details :</h6>
//                   </div>
//                 </div>

//                 <div className="newcase-container">
//                   {/* pairs */}
//                   {[
//                     ["Issue Date", issueDate || "-"],
//                     ["Submited On", toISTString(submittedOn) || "-"],
//                     ["VAC", vacName],
//                     ["Full Name", fullName || "-"],
//                     ["Email Id", email || "-"],
//                     ["Passport Number", passportNo || "-"],
//                     ["Nulla osta No", nullaOstaNo || "-"],
//                     ["DOB", dob || "-"],
//                   ].map(([l, v], i) => (
//                     <div className="form-group row border-bottom" key={i}>
//                       <div className="col-sm-6">
//                         <label className="form-label">{l}</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <label className="form-label">{v}</label>
//                       </div>
//                     </div>
//                   ))}

//                   {/* Status */}
//                   <div className="form-group row border-bottom mb-2">
//                     <div className="col-sm-6">
//                       <label className="form-label">Status</label>
//                     </div>
//                     <div className="col-sm-6">
//                       <select
//                         className="form-select form-control"
//                         disabled={!canEditRight}
//                         value={status}
//                         onChange={(e) => setStatus(e.target.value)}
//                       >
//                         <option value="">---Select---</option>
//                         {statusList.map((s) => (
//                           <option
//                             key={s.request_status_id}
//                             value={s.request_status_id}
//                           >
//                             {s.request_status_name}
//                           </option>
//                         ))}
//                       </select>
//                     </div>
//                   </div>

//                   {/* Reason */}
//                   <div className="form-group row border-bottom">
//                     <div className="col-sm-6">
//                       <label className="form-label">Reason</label>
//                     </div>
//                     <div className="col-sm-6">
//                       <select
//                         className="form-select form-control"
//                         disabled={!canEditRight}
//                         value={reason}
//                         onChange={(e) => setReason(e.target.value)}
//                       >
//                         {reasonList.map((r) => (
//                           <option key={r.id} value={r.id}>
//                             {r.name}
//                           </option>
//                         ))}
//                       </select>
//                     </div>
//                   </div>

//                   {/* Comments */}
//                   <div className="form-group row border-bottom">
//                     <div className="col-sm-12">
//                       <label className="form-label">Comments</label>
//                       <textarea
//                         className="form-control"
//                         rows={5}
//                         value={comments}
//                         onChange={(e) => setComments(e.target.value)}
//                         disabled={!canEditRight}
//                       />
//                     </div>
//                   </div>

//                   {canEditRight && (
//                     <div className="form-group row mt-3">
//                       <div className="col-sm-6" />
//                       <div className="col-sm-6">
//                         <button
//                           type="button"
//                           className="btn login-btn w-100"
//                           style={{ background: "#f26722", color: "#fff" }}
//                           onClick={handleSave}
//                         >
//                           Save
//                         </button>
//                       </div>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* ========================== Main (logic unchanged, UI updated) ========================== */
// export default function CaseList() {
//   const { authData } = useAuth();

//   // Filters
//   const [keyword, setKeyword] = useState("");
//   const [keyType, setKeyType] = useState("0");
//   const [dateType, setDateType] = useState("0");
//   const [vac, setVac] = useState("");
//   const [status, setStatus] = useState("0");
//   const [priority, setPriority] = useState("-1");

//   const [fromDate, setFromDate] = useState(null);
//   const [toDate, setToDate] = useState(null);

//   // Data/page
//   const [rows, setRows] = useState([]); // [{master, details[]}]
//   const [total, setTotal] = useState(0);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [expanded, setExpanded] = useState(null);
//   const [loading, setLoading] = useState(false);

//   // Modal
//   const [show, setShow] = useState(false);
//   const [activeRow, setActiveRow] = useState(null);
//   const [documents, setDocuments] = useState([]);

//   const minDate = useMemo(() => new Date("2000-01-01"), []);
//   const maxDate = useMemo(() => new Date(), []);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const statusOptions = authData?.ajaxPayload?.master_status_list || [];

//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const getStatusName = (id) =>
//     statusOptions.find((s) => String(s.request_status_id) === String(id))
//       ?.request_status_name ||
//     id ||
//     "-";

//   const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
//   const onView = (row) => {
//     setActiveRow(row);
//     setShow(true);
//   };

//   function validateFilters() {
//     if (keyword.trim() && +keyType === 0)
//       return { ok: false, msg: "Choose a Keyword type." };
//     return { ok: true };
//   }

//   function buildPayload(page = 1) {
//     let pKeyType = keyType,
//       pKeyword = keyword,
//       pDateType = dateType,
//       pVac = vac,
//       pStatus = status,
//       pPri = priority;

//     if (+pKeyType > 0) {
//       pDateType = "0";
//       pVac = "0";
//       pStatus = "0";
//       pPri = "-1";
//     }
//     if (+pDateType === 0 && (fromDate || toDate)) {
//       pDateType = "2";
//     }
//     const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

//     return {
//       session_id: authData.session_id,
//       sessionToken: authData.session_token,
//       keyword: pKeyword.trim(),
//       keyType: pKeyType,
//       dateType: pDateType,
//       vac: pVac || "0",
//       status: pStatus,
//       from: fromDate ? fromDate.toISOString().split("T")[0] : "",
//       to: toDate ? toDate.toISOString().split("T")[0] : "",
//       priority: pPri,
//       startRecord,
//       rows: 1,
//       caseList: 1,
//       allSts: 1,
//     };
//   }

//   async function fetchPage(page = 1) {
//     setLoading(true);
//     try {
//       const res = await searchCases(buildPayload(page));
//       const { rows: normalized, total } = normalizeResponse(res);
//       setRows(normalized);
//       setTotal(total || 0);
//       setDocuments(res?.documents || []);
//       setExpanded(null);
//       setCurrentPage(page);
//     } catch (e) {
//       console.error("searchCases failed:", e);
//       setRows([]);
//       setTotal(0);
//       setExpanded(null);
//       setDocuments([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     fetchPage(1);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const handleSearch = async () => {
//     const v = validateFilters();
//     if (!v.ok) {
//       alert(v.msg);
//       return;
//     }
//     await fetchPage(1);
//   };
//   const handlePrev = () => currentPage > 1 && fetchPage(currentPage - 1);
//   const handleNext = () => {
//     const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//     if (currentPage < totalPages) fetchPage(currentPage + 1);
//   };

//   const handleExcel = async () => {
//     try {
//       const flat = [];
//       for (const { master, details } of rows) {
//         const vacName = getVacName(master?.vac ?? master?.vac_id);
//         const statusName = getStatusName(master?.rStatus ?? master?.status);
//         const submittedOn = toISTString(
//           master?.submitOn ?? master?.submitted_on
//         );
//         const detailList = details && details.length ? details : [null];
//         for (const d of detailList) {
//           const issueDate = fmtDMY(d?.wpndt ?? d?.issue_date);
//           const dob = fmtDMY(d?.dob);
//           flat.push({
//             RequestID: getReqId(master),
//             IP: master?.IP ?? master?.ip ?? "",
//             FullName: [d?.fName ?? d?.first_name, d?.lName ?? d?.last_name]
//               .filter(Boolean)
//               .join(" "),
//             EmailId: master?.mailId ?? master?.email ?? d?.email ?? "",
//             PassportNo: d?.ppn ?? d?.passport_no ?? "",
//             NullaOstaNo: d?.wpn ?? d?.nulla_osta_no ?? "",
//             DOB: dob,
//             IssueDate: issueDate,
//             SubmitedOn: submittedOn,
//             VAC: vacName,
//             Status: statusName,
//           });
//         }
//       }
//       const ws = XLSX.utils.json_to_sheet(flat);
//       const wb = XLSX.utils.book_new();
//       XLSX.utils.book_append_sheet(wb, ws, "Cases");
//       XLSX.writeFile(wb, "Cases.xlsx");
//     } catch (e) {
//       console.error("excel export failed:", e);
//       alert("Excel export failed.");
//     }
//   };
//   const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//   const WINDOW = 4;

//   function range(start, end) {
//     return Array.from({ length: end - start + 1 }, (_, i) => start + i);
//   }
//   function getVisiblePages(current, total) {
//     if (total <= WINDOW) return range(1, total);

//     // Start: 1..4
//     if (current <= WINDOW) return range(1, WINDOW);

//     // End: last 4
//     if (current > total - WINDOW) return range(total - WINDOW + 1, total);

//     // Middle: current..current+3
//     return range(current, current + WINDOW - 1);
//   }

//   return (
//     <AjaxValidation>
//       {/* Filters — NewPage layout, same bindings/logic */}
//       <div className="mt-2">
//         <div className="container-fluid">
//           <h6>Case List</h6>

//           <div class="row mt-2 mb-3">
//             <div class="col-sm-12">
//               <div className="box_card">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <div className="main_agent_form">
//                       <div className="one">
//                         <input
//                           className="form-control"
//                           placeholder="Search"
//                           value={keyword}
//                           onChange={(e) => setKeyword(e.target.value)}
//                         />
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={keyType}
//                           onChange={(e) => setKeyType(e.target.value)}
//                         >
//                           <option value="0">--Keyword--</option>
//                           <option value="1">Email Id</option>
//                           <option value="2">Nulla Osta Reference Number</option>
//                           <option value="3">Passport Number</option>
//                           <option value="4">Mobile Number</option>
//                           <option value="5">Request Id</option>
//                           <option value="6">Name</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={fromDate}
//                             onChange={(d) => setFromDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="From Date"
//                             dateFormat="dd-MM-yyyy" /* visual only */
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={toDate}
//                             onChange={(d) => setToDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="To Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={dateType}
//                           onChange={(e) => setDateType(e.target.value)}
//                         >
//                           <option value="0">--Date Type--</option>
//                           <option value="1">Added On</option>
//                           <option value="2">Submitted On</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={dateType}
//                           onChange={(e) => setDateType(e.target.value)}
//                         >
//                           <option value="0">--Date Type--</option>
//                           <option value="1">Added On</option>
//                           <option value="2">Submitted On</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={vac}
//                           onChange={(e) => setVac(e.target.value)}
//                         >
//                           <option value="0">--Select VAC--</option>
//                           {vacOptions.map((v) => (
//                             <option key={v.vac_id} value={v.vac_id}>
//                               {v.vac_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={status}
//                           onChange={(e) => setStatus(e.target.value)}
//                         >
//                           <option value="0">--Select--</option>
//                           {statusOptions
//                             .filter((s) => Number(s.request_status_id) > 1)
//                             .map((s) => (
//                               <option
//                                 key={s.request_status_id}
//                                 value={s.request_status_id}
//                               >
//                                 {s.request_status_name}
//                               </option>
//                             ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={priority}
//                           onChange={(e) => setPriority(e.target.value)}
//                         >
//                           <option value="-1">--Priority--</option>
//                           <option value="0">Normal</option>
//                           <option value="1">Priority</option>
//                         </select>
//                       </div>
//                       <div className="one gap-2">
//                         <button
//                           className="btn-lg go-btn"
//                           style={{ background: "#f26722", color: "#fff" }}
//                           onClick={handleSearch}
//                         >
//                           Search
//                         </button>
//                         <img
//                           src={excel}
//                           className="common_excell_icon"
//                           alt="Excel"
//                           onClick={handleExcel}
//                           style={{ width: "25px", cursor: "pointer" }}
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//                 <div class="dropdown-divider"></div>
//                 {/* Results */}
//                 <div className="">
//                   <div className="table-responsive holiday-container">
//                     {loading ? (
//                       <div className="p-3 text-center">
//                         <div
//                           style={{
//                             position: "fixed",
//                             inset: 0,
//                             background: "rgba(0,0,0,0.35)",
//                             zIndex: 1050,
//                             display: "grid",
//                             placeItems: "center",
//                           }}
//                         >
//                           <div
//                             className="spinner-border text-light"
//                             role="status"
//                           />
//                         </div>
//                       </div>
//                     ) : rows.length === 0 ? (
//                       <div className="p-3 text-center text-muted">
//                         No records found.
//                       </div>
//                     ) : (
//                       rows.map(({ master, details }, idx) => {
//                         const rid = getReqId(master) ?? String(idx);
//                         const addedOn = toISTString(
//                           master?.addOn ?? master?.added_on
//                         );
//                         const submittedOn = toISTString(
//                           master?.submitOn ?? master?.submitted_on
//                         );
//                         const pr =
//                           master?.priority === 1 || master?.priority === "1"
//                             ? "Priority"
//                             : "Normal";
//                         const vacName = getVacName(
//                           master?.vac ?? master?.vac_id
//                         );
//                         const statusName = getStatusName(
//                           master?.rStatus ?? master?.status
//                         );

//                         return (
//                           <div key={rid} className="border">
//                             {/* master row */}
//                             <table
//                               className="table table-bordered mb-0"
//                               style={{ tableLayout: "auto", width: "100%" }}
//                             >
//                               <thead className="main_heading_table">
//                                 <tr>
//                                   {/* <th className="col-sn">
//                                     {(currentPage - 1) * ITEMS_PER_PAGE +
//                                       idx +
//                                       1}
//                                   </th> */}
//                                   <th>Request ID :</th>
//                                   <th
//                                     className={
//                                       pr === "Priority" ? "priClr" : "col-ad"
//                                     }
//                                   >
//                                     {rid}
//                                   </th>
//                                   <th>IP :</th>
//                                   <th className="col-ip">
//                                     {master?.IP ?? master?.ip ?? "-"}
//                                   </th>
//                                   <th>Added On :</th>
//                                   <th>{addedOn || "-"}</th>
//                                   <th>Submitted On :</th>
//                                   <th>{submittedOn || "-"}</th>
//                                   <th>No. Of Applicants :</th>
//                                   <th style={{ width: "60px" }}>
//                                     {master?.noOfUsr ??
//                                       master?.no_of_applicants ??
//                                       "-"}
//                                   </th>
//                                   <th>VAC :</th>
//                                   <th className="col-vac">
//                                     <div className="d-flex gap-2 align-items-center">
//                                       {vacName}
//                                       <FaEdit
//                                         style={{
//                                           color: "green",
//                                           fontSize: "0.8rem",
//                                         }}
//                                       />
//                                     </div>
//                                   </th>
//                                   <th>Priority :</th>
//                                   <th>{pr}</th>
//                                   <th>Status :</th>
//                                   <th className="col-status">{statusName}</th>
//                                   <th>
//                                     <button
//                                       className="btn-theam-filter"
//                                       onClick={() => toggleExpand(String(rid))}
//                                       title="Expand"
//                                     >
//                                       {expanded === String(rid) ? "▲" : "▼"}
//                                     </button>
//                                   </th>
//                                 </tr>
//                               </thead>
//                             </table>

//                             {/* detail table */}
//                             {expanded === String(rid) && (
//                               <table className="table table-bordered table-hover tableexpand">
//                                 <thead className="table-active tableexpand-head">
//                                   <tr>
//                                     <th>Full Name</th>
//                                     <th>Email Id</th>
//                                     <th>Passport Number</th>
//                                     <th>Nulla osta No</th>
//                                     <th>DOB</th>
//                                     <th>Issue Date</th>
//                                     <th>Submitted On</th>
//                                     <th>VAC</th>
//                                     <th>Appointment On</th>
//                                     <th>Status</th>
//                                     <th>Action</th>
//                                   </tr>
//                                 </thead>
//                                 <tbody>
//                                   {(() => {
//                                     const list = Array.isArray(details)
//                                       ? details
//                                       : details && typeof details === "object"
//                                       ? Object.values(details)
//                                       : [];

//                                     if (list.length === 0) {
//                                       return (
//                                         <tr>
//                                           <td
//                                             colSpan={11}
//                                             className="text-center text-muted"
//                                           >
//                                             No details available for this
//                                             request.
//                                           </td>
//                                         </tr>
//                                       );
//                                     }

//                                     return list.map((d, i) => {
//                                       const fullName = [
//                                         d?.fName ??
//                                           d?.first_name ??
//                                           d?.full_name?.split(" ")?.[0],
//                                         d?.lName ??
//                                           d?.last_name ??
//                                           (d?.full_name
//                                             ? d.full_name
//                                                 .split(" ")
//                                                 .slice(1)
//                                                 .join(" ")
//                                             : null),
//                                       ]
//                                         .filter(Boolean)
//                                         .join(" ");

//                                       return (
//                                         <tr key={`${rid}-detail-${i}`}>
//                                           <td>{fullName || "-"}</td>
//                                           <td>
//                                             {master?.mailId ??
//                                               master?.email ??
//                                               d?.email ??
//                                               "-"}
//                                           </td>
//                                           <td>
//                                             {d?.ppn ?? d?.passport_no ?? "-"}
//                                           </td>
//                                           <td>
//                                             {d?.wpn ?? d?.nulla_osta_no ?? "-"}
//                                           </td>
//                                           <td>{fmtDMY(d?.dob) || "-"}</td>
//                                           <td>
//                                             {fmtDMY(
//                                               d?.wpndt ?? d?.issue_date
//                                             ) || "-"}
//                                           </td>
//                                           <td>{submittedOn || "-"}</td>
//                                           <td>
//                                             {getVacName(
//                                               d?.vac ??
//                                                 master?.vac ??
//                                                 master?.vac_id
//                                             )}
//                                           </td>
//                                           <td>
//                                             {toISTString(
//                                               d?.slotAt ?? d?.appointment_on
//                                             ) || "-"}
//                                           </td>
//                                           <td>
//                                             {getStatusName(
//                                               d?.dtlStatus ??
//                                                 d?.status ??
//                                                 master?.status
//                                             )}
//                                           </td>
//                                           <td>
//                                             <button
//                                               className="btnlink"
//                                               onClick={() =>
//                                                 onView({ master, detail: d })
//                                               }
//                                             >
//                                               View
//                                             </button>
//                                           </td>
//                                         </tr>
//                                       );
//                                     });
//                                   })()}
//                                 </tbody>
//                               </table>
//                             )}
//                           </div>
//                         );
//                       })
//                     )}
//                   </div>

//                   {/* Pagination (unchanged) */}
//                   {/* {total > 0 && (
//               <div className="pagination-de">
//                 <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
//                   <p className="m-0">
//                     Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1} to{" "}
//                     {Math.min(currentPage * ITEMS_PER_PAGE, total)} of {total}
//                   </p>

//                   <button
//                     id="btnPrevious"
//                     className={`btn btn-sm ${
//                       currentPage === 1 ? "disabled" : ""
//                     }`}
//                     onClick={handlePrev}
//                   >
//                     Previous
//                   </button>
//                   {Array.from(
//                     {
//                       length: Math.max(1, Math.ceil(total / ITEMS_PER_PAGE)),
//                     },
//                     (_, i) => (
//                       <button
//                         key={i + 1}
//                         id={`btn${i + 1}`}
//                         className={`btn btn-sm ${
//                           currentPage === i + 1 ? "active" : ""
//                         }`}
//                         onClick={() => fetchPage(i + 1)}
//                       >
//                         {i + 1}
//                       </button>
//                     )
//                   )}
//                   <button
//                     id="btnNext"
//                     className={`btn btn-sm ${
//                       currentPage ===
//                       Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
//                         ? "disabled"
//                         : ""
//                     }`}
//                     onClick={handleNext}
//                   >
//                     Next
//                   </button>
//                 </div>
//               </div>
//             )} */}

//                   {total > 0 && (
//                     <div className="pagination-de">
//                       <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
//                         <button
//                           id="btnPrevious"
//                           className={`btn btn-sm ${
//                             currentPage === 1 ? "disabled" : ""
//                           }`}
//                           onClick={handlePrev}
//                         >
//                           Previous
//                         </button>

//                         {(() => {
//                           const pages = getVisiblePages(
//                             currentPage,
//                             totalPages
//                           );
//                           const hasLeftEllipsis = pages[0] > 1;
//                           const hasRightEllipsis =
//                             pages[pages.length - 1] < totalPages;

//                           return (
//                             <>
//                               {hasLeftEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}

//                               {pages.map((p) => (
//                                 <button
//                                   key={p}
//                                   id={`btn${p}`}
//                                   className={`btn btn-sm ${
//                                     currentPage === p ? "active" : ""
//                                   }`}
//                                   onClick={() => fetchPage(p)}
//                                 >
//                                   {p}
//                                 </button>
//                               ))}

//                               {hasRightEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}
//                             </>
//                           );
//                         })()}

//                         <button
//                           id="btnNext"
//                           className={`btn btn-sm ${
//                             currentPage === totalPages ? "disabled" : ""
//                           }`}
//                           onClick={handleNext}
//                         >
//                           Next
//                         </button>
//                       </div>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Modal */}
//       {show && activeRow && (
//         <CaseModal
//           key={String(getReqId(activeRow?.master))}
//           show={show}
//           onClose={() => setShow(false)}
//           row={activeRow}
//           documents={documents}
//           authData={authData}
//           statusOptions={statusOptions}
//         />
//       )}
//     </AjaxValidation>
//   );
// }

// import React, { useMemo, useState, useEffect } from "react";
// import Modal from "react-bootstrap/Modal";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import { BsCalendar2Check } from "react-icons/bs";
// import { FaEdit } from "react-icons/fa";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { searchCases } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import * as XLSX from "xlsx";
// import excel from "../assets/excel.png";

// /* ===== Constants ===== */
// const ITEMS_PER_PAGE = 10;

// // Reason options (kept here so we can label “reason” codes)
// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];
// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];
// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// /* ===== Utils ===== */
// function toISTString(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
//   const ist = new Date(istMs);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yyyy = d.getFullYear();
//   return `${dd}/${mm}/${yyyy}`;
// }
// function getReqId(obj) {
//   return (
//     obj?.reqId ??
//     obj?.request_id ??
//     obj?.req_id ??
//     obj?.reqid ??
//     obj?.requestId ??
//     obj?.reqIdFk ??
//     obj?.reqid_fk ??
//     null
//   );
// }
// function getDtlId(obj) {
//   return obj?.dtlId ?? obj?.dtlid ?? obj?.dtl_id ?? null;
// }
// /** Accepts raw API response and returns { rows:[{master,details[]}], total } */
// function normalizeResponse(res) {
//   if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
//     const byReq = res.details.reduce((acc, d) => {
//       const k = String(getReqId(d) ?? "");
//       (acc[k] ||= []).push(d);
//       return acc;
//     }, {});
//     const rows = res.master.map((m) => {
//       const mk = String(getReqId(m) ?? "");
//       return { master: m, details: byReq[mk] || [] };
//     });
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (Array.isArray(res)) {
//     const rows = res.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   if (res && Array.isArray(res.master)) {
//     const rows = res.master.map((m) => ({
//       master: m,
//       details: m.details || [],
//     }));
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (res && Array.isArray(res.data)) {
//     const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   return { rows: [], total: 0 };
// }

// /* ========================== Modal ========================== */
// function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
//   const roleId = Number(authData?.role_id);
//   const canEditRight = false; // ← force read-only per requirement

//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

//   const det =
//     row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};
//   const dtlId = String(getDtlId(det) ?? "");

//   const fullName = [
//     det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
//     det?.lName ??
//       det?.last_name ??
//       (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
//   ]
//     .filter(Boolean)
//     .join(" ");

//   const email =
//     row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";

//   const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
//   const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";

//   const dob = fmtDMY(det?.dob);
//   const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);

//   const submittedOn =
//     row?.master?.submitOn ??
//     row?.master?.submitted_on ??
//     det?.submitted_on ??
//     "";

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";

//   const vacName = getVacName(
//     det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
//   );

//   const statusList =
//     (statusOptions && statusOptions.length
//       ? statusOptions
//       : authData?.ajaxPayload?.master_status_list) || [];

//   // Right panel values (read-only)
//   const [status, setStatus] = useState("");
//   const [reason, setReason] = useState("");
//   const [comments, setComments] = useState("");

//   function buildDocUrl(fileName) {
//     if (!fileName) return "";
//     if (!authData?.session_id || !authData?.document_key) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.document_key}_${fileName}`;
//   }

//   const requestId = String(row ? getReqId(row.master) ?? "" : "");

//   // --- NEW: pick document by dtlId + type (1=Passport, 2=Nulla Osta) ---
//   function pickDocByDtlAndType(type) {
//     const list = Array.isArray(documents) ? documents : [];
//     return (
//       list.find(
//         (d) =>
//           String(d?.dtlId ?? d?.dtlid ?? d?.dtl_id) === dtlId &&
//           Number(d?.type) === Number(type)
//       ) || null
//     );
//   }

//   const passportDoc = pickDocByDtlAndType(1);
//   const nullaDoc = pickDocByDtlAndType(2);

//   const passportFile = passportDoc?.file ?? passportDoc?.file_name ?? null;
//   const nullaFile = nullaDoc?.file ?? nullaDoc?.file_name ?? null;

//   const activeDoc =
//     tab === "passport" ? passportDoc : tab === "nulla" ? nullaDoc : null;

//   const activeDocUrl =
//     tab === "passport"
//       ? buildDocUrl(passportFile)
//       : tab === "nulla"
//       ? buildDocUrl(nullaFile)
//       : "";

//   const passportHistory = row?.master?.pp_history || [];
//   const nullaHistory = row?.master?.nulla_history || [];

//   // Keep right panel values in sync with selected tab's document
//   useEffect(() => {
//     if (!activeDoc) {
//       setStatus("");
//       setReason("");
//       setComments("");
//       return;
//     }
//     const docStatus = String(activeDoc?.docStatus ?? "");
//     const docReason = String(activeDoc?.reason ?? "");
//     const docRemarks =
//       String(activeDoc?.remarks ?? "") ||
//       (AUTO_COMMENTS[Number(docReason)] ?? "");

//     setStatus(docStatus);
//     setReason(docReason);
//     setComments(docRemarks);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, documents, dtlId]);

//   // Helper to show status text (fallback to raw code if not found)
//   const getStatusName = (id) =>
//     statusList.find((s) => String(s.request_status_id) === String(id ?? ""))
//       ?.request_status_name || (id ? String(id) : "-");

//   // Helper to show reason label based on the active tab
//   function getReasonLabel(reasonId) {
//     const opts =
//       tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;
//     return (
//       opts.find((r) => String(r.id) === String(reasonId))?.label ||
//       (reasonId ? String(reasonId) : "-")
//     );
//   }

//   function handleSave() {
//     // kept as stub; right panel is read-only per requirement
//     return;
//   }

//   return (
//     <Modal
//       show={show}
//       onHide={onClose}
//       backdrop="static"
//       keyboard={false}
//       className="newcase_modal-dialog"
//       size="xl"
//       centered
//     >
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
//         </Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="model_dialog_list">
//           <div className="row">
//             {/* LEFT */}
//             <div className="col-sm-8 border-right">
//               {/* tab buttons */}
//               <div className="mb-3 d-flex gap-1">
//                 <button
//                   className={`btn ${tab === "passport" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("passport")}
//                 >
//                   Passport Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "nulla" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("nulla")}
//                 >
//                   Nulla Osta Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "history" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("history")}
//                 >
//                   Document History
//                 </button>
//               </div>

//               {tab !== "history" ? (
//                 <div
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {activeDocUrl ? (
//                     <iframe
//                       title="document-preview"
//                       src={activeDocUrl}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">File not found or inaccessible!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="table-responsive">
//                   {/* Passport history */}
//                   <div className="mt-2">
//                     <div className="fw-semibold mb-2">
//                       Passport :{passportNo}
//                     </div>
//                     <table className="table table-bordered">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Passport</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {passportHistory.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           passportHistory.map((h, i) => (
//                             <tr key={i}>
//                               <td>{i + 1}</td>
//                               <td>{h.action || "-"}</td>
//                               <td>{h.user || "-"}</td>
//                               <td>{toISTString(h.time) || "-"}</td>
//                               <td>{h.file || "-"}</td>
//                             </tr>
//                           ))
//                         )}
//                       </tbody>
//                     </table>
//                   </div>

//                   {/* Nulla history */}
//                   <div className="mt-3">
//                     <div className="fw-semibold mb-2">
//                       Nulla Osta No:{nullaOstaNo}
//                     </div>
//                     <table className="table table-bordered">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Nulla Osta</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {nullaHistory.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           nullaHistory.map((h, i) => (
//                             <tr key={i}>
//                               <td>{i + 1}</td>
//                               <td>{h.action || "-"}</td>
//                               <td>{h.user || "-"}</td>
//                               <td>{toISTString(h.time) || "-"}</td>
//                               <td>{h.file || "-"}</td>
//                             </tr>
//                           ))
//                         )}
//                       </tbody>
//                     </table>
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* RIGHT */}
//             <div className="col-sm-4">
//               {/* For HISTORY: show ONLY Nulla Osta document preview (no details) */}
//               {tab === "history" ? (
//                 <div
//                   className="img_view text-center"
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {nullaFile ? (
//                     <iframe
//                       title="history-nulla-preview"
//                       src={buildDocUrl(nullaFile)}
//                       style={{ width: "100%,", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">Nulla Osta file not found!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="accordion-body">
//                   <div className="form-group row">
//                     <div className="col-sm-12">
//                       <h6 className="modal-title mb-2">Customer Details :</h6>
//                     </div>
//                   </div>

//                   <div className="newcase-container">
//                     {/* pairs */}
//                     {[
//                       ["Issue Date", issueDate || "-"],
//                       ["Submited On", toISTString(submittedOn) || "-"],
//                       ["VAC", vacName],
//                       ["Full Name", fullName || "-"],
//                       ["Email Id", email || "-"],
//                       ["Passport Number", passportNo || "-"],
//                       ["Nulla osta No", nullaOstaNo || "-"],
//                       ["DOB", dob || "-"],
//                     ].map(([l, v], i) => (
//                       <div className="form-group row border-bottom" key={i}>
//                         <div className="col-sm-6">
//                           <label className="form-label">{l}</label>
//                         </div>
//                         <div className="col-sm-6">
//                           <label className="form-label">{v}</label>
//                         </div>
//                       </div>
//                     ))}

//                     {/* Status (read-only, but keep UI) */}
//                     <div className="form-group row border-bottom mb-2">
//                       <div className="col-sm-6">
//                         <label className="form-label">Status</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled={true}
//                           value={status}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getStatusName(status)}</option>
//                           {statusList.map((s) => (
//                             <option
//                               key={s.request_status_id}
//                               value={s.request_status_id}
//                             >
//                               {s.request_status_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Reason (read-only, label from correct set) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-6">
//                         <label className="form-label">Reason</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled={true}
//                           value={reason}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getReasonLabel(reason)}</option>
//                           {(tab === "passport"
//                             ? PASSPORT_REASON_OPTIONS
//                             : NULLA_REASON_OPTIONS
//                           ).map((r) => (
//                             <option key={r.id} value={r.id}>
//                               {r.label}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Comments (read-only) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-12">
//                         <label className="form-label">Comments</label>
//                         <textarea
//                           className="form-control"
//                           rows={5}
//                           value={comments}
//                           onChange={() => {}}
//                           disabled={true}
//                         />
//                       </div>
//                     </div>

//                     {canEditRight && (
//                       <div className="form-group row mt-3">
//                         <div className="col-sm-6" />
//                         <div className="col-sm-6">
//                           <button
//                             type="button"
//                             className="btn login-btn w-100"
//                             style={{ background: "#f26722", color: "#fff" }}
//                             onClick={handleSave}
//                           >
//                             Save
//                           </button>
//                         </div>
//                       </div>
//                     )}
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* ========================== Main ========================== */
// export default function CaseList() {
//   const { authData } = useAuth();

//   // Filters
//   const [keyword, setKeyword] = useState("");
//   const [keyType, setKeyType] = useState("0");
//   const [dateType, setDateType] = useState("0");
//   const [vac, setVac] = useState("");
//   const [status, setStatus] = useState("0");
//   const [priority, setPriority] = useState("-1");

//   const [fromDate, setFromDate] = useState(null);
//   const [toDate, setToDate] = useState(null);

//   // Data/page
//   const [rows, setRows] = useState([]); // [{master, details[]}]
//   const [total, setTotal] = useState(0);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [expanded, setExpanded] = useState(null);
//   const [loading, setLoading] = useState(false);

//   // Modal
//   const [show, setShow] = useState(false);
//   const [activeRow, setActiveRow] = useState(null);
//   const [documents, setDocuments] = useState([]);

//   const minDate = useMemo(() => new Date("2000-01-01"), []);
//   const maxDate = useMemo(() => new Date(), []);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const statusOptions = authData?.ajaxPayload?.master_status_list || [];

//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const getStatusName = (id) =>
//     statusOptions.find((s) => String(s.request_status_id) === String(id))
//       ?.request_status_name ||
//     id ||
//     "-";

//   const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
//   const onView = (row) => {
//     setActiveRow(row);
//     setShow(true);
//   };

//   function validateFilters() {
//     if (keyword.trim() && +keyType === 0)
//       return { ok: false, msg: "Choose a Keyword type." };
//     return { ok: true };
//   }

//   function buildPayload(page = 1) {
//     let pKeyType = keyType,
//       pKeyword = keyword,
//       pDateType = dateType,
//       pVac = vac,
//       pStatus = status,
//       pPri = priority;

//     if (+pKeyType > 0) {
//       pDateType = "0";
//       pVac = "0";
//       pStatus = "0";
//       pPri = "-1";
//     }
//     if (+pDateType === 0 && (fromDate || toDate)) {
//       pDateType = "2";
//     }
//     const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

//     return {
//       session_id: authData.session_id,
//       sessionToken: authData.session_token,
//       keyword: pKeyword.trim(),
//       keyType: pKeyType,
//       dateType: pDateType,
//       vac: pVac || "0",
//       status: pStatus,
//       from: fromDate ? fromDate.toISOString().split("T")[0] : "",
//       to: toDate ? toDate.toISOString().split("T")[0] : "",
//       priority: pPri,
//       startRecord,
//       rows: 1,
//       caseList: 1,
//       allSts: 1,
//     };
//   }

//   async function fetchPage(page = 1) {
//     setLoading(true);
//     try {
//       const res = await searchCases(buildPayload(page));
//       const { rows: normalized, total } = normalizeResponse(res);
//       setRows(normalized);
//       setTotal(total || 0);
//       setDocuments(res?.documents || []);
//       setExpanded(null);
//       setCurrentPage(page);
//     } catch (e) {
//       console.error("searchCases failed:", e);
//       setRows([]);
//       setTotal(0);
//       setExpanded(null);
//       setDocuments([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     fetchPage(1);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const handleSearch = async () => {
//     const v = validateFilters();
//     if (!v.ok) {
//       alert(v.msg);
//       return;
//     }
//     await fetchPage(1);
//   };
//   const handlePrev = () => currentPage > 1 && fetchPage(currentPage - 1);
//   const handleNext = () => {
//     const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//     if (currentPage < totalPages) fetchPage(currentPage + 1);
//   };

//   const handleExcel = async () => {
//     try {
//       const flat = [];
//       for (const { master, details } of rows) {
//         const vacName = getVacName(master?.vac ?? master?.vac_id);
//         const statusName = getStatusName(master?.rStatus ?? master?.status);
//         const submittedOn = toISTString(
//           master?.submitOn ?? master?.submitted_on
//         );
//         const detailList = details && details.length ? details : [null];
//         for (const d of detailList) {
//           const issueDate = fmtDMY(d?.wpndt ?? d?.issue_date);
//           const dob = fmtDMY(d?.dob);
//           flat.push({
//             RequestID: getReqId(master),
//             IP: master?.IP ?? master?.ip ?? "",
//             FullName: [d?.fName ?? d?.first_name, d?.lName ?? d?.last_name]
//               .filter(Boolean)
//               .join(" "),
//             EmailId: master?.mailId ?? master?.email ?? d?.email ?? "",
//             PassportNo: d?.ppn ?? d?.passport_no ?? "",
//             NullaOstaNo: d?.wpn ?? d?.nulla_osta_no ?? "",
//             DOB: dob,
//             IssueDate: issueDate,
//             SubmitedOn: submittedOn,
//             VAC: vacName,
//             Status: statusName,
//           });
//         }
//       }
//       const ws = XLSX.utils.json_to_sheet(flat);
//       const wb = XLSX.utils.book_new();
//       XLSX.utils.book_append_sheet(wb, ws, "Cases");
//       XLSX.writeFile(wb, "Cases.xlsx");
//     } catch (e) {
//       console.error("excel export failed:", e);
//       alert("Excel export failed.");
//     }
//   };
//   const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//   const WINDOW = 4;

//   function range(start, end) {
//     return Array.from({ length: end - start + 1 }, (_, i) => start + i);
//   }
//   function getVisiblePages(current, total) {
//     if (total <= WINDOW) return range(1, total);

//     // Start: 1..4
//     if (current <= WINDOW) return range(1, WINDOW);

//     // End: last 4
//     if (current > total - WINDOW) return range(total - WINDOW + 1, total);

//     // Middle: current..current+3
//     return range(current, current + WINDOW - 1);
//   }

//   return (
//     <AjaxValidation>
//       {/* Filters */}
//       <div className="mt-2">
//         <div className="container-fluid">
//           <h6>Case List</h6>

//           <div className="row mt-2 mb-3">
//             <div className="col-sm-12">
//               <div className="box_card">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <div className="main_agent_form">
//                       <div className="one">
//                         <input
//                           className="form-control"
//                           placeholder="Search"
//                           value={keyword}
//                           onChange={(e) => setKeyword(e.target.value)}
//                         />
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={keyType}
//                           onChange={(e) => setKeyType(e.target.value)}
//                         >
//                           <option value="0">--Keyword--</option>
//                           <option value="1">Email Id</option>
//                           <option value="2">Nulla Osta Reference Number</option>
//                           <option value="3">Passport Number</option>
//                           <option value="4">Mobile Number</option>
//                           <option value="5">Request Id</option>
//                           <option value="6">Name</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={fromDate}
//                             onChange={(d) => setFromDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="From Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={toDate}
//                             onChange={(d) => setToDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="To Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={dateType}
//                           onChange={(e) => setDateType(e.target.value)}
//                         >
//                           <option value="0">--Date Type--</option>
//                           <option value="1">Added On</option>
//                           <option value="2">Submitted On</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={dateType}
//                           onChange={(e) => setDateType(e.target.value)}
//                         >
//                           <option value="0">--Date Type--</option>
//                           <option value="1">Added On</option>
//                           <option value="2">Submitted On</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={vac}
//                           onChange={(e) => setVac(e.target.value)}
//                         >
//                           <option value="0">--Select VAC--</option>
//                           {vacOptions.map((v) => (
//                             <option key={v.vac_id} value={v.vac_id}>
//                               {v.vac_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={status}
//                           onChange={(e) => setStatus(e.target.value)}
//                         >
//                           <option value="0">--Select--</option>
//                           {statusOptions
//                             .filter((s) => Number(s.request_status_id) > 1)
//                             .map((s) => (
//                               <option
//                                 key={s.request_status_id}
//                                 value={s.request_status_id}
//                               >
//                                 {s.request_status_name}
//                               </option>
//                             ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={priority}
//                           onChange={(e) => setPriority(e.target.value)}
//                         >
//                           <option value="-1">--Priority--</option>
//                           <option value="0">Normal</option>
//                           <option value="1">Priority</option>
//                         </select>
//                       </div>
//                       <div className="one gap-2">
//                         <button
//                           className="btn-lg go-btn"
//                           style={{ background: "#f26722", color: "#fff" }}
//                           onClick={handleSearch}
//                         >
//                           Search
//                         </button>
//                         <img
//                           src={excel}
//                           className="common_excell_icon"
//                           alt="Excel"
//                           onClick={handleExcel}
//                           style={{ width: "25px", cursor: "pointer" }}
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="dropdown-divider"></div>
//                 {/* Results */}
//                 <div className="">
//                   <div className="table-responsive holiday-container">
//                     {loading ? (
//                       <div className="p-3 text-center">
//                         <div
//                           style={{
//                             position: "fixed",
//                             inset: 0,
//                             background: "rgba(0,0,0,0.35)",
//                             zIndex: 1050,
//                             display: "grid",
//                             placeItems: "center",
//                           }}
//                         >
//                           <div
//                             className="spinner-border text-light"
//                             role="status"
//                           />
//                         </div>
//                       </div>
//                     ) : rows.length === 0 ? (
//                       <div className="p-3 text-center text-muted">
//                         No records found.
//                       </div>
//                     ) : (
//                       rows.map(({ master, details }, idx) => {
//                         const rid = getReqId(master) ?? String(idx);
//                         const addedOn = toISTString(
//                           master?.addOn ?? master?.added_on
//                         );
//                         const submittedOn = toISTString(
//                           master?.submitOn ?? master?.submitted_on
//                         );
//                         const pr =
//                           master?.priority === 1 || master?.priority === "1"
//                             ? "Priority"
//                             : "Normal";
//                         const vacName = getVacName(
//                           master?.vac ?? master?.vac_id
//                         );
//                         const statusName = getStatusName(
//                           master?.rStatus ?? master?.status
//                         );

//                         return (
//                           <div key={rid} className="border">
//                             {/* master row */}
//                             <table
//                               className="table table-bordered mb-0"
//                               style={{ tableLayout: "auto", width: "100%" }}
//                             >
//                               <thead className="main_heading_table">
//                                 <tr>
//                                   <th>Request ID :</th>
//                                   <th
//                                     className={
//                                       pr === "Priority" ? "priClr" : "col-ad"
//                                     }
//                                   >
//                                     {rid}
//                                   </th>
//                                   <th>IP :</th>
//                                   <th className="col-ip">
//                                     {master?.IP ?? master?.ip ?? "-"}
//                                   </th>
//                                   <th>Added On :</th>
//                                   <th>{addedOn || "-"}</th>
//                                   <th>Submitted On :</th>
//                                   <th>{submittedOn || "-"}</th>
//                                   <th>No. Of Applicants :</th>
//                                   <th style={{ width: "60px" }}>
//                                     {master?.noOfUsr ??
//                                       master?.no_of_applicants ??
//                                       "-"}
//                                   </th>
//                                   <th>VAC :</th>
//                                   <th className="col-vac">
//                                     <div className="d-flex gap-2 align-items-center">
//                                       {vacName}
//                                       <FaEdit
//                                         style={{
//                                           color: "green",
//                                           fontSize: "0.8rem",
//                                         }}
//                                       />
//                                     </div>
//                                   </th>
//                                   <th>Priority :</th>
//                                   <th>{pr}</th>
//                                   <th>Status :</th>
//                                   <th className="col-status">{statusName}</th>
//                                   <th>
//                                     <button
//                                       className="btn-theam-filter"
//                                       onClick={() => toggleExpand(String(rid))}
//                                       title="Expand"
//                                     >
//                                       {expanded === String(rid) ? "▲" : "▼"}
//                                     </button>
//                                   </th>
//                                 </tr>
//                               </thead>
//                             </table>

//                             {/* detail table */}
//                             {expanded === String(rid) && (
//                               <table className="table table-bordered table-hover tableexpand">
//                                 <thead className="table-active tableexpand-head">
//                                   <tr>
//                                     <th>Full Name</th>
//                                     <th>Email Id</th>
//                                     <th>Passport Number</th>
//                                     <th>Nulla osta No</th>
//                                     <th>DOB</th>
//                                     <th>Issue Date</th>
//                                     <th>Submitted On</th>
//                                     <th>VAC</th>
//                                     <th>Appointment On</th>
//                                     <th>Status</th>
//                                     <th>Action</th>
//                                   </tr>
//                                 </thead>
//                                 <tbody>
//                                   {(() => {
//                                     const list = Array.isArray(details)
//                                       ? details
//                                       : details && typeof details === "object"
//                                       ? Object.values(details)
//                                       : [];

//                                     if (list.length === 0) {
//                                       return (
//                                         <tr>
//                                           <td
//                                             colSpan={11}
//                                             className="text-center text-muted"
//                                           >
//                                             No details available for this
//                                             request.
//                                           </td>
//                                         </tr>
//                                       );
//                                     }

//                                     return list.map((d, i) => {
//                                       const fullName = [
//                                         d?.fName ??
//                                           d?.first_name ??
//                                           d?.full_name?.split(" ")?.[0],
//                                         d?.lName ??
//                                           d?.last_name ??
//                                           (d?.full_name
//                                             ? d.full_name
//                                                 .split(" ")
//                                                 .slice(1)
//                                                 .join(" ")
//                                             : null),
//                                       ]
//                                         .filter(Boolean)
//                                         .join(" ");

//                                       return (
//                                         <tr key={`${rid}-detail-${i}`}>
//                                           <td>{fullName || "-"}</td>
//                                           <td>
//                                             {master?.mailId ??
//                                               master?.email ??
//                                               d?.email ??
//                                               "-"}
//                                           </td>
//                                           <td>
//                                             {d?.ppn ?? d?.passport_no ?? "-"}
//                                           </td>
//                                           <td>
//                                             {d?.wpn ?? d?.nulla_osta_no ?? "-"}
//                                           </td>
//                                           <td>{fmtDMY(d?.dob) || "-"}</td>
//                                           <td>
//                                             {fmtDMY(
//                                               d?.wpndt ?? d?.issue_date
//                                             ) || "-"}
//                                           </td>
//                                           <td>{submittedOn || "-"}</td>
//                                           <td>
//                                             {getVacName(
//                                               d?.vac ??
//                                                 master?.vac ??
//                                                 master?.vac_id
//                                             )}
//                                           </td>
//                                           <td>
//                                             {toISTString(
//                                               d?.slotAt ?? d?.appointment_on
//                                             ) || "-"}
//                                           </td>
//                                           <td>
//                                             {getStatusName(
//                                               d?.dtlStatus ??
//                                                 d?.status ??
//                                                 master?.status
//                                             )}
//                                           </td>
//                                           <td>
//                                             <button
//                                               className="btnlink"
//                                               onClick={() =>
//                                                 onView({ master, detail: d })
//                                               }
//                                             >
//                                               View
//                                             </button>
//                                           </td>
//                                         </tr>
//                                       );
//                                     });
//                                   })()}
//                                 </tbody>
//                               </table>
//                             )}
//                           </div>
//                         );
//                       })
//                     )}
//                   </div>

//                   {/* Pagination */}
//                   {total > 0 && (
//                     <div className="pagination-de">
//                       <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
//                         <button
//                           id="btnPrevious"
//                           className={`btn btn-sm ${
//                             currentPage === 1 ? "disabled" : ""
//                           }`}
//                           onClick={handlePrev}
//                         >
//                           Previous
//                         </button>

//                         {(() => {
//                           const totalPages = Math.max(
//                             1,
//                             Math.ceil(total / ITEMS_PER_PAGE)
//                           );
//                           const pages = getVisiblePages(
//                             currentPage,
//                             totalPages
//                           );
//                           const hasLeftEllipsis = pages[0] > 1;
//                           const hasRightEllipsis =
//                             pages[pages.length - 1] < totalPages;

//                           return (
//                             <>
//                               {hasLeftEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}

//                               {pages.map((p) => (
//                                 <button
//                                   key={p}
//                                   id={`btn${p}`}
//                                   className={`btn btn-sm ${
//                                     currentPage === p ? "active" : ""
//                                   }`}
//                                   onClick={() => fetchPage(p)}
//                                 >
//                                   {p}
//                                 </button>
//                               ))}

//                               {hasRightEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}
//                             </>
//                           );
//                         })()}

//                         <button
//                           id="btnNext"
//                           className={`btn btn-sm ${
//                             currentPage ===
//                             Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
//                               ? "disabled"
//                               : ""
//                           }`}
//                           onClick={handleNext}
//                         >
//                           Next
//                         </button>
//                       </div>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Modal */}
//       {show && activeRow && (
//         <CaseModal
//           key={String(getReqId(activeRow?.master))}
//           show={show}
//           onClose={() => setShow(false)}
//           row={activeRow}
//           documents={documents}
//           authData={authData}
//           statusOptions={statusOptions}
//         />
//       )}
//     </AjaxValidation>
//   );
// }

// import React, { useMemo, useState, useEffect } from "react";
// import Modal from "react-bootstrap/Modal";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import { BsCalendar2Check } from "react-icons/bs";
// import { FaEdit } from "react-icons/fa";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { searchCases, docHistory } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import * as XLSX from "xlsx";
// import excel from "../assets/excel.png";

// /* ===== Constants ===== */
// const ITEMS_PER_PAGE = 10;

// // Reason options (kept here so we can label “reason” codes)
// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];
// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];
// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// /* ===== Utils ===== */
// function toISTString(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
//   const ist = new Date(istMs);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yyyy = d.getFullYear();
//   return `${dd}/${mm}/${yyyy}`;
// }
// function getReqId(obj) {
//   return (
//     obj?.reqId ??
//     obj?.request_id ??
//     obj?.req_id ??
//     obj?.reqid ??
//     obj?.requestId ??
//     obj?.reqIdFk ??
//     obj?.reqid_fk ??
//     null
//   );
// }
// function getDtlId(obj) {
//   return obj?.dtlId ?? obj?.dtlid ?? obj?.dtl_id ?? null;
// }
// /** Accepts raw API response and returns { rows:[{master,details[]}], total } */
// function normalizeResponse(res) {
//   if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
//     const byReq = res.details.reduce((acc, d) => {
//       const k = String(getReqId(d) ?? "");
//       (acc[k] ||= []).push(d);
//       return acc;
//     }, {});
//     const rows = res.master.map((m) => {
//       const mk = String(getReqId(m) ?? "");
//       return { master: m, details: byReq[mk] || [] };
//     });
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (Array.isArray(res)) {
//     const rows = res.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   if (res && Array.isArray(res.master)) {
//     const rows = res.master.map((m) => ({
//       master: m,
//       details: m.details || [],
//     }));
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (res && Array.isArray(res.data)) {
//     const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows: rows, total: rows.length };
//   }
//   return { rows: [], total: 0 };
// }

// // map numeric doc status to label (for history headers)
// const statusText = (s) =>
//   Number(s) === 6
//     ? "Verified"
//     : Number(s) === 4
//     ? "Blocked"
//     : Number(s) === 3
//     ? "Rejected"
//     : Number(s) === 5
//     ? "Re‑Submitted"
//     : Number(s) === 2
//     ? "Submitted"
//     : "-";

// /* ========================== Modal ========================== */
// function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
//   const roleId = Number(authData?.role_id);
//   const canEditRight = false; // ← force read-only per requirement

//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

//   const det =
//     row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};
//   const dtlId = String(getDtlId(det) ?? "");

//   const fullName = [
//     det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
//     det?.lName ??
//       det?.last_name ??
//       (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
//   ]
//     .filter(Boolean)
//     .join(" ");

//   const email =
//     row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";

//   const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
//   const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";

//   const dob = fmtDMY(det?.dob);
//   const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);

//   const submittedOn =
//     row?.master?.submitOn ??
//     row?.master?.submitted_on ??
//     det?.submitted_on ??
//     "";

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";

//   const vacName = getVacName(
//     det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
//   );

//   const statusList =
//     (statusOptions && statusOptions.length
//       ? statusOptions
//       : authData?.ajaxPayload?.master_status_list) || [];

//   // Right panel values (read-only)
//   const [status, setStatus] = useState("");
//   const [reason, setReason] = useState("");
//   const [comments, setComments] = useState("");

//   // --- NEW: sessionToken + URL builder like your reference code ---
//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   function buildDocUrl(fileName) {
//     if (!fileName) return "";
//     if (!authData?.session_id || !sessionToken) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`;
//   }

//   const requestId = String(row ? getReqId(row.master) ?? "" : "");

//   // --- NEW: pick document by dtlId + type (1=Nulla Osta, 2=Passport) ---
//   function pickDocByDtlAndType(type) {
//     const list = Array.isArray(documents) ? documents : [];
//     return (
//       list.find(
//         (d) =>
//           String(d?.dtlId ?? d?.dtlid ?? d?.dtl_id) === dtlId &&
//           Number(d?.type) === Number(type)
//       ) || null
//     );
//   }
//   const nullaDoc = pickDocByDtlAndType(1);
//   const passportDoc = pickDocByDtlAndType(2);

//   const passportFile = passportDoc?.file ?? passportDoc?.file_name ?? null;
//   const nullaFile = nullaDoc?.file ?? nullaDoc?.file_name ?? null;

//   const activeDoc =
//     tab === "passport" ? passportDoc : tab === "nulla" ? nullaDoc : null;

//   const activeDocUrl =
//     tab === "passport"
//       ? buildDocUrl(passportFile)
//       : tab === "nulla"
//       ? buildDocUrl(nullaFile)
//       : "";

//   // ===== History state (from API) =====
//   const [history, setHistory] = useState({ usr: [], cust: [] }); // usr = passport, cust = nulla
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   // Load doc history when History tab is active
//   useEffect(() => {
//     const load = async () => {
//       if (tab !== "history") return;
//       // try to use either docId; BE returns both UsrActivity & CustActivity
//       const docId = nullaDoc?.docId || passportDoc?.docId;
//       if (!docId) {
//         setHistory({ usr: [], cust: [] });
//         return;
//       }
//       try {
//         setLoadingHistory(true);
//         const res = await docHistory({
//           session_id: authData.session_id,
//           sessionToken,
//           docId,
//         });
//         setHistory({
//           usr: res?.UsrActivity || [], // Passport
//           cust: res?.CustActivity || [], // Nulla
//           bot: res?.UsrActivity || [] + res?.CustActivity || [], // Combined
//         });
//       } catch (e) {
//         console.error("docHistory failed:", e);
//         setHistory({ usr: [], cust: [] });
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     load();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, nullaDoc?.docId, passportDoc?.docId]);

//   // Keep right panel values in sync with selected tab's document
//   useEffect(() => {
//     if (!activeDoc) {
//       setStatus("");
//       setReason("");
//       setComments("");
//       return;
//     }
//     const docStatus = String(activeDoc?.docStatus ?? "");
//     const docReason = String(activeDoc?.reason ?? "");
//     const docRemarks =
//       String(activeDoc?.remarks ?? "") ||
//       (AUTO_COMMENTS[Number(docReason)] ?? "");

//     setStatus(docStatus);
//     setReason(docReason);
//     setComments(docRemarks);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, documents, dtlId]);

//   // Helper to show status text (fallback to raw code if not found)
//   const getStatusName = (id) =>
//     statusList.find((s) => String(s.request_status_id) === String(id ?? ""))
//       ?.request_status_name || (id ? String(id) : "-");

//   // Helper to show reason label based on the active tab
//   function getReasonLabel(reasonId) {
//     const opts =
//       tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;
//     return (
//       opts.find((r) => String(r.id) === String(reasonId))?.label ||
//       (reasonId ? String(reasonId) : "-")
//     );
//   }

//   function handleSave() {
//     // kept as stub; right panel is read-only per requirement
//     return;
//   }

//   return (
//     <Modal
//       show={show}
//       onHide={onClose}
//       backdrop="static"
//       keyboard={false}
//       className="newcase_modal-dialog"
//       size="xl"
//       centered
//     >
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
//         </Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="model_dialog_list">
//           <div className="row">
//             {/* LEFT */}
//             <div className="col-sm-8 border-right">
//               {/* tab buttons */}
//               <div className="mb-3 d-flex gap-1">
//                 <button
//                   className={`btn ${tab === "passport" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("passport")}
//                 >
//                   Passport Document — {statusText(passportDoc?.docStatus)}
//                 </button>
//                 <button
//                   className={`btn ${tab === "nulla" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("nulla")}
//                 >
//                   Nulla Osta Document — {statusText(nullaDoc?.docStatus)}
//                 </button>
//                 <button
//                   className={`btn ${tab === "history" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("history")}
//                 >
//                   Document History
//                 </button>
//               </div>

//               {tab !== "history" ? (
//                 <div
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {activeDocUrl ? (
//                     <iframe
//                       title="document-preview"
//                       src={activeDocUrl}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">File not found or inaccessible!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div
//                   className="table-responsive"
//                   style={{ maxHeight: "55vh", overflow: "auto" }}
//                 >
//                   {loadingHistory ? (
//                     <div className="p-3">Loading history…</div>
//                   ) : (
//                     <>
//                       {/* Passport history */}
//                       <div className="d-flex justify-content-between align-items-center border p-2 mb-2">
//                         <div>Passport : {passportNo || "-"}</div>
//                         <div>Status : {statusText(passportDoc?.docStatus)}</div>
//                       </div>
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned By</th>
//                             <th>Actioned On</th>
//                             <th>Uploaded Passport</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.bot || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.bot.map((u, i) => (
//                               <tr key={`p-${i}`}>
//                                 <td>{i + 1}</td>
//                                 <td>{statusText(passportDoc?.docStatus)}</td>
//                                 <td>{u.usrId || "-"}</td>

//                                 <td>{toISTString(u.addOn) || "-"}</td>
//                                 <td>{u.file_name || "-"}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>

//                       {/* Nulla history */}
//                       <div className="d-flex justify-content-between align-items-center border p-2 mt-3 mb-2">
//                         <div>Nulla Osta : {nullaOstaNo || "-"}</div>
//                         <div>Status : {statusText(nullaDoc?.docStatus)}</div>
//                       </div>
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned By</th>
//                             <th>Actioned On</th>
//                             <th>Uploaded Nulla Osta</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.bot || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.bot.map((c, i) => (
//                               <tr key={`n-${i}`}>
//                                 <td>{i + 1}</td>
//                                 <td>{statusText(nullaDoc?.docStatus)}</td>
//                                 <td>{c.usrId || "-"}</td>
//                                 <td>{toISTString(c.addOn) || "-"}</td>
//                                 <td>{c.file_name || "-"}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </>
//                   )}
//                 </div>
//               )}
//             </div>

//             {/* RIGHT */}
//             <div className="col-sm-4">
//               {/* For HISTORY: always show Nulla Osta document preview (like your reference) */}
//               {tab === "history" ? (
//                 <div
//                   className="img_view text-center"
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {nullaFile ? (
//                     <iframe
//                       title="history-nulla-preview"
//                       src={buildDocUrl(nullaFile)}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">Nulla Osta file not found!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="accordion-body">
//                   <div className="form-group row">
//                     <div className="col-sm-12">
//                       <h6 className="modal-title mb-2">Customer Details :</h6>
//                     </div>
//                   </div>

//                   <div className="newcase-container">
//                     {/* pairs */}
//                     {[
//                       ["Issue Date", issueDate || "-"],
//                       ["Submited On", toISTString(submittedOn) || "-"],
//                       ["VAC", vacName],
//                       ["Full Name", fullName || "-"],
//                       ["Email Id", email || "-"],
//                       ["Passport Number", passportNo || "-"],
//                       ["Nulla osta No", nullaOstaNo || "-"],
//                       ["DOB", dob || "-"],
//                     ].map(([l, v], i) => (
//                       <div className="form-group row border-bottom" key={i}>
//                         <div className="col-sm-6">
//                           <label className="form-label">{l}</label>
//                         </div>
//                         <div className="col-sm-6">
//                           <label className="form-label">{v}</label>
//                         </div>
//                       </div>
//                     ))}

//                     {/* Status (read-only, but keep UI) */}
//                     <div className="form-group row border-bottom mb-2">
//                       <div className="col-sm-6">
//                         <label className="form-label">Status</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled={true}
//                           value={status}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getStatusName(status)}</option>
//                           {statusList.map((s) => (
//                             <option
//                               key={s.request_status_id}
//                               value={s.request_status_id}
//                             >
//                               {s.request_status_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Reason (read-only, label from correct set) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-6">
//                         <label className="form-label">Reason</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled={true}
//                           value={reason}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getReasonLabel(reason)}</option>
//                           {(tab === "passport"
//                             ? PASSPORT_REASON_OPTIONS
//                             : NULLA_REASON_OPTIONS
//                           ).map((r) => (
//                             <option key={r.id} value={r.id}>
//                               {r.label}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Comments (read-only) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-12">
//                         <label className="form-label">Comments</label>
//                         <textarea
//                           className="form-control"
//                           rows={5}
//                           value={comments}
//                           onChange={() => {}}
//                           disabled={true}
//                         />
//                       </div>
//                     </div>

//                     {canEditRight && (
//                       <div className="form-group row mt-3">
//                         <div className="col-sm-6" />
//                         <div className="col-sm-6">
//                           <button
//                             type="button"
//                             className="btn login-btn w-100"
//                             style={{ background: "#f26722", color: "#fff" }}
//                             onClick={handleSave}
//                           >
//                             Save
//                           </button>
//                         </div>
//                       </div>
//                     )}
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* ========================== Main ========================== */
// export default function CaseList() {
//   const { authData } = useAuth();

//   // Filters
//   const [keyword, setKeyword] = useState("");
//   const [keyType, setKeyType] = useState("0");
//   const [dateType, setDateType] = useState("0");
//   const [vac, setVac] = useState("");
//   const [status, setStatus] = useState("0");
//   const [priority, setPriority] = useState("-1");

//   const [fromDate, setFromDate] = useState(null);
//   const [toDate, setToDate] = useState(null);

//   // Data/page
//   const [rows, setRows] = useState([]); // [{master, details[]}]
//   const [total, setTotal] = useState(0);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [expanded, setExpanded] = useState(null);
//   const [loading, setLoading] = useState(false);

//   // Modal
//   const [show, setShow] = useState(false);
//   const [activeRow, setActiveRow] = useState(null);
//   const [documents, setDocuments] = useState([]);

//   const minDate = useMemo(() => new Date("2000-01-01"), []);
//   const maxDate = useMemo(() => new Date(), []);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const statusOptions = authData?.ajaxPayload?.master_status_list || [];

//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const getStatusName = (id) =>
//     statusOptions.find((s) => String(s.request_status_id) === String(id))
//       ?.request_status_name ||
//     id ||
//     "-";

//   const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
//   const onView = (row) => {
//     setActiveRow(row);
//     setShow(true);
//   };

//   function validateFilters() {
//     if (keyword.trim() && +keyType === 0)
//       return { ok: false, msg: "Choose a Keyword type." };
//     return { ok: true };
//   }

//   function buildPayload(page = 1) {
//     let pKeyType = keyType,
//       pKeyword = keyword,
//       pDateType = dateType,
//       pVac = vac,
//       pStatus = status,
//       pPri = priority;

//     if (+pKeyType > 0) {
//       pDateType = "0";
//       pVac = "0";
//       pStatus = "0";
//       pPri = "-1";
//     }
//     if (+pDateType === 0 && (fromDate || toDate)) {
//       pDateType = "2";
//     }
//     const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

//     return {
//       session_id: authData.session_id,
//       sessionToken:
//         authData.session_token ||
//         authData.sessionToken ||
//         authData.Globalsessiontoken,
//       keyword: pKeyword.trim(),
//       keyType: pKeyType,
//       dateType: pDateType,
//       vac: pVac || "0",
//       status: pStatus,
//       from: fromDate ? fromDate.toISOString().split("T")[0] : "",
//       to: toDate ? toDate.toISOString().split("T")[0] : "",
//       priority: pPri,
//       startRecord,
//       rows: 1,
//       caseList: 1,
//       allSts: 1,
//     };
//   }

//   async function fetchPage(page = 1) {
//     setLoading(true);
//     try {
//       const res = await searchCases(buildPayload(page));
//       const { rows: normalized, total } = normalizeResponse(res);
//       setRows(normalized);
//       setTotal(total || 0);
//       setDocuments(res?.documents || []);
//       setExpanded(null);
//       setCurrentPage(page);
//     } catch (e) {
//       console.error("searchCases failed:", e);
//       setRows([]);
//       setTotal(0);
//       setExpanded(null);
//       setDocuments([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     fetchPage(1);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const handleSearch = async () => {
//     const v = validateFilters();
//     if (!v.ok) {
//       alert(v.msg);
//       return;
//     }
//     await fetchPage(1);
//   };
//   const handlePrev = () => currentPage > 1 && fetchPage(currentPage - 1);
//   const handleNext = () => {
//     const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//     if (currentPage < totalPages) fetchPage(currentPage + 1);
//   };

//   const handleExcel = async () => {
//     try {
//       const flat = [];
//       for (const { master, details } of rows) {
//         const vacName = getVacName(master?.vac ?? master?.vac_id);
//         const statusName = getStatusName(master?.rStatus ?? master?.status);
//         const submittedOn = toISTString(
//           master?.submitOn ?? master?.submitted_on
//         );
//         const detailList = details && details.length ? details : [null];
//         for (const d of detailList) {
//           const issueDate = fmtDMY(d?.wpndt ?? d?.issue_date);
//           const dob = fmtDMY(d?.dob);
//           flat.push({
//             RequestID: getReqId(master),
//             IP: master?.IP ?? master?.ip ?? "",
//             FullName: [d?.fName ?? d?.first_name, d?.lName ?? d?.last_name]
//               .filter(Boolean)
//               .join(" "),
//             EmailId: master?.mailId ?? master?.email ?? d?.email ?? "",
//             PassportNo: d?.ppn ?? d?.passport_no ?? "",
//             NullaOstaNo: d?.wpn ?? d?.nulla_osta_no ?? "",
//             DOB: dob,
//             IssueDate: issueDate,
//             SubmitedOn: submittedOn,
//             VAC: vacName,
//             Status: statusName,
//           });
//         }
//       }
//       const ws = XLSX.utils.json_to_sheet(flat);
//       const wb = XLSX.utils.book_new();
//       XLSX.utils.book_append_sheet(wb, ws, "Cases");
//       XLSX.writeFile(wb, "Cases.xlsx");
//     } catch (e) {
//       console.error("excel export failed:", e);
//       alert("Excel export failed.");
//     }
//   };
//   const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//   const WINDOW = 4;

//   function range(start, end) {
//     return Array.from({ length: end - start + 1 }, (_, i) => start + i);
//   }
//   function getVisiblePages(current, total) {
//     if (total <= WINDOW) return range(1, total);

//     // Start: 1..4
//     if (current <= WINDOW) return range(1, WINDOW);

//     // End: last 4
//     if (current > total - WINDOW) return range(total - WINDOW + 1, total);

//     // Middle: current..current+3
//     return range(current, current + WINDOW - 1);
//   }

//   return (
//     <AjaxValidation>
//       {/* Filters */}
//       <div className="mt-2">
//         <div className="container-fluid">
//           <h6>Case List</h6>

//           <div className="row mt-2 mb-3">
//             <div className="col-sm-12">
//               <div className="box_card">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <div className="main_agent_form">
//                       <div className="one">
//                         <input
//                           className="form-control"
//                           placeholder="Search"
//                           value={keyword}
//                           onChange={(e) => setKeyword(e.target.value)}
//                         />
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={keyType}
//                           onChange={(e) => setKeyType(e.target.value)}
//                         >
//                           <option value="0">--Keyword--</option>
//                           <option value="1">Email Id</option>
//                           <option value="2">Nulla Osta Reference Number</option>
//                           <option value="3">Passport Number</option>
//                           <option value="4">Mobile Number</option>
//                           <option value="5">Request Id</option>
//                           <option value="6">Name</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={fromDate}
//                             onChange={(d) => setFromDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="From Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={toDate}
//                             onChange={(d) => setToDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="To Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={dateType}
//                           onChange={(e) => setDateType(e.target.value)}
//                         >
//                           <option value="0">--Date Type--</option>
//                           <option value="1">Added On</option>
//                           <option value="2">Submitted On</option>
//                         </select>
//                       </div>
//                       {/* NOTE: removed duplicate Date Type select from original */}
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={vac}
//                           onChange={(e) => setVac(e.target.value)}
//                         >
//                           <option value="0">--Select VAC--</option>
//                           {vacOptions.map((v) => (
//                             <option key={v.vac_id} value={v.vac_id}>
//                               {v.vac_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={status}
//                           onChange={(e) => setStatus(e.target.value)}
//                         >
//                           <option value="0">--Select--</option>
//                           {statusOptions
//                             .filter((s) => Number(s.request_status_id) > 1)
//                             .map((s) => (
//                               <option
//                                 key={s.request_status_id}
//                                 value={s.request_status_id}
//                               >
//                                 {s.request_status_name}
//                               </option>
//                             ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={priority}
//                           onChange={(e) => setPriority(e.target.value)}
//                         >
//                           <option value="-1">--Priority--</option>
//                           <option value="0">Normal</option>
//                           <option value="1">Priority</option>
//                         </select>
//                       </div>
//                       <div className="one gap-2">
//                         <button
//                           className="btn-lg go-btn"
//                           style={{ background: "#f26722", color: "#fff" }}
//                           onClick={handleSearch}
//                         >
//                           Search
//                         </button>
//                         <img
//                           src={excel}
//                           className="common_excell_icon"
//                           alt="Excel"
//                           onClick={handleExcel}
//                           style={{ width: "25px", cursor: "pointer" }}
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="dropdown-divider"></div>
//                 {/* Results */}
//                 <div className="">
//                   <div className="table-responsive holiday-container">
//                     {loading ? (
//                       <div className="p-3 text-center">
//                         <div
//                           style={{
//                             position: "fixed",
//                             inset: 0,
//                             background: "rgba(0,0,0,0.35)",
//                             zIndex: 1050,
//                             display: "grid",
//                             placeItems: "center",
//                           }}
//                         >
//                           <div
//                             className="spinner-border text-light"
//                             role="status"
//                           />
//                         </div>
//                       </div>
//                     ) : rows.length === 0 ? (
//                       <div className="p-3 text-center text-muted">
//                         No records found.
//                       </div>
//                     ) : (
//                       rows.map(({ master, details }, idx) => {
//                         const rid = getReqId(master) ?? String(idx);
//                         const addedOn = toISTString(
//                           master?.addOn ?? master?.added_on
//                         );
//                         const submittedOn = toISTString(
//                           master?.submitOn ?? master?.submitted_on
//                         );
//                         const pr =
//                           master?.priority === 1 || master?.priority === "1"
//                             ? "Priority"
//                             : "Normal";
//                         const vacName = getVacName(
//                           master?.vac ?? master?.vac_id
//                         );
//                         const statusName = getStatusName(
//                           master?.rStatus ?? master?.status
//                         );

//                         return (
//                           <div key={rid} className="border">
//                             {/* master row */}
//                             <table
//                               className="table table-bordered mb-0"
//                               style={{ tableLayout: "auto", width: "100%" }}
//                             >
//                               <thead className="main_heading_table">
//                                 <tr>
//                                   <th>Request ID :</th>
//                                   <th
//                                     className={
//                                       pr === "Priority" ? "priClr" : "col-ad"
//                                     }
//                                   >
//                                     {rid}
//                                   </th>
//                                   <th>IP :</th>
//                                   <th className="col-ip">
//                                     {master?.IP ?? master?.ip ?? "-"}
//                                   </th>
//                                   <th>Added On :</th>
//                                   <th>{addedOn || "-"}</th>
//                                   <th>Submitted On :</th>
//                                   <th>{submittedOn || "-"}</th>
//                                   <th>No. Of Applicants :</th>
//                                   <th style={{ width: "60px" }}>
//                                     {master?.noOfUsr ??
//                                       master?.no_of_applicants ??
//                                       "-"}
//                                   </th>
//                                   <th>VAC :</th>
//                                   <th className="col-vac">
//                                     <div className="d-flex gap-2 align-items-center">
//                                       {vacName}
//                                       <FaEdit
//                                         style={{
//                                           color: "green",
//                                           fontSize: "0.8rem",
//                                         }}
//                                       />
//                                     </div>
//                                   </th>
//                                   <th>Priority :</th>
//                                   <th>{pr}</th>
//                                   <th>Status :</th>
//                                   <th className="col-status">{statusName}</th>
//                                   <th>
//                                     <button
//                                       className="btn-theam-filter"
//                                       onClick={() => toggleExpand(String(rid))}
//                                       title="Expand"
//                                     >
//                                       {expanded === String(rid) ? "▲" : "▼"}
//                                     </button>
//                                   </th>
//                                 </tr>
//                               </thead>
//                             </table>

//                             {/* detail table */}
//                             {expanded === String(rid) && (
//                               <table className="table table-bordered table-hover tableexpand">
//                                 <thead className="table-active tableexpand-head">
//                                   <tr>
//                                     <th>Full Name</th>
//                                     <th>Email Id</th>
//                                     <th>Passport Number</th>
//                                     <th>Nulla osta No</th>
//                                     <th>DOB</th>
//                                     <th>Issue Date</th>
//                                     <th>Submitted On</th>
//                                     <th>VAC</th>
//                                     <th>Appointment On</th>
//                                     <th>Status</th>
//                                     <th>Action</th>
//                                   </tr>
//                                 </thead>
//                                 <tbody>
//                                   {(() => {
//                                     const list = Array.isArray(details)
//                                       ? details
//                                       : details && typeof details === "object"
//                                       ? Object.values(details)
//                                       : [];

//                                     if (list.length === 0) {
//                                       return (
//                                         <tr>
//                                           <td
//                                             colSpan={11}
//                                             className="text-center text-muted"
//                                           >
//                                             No details available for this
//                                             request.
//                                           </td>
//                                         </tr>
//                                       );
//                                     }

//                                     return list.map((d, i) => {
//                                       const fullName = [
//                                         d?.fName ??
//                                           d?.first_name ??
//                                           d?.full_name?.split(" ")?.[0],
//                                         d?.lName ??
//                                           d?.last_name ??
//                                           (d?.full_name
//                                             ? d.full_name
//                                                 .split(" ")
//                                                 .slice(1)
//                                                 .join(" ")
//                                             : null),
//                                       ]
//                                         .filter(Boolean)
//                                         .join(" ");

//                                       return (
//                                         <tr key={`${rid}-detail-${i}`}>
//                                           <td>{fullName || "-"}</td>
//                                           <td>
//                                             {master?.mailId ??
//                                               master?.email ??
//                                               d?.email ??
//                                               "-"}
//                                           </td>
//                                           <td>
//                                             {d?.ppn ?? d?.passport_no ?? "-"}
//                                           </td>
//                                           <td>
//                                             {d?.wpn ?? d?.nulla_osta_no ?? "-"}
//                                           </td>
//                                           <td>{fmtDMY(d?.dob) || "-"}</td>
//                                           <td>
//                                             {fmtDMY(
//                                               d?.wpndt ?? d?.issue_date
//                                             ) || "-"}
//                                           </td>
//                                           <td>{submittedOn || "-"}</td>
//                                           <td>
//                                             {getVacName(
//                                               d?.vac ??
//                                                 master?.vac ??
//                                                 master?.vac_id
//                                             )}
//                                           </td>
//                                           <td>
//                                             {toISTString(
//                                               d?.slotAt ?? d?.appointment_on
//                                             ) || "-"}
//                                           </td>
//                                           <td>
//                                             {getStatusName(
//                                               d?.dtlStatus ??
//                                                 d?.status ??
//                                                 master?.status
//                                             )}
//                                           </td>
//                                           <td>
//                                             <button
//                                               className="btnlink"
//                                               onClick={() =>
//                                                 onView({ master, detail: d })
//                                               }
//                                             >
//                                               View
//                                             </button>
//                                           </td>
//                                         </tr>
//                                       );
//                                     });
//                                   })()}
//                                 </tbody>
//                               </table>
//                             )}
//                           </div>
//                         );
//                       })
//                     )}
//                   </div>

//                   {/* Pagination */}
//                   {total > 0 && (
//                     <div className="pagination-de">
//                       <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
//                         <button
//                           id="btnPrevious"
//                           className={`btn btn-sm ${
//                             currentPage === 1 ? "disabled" : ""
//                           }`}
//                           onClick={handlePrev}
//                         >
//                           Previous
//                         </button>

//                         {(() => {
//                           const totalPages = Math.max(
//                             1,
//                             Math.ceil(total / ITEMS_PER_PAGE)
//                           );
//                           const pages = getVisiblePages(
//                             currentPage,
//                             totalPages
//                           );
//                           const hasLeftEllipsis = pages[0] > 1;
//                           const hasRightEllipsis =
//                             pages[pages.length - 1] < totalPages;

//                           return (
//                             <>
//                               {hasLeftEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}

//                               {pages.map((p) => (
//                                 <button
//                                   key={p}
//                                   id={`btn${p}`}
//                                   className={`btn btn-sm ${
//                                     currentPage === p ? "active" : ""
//                                   }`}
//                                   onClick={() => fetchPage(p)}
//                                 >
//                                   {p}
//                                 </button>
//                               ))}

//                               {hasRightEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}
//                             </>
//                           );
//                         })()}

//                         <button
//                           id="btnNext"
//                           className={`btn btn-sm ${
//                             currentPage ===
//                             Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
//                               ? "disabled"
//                               : ""
//                           }`}
//                           onClick={handleNext}
//                         >
//                           Next
//                         </button>
//                       </div>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Modal */}
//       {show && activeRow && (
//         <CaseModal
//           key={String(getReqId(activeRow?.master))}
//           show={show}
//           onClose={() => setShow(false)}
//           row={activeRow}
//           documents={documents}
//           authData={authData}
//           statusOptions={statusOptions}
//         />
//       )}
//     </AjaxValidation>
//   );
// }

// import React, { useMemo, useState, useEffect } from "react";
// import Modal from "react-bootstrap/Modal";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import { BsCalendar2Check } from "react-icons/bs";
// import { FaEdit } from "react-icons/fa";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { searchCases, docHistory } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import * as XLSX from "xlsx";
// import excel from "../assets/excel.png";

// /* ===== Constants ===== */
// const ITEMS_PER_PAGE = 100;

// // Reason options (kept here so we can label “reason” codes)
// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];
// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];
// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// /* ===== Utils ===== */
// function toISTString(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
//   const ist = new Date(istMs);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yyyy = d.getFullYear();
//   return `${dd}/${mm}/${yyyy}`;
// }
// function getReqId(obj) {
//   return (
//     obj?.reqId ??
//     obj?.request_id ??
//     obj?.req_id ??
//     obj?.reqid ??
//     obj?.requestId ??
//     obj?.reqIdFk ??
//     obj?.reqid_fk ??
//     null
//   );
// }
// function getDtlId(obj) {
//   return obj?.dtlId ?? obj?.dtlid ?? obj?.dtl_id ?? null;
// }
// /** Accepts raw API response and returns { rows:[{master,details[]}], total } */
// function normalizeResponse(res) {
//   if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
//     const byReq = res.details.reduce((acc, d) => {
//       const k = String(getReqId(d) ?? "");
//       (acc[k] ||= []).push(d);
//       return acc;
//     }, {});
//     const rows = res.master.map((m) => {
//       const mk = String(getReqId(m) ?? "");
//       return { master: m, details: byReq[mk] || [] };
//     });
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (Array.isArray(res)) {
//     const rows = res.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   if (res && Array.isArray(res.master)) {
//     const rows = res.master.map((m) => ({
//       master: m,
//       details: m.details || [],
//     }));
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (res && Array.isArray(res.data)) {
//     const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows: rows, total: rows.length };
//   }
//   return { rows: [], total: 0 };
// }

// // map numeric doc status to label (for history headers)
// const statusText = (s) =>
//   Number(s) === 6
//     ? "Verified"
//     : Number(s) === 4
//     ? "Blocked"
//     : Number(s) === 3
//     ? "Rejected"
//     : Number(s) === 5
//     ? "Re‑Submitted"
//     : Number(s) === 2
//     ? "Submitted"
//     : "-";

// /* ========================== Modal ========================== */
// function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
//   const canEditRight = false; // read-only

//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

//   const det =
//     row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};
//   const dtlId = String(getDtlId(det) ?? "");

//   const fullName = [
//     det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
//     det?.lName ??
//       det?.last_name ??
//       (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
//   ]
//     .filter(Boolean)
//     .join(" ");

//   const email =
//     row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";

//   const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
//   const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";

//   const dob = fmtDMY(det?.dob);
//   const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);

//   const submittedOn =
//     row?.master?.submitOn ??
//     row?.master?.submitted_on ??
//     det?.submitted_on ??
//     "";

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";

//   const vacName = getVacName(
//     det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
//   );

//   const statusList =
//     (statusOptions && statusOptions.length
//       ? statusOptions
//       : authData?.ajaxPayload?.master_status_list) || [];

//   // Right panel values (read-only)
//   const [status, setStatus] = useState("");
//   const [reason, setReason] = useState("");
//   const [comments, setComments] = useState("");

//   // Session token (for document URL)
//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   function buildDocUrl(fileName) {
//     if (!fileName) return "";
//     if (!authData?.session_id || !sessionToken) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`;
//   }

//   const requestId = String(row ? getReqId(row.master) ?? "" : "");

//   // pick document by dtlId + type (1=Nulla Osta, 2=Passport)
//   function pickDocByDtlAndType(type) {
//     const list = Array.isArray(documents) ? documents : [];
//     return (
//       list.find(
//         (d) =>
//           String(d?.dtlId ?? d?.dtlid ?? d?.dtl_id) === dtlId &&
//           Number(d?.type) === Number(type)
//       ) || null
//     );
//   }
//   const nullaDoc = pickDocByDtlAndType(1);
//   const passportDoc = pickDocByDtlAndType(2);

//   const passportFile = passportDoc?.file ?? passportDoc?.file_name ?? null;
//   const nullaFile = nullaDoc?.file ?? nullaDoc?.file_name ?? null;

//   const activeDoc =
//     tab === "passport" ? passportDoc : tab === "nulla" ? nullaDoc : null;

//   const activeDocUrl =
//     tab === "passport"
//       ? buildDocUrl(passportFile)
//       : tab === "nulla"
//       ? buildDocUrl(nullaFile)
//       : "";

//   // ===== History state (from API) =====
//   const [history, setHistory] = useState({ usr: [], cust: [] }); // usr = passport, cust = nulla
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   // Load doc history when History tab is active
//   useEffect(() => {
//     const load = async () => {
//       if (tab !== "history") return;
//       // try to use either docId; BE returns both UsrActivity & CustActivity
//       const docId = nullaDoc?.docId || passportDoc?.docId;
//       if (!docId) {
//         setHistory({ usr: [], cust: [] });
//         return;
//       }
//       try {
//         setLoadingHistory(true);
//         const res = await docHistory({
//           session_id: authData.session_id,
//           sessionToken,
//           docId,
//         });
//         setHistory({
//           usr: res?.UsrActivity || [], // Passport activity rows
//           cust: res?.CustActivity || [], // Nulla activity rows
//         });
//       } catch (e) {
//         console.error("docHistory failed:", e);
//         setHistory({ usr: [], cust: [] });
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     load();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, nullaDoc?.docId, passportDoc?.docId]);

//   // Keep right panel values in sync with selected tab's document
//   useEffect(() => {
//     if (!activeDoc) {
//       setStatus("");
//       setReason("");
//       setComments("");
//       return;
//     }
//     const docStatus = String(activeDoc?.docStatus ?? "");
//     const docReason = String(activeDoc?.reason ?? "");
//     const docRemarks =
//       String(activeDoc?.remarks ?? "") ||
//       (AUTO_COMMENTS[Number(docReason)] ?? "");

//     setStatus(docStatus);
//     setReason(docReason);
//     setComments(docRemarks);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, documents, dtlId]);

//   // Helpers
//   const getStatusName = (id) =>
//     statusList.find((s) => String(s.request_status_id) === String(id ?? ""))
//       ?.request_status_name || (id ? String(id) : "-");

//   function getReasonLabel(reasonId) {
//     const opts =
//       tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;
//     return (
//       opts.find((r) => String(r.id) === String(reasonId))?.label ||
//       (reasonId ? String(reasonId) : "-")
//     );
//   }

//   function handleSave() {
//     // read-only stub
//     return;
//   }

//   return (
//     <Modal
//       show={show}
//       onHide={onClose}
//       backdrop="static"
//       keyboard={false}
//       className="newcase_modal-dialog"
//       size="xl"
//       centered
//     >
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
//         </Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="model_dialog_list">
//           <div className="row">
//             {/* LEFT */}
//             <div className="col-sm-8 border-right">
//               {/* tab buttons */}
//               <div className="mb-3 d-flex gap-1">
//                 <button
//                   className={`btn ${tab === "passport" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("passport")}
//                 >
//                   Passport Document — {statusText(passportDoc?.docStatus)}
//                 </button>
//                 <button
//                   className={`btn ${tab === "nulla" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("nulla")}
//                 >
//                   Nulla Osta Document — {statusText(nullaDoc?.docStatus)}
//                 </button>
//                 <button
//                   className={`btn ${tab === "history" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("history")}
//                 >
//                   Document History
//                 </button>
//               </div>

//               {tab !== "history" ? (
//                 <div
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {activeDocUrl ? (
//                     <iframe
//                       title="document-preview"
//                       src={activeDocUrl}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">File not found or inaccessible!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div
//                   className="table-responsive"
//                   style={{ maxHeight: "55vh", overflow: "auto" }}
//                 >
//                   {loadingHistory ? (
//                     <div className="p-3">Loading history…</div>
//                   ) : (
//                     <>
//                       {/* Passport history */}
//                       <div className="d-flex justify-content-between align-items-center border p-2 mb-2">
//                         <div>Passport : {passportNo || "-"}</div>
//                         <div>Status : {statusText(passportDoc?.docStatus)}</div>
//                       </div>
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned By</th>
//                             <th>Actioned On</th>
//                             <th>Uploaded Passport</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.usr || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.usr.map((u, i) => (
//                               <tr key={`p-${i}`}>
//                                 <td>{i + 1}</td>
//                                 {/* Action = current passport status text */}
//                                 <td>{statusText(passportDoc?.docStatus)}</td>
//                                 {/* Actioned By = fName + lName */}
//                                 <td>{fullName || "-"}</td>
//                                 {/* Actioned On = addOn from row */}
//                                 <td>{toISTString(u.addOn) || "-"}</td>
//                                 {/* Uploaded Passport = file from row */}
//                                 <td>{u.file || u.file_name || "-"}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>

//                       {/* Nulla history */}
//                       <div className="d-flex justify-content-between align-items-center border p-2 mt-3 mb-2">
//                         <div>Nulla Osta : {nullaOstaNo || "-"}</div>
//                         <div>Status : {statusText(nullaDoc?.docStatus)}</div>
//                       </div>
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned By</th>
//                             <th>Actioned On</th>
//                             <th>Uploaded Nulla Osta</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.cust || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.cust.map((c, i) => (
//                               <tr key={`n-${i}`}>
//                                 <td>{i + 1}</td>
//                                 {/* Action = current nulla status text */}
//                                 <td>{statusText(nullaDoc?.docStatus)}</td>
//                                 {/* Actioned By = fName + lName */}
//                                 <td>{fullName || "-"}</td>
//                                 {/* Actioned On = addOn from row */}
//                                 <td>{toISTString(c.addOn) || "-"}</td>
//                                 {/* Uploaded Nulla Osta = file from row */}
//                                 <td>{c.file || c.file_name || "-"}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </>
//                   )}
//                 </div>
//               )}
//             </div>

//             {/* RIGHT */}
//             <div className="col-sm-4">
//               {/* For HISTORY: always show Nulla Osta document preview */}
//               {tab === "history" ? (
//                 <div
//                   className="img_view text-center"
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {nullaFile ? (
//                     <iframe
//                       title="history-nulla-preview"
//                       src={buildDocUrl(nullaFile)}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">Nulla Osta file not found!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="accordion-body">
//                   <div className="form-group row">
//                     <div className="col-sm-12">
//                       <h6 className="modal-title mb-2">Customer Details :</h6>
//                     </div>
//                   </div>

//                   <div className="newcase-container">
//                     {[
//                       ["Issue Date", issueDate || "-"],
//                       ["Submited On", toISTString(submittedOn) || "-"],
//                       ["VAC", vacName],
//                       ["Full Name", fullName || "-"],
//                       ["Email Id", email || "-"],
//                       ["Passport Number", passportNo || "-"],
//                       ["Nulla osta No", nullaOstaNo || "-"],
//                       ["DOB", dob || "-"],
//                     ].map(([l, v], i) => (
//                       <div className="form-group row border-bottom" key={i}>
//                         <div className="col-sm-6">
//                           <label className="form-label">{l}</label>
//                         </div>
//                         <div className="col-sm-6">
//                           <label className="form-label">{v}</label>
//                         </div>
//                       </div>
//                     ))}

//                     {/* Status (read-only, but keep UI) */}
//                     <div className="form-group row border-bottom mb-2">
//                       <div className="col-sm-6">
//                         <label className="form-label">Status</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled={true}
//                           value={status}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getStatusName(status)}</option>
//                           {statusList.map((s) => (
//                             <option
//                               key={s.request_status_id}
//                               value={s.request_status_id}
//                             >
//                               {s.request_status_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Reason (read-only, label from correct set) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-6">
//                         <label className="form-label">Reason</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled={true}
//                           value={reason}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getReasonLabel(reason)}</option>
//                           {(tab === "passport"
//                             ? PASSPORT_REASON_OPTIONS
//                             : NULLA_REASON_OPTIONS
//                           ).map((r) => (
//                             <option key={r.id} value={r.id}>
//                               {r.label}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Comments (read-only) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-12">
//                         <label className="form-label">Comments</label>
//                         <textarea
//                           className="form-control"
//                           rows={5}
//                           value={comments}
//                           onChange={() => {}}
//                           disabled={true}
//                         />
//                       </div>
//                     </div>

//                     {canEditRight && (
//                       <div className="form-group row mt-3">
//                         <div className="col-sm-6" />
//                         <div className="col-sm-6">
//                           <button
//                             type="button"
//                             className="btn login-btn w-100"
//                             style={{ background: "#f26722", color: "#fff" }}
//                             onClick={handleSave}
//                           >
//                             Save
//                           </button>
//                         </div>
//                       </div>
//                     )}
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* ========================== Main ========================== */
// export default function CaseList() {
//   const { authData } = useAuth();

//   // Filters
//   const [keyword, setKeyword] = useState("");
//   const [keyType, setKeyType] = useState("0");
//   const [dateType, setDateType] = useState("0");
//   const [vac, setVac] = useState("");
//   const [status, setStatus] = useState("0");
//   const [priority, setPriority] = useState("-1");

//   const [fromDate, setFromDate] = useState(null);
//   const [toDate, setToDate] = useState(null);

//   // Data/page
//   const [rows, setRows] = useState([]); // [{master, details[]}]
//   const [total, setTotal] = useState(0);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [expanded, setExpanded] = useState(null);
//   const [loading, setLoading] = useState(false);

//   // Modal
//   const [show, setShow] = useState(false);
//   const [activeRow, setActiveRow] = useState(null);
//   const [documents, setDocuments] = useState([]);

//   const minDate = useMemo(() => new Date("2000-01-01"), []);
//   const maxDate = useMemo(() => new Date(), []);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const statusOptions = authData?.ajaxPayload?.master_status_list || [];

//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const getStatusName = (id) =>
//     statusOptions.find((s) => String(s.request_status_id) === String(id))
//       ?.request_status_name ||
//     id ||
//     "-";

//   const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
//   const onView = (row) => {
//     setActiveRow(row);
//     setShow(true);
//   };

//   function validateFilters() {
//     if (keyword.trim() && +keyType === 0)
//       return { ok: false, msg: "Choose a Keyword type." };
//     return { ok: true };
//   }

//   function buildPayload(page = 1) {
//     let pKeyType = keyType,
//       pKeyword = keyword,
//       pDateType = dateType,
//       pVac = vac,
//       pStatus = status,
//       pPri = priority;

//     if (+pKeyType > 0) {
//       pDateType = "0";
//       pVac = "0";
//       pStatus = "0";
//       pPri = "-1";
//     }
//     if (+pDateType === 0 && (fromDate || toDate)) {
//       pDateType = "2";
//     }
//     const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

//     return {
//       session_id: authData.session_id,
//       sessionToken:
//         authData.session_token ||
//         authData.sessionToken ||
//         authData.Globalsessiontoken,
//       keyword: pKeyword.trim(),
//       keyType: pKeyType,
//       dateType: pDateType,
//       vac: pVac || "0",
//       status: pStatus,
//       from: fromDate ? fromDate.toISOString().split("T")[0] : "",
//       to: toDate ? toDate.toISOString().split("T")[0] : "",
//       priority: pPri,
//       startRecord,
//       rows: 1,
//       caseList: 1,
//       allSts: 1,
//     };
//   }

//   async function fetchPage(page = 1) {
//     setLoading(true);
//     try {
//       const res = await searchCases(buildPayload(page));
//       const { rows: normalized, total } = normalizeResponse(res);
//       setRows(normalized);
//       setTotal(total || 0);
//       setDocuments(res?.documents || []);
//       setExpanded(null);
//       setCurrentPage(page);
//     } catch (e) {
//       console.error("searchCases failed:", e);
//       setRows([]);
//       setTotal(0);
//       setExpanded(null);
//       setDocuments([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     fetchPage(1);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const handleSearch = async () => {
//     const v = validateFilters();
//     if (!v.ok) {
//       alert(v.msg);
//       return;
//     }
//     await fetchPage(1);
//   };
//   const handlePrev = () => currentPage > 1 && fetchPage(currentPage - 1);
//   const handleNext = () => {
//     const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//     if (currentPage < totalPages) fetchPage(currentPage + 1);
//   };

//   const handleExcel = async () => {
//     try {
//       const flat = [];
//       for (const { master, details } of rows) {
//         const vacName = getVacName(master?.vac ?? master?.vac_id);
//         const statusName = getStatusName(master?.rStatus ?? master?.status);
//         const submittedOn = toISTString(
//           master?.submitOn ?? master?.submitted_on
//         );
//         const detailList = details && details.length ? details : [null];
//         for (const d of detailList) {
//           const issueDate = fmtDMY(d?.wpndt ?? d?.issue_date);
//           const dob = fmtDMY(d?.dob);
//           flat.push({
//             RequestID: getReqId(master),
//             IP: master?.IP ?? master?.ip ?? "",
//             FullName: [d?.fName ?? d?.first_name, d?.lName ?? d?.last_name]
//               .filter(Boolean)
//               .join(" "),
//             EmailId: master?.mailId ?? master?.email ?? d?.email ?? "",
//             PassportNo: d?.ppn ?? d?.passport_no ?? "",
//             NullaOstaNo: d?.wpn ?? d?.nulla_osta_no ?? "",
//             DOB: dob,
//             IssueDate: issueDate,
//             SubmitedOn: submittedOn,
//             VAC: vacName,
//             Status: statusName,
//           });
//         }
//       }
//       const ws = XLSX.utils.json_to_sheet(flat);
//       const wb = XLSX.utils.book_new();
//       XLSX.utils.book_append_sheet(wb, ws, "Cases");
//       XLSX.writeFile(wb, "Cases.xlsx");
//     } catch (e) {
//       console.error("excel export failed:", e);
//       alert("Excel export failed.");
//     }
//   };
//   const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//   const WINDOW = 4;

//   function range(start, end) {
//     return Array.from({ length: end - start + 1 }, (_, i) => start + i);
//   }
//   function getVisiblePages(current, total) {
//     if (total <= WINDOW) return range(1, total);
//     if (current <= WINDOW) return range(1, WINDOW);
//     if (current > total - WINDOW) return range(total - WINDOW + 1, total);
//     return range(current, current + WINDOW - 1);
//   }

//   return (
//     <AjaxValidation>
//       {/* Filters */}
//       <div className="mt-2">
//         <div className="container-fluid">
//           <h6>Case List</h6>

//           <div className="row mt-2 mb-3">
//             <div className="col-sm-12">
//               <div className="box_card">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <div className="main_agent_form">
//                       <div className="one">
//                         <input
//                           className="form-control"
//                           placeholder="Search"
//                           value={keyword}
//                           onChange={(e) => setKeyword(e.target.value)}
//                         />
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={keyType}
//                           onChange={(e) => setKeyType(e.target.value)}
//                         >
//                           <option value="0">--Keyword--</option>
//                           <option value="1">Email Id</option>
//                           <option value="2">Nulla Osta Reference Number</option>
//                           <option value="3">Passport Number</option>
//                           <option value="4">Mobile Number</option>
//                           <option value="5">Request Id</option>
//                           <option value="6">Name</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={fromDate}
//                             onChange={(d) => setFromDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="From Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={toDate}
//                             onChange={(d) => setToDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="To Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={dateType}
//                           onChange={(e) => setDateType(e.target.value)}
//                         >
//                           <option value="0">--Date Type--</option>
//                           <option value="1">Added On</option>
//                           <option value="2">Submitted On</option>
//                         </select>
//                       </div>
//                       {/* removed the duplicate Date Type select from original */}
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={vac}
//                           onChange={(e) => setVac(e.target.value)}
//                         >
//                           <option value="0">--Select VAC--</option>
//                           {vacOptions.map((v) => (
//                             <option key={v.vac_id} value={v.vac_id}>
//                               {v.vac_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={status}
//                           onChange={(e) => setStatus(e.target.value)}
//                         >
//                           <option value="0">--Select--</option>
//                           {statusOptions
//                             .filter((s) => Number(s.request_status_id) > 1)
//                             .map((s) => (
//                               <option
//                                 key={s.request_status_id}
//                                 value={s.request_status_id}
//                               >
//                                 {s.request_status_name}
//                               </option>
//                             ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={priority}
//                           onChange={(e) => setPriority(e.target.value)}
//                         >
//                           <option value="-1">--Priority--</option>
//                           <option value="0">Normal</option>
//                           <option value="1">Priority</option>
//                         </select>
//                       </div>
//                       <div className="one gap-2">
//                         <button
//                           className="btn-lg go-btn"
//                           style={{ background: "#f26722", color: "#fff" }}
//                           onClick={handleSearch}
//                         >
//                           Search
//                         </button>
//                         <img
//                           src={excel}
//                           className="common_excell_icon"
//                           alt="Excel"
//                           onClick={handleExcel}
//                           style={{ width: "25px", cursor: "pointer" }}
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="dropdown-divider"></div>
//                 {/* Results */}
//                 <div className="">
//                   <div className="table-responsive holiday-container">
//                     {loading ? (
//                       <div className="p-3 text-center">
//                         <div
//                           style={{
//                             position: "fixed",
//                             inset: 0,
//                             background: "rgba(0,0,0,0.35)",
//                             zIndex: 1050,
//                             display: "grid",
//                             placeItems: "center",
//                           }}
//                         >
//                           <div
//                             className="spinner-border text-light"
//                             role="status"
//                           />
//                         </div>
//                       </div>
//                     ) : rows.length === 0 ? (
//                       <div className="p-3 text-center text-muted">
//                         No records found.
//                       </div>
//                     ) : (
//                       rows.map(({ master, details }, idx) => {
//                         const rid = getReqId(master) ?? String(idx);
//                         const addedOn = toISTString(
//                           master?.addOn ?? master?.added_on
//                         );
//                         const submittedOn = toISTString(
//                           master?.submitOn ?? master?.submitted_on
//                         );
//                         const pr =
//                           master?.priority === 1 || master?.priority === "1"
//                             ? "Priority"
//                             : "Normal";
//                         const vacName = getVacName(
//                           master?.vac ?? master?.vac_id
//                         );
//                         const statusName = getStatusName(
//                           master?.rStatus ?? master?.status
//                         );

//                         return (
//                           <div key={rid} className="border">
//                             {/* master row */}
//                             <table
//                               className="table table-bordered mb-0"
//                               style={{ tableLayout: "auto", width: "100%" }}
//                             >
//                               <thead className="main_heading_table">
//                                 <tr>
//                                   <th>Request ID :</th>
//                                   <th
//                                     className={
//                                       pr === "Priority" ? "priClr" : "col-ad"
//                                     }
//                                   >
//                                     {rid}
//                                   </th>
//                                   <th>IP :</th>
//                                   <th className="col-ip">
//                                     {master?.IP ?? master?.ip ?? "-"}
//                                   </th>
//                                   <th>Added On :</th>
//                                   <th>{addedOn || "-"}</th>
//                                   <th>Submitted On :</th>
//                                   <th>{submittedOn || "-"}</th>
//                                   <th>No. Of Applicants :</th>
//                                   <th style={{ width: "60px" }}>
//                                     {master?.noOfUsr ??
//                                       master?.no_of_applicants ??
//                                       "-"}
//                                   </th>
//                                   <th>VAC :</th>
//                                   <th className="col-vac">
//                                     <div className="d-flex gap-2 align-items-center">
//                                       {vacName}
//                                       <FaEdit
//                                         style={{
//                                           color: "green",
//                                           fontSize: "0.8rem",
//                                         }}
//                                       />
//                                     </div>
//                                   </th>
//                                   <th>Priority :</th>
//                                   <th>{pr}</th>
//                                   <th>Status :</th>
//                                   <th className="col-status">{statusName}</th>
//                                   <th>
//                                     <button
//                                       className="btn-theam-filter"
//                                       onClick={() => toggleExpand(String(rid))}
//                                       title="Expand"
//                                     >
//                                       {expanded === String(rid) ? "▲" : "▼"}
//                                     </button>
//                                   </th>
//                                 </tr>
//                               </thead>
//                             </table>

//                             {/* detail table */}
//                             {expanded === String(rid) && (
//                               <table className="table table-bordered table-hover tableexpand">
//                                 <thead className="table-active tableexpand-head">
//                                   <tr>
//                                     <th>Full Name</th>
//                                     <th>Email Id</th>
//                                     <th>Passport Number</th>
//                                     <th>Nulla osta No</th>
//                                     <th>DOB</th>
//                                     <th>Issue Date</th>
//                                     <th>Submitted On</th>
//                                     <th>VAC</th>
//                                     <th>Appointment On</th>
//                                     <th>Status</th>
//                                     <th>Action</th>
//                                   </tr>
//                                 </thead>
//                                 <tbody>
//                                   {(() => {
//                                     const list = Array.isArray(details)
//                                       ? details
//                                       : details && typeof details === "object"
//                                       ? Object.values(details)
//                                       : [];

//                                     if (list.length === 0) {
//                                       return (
//                                         <tr>
//                                           <td
//                                             colSpan={11}
//                                             className="text-center text-muted"
//                                           >
//                                             No details available for this
//                                             request.
//                                           </td>
//                                         </tr>
//                                       );
//                                     }

//                                     return list.map((d, i) => {
//                                       const fullName = [
//                                         d?.fName ??
//                                           d?.first_name ??
//                                           d?.full_name?.split(" ")?.[0],
//                                         d?.lName ??
//                                           d?.last_name ??
//                                           (d?.full_name
//                                             ? d.full_name
//                                                 .split(" ")
//                                                 .slice(1)
//                                                 .join(" ")
//                                             : null),
//                                       ]
//                                         .filter(Boolean)
//                                         .join(" ");

//                                       return (
//                                         <tr key={`${rid}-detail-${i}`}>
//                                           <td>{fullName || "-"}</td>
//                                           <td>
//                                             {master?.mailId ??
//                                               master?.email ??
//                                               d?.email ??
//                                               "-"}
//                                           </td>
//                                           <td>
//                                             {d?.ppn ?? d?.passport_no ?? "-"}
//                                           </td>
//                                           <td>
//                                             {d?.wpn ?? d?.nulla_osta_no ?? "-"}
//                                           </td>
//                                           <td>{fmtDMY(d?.dob) || "-"}</td>
//                                           <td>
//                                             {fmtDMY(
//                                               d?.wpndt ?? d?.issue_date
//                                             ) || "-"}
//                                           </td>
//                                           <td>{submittedOn || "-"}</td>
//                                           <td>
//                                             {getVacName(
//                                               d?.vac ??
//                                                 master?.vac ??
//                                                 master?.vac_id
//                                             )}
//                                           </td>
//                                           <td>
//                                             {toISTString(
//                                               d?.slotAt ?? d?.appointment_on
//                                             ) || "-"}
//                                           </td>
//                                           <td>
//                                             {getStatusName(
//                                               d?.dtlStatus ??
//                                                 d?.status ??
//                                                 master?.status
//                                             )}
//                                           </td>
//                                           <td>
//                                             <button
//                                               className="btnlink"
//                                               onClick={() =>
//                                                 onView({ master, detail: d })
//                                               }
//                                             >
//                                               View
//                                             </button>
//                                           </td>
//                                         </tr>
//                                       );
//                                     });
//                                   })()}
//                                 </tbody>
//                               </table>
//                             )}
//                           </div>
//                         );
//                       })
//                     )}
//                   </div>

//                   {/* Pagination */}
//                   {total > 0 && (
//                     <div className="pagination-de">
//                       <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
//                         <button
//                           id="btnPrevious"
//                           className={`btn btn-sm ${
//                             currentPage === 1 ? "disabled" : ""
//                           }`}
//                           onClick={handlePrev}
//                         >
//                           Previous
//                         </button>

//                         {(() => {
//                           const totalPages = Math.max(
//                             1,
//                             Math.ceil(total / ITEMS_PER_PAGE)
//                           );
//                           const pages = getVisiblePages(
//                             currentPage,
//                             totalPages
//                           );
//                           const hasLeftEllipsis = pages[0] > 1;
//                           const hasRightEllipsis =
//                             pages[pages.length - 1] < totalPages;

//                           return (
//                             <>
//                               {hasLeftEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}

//                               {pages.map((p) => (
//                                 <button
//                                   key={p}
//                                   id={`btn${p}`}
//                                   className={`btn btn-sm ${
//                                     currentPage === p ? "active" : ""
//                                   }`}
//                                   onClick={() => fetchPage(p)}
//                                 >
//                                   {p}
//                                 </button>
//                               ))}

//                               {hasRightEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}
//                             </>
//                           );
//                         })()}

//                         <button
//                           id="btnNext"
//                           className={`btn btn-sm ${
//                             currentPage ===
//                             Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
//                               ? "disabled"
//                               : ""
//                           }`}
//                           onClick={handleNext}
//                         >
//                           Next
//                         </button>
//                       </div>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Modal */}
//       {show && activeRow && (
//         <CaseModal
//           key={String(getReqId(activeRow?.master))}
//           show={show}
//           onClose={() => setShow(false)}
//           row={activeRow}
//           documents={documents}
//           authData={authData}
//           statusOptions={statusOptions}
//         />
//       )}
//     </AjaxValidation>
//   );
// }

// import React, { useMemo, useState, useEffect } from "react";
// import Modal from "react-bootstrap/Modal";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import { BsCalendar2Check } from "react-icons/bs";
// import { FaEdit } from "react-icons/fa";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { searchCases, docHistory } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import * as XLSX from "xlsx";
// import excel from "../assets/excel.png";

// /* ===== Constants ===== */
// const ITEMS_PER_PAGE = 100;

// // Reason options (kept here so we can label “reason” codes)
// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];
// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];
// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// /* ===== Utils ===== */
// function toISTString(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
//   const ist = new Date(istMs);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yyyy = d.getFullYear();
//   return `${dd}/${mm}/${yyyy}`;
// }
// function getReqId(obj) {
//   return (
//     obj?.reqId ??
//     obj?.request_id ??
//     obj?.req_id ??
//     obj?.reqid ??
//     obj?.requestId ??
//     obj?.reqIdFk ??
//     obj?.reqid_fk ??
//     null
//   );
// }
// function getDtlId(obj) {
//   return obj?.dtlId ?? obj?.dtlid ?? obj?.dtl_id ?? null;
// }
// /** Accepts raw API response and returns { rows:[{master,details[]}], total } */
// function normalizeResponse(res) {
//   if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
//     const byReq = res.details.reduce((acc, d) => {
//       const k = String(getReqId(d) ?? "");
//       (acc[k] ||= []).push(d);
//       return acc;
//     }, {});
//     const rows = res.master.map((m) => {
//       const mk = String(getReqId(m) ?? "");
//       return { master: m, details: byReq[mk] || [] };
//     });
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (Array.isArray(res)) {
//     const rows = res.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   if (res && Array.isArray(res.master)) {
//     const rows = res.master.map((m) => ({
//       master: m,
//       details: m.details || [],
//     }));
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (res && Array.isArray(res.data)) {
//     const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows: rows, total: rows.length };
//   }
//   return { rows: [], total: 0 };
// }

// // map numeric doc status to label (for history headers)
// const statusText = (s) =>
//   Number(s) === 6
//     ? "Verified"
//     : Number(s) === 4
//     ? "Blocked"
//     : Number(s) === 3
//     ? "Rejected"
//     : Number(s) === 5
//     ? "Re-Submitted"
//     : Number(s) === 2
//     ? "Submitted"
//     : "-";

// /* ========================== Modal ========================== */
// function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
//   const canEditRight = false; // read-only

//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

//   const det =
//     row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};
//   const dtlId = String(getDtlId(det) ?? "");

//   const fullName = [
//     det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
//     det?.lName ??
//       det?.last_name ??
//       (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
//   ]
//     .filter(Boolean)
//     .join(" ");

//   const email =
//     row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";

//   const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
//   const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";

//   const dob = fmtDMY(det?.dob);
//   const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);

//   const submittedOn =
//     row?.master?.submitOn ??
//     row?.master?.submitted_on ??
//     det?.submitted_on ??
//     "";

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";

//   const vacName = getVacName(
//     det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
//   );

//   const statusList =
//     (statusOptions && statusOptions.length
//       ? statusOptions
//       : authData?.ajaxPayload?.master_status_list) || [];

//   // Right panel values (read-only)
//   const [status, setStatus] = useState("");
//   const [reason, setReason] = useState("");
//   const [comments, setComments] = useState("");

//   // Session token (for document URL)
//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   function buildDocUrl(fileName) {
//     if (!fileName) return "";
//     if (!authData?.session_id || !sessionToken) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`;
//   }

//   const requestId = String(row ? getReqId(row.master) ?? "" : "");

//   // pick document by dtlId + type (1=Nulla Osta, 2=Passport)
//   function pickDocByDtlAndType(type) {
//     const list = Array.isArray(documents) ? documents : [];
//     return (
//       list.find(
//         (d) =>
//           String(d?.dtlId ?? d?.dtlid ?? d?.dtl_id) === dtlId &&
//           Number(d?.type) === Number(type)
//       ) || null
//     );
//   }
//   const nullaDoc = pickDocByDtlAndType(1);
//   const passportDoc = pickDocByDtlAndType(2);

//   const passportFile = passportDoc?.file ?? passportDoc?.file_name ?? null;
//   const nullaFile = nullaDoc?.file ?? nullaDoc?.file_name ?? null;

//   const activeDoc =
//     tab === "passport" ? passportDoc : tab === "nulla" ? nullaDoc : null;

//   const activeDocUrl =
//     tab === "passport"
//       ? buildDocUrl(passportFile)
//       : tab === "nulla"
//       ? buildDocUrl(nullaFile)
//       : "";

//   // ===== History state (from API + searchCases derived) =====
//   const [history, setHistory] = useState({ usr: [], cust: [] }); // usr = passport, cust = nulla
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   // Load doc history when History tab is active
//   useEffect(() => {
//     const load = async () => {
//       if (tab !== "history") return;

//       // We will combine: [derived-from-searchCases, ...docHistory()]
//       const addedOnFromSearch =
//         row?.master?.addOn ?? row?.master?.added_on ?? null;

//       // Base “derived” entries from the current searchCases result:
//       const searchPassportEntry =
//         passportDoc && (passportDoc.file || passportDoc.file_name)
//           ? {
//               addOn: addedOnFromSearch,
//               file: passportDoc.file ?? passportDoc.file_name,
//               file_name: passportDoc.file ?? passportDoc.file_name,
//             }
//           : null;

//       const searchNullaEntry =
//         nullaDoc && (nullaDoc.file || nullaDoc.file_name)
//           ? {
//               addOn: addedOnFromSearch,
//               file: nullaDoc.file ?? nullaDoc.file_name,
//               file_name: nullaDoc.file ?? nullaDoc.file_name,
//             }
//           : null;

//       const docId = nullaDoc?.docId || passportDoc?.docId;

//       // If BE has no docId (edge) we still show the derived row(s)
//       if (!docId) {
//         setHistory({
//           usr: [...(searchPassportEntry ? [searchPassportEntry] : [])],
//           cust: [...(searchNullaEntry ? [searchNullaEntry] : [])],
//         });
//         return;
//       }

//       try {
//         setLoadingHistory(true);
//         const res = await docHistory({
//           session_id: authData.session_id,
//           sessionToken,
//           docId,
//         });

//         const usr = Array.isArray(res?.UsrActivity) ? res.UsrActivity : [];
//         const cust = Array.isArray(res?.CustActivity) ? res.CustActivity : [];

//         // <<<<< IMPORTANT: include the searchCases-derived entry at the top >>>>>
//         setHistory({
//           usr: [...(searchPassportEntry ? [searchPassportEntry] : []), ...usr],
//           cust: [...(searchNullaEntry ? [searchNullaEntry] : []), ...cust],
//         });
//       } catch (e) {
//         console.error("docHistory failed:", e);
//         setHistory({
//           usr: [...(searchPassportEntry ? [searchPassportEntry] : [])],
//           cust: [...(searchNullaEntry ? [searchNullaEntry] : [])],
//         });
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     load();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, nullaDoc?.docId, passportDoc?.docId, row?.master?.addOn]);

//   // Keep right panel values in sync with selected tab's document
//   useEffect(() => {
//     if (!activeDoc) {
//       setStatus("");
//       setReason("");
//       setComments("");
//       return;
//     }
//     const docStatus = String(activeDoc?.docStatus ?? "");
//     const docReason = String(activeDoc?.reason ?? "");
//     const docRemarks =
//       String(activeDoc?.remarks ?? "") ||
//       (AUTO_COMMENTS[Number(docReason)] ?? "");

//     setStatus(docStatus);
//     setReason(docReason);
//     setComments(docRemarks);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, documents, dtlId]);

//   // Helpers
//   const getStatusName = (id) =>
//     statusList.find((s) => String(s.request_status_id) === String(id ?? ""))
//       ?.request_status_name || (id ? String(id) : "-");

//   function getReasonLabel(reasonId) {
//     const opts =
//       tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;
//     return (
//       opts.find((r) => String(r.id) === String(reasonId))?.label ||
//       (reasonId ? String(reasonId) : "-")
//     );
//   }

//   function handleSave() {
//     // read-only stub
//     return;
//   }

//   return (
//     <Modal
//       show={show}
//       onHide={onClose}
//       backdrop="static"
//       keyboard={false}
//       className="newcase_modal-dialog"
//       size="xl"
//       centered
//     >
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
//         </Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="model_dialog_list">
//           <div className="row">
//             {/* LEFT */}
//             <div className="col-sm-8 border-right">
//               {/* tab buttons */}
//               <div className="mb-3 d-flex gap-1">
//                 <button
//                   className={`btn ${tab === "passport" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("passport")}
//                 >
//                   Passport Document — {statusText(passportDoc?.docStatus)}
//                 </button>
//                 <button
//                   className={`btn ${tab === "nulla" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("nulla")}
//                 >
//                   Nulla Osta Document — {statusText(nullaDoc?.docStatus)}
//                 </button>
//                 <button
//                   className={`btn ${tab === "history" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("history")}
//                 >
//                   Document History
//                 </button>
//               </div>

//               {tab !== "history" ? (
//                 <div
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {activeDocUrl ? (
//                     <iframe
//                       title="document-preview"
//                       src={activeDocUrl}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">File not found or inaccessible!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div
//                   className="table-responsive"
//                   style={{ maxHeight: "55vh", overflow: "auto" }}
//                 >
//                   {loadingHistory ? (
//                     <div className="p-3">Loading history…</div>
//                   ) : (
//                     <>
//                       {/* Passport history */}
//                       <div className="d-flex justify-content-between align-items-center border p-2 mb-2">
//                         <div>Passport : {passportNo || "-"}</div>
//                         <div>Status : {statusText(passportDoc?.docStatus)}</div>
//                       </div>
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned By</th>
//                             <th>Actioned On</th>
//                             <th>Uploaded Passport</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.usr || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.usr.map((u, i) => (
//                               <tr key={`p-${i}`}>
//                                 <td>{i + 1}</td>
//                                 {/* Action = current passport status text */}
//                                 <td>{statusText(passportDoc?.docStatus)}</td>
//                                 {/* Actioned By = fName + lName */}
//                                 <td>{fullName || "-"}</td>
//                                 {/* Actioned On = addOn (searchCases-derived or history) */}
//                                 <td>{toISTString(u.addOn) || "-"}</td>
//                                 {/* Uploaded Passport = file name */}
//                                 <td>{u.file || u.file_name || "-"}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>

//                       {/* Nulla history */}
//                       <div className="d-flex justify-content-between align-items-center border p-2 mt-3 mb-2">
//                         <div>Nulla Osta : {nullaOstaNo || "-"}</div>
//                         <div>Status : {statusText(nullaDoc?.docStatus)}</div>
//                       </div>
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned By</th>
//                             <th>Actioned On</th>
//                             <th>Uploaded Nulla Osta</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.cust || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.cust.map((c, i) => (
//                               <tr key={`n-${i}`}>
//                                 <td>{i + 1}</td>
//                                 {/* Action = current nulla status text */}
//                                 <td>{statusText(nullaDoc?.docStatus)}</td>
//                                 {/* Actioned By = fName + lName */}
//                                 <td>{fullName || "-"}</td>
//                                 {/* Actioned On = addOn (searchCases-derived or history) */}
//                                 <td>{toISTString(c.addOn) || "-"}</td>
//                                 {/* Uploaded Nulla Osta = file name */}
//                                 <td>{c.file || c.file_name || "-"}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </>
//                   )}
//                 </div>
//               )}
//             </div>

//             {/* RIGHT */}
//             <div className="col-sm-4">
//               {/* For HISTORY: always show Nulla Osta document preview */}
//               {tab === "history" ? (
//                 <div
//                   className="img_view text-center"
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {nullaFile ? (
//                     <iframe
//                       title="history-nulla-preview"
//                       src={buildDocUrl(nullaFile)}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">Nulla Osta file not found!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="accordion-body">
//                   <div className="form-group row">
//                     <div className="col-sm-12">
//                       <h6 className="modal-title mb-2">Customer Details :</h6>
//                     </div>
//                   </div>

//                   <div className="newcase-container">
//                     {[
//                       ["Issue Date", issueDate || "-"],
//                       ["Submited On", toISTString(submittedOn) || "-"],
//                       ["VAC", vacName],
//                       ["Full Name", fullName || "-"],
//                       ["Email Id", email || "-"],
//                       ["Passport Number", passportNo || "-"],
//                       ["Nulla osta No", nullaOstaNo || "-"],
//                       ["DOB", dob || "-"],
//                     ].map(([l, v], i) => (
//                       <div className="form-group row border-bottom" key={i}>
//                         <div className="col-sm-6">
//                           <label className="form-label">{l}</label>
//                         </div>
//                         <div className="col-sm-6">
//                           <label className="form-label">{v}</label>
//                         </div>
//                       </div>
//                     ))}

//                     {/* Status (read-only, but keep UI) */}
//                     <div className="form-group row border-bottom mb-2">
//                       <div className="col-sm-6">
//                         <label className="form-label">Status</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled={true}
//                           value={status}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getStatusName(status)}</option>
//                           {statusList.map((s) => (
//                             <option
//                               key={s.request_status_id}
//                               value={s.request_status_id}
//                             >
//                               {s.request_status_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Reason (read-only, label from correct set) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-6">
//                         <label className="form-label">Reason</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled={true}
//                           value={reason}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getReasonLabel(reason)}</option>
//                           {(tab === "passport"
//                             ? PASSPORT_REASON_OPTIONS
//                             : NULLA_REASON_OPTIONS
//                           ).map((r) => (
//                             <option key={r.id} value={r.id}>
//                               {r.label}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Comments (read-only) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-12">
//                         <label className="form-label">Comments</label>
//                         <textarea
//                           className="form-control"
//                           rows={5}
//                           value={comments}
//                           onChange={() => {}}
//                           disabled={true}
//                         />
//                       </div>
//                     </div>

//                     {canEditRight && (
//                       <div className="form-group row mt-3">
//                         <div className="col-sm-6" />
//                         <div className="col-sm-6">
//                           <button
//                             type="button"
//                             className="btn login-btn w-100"
//                             style={{ background: "#f26722", color: "#fff" }}
//                             onClick={handleSave}
//                           >
//                             Save
//                           </button>
//                         </div>
//                       </div>
//                     )}
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* ========================== Main ========================== */
// export default function CaseList() {
//   const { authData } = useAuth();

//   // Filters
//   const [keyword, setKeyword] = useState("");
//   const [keyType, setKeyType] = useState("0");
//   const [dateType, setDateType] = useState("0");
//   const [vac, setVac] = useState("");
//   const [status, setStatus] = useState("0");
//   const [priority, setPriority] = useState("-1");

//   const [fromDate, setFromDate] = useState(null);
//   const [toDate, setToDate] = useState(null);

//   // Data/page
//   const [rows, setRows] = useState([]); // [{master, details[]}]
//   const [total, setTotal] = useState(0);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [expanded, setExpanded] = useState(null);
//   const [loading, setLoading] = useState(false);

//   // Modal
//   const [show, setShow] = useState(false);
//   const [activeRow, setActiveRow] = useState(null);
//   const [documents, setDocuments] = useState([]);

//   const minDate = useMemo(() => new Date("2000-01-01"), []);
//   const maxDate = useMemo(() => new Date(), []);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const statusOptions = authData?.ajaxPayload?.master_status_list || [];

//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const getStatusName = (id) =>
//     statusOptions.find((s) => String(s.request_status_id) === String(id))
//       ?.request_status_name ||
//     id ||
//     "-";

//   const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
//   const onView = (row) => {
//     setActiveRow(row);
//     setShow(true);
//   };

//   function validateFilters() {
//     if (keyword.trim() && +keyType === 0)
//       return { ok: false, msg: "Choose a Keyword type." };
//     return { ok: true };
//   }

//   function buildPayload(page = 1) {
//     let pKeyType = keyType,
//       pKeyword = keyword,
//       pDateType = dateType,
//       pVac = vac,
//       pStatus = status,
//       pPri = priority;

//     if (+pKeyType > 0) {
//       pDateType = "0";
//       pVac = "0";
//       pStatus = "0";
//       pPri = "-1";
//     }
//     if (+pDateType === 0 && (fromDate || toDate)) {
//       pDateType = "2";
//     }
//     const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

//     return {
//       session_id: authData.session_id,
//       sessionToken:
//         authData.session_token ||
//         authData.sessionToken ||
//         authData.Globalsessiontoken,
//       keyword: pKeyword.trim(),
//       keyType: pKeyType,
//       dateType: pDateType,
//       vac: pVac || "0",
//       status: pStatus,
//       from: fromDate ? fromDate.toISOString().split("T")[0] : "",
//       to: toDate ? toDate.toISOString().split("T")[0] : "",
//       priority: pPri,
//       startRecord,
//       rows: 1,
//       caseList: 1,
//       allSts: 1,
//     };
//   }

//   async function fetchPage(page = 1) {
//     setLoading(true);
//     try {
//       const res = await searchCases(buildPayload(page));
//       const { rows: normalized, total } = normalizeResponse(res);
//       setRows(normalized);
//       setTotal(total || 0);
//       setDocuments(res?.documents || []);
//       setExpanded(null);
//       setCurrentPage(page);
//     } catch (e) {
//       console.error("searchCases failed:", e);
//       setRows([]);
//       setTotal(0);
//       setExpanded(null);
//       setDocuments([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     fetchPage(1);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const handleSearch = async () => {
//     const v = validateFilters();
//     if (!v.ok) {
//       alert(v.msg);
//       return;
//     }
//     await fetchPage(1);
//   };
//   const handlePrev = () => currentPage > 1 && fetchPage(currentPage - 1);
//   const handleNext = () => {
//     const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//     if (currentPage < totalPages) fetchPage(currentPage + 1);
//   };

//   const handleExcel = async () => {
//     try {
//       const flat = [];
//       for (const { master, details } of rows) {
//         const vacName = getVacName(master?.vac ?? master?.vac_id);
//         const statusName = getStatusName(master?.rStatus ?? master?.status);
//         const submittedOn = toISTString(
//           master?.submitOn ?? master?.submitted_on
//         );
//         const detailList = details && details.length ? details : [null];
//         for (const d of detailList) {
//           const issueDate = fmtDMY(d?.wpndt ?? d?.issue_date);
//           const dob = fmtDMY(d?.dob);
//           flat.push({
//             RequestID: getReqId(master),
//             IP: master?.IP ?? master?.ip ?? "",
//             FullName: [d?.fName ?? d?.first_name, d?.lName ?? d?.last_name]
//               .filter(Boolean)
//               .join(" "),
//             EmailId: master?.mailId ?? master?.email ?? d?.email ?? "",
//             PassportNo: d?.ppn ?? d?.passport_no ?? "",
//             NullaOstaNo: d?.wpn ?? d?.nulla_osta_no ?? "",
//             DOB: dob,
//             IssueDate: issueDate,
//             SubmitedOn: submittedOn,
//             VAC: vacName,
//             Status: statusName,
//           });
//         }
//       }
//       const ws = XLSX.utils.json_to_sheet(flat);
//       const wb = XLSX.utils.book_new();
//       XLSX.utils.book_append_sheet(wb, ws, "Cases");
//       XLSX.writeFile(wb, "Cases.xlsx");
//     } catch (e) {
//       console.error("excel export failed:", e);
//       alert("Excel export failed.");
//     }
//   };
//   const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//   const WINDOW = 4;

//   function range(start, end) {
//     return Array.from({ length: end - start + 1 }, (_, i) => start + i);
//   }
//   function getVisiblePages(current, total) {
//     if (total <= WINDOW) return range(1, total);
//     if (current <= WINDOW) return range(1, WINDOW);
//     if (current > total - WINDOW) return range(total - WINDOW + 1, total);
//     return range(current, current + WINDOW - 1);
//   }

//   return (
//     <AjaxValidation>
//       {/* Filters */}
//       <div className="mt-2">
//         <div className="container-fluid">
//           <h6>Case List</h6>

//           <div className="row mt-2 mb-3">
//             <div className="col-sm-12">
//               <div className="box_card">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <div className="main_agent_form">
//                       <div className="one">
//                         <input
//                           className="form-control"
//                           placeholder="Search"
//                           value={keyword}
//                           onChange={(e) => setKeyword(e.target.value)}
//                         />
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={keyType}
//                           onChange={(e) => setKeyType(e.target.value)}
//                         >
//                           <option value="0">--Keyword--</option>
//                           <option value="1">Email Id</option>
//                           <option value="2">Nulla Osta Reference Number</option>
//                           <option value="3">Passport Number</option>
//                           <option value="4">Mobile Number</option>
//                           <option value="5">Request Id</option>
//                           <option value="6">Name</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={fromDate}
//                             onChange={(d) => setFromDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="From Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={toDate}
//                             onChange={(d) => setToDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="To Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={dateType}
//                           onChange={(e) => setDateType(e.target.value)}
//                         >
//                           <option value="0">--Date Type--</option>
//                           <option value="1">Added On</option>
//                           <option value="2">Submitted On</option>
//                         </select>
//                       </div>
//                       {/* removed the duplicate Date Type select from original */}
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={vac}
//                           onChange={(e) => setVac(e.target.value)}
//                         >
//                           <option value="0">--Select VAC--</option>
//                           {vacOptions.map((v) => (
//                             <option key={v.vac_id} value={v.vac_id}>
//                               {v.vac_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={status}
//                           onChange={(e) => setStatus(e.target.value)}
//                         >
//                           <option value="0">--Select--</option>
//                           {statusOptions
//                             .filter((s) => Number(s.request_status_id) > 1)
//                             .map((s) => (
//                               <option
//                                 key={s.request_status_id}
//                                 value={s.request_status_id}
//                               >
//                                 {s.request_status_name}
//                               </option>
//                             ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={priority}
//                           onChange={(e) => setPriority(e.target.value)}
//                         >
//                           <option value="-1">--Priority--</option>
//                           <option value="0">Normal</option>
//                           <option value="1">Priority</option>
//                         </select>
//                       </div>
//                       <div className="one gap-2">
//                         <button
//                           className="btn-lg go-btn"
//                           style={{ background: "#f26722", color: "#fff" }}
//                           onClick={handleSearch}
//                         >
//                           Search
//                         </button>
//                         <img
//                           src={excel}
//                           className="common_excell_icon"
//                           alt="Excel"
//                           onClick={handleExcel}
//                           style={{ width: "25px", cursor: "pointer" }}
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="dropdown-divider"></div>
//                 {/* Results */}
//                 <div className="">
//                   <div className="table-responsive holiday-container">
//                     {loading ? (
//                       <div className="p-3 text-center">
//                         <div
//                           style={{
//                             position: "fixed",
//                             inset: 0,
//                             background: "rgba(0,0,0,0.35)",
//                             zIndex: 1050,
//                             display: "grid",
//                             placeItems: "center",
//                           }}
//                         >
//                           <div
//                             className="spinner-border text-light"
//                             role="status"
//                           />
//                         </div>
//                       </div>
//                     ) : rows.length === 0 ? (
//                       <div className="p-3 text-center text-muted">
//                         No records found.
//                       </div>
//                     ) : (
//                       rows.map(({ master, details }, idx) => {
//                         const rid = getReqId(master) ?? String(idx);
//                         const addedOn = toISTString(
//                           master?.addOn ?? master?.added_on
//                         );
//                         const submittedOn = toISTString(
//                           master?.submitOn ?? master?.submitted_on
//                         );
//                         const pr =
//                           master?.priority === 1 || master?.priority === "1"
//                             ? "Priority"
//                             : "Normal";
//                         const vacName = getVacName(
//                           master?.vac ?? master?.vac_id
//                         );
//                         const statusName = getStatusName(
//                           master?.rStatus ?? master?.status
//                         );

//                         return (
//                           <div key={rid} className="border">
//                             {/* master row */}
//                             <table
//                               className="table table-bordered mb-0"
//                               style={{ tableLayout: "auto", width: "100%" }}
//                             >
//                               <thead className="main_heading_table">
//                                 <tr>
//                                   <th>Request ID :</th>
//                                   <th
//                                     className={
//                                       pr === "Priority" ? "priClr" : "col-ad"
//                                     }
//                                   >
//                                     {rid}
//                                   </th>
//                                   <th>IP :</th>
//                                   <th className="col-ip">
//                                     {master?.IP ?? master?.ip ?? "-"}
//                                   </th>
//                                   <th>Added On :</th>
//                                   <th>{addedOn || "-"}</th>
//                                   <th>Submitted On :</th>
//                                   <th>{submittedOn || "-"}</th>
//                                   <th>No. Of Applicants :</th>
//                                   <th style={{ width: "60px" }}>
//                                     {master?.noOfUsr ??
//                                       master?.no_of_applicants ??
//                                       "-"}
//                                   </th>
//                                   <th>VAC :</th>
//                                   <th className="col-vac">
//                                     <div className="d-flex gap-2 align-items-center">
//                                       {vacName}
//                                       <FaEdit
//                                         style={{
//                                           color: "green",
//                                           fontSize: "0.8rem",
//                                         }}
//                                       />
//                                     </div>
//                                   </th>
//                                   <th>Priority :</th>
//                                   <th>{pr}</th>
//                                   <th>Status :</th>
//                                   <th className="col-status">{statusName}</th>
//                                   <th>
//                                     <button
//                                       className="btn-theam-filter"
//                                       onClick={() => toggleExpand(String(rid))}
//                                       title="Expand"
//                                     >
//                                       {expanded === String(rid) ? "▲" : "▼"}
//                                     </button>
//                                   </th>
//                                 </tr>
//                               </thead>
//                             </table>

//                             {/* detail table */}
//                             {expanded === String(rid) && (
//                               <table className="table table-bordered table-hover tableexpand">
//                                 <thead className="table-active tableexpand-head">
//                                   <tr>
//                                     <th>Full Name</th>
//                                     <th>Email Id</th>
//                                     <th>Passport Number</th>
//                                     <th>Nulla osta No</th>
//                                     <th>DOB</th>
//                                     <th>Issue Date</th>
//                                     <th>Submitted On</th>
//                                     <th>VAC</th>
//                                     <th>Appointment On</th>
//                                     <th>Status</th>
//                                     <th>Action</th>
//                                   </tr>
//                                 </thead>
//                                 <tbody>
//                                   {(() => {
//                                     const list = Array.isArray(details)
//                                       ? details
//                                       : details && typeof details === "object"
//                                       ? Object.values(details)
//                                       : [];

//                                     if (list.length === 0) {
//                                       return (
//                                         <tr>
//                                           <td
//                                             colSpan={11}
//                                             className="text-center text-muted"
//                                           >
//                                             No details available for this
//                                             request.
//                                           </td>
//                                         </tr>
//                                       );
//                                     }

//                                     return list.map((d, i) => {
//                                       const fullName = [
//                                         d?.fName ??
//                                           d?.first_name ??
//                                           d?.full_name?.split(" ")?.[0],
//                                         d?.lName ??
//                                           d?.last_name ??
//                                           (d?.full_name
//                                             ? d.full_name
//                                                 .split(" ")
//                                                 .slice(1)
//                                                 .join(" ")
//                                             : null),
//                                       ]
//                                         .filter(Boolean)
//                                         .join(" ");

//                                       return (
//                                         <tr key={`${rid}-detail-${i}`}>
//                                           <td>{fullName || "-"}</td>
//                                           <td>
//                                             {master?.mailId ??
//                                               master?.email ??
//                                               d?.email ??
//                                               "-"}
//                                           </td>
//                                           <td>
//                                             {d?.ppn ?? d?.passport_no ?? "-"}
//                                           </td>
//                                           <td>
//                                             {d?.wpn ?? d?.nulla_osta_no ?? "-"}
//                                           </td>
//                                           <td>{fmtDMY(d?.dob) || "-"}</td>
//                                           <td>
//                                             {fmtDMY(
//                                               d?.wpndt ?? d?.issue_date
//                                             ) || "-"}
//                                           </td>
//                                           <td>{submittedOn || "-"}</td>
//                                           <td>
//                                             {getVacName(
//                                               d?.vac ??
//                                                 master?.vac ??
//                                                 master?.vac_id
//                                             )}
//                                           </td>
//                                           <td>
//                                             {toISTString(
//                                               d?.slotAt ?? d?.appointment_on
//                                             ) || "-"}
//                                           </td>
//                                           <td>
//                                             {getStatusName(
//                                               d?.dtlStatus ??
//                                                 d?.status ??
//                                                 master?.status
//                                             )}
//                                           </td>
//                                           <td>
//                                             <button
//                                               className="btnlink"
//                                               onClick={() =>
//                                                 onView({ master, detail: d })
//                                               }
//                                             >
//                                               View
//                                             </button>
//                                           </td>
//                                         </tr>
//                                       );
//                                     });
//                                   })()}
//                                 </tbody>
//                               </table>
//                             )}
//                           </div>
//                         );
//                       })
//                     )}
//                   </div>

//                   {/* Pagination */}
//                   {total > 0 && (
//                     <div className="pagination-de">
//                       <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
//                         <button
//                           id="btnPrevious"
//                           className={`btn btn-sm ${
//                             currentPage === 1 ? "disabled" : ""
//                           }`}
//                           onClick={handlePrev}
//                         >
//                           Previous
//                         </button>

//                         {(() => {
//                           const totalPages = Math.max(
//                             1,
//                             Math.ceil(total / ITEMS_PER_PAGE)
//                           );
//                           const pages = getVisiblePages(
//                             currentPage,
//                             totalPages
//                           );
//                           const hasLeftEllipsis = pages[0] > 1;
//                           const hasRightEllipsis =
//                             pages[pages.length - 1] < totalPages;

//                           return (
//                             <>
//                               {hasLeftEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}

//                               {pages.map((p) => (
//                                 <button
//                                   key={p}
//                                   id={`btn${p}`}
//                                   className={`btn btn-sm ${
//                                     currentPage === p ? "active" : ""
//                                   }`}
//                                   onClick={() => fetchPage(p)}
//                                 >
//                                   {p}
//                                 </button>
//                               ))}

//                               {hasRightEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}
//                             </>
//                           );
//                         })()}

//                         <button
//                           id="btnNext"
//                           className={`btn btn-sm ${
//                             currentPage ===
//                             Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
//                               ? "disabled"
//                               : ""
//                           }`}
//                           onClick={handleNext}
//                         >
//                           Next
//                         </button>
//                       </div>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Modal */}
//       {show && activeRow && (
//         <CaseModal
//           key={String(getReqId(activeRow?.master))}
//           show={show}
//           onClose={() => setShow(false)}
//           row={activeRow}
//           documents={documents}
//           authData={authData}
//           statusOptions={statusOptions}
//         />
//       )}
//     </AjaxValidation>
//   );
// }

// import React, { useMemo, useState, useEffect } from "react";
// import Modal from "react-bootstrap/Modal";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import { BsCalendar2Check } from "react-icons/bs";
// import { FaEdit } from "react-icons/fa";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { searchCases, docHistory } from "../api/client"; // ← use docHistory
// import { useAuth } from "../context/AuthContext";
// import * as XLSX from "xlsx";
// import excel from "../assets/excel.png";

// /* ===== Constants ===== */
// const ITEMS_PER_PAGE = 10;

// // Reason options (kept here so we can label “reason” codes)
// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];
// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];
// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// /* ===== Utils ===== */
// function toISTString(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
//   const ist = new Date(istMs);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yyyy = d.getFullYear();
//   return `${dd}/${mm}/${yyyy}`;
// }
// function getReqId(obj) {
//   return (
//     obj?.reqId ??
//     obj?.request_id ??
//     obj?.req_id ??
//     obj?.reqid ??
//     obj?.requestId ??
//     obj?.reqIdFk ??
//     obj?.reqid_fk ??
//     null
//   );
// }
// function getDtlId(obj) {
//   return obj?.dtlId ?? obj?.dtlid ?? obj?.dtl_id ?? null;
// }
// /** Accepts raw API response and returns { rows:[{master,details[]}], total } */
// function normalizeResponse(res) {
//   if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
//     const byReq = res.details.reduce((acc, d) => {
//       const k = String(getReqId(d) ?? "");
//       (acc[k] ||= []).push(d);
//       return acc;
//     }, {});
//     const rows = res.master.map((m) => {
//       const mk = String(getReqId(m) ?? "");
//       return { master: m, details: byReq[mk] || [] };
//     });
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (Array.isArray(res)) {
//     const rows = res.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   if (res && Array.isArray(res.master)) {
//     const rows = res.master.map((m) => ({
//       master: m,
//       details: m.details || [],
//     }));
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (res && Array.isArray(res.data)) {
//     const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   return { rows: [], total: 0 };
// }

// /* ========================== Modal ========================== */
// function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
//   const canEditRight = false; // read-only per requirement
//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

//   const det =
//     row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};
//   const dtlId = String(getDtlId(det) ?? "");

//   const fullName = [
//     det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
//     det?.lName ??
//       det?.last_name ??
//       (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
//   ]
//     .filter(Boolean)
//     .join(" ");

//   const email =
//     row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";

//   const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
//   const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";

//   const dob = fmtDMY(det?.dob);
//   const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);

//   const submittedOn =
//     row?.master?.submitOn ??
//     row?.master?.submitted_on ??
//     det?.submitted_on ??
//     "";

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";

//   const vacName = getVacName(
//     det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
//   );

//   const statusList =
//     (statusOptions && statusOptions.length
//       ? statusOptions
//       : authData?.ajaxPayload?.master_status_list) || [];

//   // Right panel values (read-only)
//   const [status, setStatus] = useState("");
//   const [reason, setReason] = useState("");
//   const [comments, setComments] = useState("");

//   function buildDocUrl(fileName) {
//     if (!fileName) return "";
//     if (!authData?.session_id || !authData?.document_key) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.document_key}_${fileName}`;
//   }

//   const requestId = String(row ? getReqId(row.master) ?? "" : "");

//   // NOTE: In this API, type=2 is PASSPORT, type=1 is NULLA OSTA (flipped)
//   function pickDocByDtlAndType(type) {
//     const list = Array.isArray(documents) ? documents : [];
//     return (
//       list.find(
//         (d) =>
//           String(d?.dtlId ?? d?.dtlid ?? d?.dtl_id) === dtlId &&
//           Number(d?.type) === Number(type)
//       ) || null
//     );
//   }

//   const passportDoc = pickDocByDtlAndType(2); // ← passport is type 2
//   const nullaDoc = pickDocByDtlAndType(1); // ← nulla is type 1

//   // History state
//   const [passUsrActs, setPassUsrActs] = useState([]); // UsrActivity (passport)
//   const [passCusActs, setPassCusActs] = useState([]); // CustActivity (passport)
//   const [nullaUsrActs, setNullaUsrActs] = useState([]); // UsrActivity (nulla)
//   const [nullaCusActs, setNullaCusActs] = useState([]); // CustActivity (nulla)
//   const [hisLoading, setHisLoading] = useState(false);

//   const passportFile = passportDoc?.file ?? passportDoc?.file_name ?? null;
//   const nullaFile = nullaDoc?.file ?? nullaDoc?.file_name ?? null;

//   const activeDoc =
//     tab === "passport" ? passportDoc : tab === "nulla" ? nullaDoc : null;

//   const activeDocUrl =
//     tab === "passport"
//       ? buildDocUrl(passportFile)
//       : tab === "nulla"
//       ? buildDocUrl(nullaFile)
//       : "";

//   // Keep right panel values in sync with selected tab's document
//   useEffect(() => {
//     if (!activeDoc) {
//       setStatus("");
//       setReason("");
//       setComments("");
//       return;
//     }
//     const docStatus = String(activeDoc?.docStatus ?? "");
//     const docReason = String(activeDoc?.reason ?? "");
//     const docRemarks =
//       String(activeDoc?.remarks ?? "") ||
//       (AUTO_COMMENTS[Number(docReason)] ?? "");

//     setStatus(docStatus);
//     setReason(docReason);
//     setComments(docRemarks);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, documents, dtlId]);

//   // map codes to names
//   const getStatusName = (id) =>
//     statusList.find((s) => String(s.request_status_id) === String(id ?? ""))
//       ?.request_status_name || (id ? String(id) : "-");

//   function getReasonLabel(reasonId) {
//     const opts =
//       tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;
//     return (
//       opts.find((r) => String(r.id) === String(reasonId))?.label ||
//       (reasonId ? String(reasonId) : "-")
//     );
//   }

//   function handleSave() {
//     return; // read-only
//   }

//   // “Actioned By” letter
//   // C = customer upload; S = system (remarks mentions 'system'); A = agent/staff
//   const whoChar = (entry) => {
//     if (entry?.file) return "C";
//     const txt = String(entry?.remarks || "").toLowerCase();
//     if (txt.includes("system")) return "S";
//     return "A";
//   };

//   const fmtTime = (s) => toISTString(s) || "-";

//   // Pull DocDtls when opening History
//   useEffect(() => {
//     let abort = false;

//     async function load(docId, setUsr, setCus) {
//       if (!docId) {
//         setUsr([]);
//         setCus([]);
//         return;
//       }
//       const payload = {
//         session_id: authData?.session_id,
//         sessionToken: authData?.session_token, // camelCase key
//         docId,
//       };
//       const res = await docHistory(payload);
//       if (abort) return;
//       setUsr(Array.isArray(res?.UsrActivity) ? res.UsrActivity : []);
//       setCus(Array.isArray(res?.CustActivity) ? res.CustActivity : []);
//     }

//     async function run() {
//       if (tab !== "history") return;
//       setHisLoading(true);
//       try {
//         await Promise.all([
//           load(
//             passportDoc?.docId ?? passportDoc?.id,
//             setPassUsrActs,
//             setPassCusActs
//           ),
//           load(
//             nullaDoc?.docId ?? nullaDoc?.id,
//             setNullaUsrActs,
//             setNullaCusActs
//           ),
//         ]);
//       } catch (e) {
//         console.error("DocDtls failed:", e);
//         setPassUsrActs([]);
//         setPassCusActs([]);
//         setNullaUsrActs([]);
//         setNullaCusActs([]);
//       } finally {
//         setHisLoading(false);
//       }
//     }

//     run();
//     return () => {
//       abort = true;
//     };
//   }, [
//     tab,
//     authData?.session_id,
//     authData?.session_token,
//     passportDoc?.docId,
//     passportDoc?.id,
//     nullaDoc?.docId,
//     nullaDoc?.id,
//   ]);

//   // status chip:
//   // - Verified (6): green
//   // - Blocked (4): red
//   // - others: gray
//   const statusChip = (docStatus) => {
//     const code = String(docStatus || "");
//     const cls =
//       code === "6"
//         ? "text-success fw-semibold"
//         : code === "4"
//         ? "text-danger fw-semibold"
//         : "text-secondary";
//     return <span className={cls}>{getStatusName(code)}</span>;
//   };

//   return (
//     <Modal
//       show={show}
//       onHide={onClose}
//       backdrop="static"
//       keyboard={false}
//       className="newcase_modal-dialog"
//       size="xl"
//       centered
//     >
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
//         </Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="model_dialog_list">
//           <div className="row">
//             {/* LEFT */}
//             <div className="col-sm-8 border-right">
//               {/* tab buttons */}
//               <div className="mb-3 d-flex gap-1">
//                 <button
//                   className={`btn ${tab === "passport" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("passport")}
//                 >
//                   Passport Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "nulla" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("nulla")}
//                 >
//                   Nulla Osta Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "history" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("history")}
//                 >
//                   Document History
//                 </button>
//               </div>

//               {tab !== "history" ? (
//                 <div
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {activeDocUrl ? (
//                     <iframe
//                       title="document-preview"
//                       src={activeDocUrl}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">File not found or inaccessible!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="pdf_view tab_scroll">
//                   <style>{`
//                     .history_table>:not(caption)>*>*{border-width:0 1px!important;font-size:12px!important}
//                     .status-flex{display:flex;justify-content:space-between;align-items:center;text-align:center;padding:.5rem 1rem;border:1px solid #dee2e6;font-size:14px}
//                   `}</style>

//                   {/* Passport Section */}
//                   <div className="status-flex">
//                     <div>
//                       Passport : <span>{passportNo || "-"}</span>
//                     </div>
//                     <div>Status : {statusChip(passportDoc?.docStatus)}</div>
//                   </div>

//                   <div className="table-responsive mt-2">
//                     <table className="table table-bordered history_table text-left">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Passport</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {hisLoading ? (
//                           <tr>
//                             <td colSpan={5}>Loading…</td>
//                           </tr>
//                         ) : passUsrActs.length === 0 &&
//                           passCusActs.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           <>
//                             {passCusActs.map((c, i) => (
//                               <tr key={`pc-${i}`}>
//                                 <td>{i + 1}</td>
//                                 <td>Uploaded</td>
//                                 <td>{whoChar(c)}</td>
//                                 <td>{fmtTime(c.addOn)}</td>
//                                 <td>{c.file || "-"}</td>
//                               </tr>
//                             ))}
//                             {passUsrActs.map((u, i) => (
//                               <tr key={`pu-${i}`}>
//                                 <td>{passCusActs.length + i + 1}</td>
//                                 <td>
//                                   {AUTO_COMMENTS[String(u.reason)] || "Updated"}
//                                 </td>
//                                 <td>{whoChar(u)}</td>
//                                 <td>{fmtTime(u.addOn)}</td>
//                                 <td>-</td>
//                               </tr>
//                             ))}
//                           </>
//                         )}
//                       </tbody>
//                     </table>
//                   </div>

//                   {/* Nulla Osta Section */}
//                   <div className="status-flex mt-3">
//                     <div>
//                       Nulla Osta : <span>{nullaOstaNo || "-"}</span>
//                     </div>
//                     <div>Status : {statusChip(nullaDoc?.docStatus)}</div>
//                   </div>

//                   <div className="table-responsive mt-2">
//                     <table className="table table-bordered history_table text-left">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Nulla Osta</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {hisLoading ? (
//                           <tr>
//                             <td colSpan={5}>Loading…</td>
//                           </tr>
//                         ) : nullaUsrActs.length === 0 &&
//                           nullaCusActs.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           <>
//                             {nullaCusActs.map((c, i) => (
//                               <tr key={`nc-${i}`}>
//                                 <td>{i + 1}</td>
//                                 <td>Uploaded</td>
//                                 <td>{whoChar(c)}</td>
//                                 <td>{fmtTime(c.addOn)}</td>
//                                 <td>{c.file || "-"}</td>
//                               </tr>
//                             ))}
//                             {nullaUsrActs.map((u, i) => (
//                               <tr key={`nu-${i}`}>
//                                 <td>{nullaCusActs.length + i + 1}</td>
//                                 <td>
//                                   {AUTO_COMMENTS[String(u.reason)] || "Updated"}
//                                 </td>
//                                 <td>{whoChar(u)}</td>
//                                 <td>{fmtTime(u.addOn)}</td>
//                                 <td>-</td>
//                               </tr>
//                             ))}
//                           </>
//                         )}
//                       </tbody>
//                     </table>
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* RIGHT */}
//             <div className="col-sm-4">
//               {tab === "history" ? (
//                 <div
//                   className="img_view text-center"
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {nullaFile ? (
//                     <iframe
//                       title="history-nulla-preview"
//                       src={buildDocUrl(nullaFile)}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">Nulla Osta file not found!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="accordion-body">
//                   <div className="form-group row">
//                     <div className="col-sm-12">
//                       <h6 className="modal-title mb-2">Customer Details :</h6>
//                     </div>
//                   </div>

//                   <div className="newcase-container">
//                     {/* pairs */}
//                     {[
//                       ["Issue Date", issueDate || "-"],
//                       ["Submited On", toISTString(submittedOn) || "-"],
//                       ["VAC", vacName],
//                       ["Full Name", fullName || "-"],
//                       ["Email Id", email || "-"],
//                       ["Passport Number", passportNo || "-"],
//                       ["Nulla osta No", nullaOstaNo || "-"],
//                       ["DOB", dob || "-"],
//                     ].map(([l, v], i) => (
//                       <div className="form-group row border-bottom" key={i}>
//                         <div className="col-sm-6">
//                           <label className="form-label">{l}</label>
//                         </div>
//                         <div className="col-sm-6">
//                           <label className="form-label">{v}</label>
//                         </div>
//                       </div>
//                     ))}

//                     {/* Status (read-only) */}
//                     <div className="form-group row border-bottom mb-2">
//                       <div className="col-sm-6">
//                         <label className="form-label">Status</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled
//                           value={status}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getStatusName(status)}</option>
//                           {statusList.map((s) => (
//                             <option
//                               key={s.request_status_id}
//                               value={s.request_status_id}
//                             >
//                               {s.request_status_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Reason (read-only, correct option set per tab) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-6">
//                         <label className="form-label">Reason</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled
//                           value={reason}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getReasonLabel(reason)}</option>
//                           {(tab === "passport"
//                             ? PASSPORT_REASON_OPTIONS
//                             : NULLA_REASON_OPTIONS
//                           ).map((r) => (
//                             <option key={r.id} value={r.id}>
//                               {r.label}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Comments (read-only) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-12">
//                         <label className="form-label">Comments</label>
//                         <textarea
//                           className="form-control"
//                           rows={5}
//                           value={comments}
//                           onChange={() => {}}
//                           disabled
//                         />
//                       </div>
//                     </div>

//                     {/* (kept for future) */}
//                     {canEditRight && (
//                       <div className="form-group row mt-3">
//                         <div className="col-sm-6" />
//                         <div className="col-sm-6">
//                           <button
//                             type="button"
//                             className="btn login-btn w-100"
//                             style={{ background: "#f26722", color: "#fff" }}
//                             onClick={handleSave}
//                           >
//                             Save
//                           </button>
//                         </div>
//                       </div>
//                     )}
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* ========================== Main ========================== */
// export default function CaseList() {
//   const { authData } = useAuth();

//   // Filters
//   const [keyword, setKeyword] = useState("");
//   const [keyType, setKeyType] = useState("0");
//   const [dateType, setDateType] = useState("0");
//   const [vac, setVac] = useState("");
//   const [status, setStatus] = useState("0");
//   const [priority, setPriority] = useState("-1");

//   const [fromDate, setFromDate] = useState(null);
//   const [toDate, setToDate] = useState(null);

//   // Data/page
//   const [rows, setRows] = useState([]); // [{master, details[]}]
//   const [total, setTotal] = useState(0);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [expanded, setExpanded] = useState(null);
//   const [loading, setLoading] = useState(false);

//   // Modal
//   const [show, setShow] = useState(false);
//   const [activeRow, setActiveRow] = useState(null);
//   const [documents, setDocuments] = useState([]);

//   const minDate = useMemo(() => new Date("2000-01-01"), []);
//   const maxDate = useMemo(() => new Date(), []);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const statusOptions = authData?.ajaxPayload?.master_status_list || [];

//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const getStatusName = (id) =>
//     statusOptions.find((s) => String(s.request_status_id) === String(id))
//       ?.request_status_name ||
//     id ||
//     "-";

//   const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
//   const onView = (row) => {
//     setActiveRow(row);
//     setShow(true);
//   };

//   function validateFilters() {
//     if (keyword.trim() && +keyType === 0)
//       return { ok: false, msg: "Choose a Keyword type." };
//     return { ok: true };
//   }

//   function buildPayload(page = 1) {
//     let pKeyType = keyType,
//       pKeyword = keyword,
//       pDateType = dateType,
//       pVac = vac,
//       pStatus = status,
//       pPri = priority;

//     if (+pKeyType > 0) {
//       pDateType = "0";
//       pVac = "0";
//       pStatus = "0";
//       pPri = "-1";
//     }
//     if (+pDateType === 0 && (fromDate || toDate)) {
//       pDateType = "2";
//     }
//     const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

//     return {
//       session_id: authData.session_id,
//       sessionToken: authData.session_token,
//       keyword: pKeyword.trim(),
//       keyType: pKeyType,
//       dateType: pDateType,
//       vac: pVac || "0",
//       status: pStatus,
//       from: fromDate ? fromDate.toISOString().split("T")[0] : "",
//       to: toDate ? toDate.toISOString().split("T")[0] : "",
//       priority: pPri,
//       startRecord,
//       rows: 1,
//       caseList: 1,
//       allSts: 1,
//     };
//   }

//   async function fetchPage(page = 1) {
//     setLoading(true);
//     try {
//       const res = await searchCases(buildPayload(page));
//       const { rows: normalized, total } = normalizeResponse(res);
//       setRows(normalized);
//       setTotal(total || 0);
//       setDocuments(res?.documents || []);
//       setExpanded(null);
//       setCurrentPage(page);
//     } catch (e) {
//       console.error("searchCases failed:", e);
//       setRows([]);
//       setTotal(0);
//       setExpanded(null);
//       setDocuments([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     fetchPage(1);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const handleSearch = async () => {
//     const v = validateFilters();
//     if (!v.ok) {
//       alert(v.msg);
//       return;
//     }
//     await fetchPage(1);
//   };
//   const handlePrev = () => currentPage > 1 && fetchPage(currentPage - 1);
//   const handleNext = () => {
//     const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//     if (currentPage < totalPages) fetchPage(currentPage + 1);
//   };

//   const handleExcel = async () => {
//     try {
//       const flat = [];
//       for (const { master, details } of rows) {
//         const vacName = getVacName(master?.vac ?? master?.vac_id);
//         const statusName = getStatusName(master?.rStatus ?? master?.status);
//         const submittedOn = toISTString(
//           master?.submitOn ?? master?.submitted_on
//         );
//         const detailList = details && details.length ? details : [null];
//         for (const d of detailList) {
//           const issueDate = fmtDMY(d?.wpndt ?? d?.issue_date);
//           const dob = fmtDMY(d?.dob);
//           flat.push({
//             RequestID: getReqId(master),
//             IP: master?.IP ?? master?.ip ?? "",
//             FullName: [d?.fName ?? d?.first_name, d?.lName ?? d?.last_name]
//               .filter(Boolean)
//               .join(" "),
//             EmailId: master?.mailId ?? master?.email ?? d?.email ?? "",
//             PassportNo: d?.ppn ?? d?.passport_no ?? "",
//             NullaOstaNo: d?.wpn ?? d?.nulla_osta_no ?? "",
//             DOB: dob,
//             IssueDate: issueDate,
//             SubmitedOn: submittedOn,
//             VAC: vacName,
//             Status: statusName,
//           });
//         }
//       }
//       const ws = XLSX.utils.json_to_sheet(flat);
//       const wb = XLSX.utils.book_new();
//       XLSX.utils.book_append_sheet(wb, ws, "Cases");
//       XLSX.writeFile(wb, "Cases.xlsx");
//     } catch (e) {
//       console.error("excel export failed:", e);
//       alert("Excel export failed.");
//     }
//   };
//   const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//   const WINDOW = 4;

//   function range(start, end) {
//     return Array.from({ length: end - start + 1 }, (_, i) => start + i);
//   }
//   function getVisiblePages(current, total) {
//     if (total <= WINDOW) return range(1, total);

//     // Start: 1..4
//     if (current <= WINDOW) return range(1, WINDOW);

//     // End: last 4
//     if (current > total - WINDOW) return range(total - WINDOW + 1, total);

//     // Middle: current..current+3
//     return range(current, current + WINDOW - 1);
//   }

//   return (
//     <AjaxValidation>
//       {/* Filters */}
//       <div className="mt-2">
//         <div className="container-fluid">
//           <h6>Case List</h6>

//           <div className="row mt-2 mb-3">
//             <div className="col-sm-12">
//               <div className="box_card">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <div className="main_agent_form">
//                       <div className="one">
//                         <input
//                           className="form-control"
//                           placeholder="Search"
//                           value={keyword}
//                           onChange={(e) => setKeyword(e.target.value)}
//                         />
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={keyType}
//                           onChange={(e) => setKeyType(e.target.value)}
//                         >
//                           <option value="0">--Keyword--</option>
//                           <option value="1">Email Id</option>
//                           <option value="2">Nulla Osta Reference Number</option>
//                           <option value="3">Passport Number</option>
//                           <option value="4">Mobile Number</option>
//                           <option value="5">Request Id</option>
//                           <option value="6">Name</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={fromDate}
//                             onChange={(d) => setFromDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="From Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={toDate}
//                             onChange={(d) => setToDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="To Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={dateType}
//                           onChange={(e) => setDateType(e.target.value)}
//                         >
//                           <option value="0">--Date Type--</option>
//                           <option value="1">Added On</option>
//                           <option value="2">Submitted On</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={vac}
//                           onChange={(e) => setVac(e.target.value)}
//                         >
//                           <option value="0">--Select VAC--</option>
//                           {vacOptions.map((v) => (
//                             <option key={v.vac_id} value={v.vac_id}>
//                               {v.vac_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={status}
//                           onChange={(e) => setStatus(e.target.value)}
//                         >
//                           <option value="0">--Select--</option>
//                           {statusOptions
//                             .filter((s) => Number(s.request_status_id) > 1)
//                             .map((s) => (
//                               <option
//                                 key={s.request_status_id}
//                                 value={s.request_status_id}
//                               >
//                                 {s.request_status_name}
//                               </option>
//                             ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={priority}
//                           onChange={(e) => setPriority(e.target.value)}
//                         >
//                           <option value="-1">--Priority--</option>
//                           <option value="0">Normal</option>
//                           <option value="1">Priority</option>
//                         </select>
//                       </div>
//                       <div className="one gap-2">
//                         <button
//                           className="btn-lg go-btn"
//                           style={{ background: "#f26722", color: "#fff" }}
//                           onClick={handleSearch}
//                         >
//                           Search
//                         </button>
//                         <img
//                           src={excel}
//                           className="common_excell_icon"
//                           alt="Excel"
//                           onClick={handleExcel}
//                           style={{ width: "25px", cursor: "pointer" }}
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="dropdown-divider"></div>
//                 {/* Results */}
//                 <div className="">
//                   <div className="table-responsive holiday-container">
//                     {loading ? (
//                       <div className="p-3 text-center">
//                         <div
//                           style={{
//                             position: "fixed",
//                             inset: 0,
//                             background: "rgba(0,0,0,0.35)",
//                             zIndex: 1050,
//                             display: "grid",
//                             placeItems: "center",
//                           }}
//                         >
//                           <div
//                             className="spinner-border text-light"
//                             role="status"
//                           />
//                         </div>
//                       </div>
//                     ) : rows.length === 0 ? (
//                       <div className="p-3 text-center text-muted">
//                         No records found.
//                       </div>
//                     ) : (
//                       rows.map(({ master, details }, idx) => {
//                         const rid = getReqId(master) ?? String(idx);
//                         const addedOn = toISTString(
//                           master?.addOn ?? master?.added_on
//                         );
//                         const submittedOn = toISTString(
//                           master?.submitOn ?? master?.submitted_on
//                         );
//                         const pr =
//                           master?.priority === 1 || master?.priority === "1"
//                             ? "Priority"
//                             : "Normal";
//                         const vacName = getVacName(
//                           master?.vac ?? master?.vac_id
//                         );
//                         const statusName = getStatusName(
//                           master?.rStatus ?? master?.status
//                         );

//                         return (
//                           <div key={rid} className="border">
//                             {/* master row */}
//                             <table
//                               className="table table-bordered mb-0"
//                               style={{ tableLayout: "auto", width: "100%" }}
//                             >
//                               <thead className="main_heading_table">
//                                 <tr>
//                                   <th>Request ID :</th>
//                                   <th
//                                     className={
//                                       pr === "Priority" ? "priClr" : "col-ad"
//                                     }
//                                   >
//                                     {rid}
//                                   </th>
//                                   <th>IP :</th>
//                                   <th className="col-ip">
//                                     {master?.IP ?? master?.ip ?? "-"}
//                                   </th>
//                                   <th>Added On :</th>
//                                   <th>{addedOn || "-"}</th>
//                                   <th>Submitted On :</th>
//                                   <th>{submittedOn || "-"}</th>
//                                   <th>No. Of Applicants :</th>
//                                   <th style={{ width: "60px" }}>
//                                     {master?.noOfUsr ??
//                                       master?.no_of_applicants ??
//                                       "-"}
//                                   </th>
//                                   <th>VAC :</th>
//                                   <th className="col-vac">
//                                     <div className="d-flex gap-2 align-items-center">
//                                       {vacName}
//                                       <FaEdit
//                                         style={{
//                                           color: "green",
//                                           fontSize: "0.8rem",
//                                         }}
//                                       />
//                                     </div>
//                                   </th>
//                                   <th>Priority :</th>
//                                   <th>{pr}</th>
//                                   <th>Status :</th>
//                                   <th className="col-status">{statusName}</th>
//                                   <th>
//                                     <button
//                                       className="btn-theam-filter"
//                                       onClick={() => toggleExpand(String(rid))}
//                                       title="Expand"
//                                     >
//                                       {expanded === String(rid) ? "▲" : "▼"}
//                                     </button>
//                                   </th>
//                                 </tr>
//                               </thead>
//                             </table>

//                             {/* detail table */}
//                             {expanded === String(rid) && (
//                               <table className="table table-bordered table-hover tableexpand">
//                                 <thead className="table-active tableexpand-head">
//                                   <tr>
//                                     <th>Full Name</th>
//                                     <th>Email Id</th>
//                                     <th>Passport Number</th>
//                                     <th>Nulla osta No</th>
//                                     <th>DOB</th>
//                                     <th>Issue Date</th>
//                                     <th>Submitted On</th>
//                                     <th>VAC</th>
//                                     <th>Appointment On</th>
//                                     <th>Status</th>
//                                     <th>Action</th>
//                                   </tr>
//                                 </thead>
//                                 <tbody>
//                                   {(() => {
//                                     const list = Array.isArray(details)
//                                       ? details
//                                       : details && typeof details === "object"
//                                       ? Object.values(details)
//                                       : [];

//                                     if (list.length === 0) {
//                                       return (
//                                         <tr>
//                                           <td
//                                             colSpan={11}
//                                             className="text-center text-muted"
//                                           >
//                                             No details available for this
//                                             request.
//                                           </td>
//                                         </tr>
//                                       );
//                                     }

//                                     return list.map((d, i) => {
//                                       const fullName = [
//                                         d?.fName ??
//                                           d?.first_name ??
//                                           d?.full_name?.split(" ")?.[0],
//                                         d?.lName ??
//                                           d?.last_name ??
//                                           (d?.full_name
//                                             ? d.full_name
//                                                 .split(" ")
//                                                 .slice(1)
//                                                 .join(" ")
//                                             : null),
//                                       ]
//                                         .filter(Boolean)
//                                         .join(" ");

//                                       return (
//                                         <tr key={`${rid}-detail-${i}`}>
//                                           <td>{fullName || "-"}</td>
//                                           <td>
//                                             {master?.mailId ??
//                                               master?.email ??
//                                               d?.email ??
//                                               "-"}
//                                           </td>
//                                           <td>
//                                             {d?.ppn ?? d?.passport_no ?? "-"}
//                                           </td>
//                                           <td>
//                                             {d?.wpn ?? d?.nulla_osta_no ?? "-"}
//                                           </td>
//                                           <td>{fmtDMY(d?.dob) || "-"}</td>
//                                           <td>
//                                             {fmtDMY(
//                                               d?.wpndt ?? d?.issue_date
//                                             ) || "-"}
//                                           </td>
//                                           <td>{submittedOn || "-"}</td>
//                                           <td>
//                                             {getVacName(
//                                               d?.vac ??
//                                                 master?.vac ??
//                                                 master?.vac_id
//                                             )}
//                                           </td>
//                                           <td>
//                                             {toISTString(
//                                               d?.slotAt ?? d?.appointment_on
//                                             ) || "-"}
//                                           </td>
//                                           <td>
//                                             {getStatusName(
//                                               d?.dtlStatus ??
//                                                 d?.status ??
//                                                 master?.status
//                                             )}
//                                           </td>
//                                           <td>
//                                             <button
//                                               className="btnlink"
//                                               onClick={() =>
//                                                 onView({ master, detail: d })
//                                               }
//                                             >
//                                               View
//                                             </button>
//                                           </td>
//                                         </tr>
//                                       );
//                                     });
//                                   })()}
//                                 </tbody>
//                               </table>
//                             )}
//                           </div>
//                         );
//                       })
//                     )}
//                   </div>

//                   {/* Pagination */}
//                   {total > 0 && (
//                     <div className="pagination-de">
//                       <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
//                         <button
//                           id="btnPrevious"
//                           className={`btn btn-sm ${
//                             currentPage === 1 ? "disabled" : ""
//                           }`}
//                           onClick={handlePrev}
//                         >
//                           Previous
//                         </button>

//                         {(() => {
//                           const totalPages = Math.max(
//                             1,
//                             Math.ceil(total / ITEMS_PER_PAGE)
//                           );
//                           const pages = getVisiblePages(
//                             currentPage,
//                             totalPages
//                           );
//                           const hasLeftEllipsis = pages[0] > 1;
//                           const hasRightEllipsis =
//                             pages[pages.length - 1] < totalPages;

//                           return (
//                             <>
//                               {hasLeftEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}

//                               {pages.map((p) => (
//                                 <button
//                                   key={p}
//                                   id={`btn${p}`}
//                                   className={`btn btn-sm ${
//                                     currentPage === p ? "active" : ""
//                                   }`}
//                                   onClick={() => fetchPage(p)}
//                                 >
//                                   {p}
//                                 </button>
//                               ))}

//                               {hasRightEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}
//                             </>
//                           );
//                         })()}

//                         <button
//                           id="btnNext"
//                           className={`btn btn-sm ${
//                             currentPage ===
//                             Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
//                               ? "disabled"
//                               : ""
//                           }`}
//                           onClick={handleNext}
//                         >
//                           Next
//                         </button>
//                       </div>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Modal */}
//       {show && activeRow && (
//         <CaseModal
//           key={String(getReqId(activeRow?.master))}
//           show={show}
//           onClose={() => setShow(false)}
//           row={activeRow}
//           documents={documents}
//           authData={authData}
//           statusOptions={statusOptions}
//         />
//       )}
//     </AjaxValidation>
//   );
// }

// import React, { useMemo, useState, useEffect } from "react";
// import Modal from "react-bootstrap/Modal";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import { BsCalendar2Check } from "react-icons/bs";
// import { FaEdit } from "react-icons/fa";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { searchCases, docHistory } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import * as XLSX from "xlsx";
// import excel from "../assets/excel.png";

// /* ===== Constants ===== */
// const ITEMS_PER_PAGE = 10;

// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];
// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];
// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// /* ===== Utils ===== */
// function toISTString(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
//   const ist = new Date(istMs);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yyyy = d.getFullYear();
//   return `${dd}/${mm}/${yyyy}`;
// }
// function getReqId(obj) {
//   return (
//     obj?.reqId ??
//     obj?.request_id ??
//     obj?.req_id ??
//     obj?.reqid ??
//     obj?.requestId ??
//     obj?.reqIdFk ??
//     obj?.reqid_fk ??
//     null
//   );
// }
// function getDtlId(obj) {
//   return obj?.dtlId ?? obj?.dtlid ?? obj?.dtl_id ?? null;
// }
// /** Accepts raw API response and returns { rows:[{master,details[]}], total } */
// function normalizeResponse(res) {
//   if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
//     const byReq = res.details.reduce((acc, d) => {
//       const k = String(getReqId(d) ?? "");
//       (acc[k] ||= []).push(d);
//       return acc;
//     }, {});
//     const rows = res.master.map((m) => {
//       const mk = String(getReqId(m) ?? "");
//       return { master: m, details: byReq[mk] || [] };
//     });
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (Array.isArray(res)) {
//     const rows = res.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   if (res && Array.isArray(res.master)) {
//     const rows = res.master.map((m) => ({
//       master: m,
//       details: m.details || [],
//     }));
//     return {
//       rows,
//       total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
//     };
//   }
//   if (res && Array.isArray(res.data)) {
//     const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
//     return { rows, total: rows.length };
//   }
//   return { rows: [], total: 0 };
// }

// function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
//   const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

//   // ---- helpers (same as before) ----
//   const det =
//     row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};
//   const dtlId = String(getDtlId(det) ?? "");
//   const fullName = [
//     det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
//     det?.lName ??
//       det?.last_name ??
//       (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
//   ]
//     .filter(Boolean)
//     .join(" ");

//   const email =
//     row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";
//   const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
//   const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";
//   const dob = fmtDMY(det?.dob);
//   const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);
//   const submittedOn =
//     row?.master?.submitOn ??
//     row?.master?.submitted_on ??
//     det?.submitted_on ??
//     "";

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const vacName = getVacName(
//     det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
//   );

//   const statusList =
//     (statusOptions && statusOptions.length
//       ? statusOptions
//       : authData?.ajaxPayload?.master_status_list) || [];

//   const [status, setStatus] = useState("");
//   const [reason, setReason] = useState("");
//   const [comments, setComments] = useState("");

//   function buildDocUrl(fileName) {
//     if (!fileName) return "";
//     if (!authData?.session_id || !authData?.document_key) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${authData.document_key}_${fileName}`;
//   }

//   const requestId = String(row ? getReqId(row.master) ?? "" : "");

//   // NOTE: type=2 → PASSPORT, type=1 → NULLA OSTA
//   function pickDocByDtlAndType(type) {
//     const list = Array.isArray(documents) ? documents : [];
//     return (
//       list.find(
//         (d) =>
//           String(d?.dtlId ?? d?.dtlid ?? d?.dtl_id) === dtlId &&
//           Number(d?.type) === Number(type)
//       ) || null
//     );
//   }

//   const passportDoc = pickDocByDtlAndType(2);
//   const nullaDoc = pickDocByDtlAndType(1);

//   // histories
//   const [passUsrActs, setPassUsrActs] = useState([]);
//   const [passCusActs, setPassCusActs] = useState([]);
//   const [nullaUsrActs, setNullaUsrActs] = useState([]);
//   const [nullaCusActs, setNullaCusActs] = useState([]);
//   const [hisLoading, setHisLoading] = useState(false);

//   const passportFile = passportDoc?.file ?? passportDoc?.file_name ?? null;
//   const nullaFile = nullaDoc?.file ?? nullaDoc?.file_name ?? null;

//   // current doc for left preview (tabs 'passport'/'nulla')
//   const activeDoc =
//     tab === "passport" ? passportDoc : tab === "nulla" ? nullaDoc : null;
//   const activeDocUrl =
//     tab === "passport"
//       ? buildDocUrl(passportFile)
//       : tab === "nulla"
//       ? buildDocUrl(nullaFile)
//       : "";

//   // current focused doc for HISTORY right-side preview
//   const [historyFocus, setHistoryFocus] = useState("passport"); // 'passport'|'nulla'
//   const historyPreviewUrl =
//     historyFocus === "passport"
//       ? buildDocUrl(passportFile)
//       : buildDocUrl(nullaFile);

//   // keep right panel values in sync with selected left-tab document
//   useEffect(() => {
//     if (!activeDoc) {
//       setStatus("");
//       setReason("");
//       setComments("");
//       return;
//     }
//     const docStatus = String(activeDoc?.docStatus ?? "");
//     const docReason = String(activeDoc?.reason ?? "");
//     const docRemarks =
//       String(activeDoc?.remarks ?? "") ||
//       (AUTO_COMMENTS[Number(docReason)] ?? "");
//     setStatus(docStatus);
//     setReason(docReason);
//     setComments(docRemarks);
//   }, [tab, documents, dtlId]); // eslint-disable-line

//   const getStatusName = (id) =>
//     statusList.find((s) => String(s.request_status_id) === String(id ?? ""))
//       ?.request_status_name || (id ? String(id) : "-");

//   function getReasonLabel(reasonId) {
//     const opts =
//       tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;
//     return (
//       opts.find((r) => String(r.id) === String(reasonId))?.label ||
//       (reasonId ? String(reasonId) : "-")
//     );
//   }

//   const whoChar = (entry) => {
//     if (entry?.file) return "Applicant";
//     const txt = String(entry?.remarks || "").toLowerCase();
//     if (txt.includes("system")) return "System";
//     return "Agent";
//   };
//   const fmtTime = (s) => toISTString(s) || "-";

//   // Pull activity when entering History
//   useEffect(() => {
//     let abort = false;

//     async function load(docId, setUsr, setCus) {
//       if (!docId) {
//         setUsr([]);
//         setCus([]);
//         return;
//       }
//       const payload = {
//         session_id: authData?.session_id,
//         sessionToken: authData?.session_token,
//         docId,
//       };
//       const res = await docHistory(payload);
//       if (abort) return;
//       setUsr(Array.isArray(res?.UsrActivity) ? res.UsrActivity : []);
//       setCus(Array.isArray(res?.CustActivity) ? res.CustActivity : []);
//     }

//     async function run() {
//       if (tab !== "history") return;
//       setHisLoading(true);
//       try {
//         await Promise.all([
//           load(
//             passportDoc?.docId ?? passportDoc?.id,
//             setPassUsrActs,
//             setPassCusActs
//           ),
//           load(
//             nullaDoc?.docId ?? nullaDoc?.id,
//             setNullaUsrActs,
//             setNullaCusActs
//           ),
//         ]);
//         // default focus to the first available doc
//         setHistoryFocus(passportDoc ? "passport" : "nulla");
//       } catch (e) {
//         console.error("DocDtls failed:", e);
//         setPassUsrActs([]);
//         setPassCusActs([]);
//         setNullaUsrActs([]);
//         setNullaCusActs([]);
//       } finally {
//         setHisLoading(false);
//       }
//     }
//     run();
//     return () => {
//       abort = true;
//     };
//   }, [
//     tab,
//     authData?.session_id,
//     authData?.session_token,
//     passportDoc?.docId,
//     passportDoc?.id,
//     nullaDoc?.docId,
//     nullaDoc?.id,
//   ]);

//   // Build rows for the two history tables.
//   // IMPORTANT: synthesize the first “Submitted” row from `documents` when CustActivity is empty.
//   function buildHistoryRows(kind) {
//     // kind: 'passport' | 'nulla'
//     const doc = kind === "passport" ? passportDoc : nullaDoc;
//     const usr = kind === "passport" ? passUsrActs : nullaUsrActs;
//     const cus = kind === "passport" ? passCusActs : nullaCusActs;

//     const rows = [];
//     let index = 1;

//     // 1) Submitted row (from CustActivity if present; otherwise from documents[] fallback)
//     if (Array.isArray(cus) && cus.length > 0) {
//       cus.forEach((c) => {
//         rows.push({
//           idx: index++,
//           action: "Submitted",
//           by: whoChar(c),
//           on: fmtTime(c.addOn),
//           file: c.file || "-",
//         });
//       });
//     } else if (doc?.file) {
//       // synthesize "Submitted" from SearchCases.documents
//       const when =
//         doc?.submitOn || submittedOn || doc?.verifyOn || row?.master?.addOn;
//       rows.push({
//         idx: index++,
//         action: "Submitted",
//         by: "Applicant",
//         on: fmtTime(when),
//         file: doc.file,
//       });
//     }

//     // 2) Agent/System updates (UsrActivity)
//     // (Array.isArray(usr) ? usr : []).forEach((u) => {
//     //   const label =
//     //     AUTO_COMMENTS[String(u.reason)] ||
//     //     String(u?.remarks || "").trim() ||
//     //     "Updated";
//     //   rows.push({
//     //     idx: index++,
//     //     action: label,
//     //     by: whoChar(u),
//     //     on: fmtTime(u.addOn),
//     //     file: "-", // updates don't carry a file
//     //   });
//     // });

//     return rows;
//   }

//   const passportRows = buildHistoryRows("passport");
//   const nullaRows = buildHistoryRows("nulla");

//   // status pill
//   const statusChip = (docStatus) => {
//     const code = String(docStatus || "");
//     const cls =
//       code === "6"
//         ? "text-success fw-semibold"
//         : code === "4"
//         ? "text-danger fw-semibold"
//         : "text-secondary";
//     return <span className={cls}>{getStatusName(code)}</span>;
//   };

//   return (
//     <Modal
//       show={show}
//       onHide={onClose}
//       backdrop="static"
//       keyboard={false}
//       className="newcase_modal-dialog"
//       size="xl"
//       centered
//     >
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
//         </Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="model_dialog_list">
//           <div className="row">
//             {/* LEFT */}
//             <div className="col-sm-8 border-right">
//               {/* tab buttons */}
//               <div className="mb-3 d-flex gap-1">
//                 <button
//                   className={`btn ${tab === "passport" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("passport")}
//                 >
//                   Passport Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "nulla" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("nulla")}
//                 >
//                   Nulla Osta Document
//                 </button>
//                 <button
//                   className={`btn ${tab === "history" ? "text-white" : ""}`}
//                   style={{
//                     backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
//                     fontSize: "0.8rem",
//                   }}
//                   onClick={() => setTab("history")}
//                 >
//                   Document History
//                 </button>
//               </div>

//               {tab !== "history" ? (
//                 <div
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {activeDocUrl ? (
//                     <iframe
//                       title="document-preview"
//                       src={activeDocUrl}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">File not found or inaccessible!</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="pdf_view tab_scroll">
//                   <style>{`
//                     .history_table>:not(caption)>*>*{border-width:0 1px!important;font-size:12px!important}
//                     .status-flex{display:flex;justify-content:space-between;align-items:center;text-align:center;padding:.5rem 1rem;border:1px solid #dee2e6;font-size:14px}
//                     .history-row{cursor:pointer}
//                   `}</style>

//                   {/* Passport Section */}
//                   <div
//                     className="status-flex"
//                     onClick={() => setHistoryFocus("passport")}
//                   >
//                     <div>
//                       Passport : <span>{passportNo || "-"}</span>
//                     </div>
//                     <div>Status : {statusChip(passportDoc?.docStatus)}</div>
//                   </div>

//                   <div className="table-responsive mt-2">
//                     <table className="table table-bordered history_table text-left">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Passport</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {hisLoading ? (
//                           <tr>
//                             <td colSpan={5}>Loading…</td>
//                           </tr>
//                         ) : passportRows.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           passportRows.map((r) => (
//                             <tr
//                               key={`pr-${r.idx}`}
//                               className="history-row"
//                               onClick={() => setHistoryFocus("passport")}
//                             >
//                               <td>{r.idx}</td>
//                               <td>{r.action}</td>
//                               <td>{r.by}</td>
//                               <td>{r.on}</td>
//                               <td>{r.file || "-"}</td>
//                             </tr>
//                           ))
//                         )}
//                       </tbody>
//                     </table>
//                   </div>

//                   {/* Nulla Osta Section */}
//                   <div
//                     className="status-flex mt-3"
//                     onClick={() => setHistoryFocus("nulla")}
//                   >
//                     <div>
//                       Nulla Osta : <span>{nullaOstaNo || "-"}</span>
//                     </div>
//                     <div>Status : {statusChip(nullaDoc?.docStatus)}</div>
//                   </div>

//                   <div className="table-responsive mt-2">
//                     <table className="table table-bordered history_table text-left">
//                       <thead className="table-active">
//                         <tr>
//                           <th>#</th>
//                           <th>Action</th>
//                           <th>Actioned By</th>
//                           <th>Actioned On</th>
//                           <th>Uploaded Nulla Osta</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {hisLoading ? (
//                           <tr>
//                             <td colSpan={5}>Loading…</td>
//                           </tr>
//                         ) : nullaRows.length === 0 ? (
//                           <tr>
//                             <td colSpan={5} className="text-muted">
//                               —
//                             </td>
//                           </tr>
//                         ) : (
//                           nullaRows.map((r) => (
//                             <tr
//                               key={`nr-${r.idx}`}
//                               className="history-row"
//                               onClick={() => setHistoryFocus("nulla")}
//                             >
//                               <td>{r.idx}</td>
//                               <td>{r.action}</td>
//                               <td>{r.by}</td>
//                               <td>{r.on}</td>
//                               <td>{r.file || "-"}</td>
//                             </tr>
//                           ))
//                         )}
//                       </tbody>
//                     </table>
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* RIGHT */}
//             <div className="col-sm-4">
//               {tab === "history" ? (
//                 <div
//                   className="img_view text-center"
//                   style={{
//                     height: "55vh",
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                     background: "#fff",
//                   }}
//                 >
//                   {historyPreviewUrl ? (
//                     <iframe
//                       title="history-preview"
//                       src={historyPreviewUrl}
//                       style={{ width: "100%", height: "100%", border: 0 }}
//                     />
//                   ) : (
//                     <div className="p-3">No file to preview.</div>
//                   )}
//                 </div>
//               ) : (
//                 <div className="accordion-body">
//                   <div className="form-group row">
//                     <div className="col-sm-12">
//                       <h6 className="modal-title mb-2">Customer Details :</h6>
//                     </div>
//                   </div>

//                   <div className="newcase-container">
//                     {[
//                       ["Issue Date", issueDate || "-"],
//                       ["Submited On", toISTString(submittedOn) || "-"],
//                       ["VAC", vacName],
//                       ["Full Name", fullName || "-"],
//                       ["Email Id", email || "-"],
//                       ["Passport Number", passportNo || "-"],
//                       ["Nulla osta No", nullaOstaNo || "-"],
//                       ["DOB", dob || "-"],
//                     ].map(([l, v], i) => (
//                       <div className="form-group row border-bottom" key={i}>
//                         <div className="col-sm-6">
//                           <label className="form-label">{l}</label>
//                         </div>
//                         <div className="col-sm-6">
//                           <label className="form-label">{v}</label>
//                         </div>
//                       </div>
//                     ))}

//                     {/* Status (read-only) */}
//                     <div className="form-group row border-bottom mb-2">
//                       <div className="col-sm-6">
//                         <label className="form-label">Status</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled
//                           value={status}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getStatusName(status)}</option>
//                           {statusList.map((s) => (
//                             <option
//                               key={s.request_status_id}
//                               value={s.request_status_id}
//                             >
//                               {s.request_status_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Reason (read-only) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-6">
//                         <label className="form-label">Reason</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <select
//                           className="form-select form-control"
//                           disabled
//                           value={reason}
//                           onChange={() => {}}
//                         >
//                           <option value="">{getReasonLabel(reason)}</option>
//                           {(tab === "passport"
//                             ? PASSPORT_REASON_OPTIONS
//                             : NULLA_REASON_OPTIONS
//                           ).map((r) => (
//                             <option key={r.id} value={r.id}>
//                               {r.label}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                     </div>

//                     {/* Comments (read-only) */}
//                     <div className="form-group row border-bottom">
//                       <div className="col-sm-12">
//                         <label className="form-label">Comments</label>
//                         <textarea
//                           className="form-control"
//                           rows={5}
//                           value={comments}
//                           onChange={() => {}}
//                           disabled
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* ========================== Main ========================== */
// export default function CaseList() {
//   const { authData } = useAuth();

//   // Filters
//   const [keyword, setKeyword] = useState("");
//   const [keyType, setKeyType] = useState("0");
//   const [dateType, setDateType] = useState("0");
//   const [vac, setVac] = useState("");
//   const [status, setStatus] = useState("0");
//   const [priority, setPriority] = useState("-1");

//   const [fromDate, setFromDate] = useState(null);
//   const [toDate, setToDate] = useState(null);

//   // Data/page
//   const [rows, setRows] = useState([]);
//   const [total, setTotal] = useState(0);
//   const [currentPage, setCurrentPage] = useState(1);
//   const [expanded, setExpanded] = useState(null);
//   const [loading, setLoading] = useState(false);

//   // Modal
//   const [show, setShow] = useState(false);
//   const [activeRow, setActiveRow] = useState(null);
//   const [documents, setDocuments] = useState([]);

//   const minDate = useMemo(() => new Date("2000-01-01"), []);
//   const maxDate = useMemo(() => new Date(), []);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const statusOptions = authData?.ajaxPayload?.master_status_list || [];

//   const getVacName = (id) =>
//     vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
//     id ||
//     "-";
//   const getStatusName = (id) =>
//     statusOptions.find((s) => String(s.request_status_id) === String(id))
//       ?.request_status_name ||
//     id ||
//     "-";

//   const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
//   const onView = (row) => {
//     setActiveRow(row);
//     setShow(true);
//   };

//   function validateFilters() {
//     if (keyword.trim() && +keyType === 0)
//       return { ok: false, msg: "Choose a Keyword type." };
//     return { ok: true };
//   }

//   function buildPayload(page = 1) {
//     let pKeyType = keyType,
//       pKeyword = keyword,
//       pDateType = dateType,
//       pVac = vac,
//       pStatus = status,
//       pPri = priority;

//     if (+pKeyType > 0) {
//       pDateType = "0";
//       pVac = "0";
//       pStatus = "0";
//       pPri = "-1";
//     }
//     if (+pDateType === 0 && (fromDate || toDate)) {
//       pDateType = "2";
//     }
//     const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

//     return {
//       session_id: authData.session_id,
//       sessionToken: authData.session_token,
//       keyword: pKeyword.trim(),
//       keyType: pKeyType,
//       dateType: pDateType,
//       vac: pVac || "0",
//       status: pStatus,
//       from: fromDate ? fromDate.toISOString().split("T")[0] : "",
//       to: toDate ? toDate.toISOString().split("T")[0] : "",
//       priority: pPri,
//       startRecord,
//       rows: 1,
//       caseList: 1,
//       allSts: 1,
//     };
//   }

//   async function fetchPage(page = 1) {
//     setLoading(true);
//     try {
//       const res = await searchCases(buildPayload(page));
//       const { rows: normalized, total } = normalizeResponse(res);
//       setRows(normalized);
//       setTotal(total || 0);
//       setDocuments(res?.documents || []);
//       setExpanded(null);
//       setCurrentPage(page);
//     } catch (e) {
//       console.error("searchCases failed:", e);
//       setRows([]);
//       setTotal(0);
//       setExpanded(null);
//       setDocuments([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     fetchPage(1);
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const handleSearch = async () => {
//     const v = validateFilters();
//     if (!v.ok) {
//       alert(v.msg);
//       return;
//     }
//     await fetchPage(1);
//   };
//   const handlePrev = () => currentPage > 1 && fetchPage(currentPage - 1);
//   const handleNext = () => {
//     const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//     if (currentPage < totalPages) fetchPage(currentPage + 1);
//   };

//   const handleExcel = async () => {
//     try {
//       const flat = [];
//       for (const { master, details } of rows) {
//         const vacName = getVacName(master?.vac ?? master?.vac_id);
//         const statusName = getStatusName(master?.rStatus ?? master?.status);
//         const submittedOn = toISTString(
//           master?.submitOn ?? master?.submitted_on
//         );
//         const detailList = details && details.length ? details : [null];
//         for (const d of detailList) {
//           const issueDate = fmtDMY(d?.wpndt ?? d?.issue_date);
//           const dob = fmtDMY(d?.dob);
//           flat.push({
//             RequestID: getReqId(master),
//             IP: master?.IP ?? master?.ip ?? "",
//             FullName: [d?.fName ?? d?.first_name, d?.lName ?? d?.last_name]
//               .filter(Boolean)
//               .join(" "),
//             EmailId: master?.mailId ?? master?.email ?? d?.email ?? "",
//             PassportNo: d?.ppn ?? d?.passport_no ?? "",
//             NullaOstaNo: d?.wpn ?? d?.nulla_osta_no ?? "",
//             DOB: dob,
//             IssueDate: issueDate,
//             SubmitedOn: submittedOn,
//             VAC: vacName,
//             Status: statusName,
//           });
//         }
//       }
//       const ws = XLSX.utils.json_to_sheet(flat);
//       const wb = XLSX.utils.book_new();
//       XLSX.utils.book_append_sheet(wb, ws, "Cases");
//       XLSX.writeFile(wb, "Cases.xlsx");
//     } catch (e) {
//       console.error("excel export failed:", e);
//       alert("Excel export failed.");
//     }
//   };

//   const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
//   const WINDOW = 4;

//   function range(start, end) {
//     return Array.from({ length: end - start + 1 }, (_, i) => start + i);
//   }
//   function getVisiblePages(current, total) {
//     if (total <= WINDOW) return range(1, total);
//     if (current <= WINDOW) return range(1, WINDOW);
//     if (current > total - WINDOW) return range(total - WINDOW + 1, total);
//     return range(current, current + WINDOW - 1);
//   }

//   return (
//     <AjaxValidation>
//       {/* Filters */}
//       <div className="mt-2">
//         <div className="container-fluid">
//           <h6>Case List</h6>

//           <div className="row mt-2 mb-3">
//             <div className="col-sm-12">
//               <div className="box_card">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <div className="main_agent_form">
//                       <div className="one">
//                         <input
//                           className="form-control"
//                           placeholder="Search"
//                           value={keyword}
//                           onChange={(e) => setKeyword(e.target.value)}
//                         />
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={keyType}
//                           onChange={(e) => setKeyType(e.target.value)}
//                         >
//                           <option value="0">--Keyword--</option>
//                           <option value="1">Email Id</option>
//                           <option value="2">Nulla Osta Reference Number</option>
//                           <option value="3">Passport Number</option>
//                           <option value="4">Mobile Number</option>
//                           <option value="5">Request Id</option>
//                           <option value="6">Name</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={fromDate}
//                             onChange={(d) => setFromDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="From Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <div
//                           className="input-group date_pick"
//                           style={{ flexWrap: "nowrap" }}
//                         >
//                           <DatePicker
//                             selected={toDate}
//                             onChange={(d) => setToDate(d)}
//                             className="form-control border_right_radius"
//                             placeholderText="To Date"
//                             dateFormat="dd-MM-yyyy"
//                             showMonthDropdown
//                             showYearDropdown
//                             dropdownMode="select"
//                             scrollableYearDropdown
//                             isClearable
//                             minDate={minDate}
//                             maxDate={maxDate}
//                           />
//                           <span className="input-group-text">
//                             <BsCalendar2Check />
//                           </span>
//                         </div>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={dateType}
//                           onChange={(e) => setDateType(e.target.value)}
//                         >
//                           <option value="0">--Date Type--</option>
//                           <option value="1">Added On</option>
//                           <option value="2">Submitted On</option>
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={vac}
//                           onChange={(e) => setVac(e.target.value)}
//                         >
//                           <option value="0">--Select VAC--</option>
//                           {vacOptions.map((v) => (
//                             <option key={v.vac_id} value={v.vac_id}>
//                               {v.vac_name}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={status}
//                           onChange={(e) => setStatus(e.target.value)}
//                         >
//                           <option value="0">--Select--</option>
//                           {statusOptions
//                             .filter((s) => Number(s.request_status_id) > 1)
//                             .map((s) => (
//                               <option
//                                 key={s.request_status_id}
//                                 value={s.request_status_id}
//                               >
//                                 {s.request_status_name}
//                               </option>
//                             ))}
//                         </select>
//                       </div>
//                       <div className="one">
//                         <select
//                           className="form-select form-control"
//                           value={priority}
//                           onChange={(e) => setPriority(e.target.value)}
//                         >
//                           <option value="-1">--Priority--</option>
//                           <option value="0">Normal</option>
//                           <option value="1">Priority</option>
//                         </select>
//                       </div>
//                       <div className="one gap-2">
//                         <button
//                           className="btn-lg go-btn"
//                           style={{ background: "#f26722", color: "#fff" }}
//                           onClick={handleSearch}
//                         >
//                           Search
//                         </button>
//                         <img
//                           src={excel}
//                           className="common_excell_icon"
//                           alt="Excel"
//                           onClick={handleExcel}
//                           style={{ width: "25px", cursor: "pointer" }}
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="dropdown-divider"></div>
//                 {/* Results */}
//                 <div className="">
//                   <div className="table-responsive holiday-container">
//                     {loading ? (
//                       <div className="p-3 text-center">
//                         <div
//                           style={{
//                             position: "fixed",
//                             inset: 0,
//                             background: "rgba(0,0,0,0.35)",
//                             zIndex: 1050,
//                             display: "grid",
//                             placeItems: "center",
//                           }}
//                         >
//                           <div
//                             className="spinner-border text-light"
//                             role="status"
//                           />
//                         </div>
//                       </div>
//                     ) : rows.length === 0 ? (
//                       <div className="p-3 text-center text-muted">
//                         No records found.
//                       </div>
//                     ) : (
//                       rows.map(({ master, details }, idx) => {
//                         const rid = getReqId(master) ?? String(idx);
//                         const addedOn = toISTString(
//                           master?.addOn ?? master?.added_on
//                         );
//                         const submittedOn = toISTString(
//                           master?.submitOn ?? master?.submitted_on
//                         );
//                         const pr =
//                           master?.priority === 1 || master?.priority === "1"
//                             ? "Priority"
//                             : "Normal";
//                         const vacName = getVacName(
//                           master?.vac ?? master?.vac_id
//                         );
//                         const statusName = getStatusName(
//                           master?.rStatus ?? master?.status
//                         );

//                         return (
//                           <div key={rid} className="border">
//                             {/* master row */}
//                             <table
//                               className="table table-bordered mb-0"
//                               style={{ tableLayout: "auto", width: "100%" }}
//                             >
//                               <thead className="main_heading_table">
//                                 <tr>
//                                   <th>Request ID :</th>
//                                   <th
//                                     className={
//                                       pr === "Priority" ? "priClr" : "col-ad"
//                                     }
//                                   >
//                                     {rid}
//                                   </th>
//                                   <th>IP :</th>
//                                   <th className="col-ip">
//                                     {master?.IP ?? master?.ip ?? "-"}
//                                   </th>
//                                   <th>Added On :</th>
//                                   <th>{addedOn || "-"}</th>
//                                   <th>Submitted On :</th>
//                                   <th>{submittedOn || "-"}</th>
//                                   <th>No. Of Applicants :</th>
//                                   <th style={{ width: "60px" }}>
//                                     {master?.noOfUsr ??
//                                       master?.no_of_applicants ??
//                                       "-"}
//                                   </th>
//                                   <th>VAC :</th>
//                                   <th className="col-vac">
//                                     <div className="d-flex gap-2 align-items-center">
//                                       {vacName}
//                                       <FaEdit
//                                         style={{
//                                           color: "green",
//                                           fontSize: "0.8rem",
//                                         }}
//                                       />
//                                     </div>
//                                   </th>
//                                   <th>Priority :</th>
//                                   <th>{pr}</th>
//                                   <th>Status :</th>
//                                   <th className="col-status">{statusName}</th>
//                                   <th>
//                                     <button
//                                       className="btn-theam-filter"
//                                       onClick={() => toggleExpand(String(rid))}
//                                       title="Expand"
//                                     >
//                                       {expanded === String(rid) ? "▲" : "▼"}
//                                     </button>
//                                   </th>
//                                 </tr>
//                               </thead>
//                             </table>

//                             {/* detail table */}
//                             {expanded === String(rid) && (
//                               <table className="table table-bordered table-hover tableexpand">
//                                 <thead className="table-active tableexpand-head">
//                                   <tr>
//                                     <th>Full Name</th>
//                                     <th>Email Id</th>
//                                     <th>Passport Number</th>
//                                     <th>Nulla osta No</th>
//                                     <th>DOB</th>
//                                     <th>Issue Date</th>
//                                     <th>Submitted On</th>
//                                     <th>VAC</th>
//                                     <th>Appointment On</th>
//                                     <th>Status</th>
//                                     <th>Action</th>
//                                   </tr>
//                                 </thead>
//                                 <tbody>
//                                   {(() => {
//                                     const list = Array.isArray(details)
//                                       ? details
//                                       : details && typeof details === "object"
//                                       ? Object.values(details)
//                                       : [];

//                                     if (list.length === 0) {
//                                       return (
//                                         <tr>
//                                           <td
//                                             colSpan={11}
//                                             className="text-center text-muted"
//                                           >
//                                             No details available for this
//                                             request.
//                                           </td>
//                                         </tr>
//                                       );
//                                     }

//                                     return list.map((d, i) => {
//                                       const fullName = [
//                                         d?.fName ??
//                                           d?.first_name ??
//                                           d?.full_name?.split(" ")?.[0],
//                                         d?.lName ??
//                                           d?.last_name ??
//                                           (d?.full_name
//                                             ? d.full_name
//                                                 .split(" ")
//                                                 .slice(1)
//                                                 .join(" ")
//                                             : null),
//                                       ]
//                                         .filter(Boolean)
//                                         .join(" ");

//                                       return (
//                                         <tr key={`${rid}-detail-${i}`}>
//                                           <td>{fullName || "-"}</td>
//                                           <td>
//                                             {master?.mailId ??
//                                               master?.email ??
//                                               d?.email ??
//                                               "-"}
//                                           </td>
//                                           <td>
//                                             {d?.ppn ?? d?.passport_no ?? "-"}
//                                           </td>
//                                           <td>
//                                             {d?.wpn ?? d?.nulla_osta_no ?? "-"}
//                                           </td>
//                                           <td>{fmtDMY(d?.dob) || "-"}</td>
//                                           <td>
//                                             {fmtDMY(
//                                               d?.wpndt ?? d?.issue_date
//                                             ) || "-"}
//                                           </td>
//                                           <td>
//                                             {toISTString(
//                                               master?.submitOn ??
//                                                 master?.submitted_on
//                                             ) || "-"}
//                                           </td>
//                                           <td>
//                                             {getVacName(
//                                               d?.vac ??
//                                                 master?.vac ??
//                                                 master?.vac_id
//                                             )}
//                                           </td>
//                                           <td>
//                                             {toISTString(
//                                               d?.slotAt ?? d?.appointment_on
//                                             ) || "-"}
//                                           </td>
//                                           <td>
//                                             {getStatusName(
//                                               d?.dtlStatus ??
//                                                 d?.status ??
//                                                 master?.status
//                                             )}
//                                           </td>
//                                           <td>
//                                             <button
//                                               className="btnlink"
//                                               onClick={() =>
//                                                 onView({ master, detail: d })
//                                               }
//                                             >
//                                               View
//                                             </button>
//                                           </td>
//                                         </tr>
//                                       );
//                                     });
//                                   })()}
//                                 </tbody>
//                               </table>
//                             )}
//                           </div>
//                         );
//                       })
//                     )}
//                   </div>

//                   {/* Pagination */}
//                   {total > 0 && (
//                     <div className="pagination-de">
//                       <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
//                         <button
//                           id="btnPrevious"
//                           className={`btn btn-sm ${
//                             currentPage === 1 ? "disabled" : ""
//                           }`}
//                           onClick={handlePrev}
//                         >
//                           Previous
//                         </button>

//                         {(() => {
//                           const totalPages = Math.max(
//                             1,
//                             Math.ceil(total / ITEMS_PER_PAGE)
//                           );
//                           const pages = getVisiblePages(
//                             currentPage,
//                             totalPages
//                           );
//                           const hasLeftEllipsis = pages[0] > 1;
//                           const hasRightEllipsis =
//                             pages[pages.length - 1] < totalPages;

//                           return (
//                             <>
//                               {hasLeftEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}

//                               {pages.map((p) => (
//                                 <button
//                                   key={p}
//                                   id={`btn${p}`}
//                                   className={`btn btn-sm ${
//                                     currentPage === p ? "active" : ""
//                                   }`}
//                                   onClick={() => fetchPage(p)}
//                                 >
//                                   {p}
//                                 </button>
//                               ))}

//                               {hasRightEllipsis && (
//                                 <span className="px-1">…</span>
//                               )}
//                             </>
//                           );
//                         })()}

//                         <button
//                           id="btnNext"
//                           className={`btn btn-sm ${
//                             currentPage ===
//                             Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
//                               ? "disabled"
//                               : ""
//                           }`}
//                           onClick={handleNext}
//                         >
//                           Next
//                         </button>
//                       </div>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Modal */}
//       {show && activeRow && (
//         <CaseModal
//           key={String(getReqId(activeRow?.master))}
//           show={show}
//           onClose={() => setShow(false)}
//           row={activeRow}
//           documents={documents}
//           authData={authData}
//           statusOptions={statusOptions}
//         />
//       )}
//     </AjaxValidation>
//   );
// }

// src/pages/CaseList.jsx
import React, { useEffect, useMemo, useState } from "react";
import Modal from "react-bootstrap/Modal";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { BsCalendar2Check } from "react-icons/bs";
import { FaEdit } from "react-icons/fa";
import AjaxValidation from "../hooks/AjaxValidation";
import { searchCases, docHistory } from "../api/client";
import { useAuth } from "../context/AuthContext";
import * as XLSX from "xlsx";
import excel from "../assets/excel.png";

/* ===== Constants ===== */
const ITEMS_PER_PAGE = 10;

const PASSPORT_REASON_OPTIONS = [
  { id: 16, label: "NOT ELIGIBLE" },
  { id: 17, label: "DOCUMENT NOT CLEAR" },
  { id: 19, label: "DETAILS MISMATCH" },
  { id: 21, label: "DUPLICATE ENTRY" },
  { id: 22, label: "EXPIRED PASSPORT" },
  { id: 23, label: "INCOMPLETE PASSPORT" },
  { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
];
const NULLA_REASON_OPTIONS = [
  { id: 1, label: "NOT ELIGIBLE" },
  { id: 2, label: "NOT A NULLA OSTA" },
  { id: 3, label: "DOCUMENT NOT CLEAR" },
  { id: 4, label: "INCOMPLETE DOCUMENT" },
  { id: 5, label: "INVALID DATE OF ISSUE" },
  { id: 6, label: "DETAILS MISMATCH" },
  { id: 7, label: "BLOCKED ISSUE DATE" },
  { id: 8, label: "DUPLICATE ENTRY" },
];
const AUTO_COMMENTS = {
  1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
  2: "Not a Nulla Osta",
  3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
  4: "Nulla osta uploaded is not complete",
  5: "The date of issue is not correct for the attached Nulla Osta.",
  6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
  7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
  8: "The Nulla Osta and Passport have already been submitted for appointment",
  16: "NOT ELIGIBLE",
  17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
  18: "Document uploaded is not matching the format of a Passport",
  19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
  20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
  21: "The Nulla Osta and Passport have already been submitted for appointment",
  22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
  23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
  24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
  25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
  26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
};

/* ===== Utils ===== */
function toISTString(dateLike) {
  if (!dateLike) return "";
  if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
  const d = new Date(dateLike);
  if (Number.isNaN(d.getTime())) return "";
  const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
  const ist = new Date(istMs);
  const dd = String(ist.getDate()).padStart(2, "0");
  const mm = String(ist.getMonth() + 1).padStart(2, "0");
  const yyyy = ist.getFullYear();
  const hh = String(ist.getHours()).padStart(2, "0");
  const mi = String(ist.getMinutes()).padStart(2, "0");
  return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
}
function fmtDMY(dateLike) {
  if (!dateLike) return "";
  if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
  const d = new Date(dateLike);
  if (Number.isNaN(d.getTime())) return "";
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}
function getReqId(obj) {
  return (
    obj?.reqId ??
    obj?.request_id ??
    obj?.req_id ??
    obj?.reqid ??
    obj?.requestId ??
    obj?.reqIdFk ??
    obj?.reqid_fk ??
    null
  );
}
function getDtlId(obj) {
  return obj?.dtlId ?? obj?.dtlid ?? obj?.dtl_id ?? null;
}
/** Accepts raw API response and returns { rows:[{master,details[]}], total } */
function normalizeResponse(res) {
  if (res && Array.isArray(res.master) && Array.isArray(res.details)) {
    const byReq = res.details.reduce((acc, d) => {
      const k = String(getReqId(d) ?? "");
      (acc[k] ||= []).push(d);
      return acc;
    }, {});
    const rows = res.master.map((m) => {
      const mk = String(getReqId(m) ?? "");
      return { master: m, details: byReq[mk] || [] };
    });
    return {
      rows,
      total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
    };
  }
  if (Array.isArray(res)) {
    const rows = res.map((m) => ({ master: m, details: m.details || [] }));
    return { rows, total: rows.length };
  }
  if (res && Array.isArray(res.master)) {
    const rows = res.master.map((m) => ({
      master: m,
      details: m.details || [],
    }));
    return {
      rows,
      total: res.totalRows ?? res.total_rows ?? res.total ?? rows.length,
    };
  }
  if (res && Array.isArray(res.data)) {
    const rows = res.data.map((m) => ({ master: m, details: m.details || [] }));
    return { rows, total: rows.length };
  }
  return { rows: [], total: 0 };
}

/* ========================== Case Modal ========================== */
function CaseModal({ show, onClose, row, documents, authData, statusOptions }) {
  const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

  // ---- selected applicant (dtl) ----
  const det =
    row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};
  const dtlId = String(getDtlId(det) ?? "");
  const requestId = String(row ? getReqId(row.master) ?? "" : "");

  // ---- right pane read-only info ----
  const fullName = [
    det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
    det?.lName ??
      det?.last_name ??
      (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
  ]
    .filter(Boolean)
    .join(" ");
  const email =
    row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";
  const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
  const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";
  const dob = fmtDMY(det?.dob);
  const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);
  const submittedOn =
    row?.master?.submitOn ??
    row?.master?.submitted_on ??
    det?.submitted_on ??
    "";

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const getVacName = (id) =>
    vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
    id ||
    "-";
  const vacName = getVacName(
    det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
  );

  const statusList =
    (statusOptions && statusOptions.length
      ? statusOptions
      : authData?.ajaxPayload?.master_status_list) || [];

  const [status, setStatus] = useState("");
  const [reason, setReason] = useState("");
  const [comments, setComments] = useState("");

  /** Build preview URL using session_id + ajaxPayload.document_key + fileName */
  function buildDocUrl(fileName) {
    if (!fileName) return "";
    const sessionId = authData?.session_id;
    const documentKey = authData?.ajaxPayload?.document_key;
    if (!sessionId || !documentKey) return "";
    return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${sessionId}_${documentKey}_${fileName}`;
  }
  console.log(buildDocUrl);
  // IMPORTANT: Filter ALL modal docs to the current applicant (by dtlId)
  const docsForDtl = useMemo(() => {
    const list = Array.isArray(documents) ? documents : [];
    return list.filter((d) => String(d?.dtlId ?? d?.dtl_id) === dtlId);
  }, [documents, dtlId]);

  // NOTE: API uses: type 2 → Passport, type 1 → Nulla Osta
  function pickDocByType(type) {
    return docsForDtl.find((d) => Number(d?.type) === Number(type)) || null;
  }

  const passportDoc = pickDocByType(2);
  const nullaDoc = pickDocByType(1);

  const passportFile = passportDoc?.file ?? passportDoc?.file_name ?? null;
  const nullaFile = nullaDoc?.file ?? nullaDoc?.file_name ?? null;

  // left preview (on passport/nulla tabs)
  const activeDoc =
    tab === "passport" ? passportDoc : tab === "nulla" ? nullaDoc : null;

  const activeDocUrl =
    tab === "passport"
      ? buildDocUrl(passportFile)
      : tab === "nulla"
      ? buildDocUrl(nullaFile)
      : "";

  // keep right panel selects in sync with selected doc
  useEffect(() => {
    if (!activeDoc) {
      setStatus("");
      setReason("");
      setComments("");
      return;
    }
    const docStatus = String(activeDoc?.docStatus ?? "");
    const docReason = String(activeDoc?.reason ?? "");
    const docRemarks =
      String(activeDoc?.remarks ?? "") ||
      (AUTO_COMMENTS[Number(docReason)] ?? "");
    setStatus(docStatus);
    setReason(docReason);
    setComments(docRemarks);
  }, [tab, activeDoc, docsForDtl]);

  const getStatusName = (id) =>
    statusList.find((s) => String(s.request_status_id) === String(id ?? ""))
      ?.request_status_name || (id ? String(id) : "-");

  function getReasonLabel(reasonId) {
    const opts =
      tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;
    return (
      opts.find((r) => String(r.id) === String(reasonId))?.label ||
      (reasonId ? String(reasonId) : "-")
    );
  }

  const whoChar = (entry) => {
    if (entry?.file) return "Applicant";
    const txt = String(entry?.remarks || "").toLowerCase();
    if (txt.includes("system")) return "System";
    return "Agent";
  };
  const fmtTime = (s) => toISTString(s) || "-";

  // ===== History (only for this applicant's docs; uses their docIds) =====
  const [historyFocus, setHistoryFocus] = useState("nulla"); // 'passport' | 'nulla'
  const [historyOverrideFile, setHistoryOverrideFile] = useState(null);
  const [passUsrActs, setPassUsrActs] = useState([]);
  const [passCusActs, setPassCusActs] = useState([]);
  const [nullaUsrActs, setNullaUsrActs] = useState([]);
  const [nullaCusActs, setNullaCusActs] = useState([]);
  const [hisLoading, setHisLoading] = useState(false);

  useEffect(() => {
    let abort = false;
    async function load(docId, setUsr, setCus) {
      if (!docId) {
        setUsr([]);
        setCus([]);
        return;
      }
      const payload = {
        session_id: authData?.session_id,
        sessionToken: authData?.session_token,
        docId,
      };
      const res = await docHistory(payload);
      if (abort) return;
      setUsr(Array.isArray(res?.UsrActivity) ? res.UsrActivity : []);
      setCus(Array.isArray(res?.CustActivity) ? res.CustActivity : []);
    }
    async function run() {
      if (tab !== "history") return;
      setHisLoading(true);
      try {
        setHistoryFocus("nulla");
        setHistoryOverrideFile(null);
        await Promise.all([
          load(
            passportDoc?.docId ?? passportDoc?.id,
            setPassUsrActs,
            setPassCusActs
          ),
          load(
            nullaDoc?.docId ?? nullaDoc?.id,
            setNullaUsrActs,
            setNullaCusActs
          ),
        ]);
      } finally {
        setHisLoading(false);
      }
    }
    run();
    return () => {
      abort = true;
    };
  }, [
    tab,
    authData?.session_id,
    authData?.session_token,
    passportDoc?.docId,
    passportDoc?.id,
    nullaDoc?.docId,
    nullaDoc?.id,
  ]);

  function buildHistoryRows(kind) {
    const usr = kind === "passport" ? passUsrActs : nullaUsrActs;
    const cus = kind === "passport" ? passCusActs : nullaCusActs;
    const docFile = kind === "passport" ? passportFile : nullaFile;
    const rows = [];
    let index = 1;

    if (Array.isArray(cus) && cus.length > 0) {
      cus.forEach((c) => {
        rows.push({
          idx: index++,
          action: "Submitted",
          by: whoChar(c),
          on: fmtTime(c.addOn),
          file: c.file || "-",
        });
      });
    } else if (docFile) {
      rows.push({
        idx: index++,
        action: "Submitted",
        by: "Applicant",
        on:
          fmtTime(
            (kind === "passport"
              ? passportDoc?.submitOn
              : nullaDoc?.submitOn) ?? submittedOn
          ) || "-",
        file: docFile,
      });
    }

    // If you ever want Agent/System updates too, map `usr` here.
    return rows;
  }

  const passportRows = buildHistoryRows("passport");
  const nullaRows = buildHistoryRows("nulla");

  const statusChip = (docStatus) => {
    const code = String(docStatus || "");
    const cls =
      code === "6"
        ? "text-success fw-semibold"
        : code === "4"
        ? "text-danger fw-semibold"
        : "text-secondary";
    return <span className={cls}>{getStatusName(code)}</span>;
  };

  const historyPreviewUrl = useMemo(() => {
    const fallback = historyFocus === "passport" ? passportFile : nullaFile;
    const fileToShow = historyOverrideFile || fallback;
    return buildDocUrl(fileToShow);
  }, [historyFocus, historyOverrideFile, passportFile, nullaFile]);

  return (
    <Modal
      show={show}
      onHide={onClose}
      backdrop="static"
      keyboard={false}
      className="newcase_modal-dialog"
      size="xl"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title>
          <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="model_dialog_list">
          <div className="row">
            {/* LEFT */}
            <div className="col-sm-8 border-right">
              <div className="mb-3 d-flex gap-1">
                <button
                  className={`btn ${tab === "passport" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
                    fontSize: "0.8rem",
                  }}
                  onClick={() => setTab("passport")}
                >
                  Passport Document
                </button>
                <button
                  className={`btn ${tab === "nulla" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
                    fontSize: "0.8rem",
                  }}
                  onClick={() => setTab("nulla")}
                >
                  Nulla Osta Document
                </button>
                <button
                  className={`btn ${tab === "history" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
                    fontSize: "0.8rem",
                  }}
                  onClick={() => setTab("history")}
                >
                  Document History
                </button>
              </div>

              {tab !== "history" ? (
                <div
                  style={{
                    height: "55vh",
                    border: "1px solid #ddd",
                    borderRadius: 6,
                    overflow: "hidden",
                    background: "#fff",
                  }}
                >
                  {activeDocUrl ? (
                    <iframe
                      title="document-preview"
                      src={activeDocUrl}
                      style={{ width: "100%", height: "100%", border: 0 }}
                    />
                  ) : (
                    <div className="p-3">File not found or inaccessible!</div>
                  )}
                </div>
              ) : (
                <div className="pdf_view tab_scroll">
                  <style>{`
                    .history_table>:not(caption)>*>*{border-width:0 1px!important;font-size:12px!important}
                    .status-flex{display:flex;justify-content:space-between;align-items:center;text-align:center;padding:.5rem 1rem;border:1px solid #dee2e6;font-size:14px}
                    .history-row{cursor:pointer}
                    .clickable{cursor:pointer;text-decoration:underline}
                  `}</style>

                  {/* Passport Section (click anywhere in the header to focus right preview) */}
                  <div
                    className="status-flex"
                    onClick={() => {
                      setHistoryFocus("passport");
                      setHistoryOverrideFile(null);
                    }}
                  >
                    <div>
                      Passport : <span>{passportNo || "-"}</span>
                    </div>
                    <div>Status : {statusChip(passportDoc?.docStatus)}</div>
                  </div>

                  <div className="table-responsive mt-2">
                    <table className="table table-bordered history_table text-left">
                      <thead className="table-active">
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Actioned By</th>
                          <th>Actioned On</th>
                          <th>Uploaded Passport</th>
                        </tr>
                      </thead>
                      <tbody>
                        {hisLoading ? (
                          <tr>
                            <td colSpan={5}>Loading…</td>
                          </tr>
                        ) : passportRows.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-muted">
                              —
                            </td>
                          </tr>
                        ) : (
                          passportRows.map((r) => (
                            <tr
                              key={`pr-${r.idx}`}
                              className="history-row"
                              onClick={() => {
                                setHistoryFocus("passport");
                                if (r.file && r.file !== "-")
                                  setHistoryOverrideFile(r.file);
                              }}
                            >
                              <td>{r.idx}</td>
                              <td>{r.action}</td>
                              <td>{r.by}</td>
                              <td>{r.on}</td>
                              <td className="clickable">{r.file || "-"}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Nulla Osta Section */}
                  <div
                    className="status-flex mt-3"
                    onClick={() => {
                      setHistoryFocus("nulla");
                      setHistoryOverrideFile(null);
                    }}
                  >
                    <div>
                      Nulla Osta : <span>{nullaOstaNo || "-"}</span>
                    </div>
                    <div>Status : {statusChip(nullaDoc?.docStatus)}</div>
                  </div>

                  <div className="table-responsive mt-2">
                    <table className="table table-bordered history_table text-left">
                      <thead className="table-active">
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Actioned By</th>
                          <th>Actioned On</th>
                          <th>Uploaded Nulla Osta</th>
                        </tr>
                      </thead>
                      <tbody>
                        {hisLoading ? (
                          <tr>
                            <td colSpan={5}>Loading…</td>
                          </tr>
                        ) : nullaRows.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-muted">
                              —
                            </td>
                          </tr>
                        ) : (
                          nullaRows.map((r) => (
                            <tr
                              key={`nr-${r.idx}`}
                              className="history-row"
                              onClick={() => {
                                setHistoryFocus("nulla");
                                if (r.file && r.file !== "-")
                                  setHistoryOverrideFile(r.file);
                              }}
                            >
                              <td>{r.idx}</td>
                              <td>{r.action}</td>
                              <td>{r.by}</td>
                              <td>{r.on}</td>
                              <td className="clickable">{r.file || "-"}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* RIGHT */}
            <div className="col-sm-4">
              {tab === "history" ? (
                <div
                  className="img_view text-center"
                  style={{
                    height: "55vh",
                    border: "1px solid #ddd",
                    borderRadius: 6,
                    overflow: "hidden",
                    background: "#fff",
                  }}
                >
                  {historyPreviewUrl ? (
                    <iframe
                      title="history-preview"
                      src={historyPreviewUrl}
                      style={{ width: "100%", height: "100%", border: 0 }}
                    />
                  ) : (
                    <div className="p-3">No file to preview.</div>
                  )}
                </div>
              ) : (
                <div className="accordion-body">
                  <div className="form-group row">
                    <div className="col-sm-12">
                      <h6 className="modal-title mb-2">Customer Details :</h6>
                    </div>
                  </div>

                  <div className="newcase-container">
                    {[
                      ["Issue Date", issueDate || "-"],
                      ["Submited On", toISTString(submittedOn) || "-"],
                      ["VAC", vacName],
                      ["Full Name", fullName || "-"],
                      ["Email Id", email || "-"],
                      ["Passport Number", passportNo || "-"],
                      ["Nulla osta No", nullaOstaNo || "-"],
                      ["DOB", dob || "-"],
                    ].map(([l, v], i) => (
                      <div className="form-group row border-bottom" key={i}>
                        <div className="col-sm-6">
                          <label className="form-label">{l}</label>
                        </div>
                        <div className="col-sm-6">
                          <label className="form-label">{v}</label>
                        </div>
                      </div>
                    ))}

                    {/* Status (read-only) */}
                    <div className="form-group row border-bottom mb-2">
                      <div className="col-sm-6">
                        <label className="form-label">Status</label>
                      </div>
                      <div className="col-sm-6">
                        <select
                          className="form-select form-control"
                          disabled
                          value={status}
                          onChange={() => {}}
                        >
                          <option value="">{getStatusName(status)}</option>
                          {statusList.map((s) => (
                            <option
                              key={s.request_status_id}
                              value={s.request_status_id}
                            >
                              {s.request_status_name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Reason (read-only) */}
                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label className="form-label">Reason</label>
                      </div>
                      <div className="col-sm-6">
                        <select
                          className="form-select form-control"
                          disabled
                          value={reason}
                          onChange={() => {}}
                        >
                          <option value="">{getReasonLabel(reason)}</option>
                          {(tab === "passport"
                            ? PASSPORT_REASON_OPTIONS
                            : NULLA_REASON_OPTIONS
                          ).map((r) => (
                            <option key={r.id} value={r.id}>
                              {r.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Comments (read-only) */}
                    <div className="form-group row border-bottom">
                      <div className="col-sm-12">
                        <label className="form-label">Comments</label>
                        <textarea
                          className="form-control"
                          rows={5}
                          value={comments}
                          onChange={() => {}}
                          disabled
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

/* ========================== Main ========================== */
export default function CaseList() {
  const { authData } = useAuth();

  // Filters
  const [keyword, setKeyword] = useState("");
  const [keyType, setKeyType] = useState("0");
  const [dateType, setDateType] = useState("0");
  const [vac, setVac] = useState("");
  const [status, setStatus] = useState("0");
  const [priority, setPriority] = useState("-1");

  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);

  // Data/page
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [expanded, setExpanded] = useState(null);
  const [loading, setLoading] = useState(false);

  // Modal
  const [show, setShow] = useState(false);
  const [activeRow, setActiveRow] = useState(null);

  // Store all docs from search once; pass filtered to modal (by dtlId there)
  const [documents, setDocuments] = useState([]);

  const minDate = useMemo(() => new Date("2000-01-01"), []);
  const maxDate = useMemo(() => new Date(), []);

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const statusOptions = authData?.ajaxPayload?.master_status_list || [];

  const getVacName = (id) =>
    vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
    id ||
    "-";
  const getStatusName = (id) =>
    statusOptions.find((s) => String(s.request_status_id) === String(id))
      ?.request_status_name ||
    id ||
    "-";

  const toggleExpand = (id) => setExpanded((p) => (p === id ? null : id));
  const onView = (row) => {
    setActiveRow(row);
    setShow(true);
  };

  function validateFilters() {
    if (keyword.trim() && +keyType === 0)
      return { ok: false, msg: "Choose a Keyword type." };
    return { ok: true };
  }

  function buildPayload(page = 1) {
    let pKeyType = keyType,
      pKeyword = keyword,
      pDateType = dateType,
      pVac = vac,
      pStatus = status,
      pPri = priority;

    if (+pKeyType > 0) {
      pDateType = "0";
      pVac = "0";
      pStatus = "0";
      pPri = "-1";
    }
    if (+pDateType === 0 && (fromDate || toDate)) {
      pDateType = "2";
    }
    const startRecord = (page - 1) * ITEMS_PER_PAGE + 1;

    return {
      session_id: authData.session_id,
      sessionToken: authData.session_token,
      keyword: pKeyword.trim(),
      keyType: pKeyType,
      dateType: pDateType,
      vac: pVac || "0",
      status: pStatus,
      from: fromDate ? fromDate.toISOString().split("T")[0] : "",
      to: toDate ? toDate.toISOString().split("T")[0] : "",
      priority: pPri,
      startRecord,
      rows: ITEMS_PER_PAGE,
      caseList: 1,
      allSts: 1,
    };
  }

  async function fetchPage(page = 1) {
    setLoading(true);
    try {
      const res = await searchCases(buildPayload(page));
      const { rows: normalized, total } = normalizeResponse(res);
      setRows(normalized);
      setTotal(total || 0);
      setDocuments(res?.documents || []);
      setExpanded(null);
      setCurrentPage(page);
    } catch (e) {
      console.error("searchCases failed:", e);
      setRows([]);
      setTotal(0);
      setExpanded(null);
      setDocuments([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchPage(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSearch = async () => {
    const v = validateFilters();
    if (!v.ok) {
      alert(v.msg);
      return;
    }
    await fetchPage(1);
  };
  const handlePrev = () => currentPage > 1 && fetchPage(currentPage - 1);
  const handleNext = () => {
    const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
    if (currentPage < totalPages) fetchPage(currentPage + 1);
  };

  const handleExcel = async () => {
    try {
      const flat = [];
      for (const { master, details } of rows) {
        const vacName = getVacName(master?.vac ?? master?.vac_id);
        const statusName = getStatusName(master?.rStatus ?? master?.status);
        const submittedOn = toISTString(
          master?.submitOn ?? master?.submitted_on
        );
        const detailList = details && details.length ? details : [null];
        for (const d of detailList) {
          const issueDate = fmtDMY(d?.wpndt ?? d?.issue_date);
          const dob = fmtDMY(d?.dob);
          flat.push({
            RequestID: getReqId(master),
            IP: master?.IP ?? master?.ip ?? "",
            FullName: [d?.fName ?? d?.first_name, d?.lName ?? d?.last_name]
              .filter(Boolean)
              .join(" "),
            EmailId: master?.mailId ?? master?.email ?? d?.email ?? "",
            PassportNo: d?.ppn ?? d?.passport_no ?? "",
            NullaOstaNo: d?.wpn ?? d?.nulla_osta_no ?? "",
            DOB: dob,
            IssueDate: issueDate,
            SubmitedOn: submittedOn,
            VAC: vacName,
            Status: statusName,
          });
        }
      }
      const ws = XLSX.utils.json_to_sheet(flat);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Cases");
      XLSX.writeFile(wb, "Cases.xlsx");
    } catch (e) {
      console.error("excel export failed:", e);
      alert("Excel export failed.");
    }
  };

  const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
  const WINDOW = 4;

  function range(start, end) {
    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  }
  function getVisiblePages(current, total) {
    if (total <= WINDOW) return range(1, total);
    if (current <= WINDOW) return range(1, WINDOW);
    if (current > total - WINDOW) return range(total - WINDOW + 1, total);
    return range(current, current + WINDOW - 1);
  }

  return (
    <AjaxValidation>
      {/* Filters */}
      <div className="mt-2">
        <div className="container-fluid">
          <h6>Case List</h6>

          <div className="row mt-2 mb-3">
            <div className="col-sm-12">
              <div className="box_card">
                <div className="form-group row">
                  <div className="col-sm-12">
                    <div className="main_agent_form">
                      <div className="one">
                        <input
                          className="form-control"
                          placeholder="Search"
                          value={keyword}
                          onChange={(e) => setKeyword(e.target.value)}
                        />
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={keyType}
                          onChange={(e) => setKeyType(e.target.value)}
                        >
                          <option value="0">--Keyword--</option>
                          <option value="1">Email Id</option>
                          <option value="2">Nulla Osta Reference Number</option>
                          <option value="3">Passport Number</option>
                          <option value="4">Mobile Number</option>
                          <option value="5">Request Id</option>
                          <option value="6">Name</option>
                        </select>
                      </div>
                      <div className="one">
                        <div
                          className="input-group date_pick"
                          style={{ flexWrap: "nowrap" }}
                        >
                          <DatePicker
                            selected={fromDate}
                            onChange={(d) => setFromDate(d)}
                            className="form-control border_right_radius"
                            placeholderText="From Date"
                            dateFormat="dd-MM-yyyy"
                            showMonthDropdown
                            showYearDropdown
                            dropdownMode="select"
                            scrollableYearDropdown
                            isClearable
                            minDate={minDate}
                            maxDate={maxDate}
                          />
                          <span className="input-group-text">
                            <BsCalendar2Check />
                          </span>
                        </div>
                      </div>
                      <div className="one">
                        <div
                          className="input-group date_pick"
                          style={{ flexWrap: "nowrap" }}
                        >
                          <DatePicker
                            selected={toDate}
                            onChange={(d) => setToDate(d)}
                            className="form-control border_right_radius"
                            placeholderText="To Date"
                            dateFormat="dd-MM-yyyy"
                            showMonthDropdown
                            showYearDropdown
                            dropdownMode="select"
                            scrollableYearDropdown
                            isClearable
                            minDate={minDate}
                            maxDate={maxDate}
                          />
                          <span className="input-group-text">
                            <BsCalendar2Check />
                          </span>
                        </div>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={dateType}
                          onChange={(e) => setDateType(e.target.value)}
                        >
                          <option value="0">--Date Type--</option>
                          <option value="1">Added On</option>
                          <option value="2">Submitted On</option>
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={vac}
                          onChange={(e) => setVac(e.target.value)}
                        >
                          <option value="0">--Select VAC--</option>
                          {(authData?.ajaxPayload?.vac_list || []).map((v) => (
                            <option key={v.vac_id} value={v.vac_id}>
                              {v.vac_name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={status}
                          onChange={(e) => setStatus(e.target.value)}
                        >
                          <option value="0">--Select--</option>
                          {(authData?.ajaxPayload?.master_status_list || [])
                            .filter((s) => Number(s.request_status_id) > 1)
                            .map((s) => (
                              <option
                                key={s.request_status_id}
                                value={s.request_status_id}
                              >
                                {s.request_status_name}
                              </option>
                            ))}
                        </select>
                      </div>
                      <div className="one">
                        <select
                          className="form-select form-control"
                          value={priority}
                          onChange={(e) => setPriority(e.target.value)}
                        >
                          <option value="-1">--Priority--</option>
                          <option value="0">Normal</option>
                          <option value="1">Priority</option>
                        </select>
                      </div>
                      <div className="one gap-2">
                        <button
                          className="btn-lg go-btn"
                          style={{ background: "#f26722", color: "#fff" }}
                          onClick={handleSearch}
                        >
                          Search
                        </button>
                        <img
                          src={excel}
                          className="common_excell_icon"
                          alt="Excel"
                          onClick={handleExcel}
                          style={{ width: "25px", cursor: "pointer" }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="dropdown-divider"></div>

                {/* Results */}
                <div className="">
                  <div className="table-responsive holiday-container">
                    {loading ? (
                      <div className="p-3 text-center">
                        <div
                          style={{
                            position: "fixed",
                            inset: 0,
                            background: "rgba(0,0,0,0.35)",
                            zIndex: 1050,
                            display: "grid",
                            placeItems: "center",
                          }}
                        >
                          <div
                            className="spinner-border text-light"
                            role="status"
                          />
                        </div>
                      </div>
                    ) : rows.length === 0 ? (
                      <div className="p-3 text-center text-muted">
                        No records found.
                      </div>
                    ) : (
                      rows.map(({ master, details }, idx) => {
                        const rid = getReqId(master) ?? String(idx);
                        const addedOn = toISTString(
                          master?.addOn ?? master?.added_on
                        );
                        const submittedOn = toISTString(
                          master?.submitOn ?? master?.submitted_on
                        );
                        const pr =
                          master?.priority === 1 || master?.priority === "1"
                            ? "Priority"
                            : "Normal";
                        const vacName = getVacName(
                          master?.vac ?? master?.vac_id
                        );
                        const statusName = getStatusName(
                          master?.rStatus ?? master?.status
                        );

                        return (
                          <div key={rid} className="border">
                            {/* master row */}
                            <table
                              className="table table-bordered mb-0"
                              style={{ tableLayout: "auto", width: "100%" }}
                            >
                              <thead className="main_heading_table">
                                <tr>
                                  <th>Request ID :</th>
                                  <th
                                    className={
                                      pr === "Priority" ? "priClr" : "col-ad"
                                    }
                                  >
                                    {rid}
                                  </th>
                                  <th>IP :</th>
                                  <th className="col-ip">
                                    {master?.IP ?? master?.ip ?? "-"}
                                  </th>
                                  <th>Added On :</th>
                                  <th>{addedOn || "-"}</th>
                                  <th>Submitted On :</th>
                                  <th>{submittedOn || "-"}</th>
                                  <th>No. Of Applicants :</th>
                                  <th style={{ width: "60px" }}>
                                    {master?.noOfUsr ??
                                      master?.no_of_applicants ??
                                      "-"}
                                  </th>
                                  <th>VAC :</th>
                                  <th className="col-vac">
                                    <div className="d-flex gap-2 align-items-center">
                                      {vacName}
                                      {/* Pencil shown but DISABLED (no onClick) */}
                                      <FaEdit
                                        style={{
                                          color: "green",
                                          fontSize: "0.8rem",
                                          opacity: 0.6,
                                          cursor: "not-allowed",
                                        }}
                                        title="VAC edit disabled"
                                      />
                                    </div>
                                  </th>
                                  <th>Priority :</th>
                                  <th>{pr}</th>
                                  <th>Status :</th>
                                  <th className="col-status">{statusName}</th>
                                  <th>
                                    <button
                                      className="btn-theam-filter"
                                      onClick={() => toggleExpand(String(rid))}
                                      title="Expand"
                                    >
                                      {expanded === String(rid) ? "▲" : "▼"}
                                    </button>
                                  </th>
                                </tr>
                              </thead>
                            </table>

                            {/* details */}
                            {expanded === String(rid) && (
                              <table className="table table-bordered table-hover tableexpand">
                                <thead className="table-active tableexpand-head">
                                  <tr>
                                    <th>Full Name</th>
                                    <th>Email Id</th>
                                    <th>Passport Number</th>
                                    <th>Nulla osta No</th>
                                    <th>DOB</th>
                                    <th>Issue Date</th>
                                    <th>Submitted On</th>
                                    <th>VAC</th>
                                    <th>Appointment On</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {(() => {
                                    const list = Array.isArray(details)
                                      ? details
                                      : details && typeof details === "object"
                                      ? Object.values(details)
                                      : [];

                                    if (list.length === 0) {
                                      return (
                                        <tr>
                                          <td
                                            colSpan={11}
                                            className="text-center text-muted"
                                          >
                                            No details available for this
                                            request.
                                          </td>
                                        </tr>
                                      );
                                    }

                                    return list.map((d, i) => {
                                      const fullName = [
                                        d?.fName ??
                                          d?.first_name ??
                                          d?.full_name?.split(" ")?.[0],
                                        d?.lName ??
                                          d?.last_name ??
                                          (d?.full_name
                                            ? d.full_name
                                                .split(" ")
                                                .slice(1)
                                                .join(" ")
                                            : null),
                                      ]
                                        .filter(Boolean)
                                        .join(" ");

                                      return (
                                        <tr key={`${rid}-detail-${i}`}>
                                          <td>{fullName || "-"}</td>
                                          <td>
                                            {master?.mailId ??
                                              master?.email ??
                                              d?.email ??
                                              "-"}
                                          </td>
                                          <td>
                                            {d?.ppn ?? d?.passport_no ?? "-"}
                                          </td>
                                          <td>
                                            {d?.wpn ?? d?.nulla_osta_no ?? "-"}
                                          </td>
                                          <td>{fmtDMY(d?.dob) || "-"}</td>
                                          <td>
                                            {fmtDMY(
                                              d?.wpndt ?? d?.issue_date
                                            ) || "-"}
                                          </td>
                                          <td>
                                            {toISTString(
                                              master?.submitOn ??
                                                master?.submitted_on
                                            ) || "-"}
                                          </td>
                                          <td>
                                            {getVacName(
                                              d?.vac ??
                                                master?.vac ??
                                                master?.vac_id
                                            )}
                                          </td>
                                          <td>
                                            {toISTString(
                                              d?.slotAt ?? d?.appointment_on
                                            ) || "-"}
                                          </td>
                                          <td>
                                            {getStatusName(
                                              d?.dtlStatus ??
                                                d?.status ??
                                                master?.status
                                            )}
                                          </td>
                                          <td>
                                            <button
                                              className="btnlink"
                                              onClick={() =>
                                                onView({ master, detail: d })
                                              }
                                            >
                                              View
                                            </button>
                                          </td>
                                        </tr>
                                      );
                                    });
                                  })()}
                                </tbody>
                              </table>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Pagination */}
                  {total > 0 && (
                    <div className="pagination-de">
                      <div className="pagination d-flex align-items-center gap-1 p-1 btn-primarycolor">
                        <button
                          id="btnPrevious"
                          className={`btn btn-sm ${
                            currentPage === 1 ? "disabled" : ""
                          }`}
                          onClick={handlePrev}
                        >
                          Previous
                        </button>

                        {(() => {
                          const totalPages = Math.max(
                            1,
                            Math.ceil(total / ITEMS_PER_PAGE)
                          );
                          const pages = getVisiblePages(
                            currentPage,
                            totalPages
                          );
                          const hasLeftEllipsis = pages[0] > 1;
                          const hasRightEllipsis =
                            pages[pages.length - 1] < totalPages;

                          return (
                            <>
                              {hasLeftEllipsis && (
                                <span className="px-1">…</span>
                              )}

                              {pages.map((p) => (
                                <button
                                  key={p}
                                  id={`btn${p}`}
                                  className={`btn btn-sm ${
                                    currentPage === p ? "active" : ""
                                  }`}
                                  onClick={() => fetchPage(p)}
                                >
                                  {p}
                                </button>
                              ))}

                              {hasRightEllipsis && (
                                <span className="px-1">…</span>
                              )}
                            </>
                          );
                        })()}

                        <button
                          id="btnNext"
                          className={`btn btn-sm ${
                            currentPage ===
                            Math.max(1, Math.ceil(total / ITEMS_PER_PAGE))
                              ? "disabled"
                              : ""
                          }`}
                          onClick={handleNext}
                        >
                          Next
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal */}
      {show && activeRow && (
        <CaseModal
          key={String(getReqId(activeRow?.master))}
          show={show}
          onClose={() => setShow(false)}
          row={activeRow}
          documents={documents}
          authData={authData}
          statusOptions={statusOptions}
        />
      )}
    </AjaxValidation>
  );
}
