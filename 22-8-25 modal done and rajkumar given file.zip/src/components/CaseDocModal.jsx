import React, { useEffect, useMemo, useState } from "react";
import Modal from "react-bootstrap/Modal";

/* ===== Utils (small, local) ===== */
const toISTString = (dateLike) => {
  if (!dateLike) return "";
  if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
  const d = new Date(dateLike);
  if (Number.isNaN(d.getTime())) return "";
  const istMs = d.getTime() + 5.5 * 60 * 60 * 1000;
  const ist = new Date(istMs);
  const dd = String(ist.getDate()).padStart(2, "0");
  const mm = String(ist.getMonth() + 1).padStart(2, "0");
  const yyyy = ist.getFullYear();
  const hh = String(ist.getHours()).padStart(2, "0");
  const mi = String(ist.getMinutes()).padStart(2, "0");
  return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
};
const fmtDMY = (dateLike) => {
  if (!dateLike) return "";
  if (typeof dateLike === "string" && dateLike.startsWith("0000-")) return "";
  const d = new Date(dateLike);
  if (Number.isNaN(d.getTime())) return "";
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
};
const getReqId = (obj) =>
  obj?.reqId ??
  obj?.request_id ??
  obj?.req_id ??
  obj?.reqid ??
  obj?.requestId ??
  obj?.reqIdFk ??
  obj?.reqid_fk ??
  null;
const getDtlId = (obj) =>
  obj?.dtlId ??
  obj?.dtlid ??
  obj?.dtl_id ??
  obj?.request_detail_id ??
  obj?.reqDtlId ??
  obj?.reqDetId ??
  obj?.detail_id ??
  obj?.details_id ??
  obj?.id ??
  null;

export default function CaseDocModal({
  show,
  onClose,
  row, // { master, details[] } OR { master, detail }
  documents = [], // array of docs (with dtlId/dtl_id, type, file/file_name, docStatus, reason, remarks, verifyOn, vefifyBy, id/docId)
  authData = {}, // must include session_id AND ajaxPayload.document_key (or document_key at root)
  statusOptions, // optional; falls back to authData.ajaxPayload.master_status_list
  reasonCodeList, // optional; falls back to authData.ajaxPayload.reasoncode_list
  fetchDocHistory, // optional async (payload) => { UsrActivity, CustActivity }
  docTypeMap = { passport: 2, nulla: 1 }, // override if your API uses different codes
}) {
  const [tab, setTab] = useState("passport"); // 'passport' | 'nulla' | 'history'

  // ---- applicant (detail) ----
  const det =
    row?.detail || (Array.isArray(row?.details) ? row.details[0] : {}) || {};
  const dtlId = String(getDtlId(det) ?? "");
  const requestId = String(row ? getReqId(row.master) ?? "" : "");

  // ---- right pane read-only info ----
  const fullName = [
    det?.fName ?? det?.first_name ?? det?.full_name?.split(" ")?.[0],
    det?.lName ??
      det?.last_name ??
      (det?.full_name ? det.full_name.split(" ").slice(1).join(" ") : null),
  ]
    .filter(Boolean)
    .join(" ");
  const email =
    row?.master?.mailId ?? row?.master?.email ?? det?.email ?? det?.mail ?? "";
  const passportNo = det?.ppn ?? det?.passport_no ?? det?.passport ?? "";
  const nullaOstaNo = det?.wpn ?? det?.nulla_osta_no ?? det?.nulla ?? "";
  const dob = fmtDMY(det?.dob);
  const issueDate = fmtDMY(det?.wpndt ?? det?.issue_date);
  const submittedOn =
    row?.master?.submitOn ??
    row?.master?.submitted_on ??
    det?.submitted_on ??
    "";

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const getVacName = (id) =>
    vacOptions.find((v) => String(v.vac_id) === String(id))?.vac_name ||
    id ||
    "-";
  const vacName = getVacName(
    det?.vac ?? row?.master?.vac ?? row?.master?.vac_id
  );

  const statusList =
    (statusOptions?.length
      ? statusOptions
      : authData?.ajaxPayload?.master_status_list) || [];
  const currentStatusName =
    statusList.find(
      (s) =>
        String(s.request_status_id) ===
        String(det?.dtlStatus ?? det?.status ?? row?.master?.status ?? "")
    )?.request_status_name || "-";

  // ---- reasons (dynamic) ----
  const reasons = useMemo(
    () => reasonCodeList ?? authData?.ajaxPayload?.reasoncode_list ?? [],
    [reasonCodeList, authData?.ajaxPayload?.reasoncode_list]
  );
  const nullaReasonOptions = useMemo(
    () =>
      reasons.filter(
        (r) => String(r.type) === "1" && String(r.status ?? "1") === "1"
      ),
    [reasons]
  );
  const passportReasonOptions = useMemo(
    () =>
      reasons.filter(
        (r) => String(r.type) === "2" && String(r.status ?? "1") === "1"
      ),
    [reasons]
  );
  const reasonLabelById = useMemo(() => {
    const m = {};
    for (const r of reasons) m[String(r.id)] = r.reason_code;
    return m;
  }, [reasons]);
  const reasonCommentById = useMemo(() => {
    const m = {};
    for (const r of reasons) m[String(r.id)] = r.reason_comments;
    return m;
  }, [reasons]);
  const getReasonLabel = (reasonId) =>
    reasonLabelById[String(reasonId ?? "")] ||
    (reasonId ? String(reasonId) : "-");

  useEffect(() => {
    setTab("passport");
  }, [row]);

  // ---- doc URL builder (supports both places for document_key) ----
  function buildDocUrl(fileName) {
    if (!fileName) return "";
    const sessionId = authData?.session_id;
    const documentKey =
      authData?.ajaxPayload?.document_key ?? authData?.document_key;
    if (!sessionId || !documentKey) return "";
    return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${sessionId}_${documentKey}_${fileName}`;
  }

  // ---- docs for this dtl ----
  const docsForDtl = useMemo(() => {
    const list = Array.isArray(documents) ? documents : [];
    return list.filter(
      (d) => String(d?.dtlId ?? d?.dtl_id ?? getDtlId(d)) === dtlId
    );
  }, [documents, dtlId]);

  const pickDocByType = (type) =>
    docsForDtl.find((d) => Number(d?.type) === Number(type)) || null;

  const passportDoc = pickDocByType(docTypeMap.passport);
  const nullaDoc = pickDocByType(docTypeMap.nulla);

  const passportFile = passportDoc?.file ?? passportDoc?.file_name ?? null;
  const nullaFile = nullaDoc?.file ?? nullaDoc?.file_name ?? null;

  const activeDoc =
    tab === "passport" ? passportDoc : tab === "nulla" ? nullaDoc : null;

  const activeDocUrl =
    tab === "passport"
      ? buildDocUrl(passportFile)
      : tab === "nulla"
      ? buildDocUrl(nullaFile)
      : "";

  // ---- right-hand selects reflect selected doc ----
  const [status, setStatus] = useState("");
  const [reason, setReason] = useState("");
  const [comments, setComments] = useState("");
  useEffect(() => {
    if (!activeDoc) {
      setStatus("");
      setReason("");
      setComments("");
      return;
    }
    const docStatus = String(activeDoc?.docStatus ?? "");
    const docReason = String(activeDoc?.reason ?? "");
    const docRemarks =
      String(activeDoc?.remarks ?? "") ||
      reasonCommentById[String(docReason)] ||
      "";
    setStatus(docStatus);
    setReason(docReason);
    setComments(docRemarks);
  }, [tab, activeDoc, docsForDtl, reasonCommentById]);

  const getStatusName = (id) =>
    statusList.find((s) => String(s.request_status_id) === String(id ?? ""))
      ?.request_status_name || (id ? String(id) : "-");

  /* ================= History (optional) ================= */
  const showHistoryTab = typeof fetchDocHistory === "function";
  const [historyFocus, setHistoryFocus] = useState("nulla"); // 'passport' | 'nulla'
  const [historyOverrideFile, setHistoryOverrideFile] = useState(null);
  const [passUsrActs, setPassUsrActs] = useState([]);
  const [passCusActs, setPassCusActs] = useState([]);
  const [nullaUsrActs, setNullaUsrActs] = useState([]);
  const [nullaCusActs, setNullaCusActs] = useState([]);
  const [hisLoading, setHisLoading] = useState(false);

  useEffect(() => {
    let abort = false;
    if (!showHistoryTab) return;
    async function load(docId, setUsr, setCus) {
      if (!docId) {
        setUsr([]);
        setCus([]);
        return;
      }
      const payload = {
        session_id: authData?.session_id,
        sessionToken: authData?.session_token,
        session_token: authData?.session_token,
        docId,
      };
      const res = await fetchDocHistory(payload);
      if (abort) return;
      setUsr(Array.isArray(res?.UsrActivity) ? res.UsrActivity : []);
      setCus(Array.isArray(res?.CustActivity) ? res.CustActivity : []);
    }
    async function run() {
      if (tab !== "history") return;
      setHisLoading(true);
      try {
        setHistoryFocus("nulla");
        setHistoryOverrideFile(null);
        await Promise.all([
          load(
            passportDoc?.docId ?? passportDoc?.id,
            setPassUsrActs,
            setPassCusActs
          ),
          load(
            nullaDoc?.docId ?? nullaDoc?.id,
            setNullaUsrActs,
            setNullaCusActs
          ),
        ]);
      } finally {
        setHisLoading(false);
      }
    }
    run();
    return () => {
      abort = true;
    };
  }, [
    showHistoryTab,
    tab,
    authData?.session_id,
    authData?.session_token,
    passportDoc?.docId,
    passportDoc?.id,
    nullaDoc?.docId,
    nullaDoc?.id,
    fetchDocHistory,
  ]);

  const statusNameById = useMemo(() => {
    const list = statusList || [];
    const map = {};
    for (const s of list)
      map[String(s.request_status_id)] = s.request_status_name;
    return map;
  }, [statusList]);

  const fmtTime = (s) => toISTString(s) || "-";

  function buildHistoryRows(kind) {
    const cus = kind === "passport" ? passCusActs : nullaCusActs;
    const docFile = kind === "passport" ? passportFile : nullaFile;

    const docObj = kind === "passport" ? passportDoc : nullaDoc;
    const rawStat = docObj?.docStatus ?? docObj?.docStstus;
    const actionNm = statusNameById[String(rawStat)] ?? rawStat ?? "-";
    const byNm =
      kind === "passport" ? passportDoc?.vefifyBy : nullaDoc?.vefifyBy;

    const rows = [];
    let index = 1;

    if (Array.isArray(cus) && cus.length > 0) {
      cus.forEach((c) => {
        rows.push({
          idx: index++,
          action: actionNm,
          by: byNm || "-",
          on: fmtTime(c.verifyOn),
          file: c.file || "-",
        });
      });
    } else if (docFile) {
      rows.push({
        idx: index++,
        action: actionNm,
        by: byNm || "-",
        on: fmtTime(docObj?.verifyOn) || "-",
        file: docFile,
      });
    }
    return rows;
  }

  const passportRows = buildHistoryRows("passport");
  const nullaRows = buildHistoryRows("nulla");

  const statusChip = (docStatus) => {
    const code = String(docStatus || "");
    const cls =
      code === "6"
        ? "text-success fw-semibold"
        : code === "4"
        ? "text-danger fw-semibold"
        : "text-secondary";
    return <span className={cls}>{getStatusName(code)}</span>;
  };

  const historyPreviewUrl = useMemo(() => {
    const fallback = historyFocus === "passport" ? passportFile : nullaFile;
    const fileToShow = historyOverrideFile || fallback;
    return buildDocUrl(fileToShow);
  }, [historyFocus, historyOverrideFile, passportFile, nullaFile]);

  return (
    <Modal
      show={show}
      onHide={onClose}
      backdrop="static"
      keyboard={false}
      className="newcase_modal-dialog"
      size="xl"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title>
          <h6 className="fs-6">Reference ID - {requestId || "-"}</h6>
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="model_dialog_list">
          <div className="row">
            {/* LEFT */}
            <div className="col-sm-8 border-right">
              <div className="mb-3 d-flex gap-1">
                <button
                  className={`btn ${tab === "passport" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
                    fontSize: "0.8rem",
                  }}
                  onClick={() => setTab("passport")}
                >
                  Passport Document
                </button>
                <button
                  className={`btn ${tab === "nulla" ? "text-white" : ""}`}
                  style={{
                    backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
                    fontSize: "0.8rem",
                  }}
                  onClick={() => setTab("nulla")}
                >
                  Nulla Osta Document
                </button>
                {showHistoryTab && (
                  <button
                    className={`btn ${tab === "history" ? "text-white" : ""}`}
                    style={{
                      backgroundColor:
                        tab === "history" ? "#f26722" : "#f6e6df",
                      fontSize: "0.8rem",
                    }}
                    onClick={() => setTab("history")}
                  >
                    Document History
                  </button>
                )}
              </div>

              {tab !== "history" ? (
                <div
                  style={{
                    height: "55vh",
                    border: "1px solid #ddd",
                    borderRadius: 6,
                    overflow: "hidden",
                    background: "#fff",
                  }}
                >
                  {activeDocUrl ? (
                    <iframe
                      title="document-preview"
                      src={activeDocUrl}
                      style={{ width: "100%", height: "100%", border: 0 }}
                    />
                  ) : (
                    <div className="p-3">File not found or inaccessible!</div>
                  )}
                </div>
              ) : (
                <div className="pdf_view tab_scroll">
                  <style>{`
                    .history_table>:not(caption)>*>*{border-width:0 1px!important;font-size:12px!important}
                    .status-flex{display:flex;justify-content:space-between;align-items:center;text-align:center;padding:.5rem 1rem;border:1px solid #dee2e6;font-size:14px}
                    .history-row{cursor:pointer}
                    .clickable{cursor:pointer;text-decoration:underline}
                  `}</style>

                  {/* Passport Section */}
                  <div
                    className="status-flex"
                    onClick={() => {
                      setHistoryFocus("passport");
                      setHistoryOverrideFile(null);
                    }}
                  >
                    <div>
                      Passport : <span>{passportNo || "-"}</span>
                    </div>
                    <div>Status : {statusChip(passportDoc?.docStatus)}</div>
                  </div>

                  <div className="table-responsive mt-2">
                    <table className="table table-bordered history_table text-left">
                      <thead className="table-active">
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Actioned By</th>
                          <th>Actioned On</th>
                          <th>Uploaded Passport</th>
                        </tr>
                      </thead>
                      <tbody>
                        {hisLoading ? (
                          <tr>
                            <td colSpan={5}>Loading…</td>
                          </tr>
                        ) : passportRows.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-muted">
                              —
                            </td>
                          </tr>
                        ) : (
                          passportRows.map((r) => (
                            <tr
                              key={`pr-${r.idx}`}
                              className="history-row"
                              onClick={() => {
                                setHistoryFocus("passport");
                                if (r.file && r.file !== "-")
                                  setHistoryOverrideFile(r.file);
                              }}
                            >
                              <td>{r.idx}</td>
                              <td>{r.action}</td>
                              <td>{r.by}</td>
                              <td>{r.on}</td>
                              <td className="clickable">{r.file || "-"}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Nulla Section */}
                  <div
                    className="status-flex mt-3"
                    onClick={() => {
                      setHistoryFocus("nulla");
                      setHistoryOverrideFile(null);
                    }}
                  >
                    <div>
                      Nulla Osta : <span>{nullaOstaNo || "-"}</span>
                    </div>
                    <div>Status : {statusChip(nullaDoc?.docStatus)}</div>
                  </div>

                  <div className="table-responsive mt-2">
                    <table className="table table-bordered history_table text-left">
                      <thead className="table-active">
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Actioned By</th>
                          <th>Actioned On</th>
                          <th>Uploaded Nulla Osta</th>
                        </tr>
                      </thead>
                      <tbody>
                        {hisLoading ? (
                          <tr>
                            <td colSpan={5}>Loading…</td>
                          </tr>
                        ) : nullaRows.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-muted">
                              —
                            </td>
                          </tr>
                        ) : (
                          nullaRows.map((r) => (
                            <tr
                              key={`nr-${r.idx}`}
                              className="history-row"
                              onClick={() => {
                                setHistoryFocus("nulla");
                                if (r.file && r.file !== "-")
                                  setHistoryOverrideFile(r.file);
                              }}
                            >
                              <td>{r.idx}</td>
                              <td>{r.action}</td>
                              <td>{r.by}</td>
                              <td>{r.on}</td>
                              <td className="clickable">{r.file || "-"}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* RIGHT (read-only) */}
            <div className="col-sm-4">
              {tab === "history" ? (
                <div
                  className="img_view text-center"
                  style={{
                    height: "55vh",
                    border: "1px solid #ddd",
                    borderRadius: 6,
                    overflow: "hidden",
                    background: "#fff",
                  }}
                >
                  {historyPreviewUrl ? (
                    <iframe
                      title="history-preview"
                      src={historyPreviewUrl}
                      style={{ width: "100%", height: "100%", border: 0 }}
                    />
                  ) : (
                    <div className="p-3">No file to preview.</div>
                  )}
                </div>
              ) : (
                <div className="accordion-body">
                  <div className="form-group row">
                    <div className="col-sm-12">
                      <h6 className="modal-title mb-2">Customer Details :</h6>
                    </div>
                  </div>

                  <div className="newcase-container">
                    {[
                      ["Issue Date", issueDate || "-"],
                      ["Submited On", toISTString(submittedOn) || "-"],
                      ["VAC", vacName],
                      ["Full Name", fullName || "-"],
                      ["Email Id", email || "-"],
                      ["Passport Number", passportNo || "-"],
                      ["Nulla osta No", nullaOstaNo || "-"],
                      ["DOB", fmtDMY(det?.dob) || "-"],
                      ["Status", currentStatusName],
                    ].map(([l, v], i) => (
                      <div className="form-group row border-bottom" key={i}>
                        <div className="col-sm-6">
                          <label className="form-label">{l}</label>
                        </div>
                        <div className="col-sm-6">
                          <label className="form-label">{v}</label>
                        </div>
                      </div>
                    ))}

                    {/* Doc Status (read-only) */}
                    <div className="form-group row border-bottom mb-2">
                      <div className="col-sm-6">
                        <label className="form-label">Doc Status</label>
                      </div>
                      <div className="col-sm-6">
                        <select
                          className="form-select form-control"
                          disabled
                          value={status}
                          onChange={() => {}}
                        >
                          <option value="">{getStatusName(status)}</option>
                          {statusList.map((s) => (
                            <option
                              key={s.request_status_id}
                              value={s.request_status_id}
                            >
                              {s.request_status_name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Reason (read-only) */}
                    <div className="form-group row border-bottom">
                      <div className="col-sm-6">
                        <label className="form-label">Reason</label>
                      </div>
                      <div className="col-sm-6">
                        <select
                          className="form-select form-control"
                          disabled
                          value={reason}
                          onChange={() => {}}
                        >
                          <option value="">{getReasonLabel(reason)}</option>
                          {(tab === "passport"
                            ? passportReasonOptions
                            : nullaReasonOptions
                          ).map((r) => (
                            <option key={r.id} value={String(r.id)}>
                              {r.reason_code}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Comments (read-only) */}
                    <div className="form-group row border-bottom">
                      <div className="col-sm-12">
                        <label className="form-label">Comments</label>
                        <textarea
                          className="form-control"
                          rows={5}
                          value={comments}
                          onChange={() => {}}
                          disabled
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            {/* END RIGHT */}
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}
