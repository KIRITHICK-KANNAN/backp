// components/ProtectedRoute.jsx
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ children }) {
  const { authData } = useAuth();
  if (!authData?.session_id || !authData?.session_token) {
    return <Navigate to="/" replace />;
  }
  return children;
}
