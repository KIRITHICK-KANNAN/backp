// import React, { useState } from "react";
// import DatePicker from "react-datepicker";
// import "react-datepicker/dist/react-datepicker.css";
// import CustomDateInput from "../components/CustomDateInput";
// import CustomTimeInput from "../components/CustomTimeInput";

// export default function AddSlot() {
//   const [startDate, setStartDate] = useState(new Date());
//   const [endDate, setEndDate] = useState(new Date());
//   const minDate = new Date("2000-01-01");
//   const maxDate = new Date();

//   const [starttime, setStartTime] = useState(null);
//   const [endtime, setEndTime] = useState(null);

//   const [startbreaktime, setStartBreakTime] = useState(null);
//   const [endbreaktime, setEndBreakTime] = useState(null);
//   return (
//     <div id="dash" className="mt-2">
//       <section>
//         <div className="container-fluid">
//           <div className="row">
//             <div className="col-md-12">
//               <div className="admin_form_section">
//                 <div className="admin_form_card data_table_view">
//                   <div className="head_title">
//                     <div className="row">
//                       <div className="col-md-12">
//                         <h6 className="p-0 m-0">Add Slot</h6>
//                       </div>
//                     </div>

//                     <div class="row mt-2 mb-3">
//                       <div class="col-sm-12">
//                         <form className="">
//                           <div className="box_card">
//                             <div className="form-group row">
//                               {/* VAC */}
//                               <div
//                                 className="col-sm-2 col-md-2 col-lg-2"
//                                 data-field="vac"
//                               >
//                                 <label className="form-label">VAC List</label>
//                                 <select class="form-select form-control">
//                                   <option selected>--Select VAC--</option>
//                                   <option value="1">Submission</option>
//                                   <option value="2">Travel</option>
//                                 </select>
//                               </div>

//                               {/* Start Date */}
//                               <div
//                                 className="col-sm-2 col-md-2 col-lg-2"
//                                 data-field="startDate"
//                               >
//                                 <label className="form-label">Start Date</label>
//                                 <DatePicker
//                                   selected={startDate}
//                                   className="form-control"
//                                   onChange={(date) => setStartDate(date)}
//                                   customInput={<CustomDateInput />}
//                                   dateFormat="dd/MM/yyyy"
//                                   showMonthDropdown
//                                   showYearDropdown
//                                   dropdownMode="select"
//                                   scrollableYearDropdown
//                                   minDate={minDate}
//                                   maxDate={maxDate}
//                                   yearDropdownItemNumber={
//                                     maxDate.getFullYear() - 2000 + 1
//                                   }
//                                 />
//                               </div>

//                               {/* End Date */}
//                               <div
//                                 className="col-sm-2 col-md-2 col-lg-2"
//                                 data-field="endDate"
//                               >
//                                 <label className="form-label">End Date</label>
//                                 <DatePicker
//                                   selected={endDate}
//                                   className="form-control"
//                                   onChange={(date) => setEndDate(date)}
//                                   customInput={<CustomDateInput />}
//                                   dateFormat="dd/MM/yyyy"
//                                   showMonthDropdown
//                                   showYearDropdown
//                                   dropdownMode="select"
//                                   scrollableYearDropdown
//                                   minDate={minDate}
//                                   maxDate={maxDate}
//                                   yearDropdownItemNumber={
//                                     maxDate.getFullYear() - 2000 + 1
//                                   }
//                                 />
//                               </div>

//                               {/* Start Time */}
//                               <div
//                                 className="col-sm-2 col-md-2 col-lg-2"
//                                 data-field="startTime"
//                               >
//                                 <label className="form-label">Start Time</label>
//                                 <DatePicker
//                                   className="form-control"
//                                   selected={starttime}
//                                   onChange={(date) => setStartTime(date)}
//                                   showTimeSelect
//                                   showTimeSelectOnly
//                                   timeIntervals={15}
//                                   timeCaption="Time"
//                                   dateFormat="h:mm aa"
//                                   customInput={<CustomTimeInput />}
//                                 />
//                               </div>

//                               {/* End Time */}
//                               <div
//                                 className="col-sm-2 col-md-2 col-lg-2"
//                                 data-field="endTime"
//                               >
//                                 <label className="form-label">End Time</label>
//                                 <DatePicker
//                                   className="form-control"
//                                   selected={endtime}
//                                   onChange={(date) => setEndTime(date)}
//                                   showTimeSelect
//                                   showTimeSelectOnly
//                                   timeIntervals={15}
//                                   timeCaption="Time"
//                                   dateFormat="h:mm aa"
//                                   customInput={<CustomTimeInput />}
//                                 />
//                               </div>

//                               {/* Break Start (maps all break errors to this field) */}
//                               <div
//                                 className="col-sm-2 col-md-2 col-lg-2"
//                                 data-field="breakStart"
//                               >
//                                 <label className="form-label">
//                                   Break Start Time
//                                 </label>
//                                 <DatePicker
//                                   className="form-control"
//                                   selected={startbreaktime}
//                                   onChange={(date) => setStartBreakTime(date)}
//                                   showTimeSelect
//                                   showTimeSelectOnly
//                                   timeIntervals={15}
//                                   timeCaption="Time"
//                                   dateFormat="h:mm aa"
//                                   customInput={<CustomTimeInput />}
//                                 />
//                               </div>

//                               {/* Break End */}
//                               <div
//                                 className="col-sm-2 col-md-2 col-lg-2"
//                                 data-field="breakEnd"
//                               >
//                                 <label className="form-label">
//                                   Break End Time
//                                 </label>
//                                 <DatePicker
//                                   className="form-control"
//                                   selected={endbreaktime}
//                                   onChange={(date) => setEndBreakTime(date)}
//                                   showTimeSelect
//                                   showTimeSelectOnly
//                                   timeIntervals={15}
//                                   timeCaption="Time"
//                                   dateFormat="h:mm aa"
//                                   customInput={<CustomTimeInput />}
//                                 />
//                               </div>

//                               {/* Interval */}
//                               <div
//                                 className="col-sm-2 col-md-2 col-lg-2"
//                                 data-field="intervalMin"
//                               >
//                                 <label className="form-label">
//                                   Time Interval
//                                 </label>
//                                 <select class="form-select form-control">
//                                   <option selected>--Time Interval--</option>
//                                   <option value="1">5</option>
//                                   <option value="2">10</option>
//                                   <option value="3">15</option>
//                                 </select>
//                               </div>

//                               {/* Priority */}
//                               <div
//                                 className="col-sm-2 col-md-2 col-lg-2"
//                                 data-field="priority"
//                               >
//                                 <label className="form-label">No.of Slot</label>
//                                 <input
//                                   type="text"
//                                   class="form-control"
//                                   id=""
//                                   placeholder="No.of Slot"
//                                 />
//                               </div>

//                               {/* Submit */}
//                               <div className="col-sm-2 col-md-2 col-lg-2 mt-2">
//                                 <button
//                                   className="btn-lg go-btn w-100 mt-4"
//                                   id="btnBookSlot"
//                                   type="submit"
//                                 >
//                                   Add
//                                 </button>
//                               </div>
//                             </div>
//                           </div>
//                         </form>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </section>
//     </div>
//   );
// }

import React, { useMemo, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import CustomDateInput from "../components/CustomDateInput";
import CustomTimeInput from "../components/CustomTimeInput";
import AjaxValidation from "../hooks/AjaxValidation";
import { useAuth } from "../context/AuthContext";
import { slotProcess } from "../api/client";
// import { useNavigate } from "react-router-dom";

/* ------------ Helpers ------------ */
function toDate_DDMonYYYY(d) {
  if (!d) return "";
  const dd = String(d.getDate()).padStart(2, "0");
  const mmm = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ][d.getMonth()];
  const yyyy = d.getFullYear();
  return `${dd}-${mmm}-${yyyy}`;
}
function fmtHHmm(d) {
  if (!d) return "";
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${hh}:${mm}`;
}
function minutesOf(d) {
  return d.getHours() * 60 + d.getMinutes();
}
function dayValue(d) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

/* Show only ONE error at a time (top priority first) */
const ERROR_ORDER = [
  "vac",
  "startDate",
  "endDate",
  "startTime",
  "endTime",
  "breakPair",
  "intervalMin",
  "noOfSlot",
  "priority",
];

export default function AddSlot() {
  const { authData } = useAuth();
  // const navigate = useNavigate();

  // VAC options from session (fallback to empty)
  const vacOptions = authData?.ajaxPayload?.vac_list || [];

  // ====== UI state (design: max date = today) ======
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const minDate = useMemo(() => new Date("2000-01-01"), []);
  const maxDate = useMemo(() => new Date(), []); // today

  const [startTime, setStartTime] = useState(null);
  const [endTime, setEndTime] = useState(null);
  const [breakStart, setBreakStart] = useState(null);
  const [breakEnd, setBreakEnd] = useState(null);

  const [vac, setVac] = useState("0");
  const [intervalMin, setIntervalMin] = useState("0"); // "0" means not selected
  const [noOfSlot, setNoOfSlot] = useState("");
  const [priority, setPriority] = useState(""); // "0" | "1"

  // only ONE visible error at a time
  const [errors, setErrors] = useState({});
  const invalidStyle = { borderColor: "#dc3545" };

  // IMPORTANT FIX: do fallback AFTER Number(), so 0/NaN becomes 15 (prevents freeze)
  const timeStep = Number(intervalMin) || 15;

  /* Build a full error map, then pick only the first key by ERROR_ORDER */
  function computeErrorMap() {
    const e = {};
    if (vac === "0") e.vac = "Please select a VAC.";

    if (!startDate) e.startDate = "Please choose Start Date.";
    if (!endDate) e.endDate = "Please choose End Date.";
    if (startDate && endDate && dayValue(startDate) > dayValue(endDate)) {
      e.endDate = "End Date must be after Start Date.";
    }

    if (!startTime) e.startTime = "Choose Start Time.";
    if (!endTime) e.endTime = "Choose End Time.";
    if (startTime && endTime && minutesOf(startTime) >= minutesOf(endTime)) {
      e.endTime = "End Time must be after Start Time.";
    }

    // Break validations (treated as a single logical error "breakPair")
    const hasB1 = !!breakStart;
    const hasB2 = !!breakEnd;
    if ((hasB1 && !hasB2) || (!hasB1 && hasB2)) {
      e.breakPair =
        "Provide both Break Start and Break End or leave both empty.";
    } else if (hasB1 && hasB2) {
      if (minutesOf(breakStart) >= minutesOf(breakEnd)) {
        e.breakPair = "Break End Time must be after Break Start Time.";
      } else if (
        (startTime && minutesOf(breakStart) < minutesOf(startTime)) ||
        (endTime && minutesOf(breakEnd) > minutesOf(endTime))
      ) {
        e.breakPair = "Break must lie within Start–End time.";
      }
    }

    if (!intervalMin || intervalMin === "0")
      e.intervalMin = "Choose a Time Interval.";

    const n = Number(noOfSlot);
    if (!Number.isFinite(n) || n <= 0)
      e.noOfSlot = "No of Slot must be a positive number.";

    if (priority !== "0" && priority !== "1") e.priority = "Choose a Priority.";

    return e;
  }

  function pickFirstError(eMap) {
    for (const k of ERROR_ORDER) {
      if (eMap[k]) return { key: k, msg: eMap[k] };
    }
    return null;
  }

  async function handleAdd(ev) {
    ev.preventDefault();

    // 1) compute all, 2) show only first in the defined order
    const all = computeErrorMap();
    const first = pickFirstError(all);
    if (first) {
      // Map the composite break error onto a single visible field (breakStart)
      const visualKey = first.key === "breakPair" ? "breakStart" : first.key;
      setErrors({ [visualKey]: first.msg });

      // scroll into view
      const el = document.querySelector(`[data-field="${visualKey}"]`);
      if (el?.scrollIntoView)
        el.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    setErrors({}); // clear

    const payload = {
      usrtid: String(authData?.user_id ?? authData?.role_id ?? ""),
      usrsid: String(authData?.session_id ?? ""),
      usrstkn: String(authData?.session_token ?? ""),
      Date1: toDate_DDMonYYYY(startDate),
      Date2: toDate_DDMonYYYY(endDate),
      Time1: fmtHHmm(startTime),
      Time2: fmtHHmm(endTime),
      BTime1: breakStart ? fmtHHmm(breakStart) : "",
      BTime2: breakEnd ? fmtHHmm(breakEnd) : "",
      Inrvl: String(intervalMin),
      NoOf: String(noOfSlot),
      vac: String(vac),
      RoleId: String(authData?.role_id ?? ""),
      priority: String(priority),
      type: 3,
    };

    try {
      const res = await slotProcess(payload);
      if (res?.status === 2) {
        alert("Slot added successfully");
        // Reset (keep VAC selection)
        setStartDate(new Date());
        setEndDate(new Date());
        setStartTime(null);
        setEndTime(null);
        setBreakStart(null);
        setBreakEnd(null);
        setIntervalMin("0");
        setNoOfSlot("");
        setPriority("");
        // navigate("/SlotList");
      } else {
        alert(res?.msg || "Failed to add slot(s).");
      }
    } catch (err) {
      console.error("SlotProcess error:", err);
      alert(err?.message || "Slot creation failed.");
    }
  }

  // Clear the single visible error when editing its field
  const clearErr = (k) => setErrors((prev) => (prev[k] ? {} : prev));

  return (
    <AjaxValidation>
      <div id="dash" className="mt-2">
        <section>
          <div className="container-fluid">
            <div className="row">
              <div className="col-md-12">
                <div className="admin_form_section">
                  <div className="admin_form_card data_table_view">
                    <div className="head_title">
                      <div className="row">
                        <div className="col-md-12">
                          <h6 className="p-0 m-0">Add Slot</h6>
                        </div>
                      </div>

                      <div className="row mt-2 mb-3">
                        <div className="col-sm-12">
                          <form className="" onSubmit={handleAdd}>
                            <div className="box_card">
                              <div className="form-group row">
                                {/* VAC */}
                                <div
                                  className="col-sm-2 col-md-2 col-lg-2"
                                  data-field="vac"
                                >
                                  <label className="form-label">VAC List</label>
                                  <select
                                    className={`form-select form-control ${
                                      errors.vac ? "is-invalid" : ""
                                    }`}
                                    style={
                                      errors.vac ? invalidStyle : undefined
                                    }
                                    value={vac}
                                    onChange={(e) => {
                                      setVac(e.target.value);
                                      clearErr("vac");
                                    }}
                                  >
                                    <option value="0">--Select VAC--</option>
                                    {vacOptions.map((v) => (
                                      <option
                                        key={v.vac_id}
                                        value={String(v.vac_id)}
                                      >
                                        {v.vac_name}
                                      </option>
                                    ))}
                                  </select>
                                </div>

                                {/* Start Date */}
                                <div
                                  className="col-sm-2 col-md-2 col-lg-2"
                                  data-field="startDate"
                                >
                                  <label className="form-label">
                                    Start Date
                                  </label>
                                  <DatePicker
                                    selected={startDate}
                                    onChange={(d) => {
                                      setStartDate(d);
                                      clearErr("startDate");
                                    }}
                                    customInput={<CustomDateInput />}
                                    className={`form-control ${
                                      errors.startDate ? "is-invalid" : ""
                                    }`}
                                    style={
                                      errors.startDate
                                        ? invalidStyle
                                        : undefined
                                    }
                                    dateFormat="dd/MM/yyyy"
                                    showMonthDropdown
                                    showYearDropdown
                                    dropdownMode="select"
                                    scrollableYearDropdown
                                    minDate={minDate}
                                    // maxDate={maxDate}
                                    yearDropdownItemNumber={
                                      maxDate.getFullYear() - 2000 + 1
                                    }
                                  />
                                </div>

                                {/* End Date */}
                                <div
                                  className="col-sm-2 col-md-2 col-lg-2"
                                  data-field="endDate"
                                >
                                  <label className="form-label">End Date</label>
                                  <DatePicker
                                    selected={endDate}
                                    onChange={(d) => {
                                      setEndDate(d);
                                      clearErr("endDate");
                                    }}
                                    customInput={<CustomDateInput />}
                                    className={`form-control ${
                                      errors.endDate ? "is-invalid" : ""
                                    }`}
                                    style={
                                      errors.endDate ? invalidStyle : undefined
                                    }
                                    dateFormat="dd/MM/yyyy"
                                    showMonthDropdown
                                    showYearDropdown
                                    dropdownMode="select"
                                    scrollableYearDropdown
                                    minDate={minDate}
                                    // maxDate={maxDate}
                                    yearDropdownItemNumber={
                                      maxDate.getFullYear() - 2000 + 1
                                    }
                                  />
                                </div>

                                {/* Start Time */}
                                <div
                                  className="col-sm-2 col-md-2 col-lg-2"
                                  data-field="startTime"
                                >
                                  <label className="form-label">
                                    Start Time
                                  </label>
                                  <DatePicker
                                    selected={startTime}
                                    onChange={(d) => {
                                      setStartTime(d);
                                      clearErr("startTime");
                                    }}
                                    showTimeSelect
                                    showTimeSelectOnly
                                    timeIntervals={timeStep}
                                    timeCaption="Time"
                                    dateFormat="h:mm aa"
                                    customInput={<CustomTimeInput />}
                                    className={`form-control ${
                                      errors.startTime ? "is-invalid" : ""
                                    }`}
                                    style={
                                      errors.startTime
                                        ? invalidStyle
                                        : undefined
                                    }
                                  />
                                </div>

                                {/* End Time */}
                                <div
                                  className="col-sm-2 col-md-2 col-lg-2"
                                  data-field="endTime"
                                >
                                  <label className="form-label">End Time</label>
                                  <DatePicker
                                    selected={endTime}
                                    onChange={(d) => {
                                      setEndTime(d);
                                      clearErr("endTime");
                                    }}
                                    showTimeSelect
                                    showTimeSelectOnly
                                    timeIntervals={timeStep}
                                    timeCaption="Time"
                                    dateFormat="h:mm aa"
                                    customInput={<CustomTimeInput />}
                                    className={`form-control ${
                                      errors.endTime ? "is-invalid" : ""
                                    }`}
                                    style={
                                      errors.endTime ? invalidStyle : undefined
                                    }
                                  />
                                </div>

                                {/* Break Start (maps all break errors to this field) */}
                                <div
                                  className="col-sm-2 col-md-2 col-lg-2"
                                  data-field="breakStart"
                                >
                                  <label className="form-label">
                                    Break Start Time
                                  </label>
                                  <DatePicker
                                    selected={breakStart}
                                    onChange={(d) => {
                                      setBreakStart(d);
                                      clearErr("breakStart");
                                    }}
                                    showTimeSelect
                                    showTimeSelectOnly
                                    timeIntervals={timeStep}
                                    timeCaption="Time"
                                    dateFormat="h:mm aa"
                                    customInput={<CustomTimeInput />}
                                    className={`form-control ${
                                      errors.breakStart ? "is-invalid" : ""
                                    }`}
                                    style={
                                      errors.breakStart
                                        ? invalidStyle
                                        : undefined
                                    }
                                  />
                                </div>

                                {/* Break End */}
                                <div
                                  className="col-sm-2 col-md-2 col-lg-2"
                                  data-field="breakEnd"
                                >
                                  <label className="form-label">
                                    Break End Time
                                  </label>
                                  <DatePicker
                                    selected={breakEnd}
                                    onChange={(d) => {
                                      setBreakEnd(d);
                                      // break errors are mapped to breakStart
                                    }}
                                    showTimeSelect
                                    showTimeSelectOnly
                                    timeIntervals={timeStep}
                                    timeCaption="Time"
                                    dateFormat="h:mm aa"
                                    customInput={<CustomTimeInput />}
                                    className="form-control"
                                  />
                                </div>

                                {/* Time Interval (dynamic: 5..45 step 5) */}
                                <div
                                  className="col-sm-2 col-md-2 col-lg-2"
                                  data-field="intervalMin"
                                >
                                  <label className="form-label">
                                    Time Interval
                                  </label>
                                  <select
                                    className={`form-select form-control ${
                                      errors.intervalMin ? "is-invalid" : ""
                                    }`}
                                    style={
                                      errors.intervalMin
                                        ? invalidStyle
                                        : undefined
                                    }
                                    value={intervalMin}
                                    onChange={(e) => {
                                      setIntervalMin(e.target.value);
                                      clearErr("intervalMin");
                                    }}
                                  >
                                    <option value="0">
                                      --Select Interval--
                                    </option>
                                    {Array.from(
                                      { length: 9 },
                                      (_, i) => 5 * (i + 1)
                                    ).map((n) => (
                                      <option key={n} value={String(n)}>
                                        {n}
                                      </option>
                                    ))}
                                  </select>
                                </div>

                                {/* No.of Slot */}
                                <div
                                  className="col-sm-2 col-md-2 col-lg-2"
                                  data-field="noOfSlot"
                                >
                                  <label className="form-label">
                                    No.of Slot
                                  </label>
                                  <input
                                    type="text"
                                    className={`form-control ${
                                      errors.noOfSlot ? "is-invalid" : ""
                                    }`}
                                    style={
                                      errors.noOfSlot ? invalidStyle : undefined
                                    }
                                    placeholder="No.of Slot"
                                    value={noOfSlot}
                                    onChange={(e) => {
                                      setNoOfSlot(e.target.value);
                                      clearErr("noOfSlot");
                                    }}
                                    maxLength={2}
                                  />
                                </div>

                                {/* Priority */}
                                <div
                                  className="col-sm-2 col-md-2 col-lg-2"
                                  data-field="priority"
                                >
                                  <label className="form-label">Priority</label>
                                  <select
                                    className={`form-select form-control ${
                                      errors.priority ? "is-invalid" : ""
                                    }`}
                                    style={
                                      errors.priority ? invalidStyle : undefined
                                    }
                                    value={priority}
                                    onChange={(e) => {
                                      setPriority(e.target.value);
                                      clearErr("priority");
                                    }}
                                  >
                                    <option value="">
                                      --Select Priority--
                                    </option>
                                    <option value="0">Normal</option>
                                    <option value="1">Priority</option>
                                  </select>
                                </div>

                                {/* Submit */}
                                <div className="col-sm-2 col-md-2 col-lg-2 mt-2">
                                  <button
                                    className="btn-lg go-btn w-100 mt-4"
                                    id="btnBookSlot"
                                    type="submit"
                                  >
                                    Add
                                  </button>
                                </div>

                                {/* Inline single-error helper */}
                                {/* {Object.keys(errors).length > 0 && (
                                  <div className="col-12 mt-2">
                                    <div className="text-danger small">
                                      {Object.values(errors)[0]}
                                    </div>
                                  </div>
                                )} */}
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </AjaxValidation>
  );
}
