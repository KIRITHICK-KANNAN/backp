// import React from "react";
// import Button from "react-bootstrap/Button";
// import Container from "react-bootstrap/Container";
// import Form from "react-bootstrap/Form";
// import Nav from "react-bootstrap/Nav";
// import Navbar from "react-bootstrap/Navbar";
// import NavDropdown from "react-bootstrap/NavDropdown";
// import logo from "../assets/vfs_logo.png"; // Adjust the path as necessary

// export default function Header() {
//   return (
//     <div>
//       <Navbar expand="lg" className="bg-header border-bottom">
//         <Container>
//           <Navbar.Brand href="#">
//             <img src={logo} alt="logo" className="site_logo img-fluid" />
//           </Navbar.Brand>

//           <Navbar.Toggle aria-controls="navbarScroll" />
//           <Navbar.Collapse id="navbarScroll">
//             <Nav
//               className="me-auto my-2 my-lg-0"
//               style={{ maxHeight: "100px" }}
//               navbarScroll
//             ></Nav>
//             <Form className="d-flex"></Form>
//           </Navbar.Collapse>
//         </Container>
//       </Navbar>
//     </div>
//   );
// }

// working

// import React from "react";
// import { NavLink, useNavigate } from "react-router-dom";
// import Navbar from "react-bootstrap/Navbar";
// import Container from "react-bootstrap/Container";
// import Nav from "react-bootstrap/Nav";
// import NavDropdown from "react-bootstrap/NavDropdown";
// import Button from "react-bootstrap/Button";
// import { useAuth } from "../context/AuthContext";
// import logo from "../assets/vfs_logo.png";

// export default function Header() {
//   const { authData, logout } = useAuth();
//   const navigate = useNavigate();

//   const isAuthed =
//     Boolean(authData?.session_id) && Boolean(authData?.session_token);
//   const role = String(authData?.role_id ?? "");
//   const displayName =
//     authData?.user?.full_name || authData?.user?.username || "User";

//   // Per-role menus (adjust routes to match your app)
//   const menusByRole = {
//     1: [
//       { to: "/AddSlot", label: "AddSlot" },
//       { to: "/PriorityCases", label: "PriorityCases" },
//     ],
//     2: [{ to: "/PriorityCases", label: "PriorityCases" }],
//     3: [{ to: "/PriorityCases", label: "CC Support" }],
//     4: [{ to: "/PriorityCases/AllCases", label: "CC Verify" }],
//     5: [{ to: "/PriorityCases", label: "Agency" }],
//     6: [{ to: "/PriorityCases", label: "Dashboard" }],
//   };

//   const handleLogout = () => {
//     logout();
//     navigate("/", { replace: true });
//   };

//   const brandTo = isAuthed ? "/dashboard" : "/";

//   return (
//     <Navbar expand="lg" className="bg-header border-bottom" sticky="top">
//       <Container>
//         <Navbar.Brand as={NavLink} to={brandTo}>
//           <img src={logo} alt="logo" className="site_logo img-fluid" />
//         </Navbar.Brand>

//         <Navbar.Toggle aria-controls="mainNav" />
//         <Navbar.Collapse id="mainNav">
//           <Nav className="me-auto">
//             {isAuthed &&
//               (menusByRole[role] || []).map((m) => (
//                 <Nav.Link
//                   key={m.to}
//                   as={NavLink}
//                   to={m.to}
//                   className="px-2"
//                   end
//                 >
//                   {m.label}
//                 </Nav.Link>
//               ))}
//           </Nav>

//           <Nav>
//             {isAuthed && (
//               <NavDropdown title={displayName} align="end" id="userMenu">
//                 <NavDropdown.Item disabled>
//                   Role: {role || "—"}
//                 </NavDropdown.Item>
//                 <NavDropdown.Divider />
//                 <NavDropdown.Item onClick={handleLogout}>
//                   Logout
//                 </NavDropdown.Item>
//               </NavDropdown>
//             )}
//           </Nav>
//         </Navbar.Collapse>
//       </Container>
//     </Navbar>
//   );
// }

// // pages/Header.jsx
// import React from "react";
// import { NavLink, useNavigate } from "react-router-dom";
// import Navbar from "react-bootstrap/Navbar";
// import Container from "react-bootstrap/Container";
// import Nav from "react-bootstrap/Nav";
// import NavDropdown from "react-bootstrap/NavDropdown";
// import { useAuth } from "../context/AuthContext";
// import logo from "../assets/vfs_logo.png";

// export default function Header() {
//   const { authData, logout } = useAuth();
//   const navigate = useNavigate();

//   const isAuthed =
//     Boolean(authData?.session_id) && Boolean(authData?.session_token);
//   const role = String(authData?.role_id ?? "");
//   const displayName =
//     authData?.user?.full_name || authData?.user?.username || "User";

//   const menusByRole = {
//     // role 1 — match the screenshot
//     1: [
//       { to: "/CaseList", label: "Case List" },
//       { to: "/AddSlot", label: "Add Slot" },
//       { to: "/SlotList", label: "Slot List" },
//       { to: "/Holiday", label: "Holiday" },
//       { to: "/Manifest", label: "Manifest" },
//       { to: "/dashboard", label: "Dashboard" },
//       { to: "/AgentReport", label: "Agent Report" },
//     ],
//     // keep other roles as you wish
//     2: [{ to: "/PriorityCases", label: "PriorityCases" }],
//     3: [{ to: "/PriorityCases", label: "CC Support" }],
//     4: [{ to: "/PriorityCases/AllCases", label: "CC Verify" }],
//     5: [{ to: "/PriorityCases", label: "Agency" }],
//     6: [{ to: "/PriorityCases", label: "Dashboard" }],
//   };

//   const handleLogout = () => {
//     logout();
//     navigate("/", { replace: true });
//   };

//   const brandTo = isAuthed ? "/CaseList" : "/";

//   return (
//     <Navbar expand="lg" className="bg-header border-bottom" sticky="top">
//       <Container>
//         <Navbar.Brand as={NavLink} to={brandTo}>
//           <img src={logo} alt="logo" className="site_logo img-fluid" />
//         </Navbar.Brand>

//         <Navbar.Toggle aria-controls="mainNav" />
//         <Navbar.Collapse id="mainNav">
//           <Nav className="me-auto">
//             {isAuthed &&
//               (menusByRole[role] || []).map((m) => (
//                 <Nav.Link
//                   key={m.to}
//                   as={NavLink}
//                   to={m.to}
//                   end
//                   className="px-2"
//                 >
//                   {m.label}
//                 </Nav.Link>
//               ))}
//           </Nav>

//           <Nav>
//             {isAuthed && (
//               <NavDropdown title={displayName} align="end" id="userMenu">
//                 <NavDropdown.Item disabled>
//                   Role: {role || "—"}
//                 </NavDropdown.Item>
//                 <NavDropdown.Divider />
//                 <NavDropdown.Item onClick={handleLogout}>
//                   Logout
//                 </NavDropdown.Item>
//               </NavDropdown>
//             )}
//           </Nav>
//         </Navbar.Collapse>
//       </Container>
//     </Navbar>
//   );
// }

// import React from "react";
// import { NavLink, useNavigate } from "react-router-dom";
// import Navbar from "react-bootstrap/Navbar";
// import Container from "react-bootstrap/Container";
// import Nav from "react-bootstrap/Nav";
// import { useAuth } from "../context/AuthContext";
// import logo from "../assets/vfs_logo.png";

// export default function Header() {
//   const { authData, logout } = useAuth();
//   const navigate = useNavigate();

//   const isAuthed =
//     Boolean(authData?.session_id) && Boolean(authData?.session_token);
//   const role = String(authData?.role_id ?? "");
//   const displayName =
//     authData?.user?.full_name || authData?.user?.username || "User";

//   const menusByRole = {
//     1: [
//       { to: "/CaseList", label: "Case List" },
//       { to: "/AddSlot", label: "Add Slot" },
//       { to: "/SlotList", label: "Slot List" },
//       { to: "/Holiday", label: "Holiday" },
//       { to: "/Manifest", label: "Manifest" },
//       { to: "/dashboard", label: "Dashboard" },
//       { to: "/AgentReport", label: "Agent Report" },
//     ],
//     2: [{ to: "/PriorityCases", label: "PriorityCases" }],
//     3: [{ to: "/PriorityCases", label: "CC Support" }],
//     4: [{ to: "/PriorityCases/AllCases", label: "CC Verify" }],
//     5: [{ to: "/PriorityCases", label: "Agency" }],
//     6: [{ to: "/PriorityCases", label: "Dashboard" }],
//   };

//   const handleLogout = () => {
//     logout();
//     navigate("/", { replace: true });
//   };

//   const brandTo = isAuthed ? "/CaseList" : "/";

//   return (
//     <Navbar expand="lg" className="bg-header border-bottom" sticky="top">
//       {/* If logged in — logo left, menus next, user right */}
//       {isAuthed ? (
//         <Container fluid>
//           <Navbar.Brand as={NavLink} to={brandTo} className="me-4">
//             <img
//               src={logo}
//               alt="logo"
//               className="site_logo img-fluid"
//               style={{ width: "70%" }}
//             />
//           </Navbar.Brand>

//           <Navbar.Toggle aria-controls="mainNav" />
//           <Navbar.Collapse id="mainNav">
//             <Nav className="me-auto">
//               {(menusByRole[role] || []).map((m) => (
//                 <Nav.Link
//                   key={m.to}
//                   as={NavLink}
//                   to={m.to}
//                   end
//                   className="px-3 header-link"
//                 >
//                   {m.label}
//                 </Nav.Link>
//               ))}
//             </Nav>

//             <Nav className="align-items-center">
//               <span className="me-3 fw-semibold">Welcome {displayName}</span>
//               <button
//                 type="button"
//                 className="btn btn-link p-0 header-logout"
//                 onClick={handleLogout}
//               >
//                 Logout
//               </button>
//             </Nav>
//           </Navbar.Collapse>
//         </Container>
//       ) : (
//         // If NOT logged in — logo centered
//         <Container className="justify-content-start">
//           <Navbar.Brand as={NavLink} to={brandTo}>
//             <img
//               src={logo}
//               alt="logo"
//               className="site_logo img-fluid"
//               // style={{ maxHeight: "80px" }}
//               style={{ width: "70%" }}
//             />
//           </Navbar.Brand>
//         </Container>
//       )}
//     </Navbar>
//   );
// }

import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import { useAuth } from "../context/AuthContext";
import logo from "../assets/vfs_logo.png";
import userAvatar from "../assets/user-avatar.svg";
import ProfileModal from "./ProfileModal"; // Your modal component
import { encryptPassword, updatePassword, logoutUser } from "../api/client";

const BASEURL = "https://vfseu.mioot.com/forms/UAT/reacttraining/";
export default function Header() {
  const { authData, logout } = useAuth();
  const navigate = useNavigate();

  const [showProfile, setShowProfile] = useState(false);

  const {
    session_id,
    session_token,
    role_id,
    user = {},
    role_list = [],
  } = authData;

  const username = user?.username || "";
  const full_name = user?.full_name || "";
  const isAuthed = Boolean(session_id) && Boolean(session_token);

  const capitalizeWords = (str) =>
    str.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());

  const roleName =
    role_list.find((r) => String(r.role_id) === String(role_id))?.role_name ||
    "";

  const menusByRole = {
    1: [
      { to: "/CaseList", label: "Case List" },
      { to: "/AddSlot", label: "Add Slot" },
      { to: "/SlotList", label: "Slot List" },
      { to: "/Holiday", label: "Holiday" },
      { to: "/Manifest", label: "Manifest" },
      { to: "/dashboard", label: "Dashboard" },
      { to: "/AgentReport", label: "Agent Report" },
    ],
    2: [
      { to: "/NormalCases", label: "Normal Cases" },
      { to: "/PriorityCases", label: "PriorityCases" },
      { to: "/CaseList", label: "Case List" },
    ],
    3: [
      { to: "/AgentNrCases", label: "Normal Cases" },
      { to: "/AgentPrCases", label: "PriorityCases" },
    ],
  };

  const handleLogout = async () => {
    if (!session_id || !session_token) return;
    const confirmLogout = window.confirm("Are you sure you want to logout?");
    if (!confirmLogout) return;

    try {
      await logoutUser({ session_id, session_token });
    } catch (e) {
      console.error("Logout API failed", e);
    }
    logout();
    navigate("/", { replace: true });
  };

  const handleUpdatePassword = async (form) => {
    const payload = {
      session_id,
      session_token,
      old_password: encryptPassword(form.oldPassword),
      new_password: encryptPassword(form.newPassword),
      confirm_password: encryptPassword(form.confirmPassword),
    };

    const res = await updatePassword(payload);
    if (res?.status === 1) {
      alert("Password updated successfully");
    } else {
      alert(res?.message || "Password update failed");
    }
  };

  const brandTo = isAuthed ? "/CaseList" : "/";

  return (
    <>
      <Navbar expand="lg" className="bg-header border-bottom" sticky="top">
        {isAuthed ? (
          <Container fluid>
            <Navbar.Brand as={NavLink} to={brandTo} className="me-4">
              <img
                src={`${BASEURL}assets/vfs_logo.png`}
                alt="logo"
                className="site_logo img-fluid"
                style={{ width: "70%" }}
              />
            </Navbar.Brand>

            <Navbar.Toggle aria-controls="mainNav" />
            <Navbar.Collapse id="mainNav">
              <Nav className="me-auto">
                {(menusByRole[role_id] || []).map((m) => (
                  <Nav.Link
                    key={m.to}
                    as={NavLink}
                    to={m.to}
                    end
                    className="px-3 header-link"
                  >
                    {m.label}
                  </Nav.Link>
                ))}
              </Nav>

              {/* Right side user dropdown */}
              <ul className="nav nav_logout text-center align-items-center mb-0">
                <li className="nav-item border-0">
                  <span className="nav-link" style={{ color: "#222" }}>
                    Welcome{" "}
                    <span style={{ color: "var(--primary-color)" }}>
                      {capitalizeWords(full_name)}
                    </span>
                  </span>
                </li>
                <li className="nav-item border-0">
                  <div className="dropdown text-end">
                    <a
                      href="#"
                      onClick={(e) => e.preventDefault()}
                      className="d-block link-dark text-decoration-none dropdown-toggle"
                      id="dropdownUser1"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                    >
                      <img
                        src={userAvatar}
                        alt="Profile"
                        width="32"
                        height="32"
                        className="rounded-circle img-fluid user_profile_icon"
                      />
                    </a>
                    <ul
                      className="dropdown-menu text-small"
                      aria-labelledby="dropdownUser1"
                    >
                      <li>
                        <button
                          className="dropdown-item"
                          onClick={() => setShowProfile(true)}
                        >
                          Profile
                        </button>
                      </li>
                      <li>
                        <button
                          className="dropdown-item"
                          onClick={handleLogout}
                        >
                          Logout
                        </button>
                      </li>
                    </ul>
                  </div>
                </li>
              </ul>
            </Navbar.Collapse>
          </Container>
        ) : (
          <Container className="justify-content-start">
            <Navbar.Brand as={NavLink} to={brandTo}>
              <img
                src={logo}
                alt="logo"
                className="site_logo img-fluid"
                style={{ width: "70%" }}
              />
            </Navbar.Brand>
          </Container>
        )}
      </Navbar>

      {/* Profile Modal */}
      <ProfileModal
        show={showProfile}
        onHide={() => setShowProfile(false)}
        onUpdatePassword={handleUpdatePassword}
      />
    </>
  );
}
