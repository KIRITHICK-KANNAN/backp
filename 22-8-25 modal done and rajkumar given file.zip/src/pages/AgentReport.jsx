import AjaxValidation from "../hooks/AjaxValidation";
export default function AgentReport() {
  return (
    <AjaxValidation>
      <div className="container py-3">
        <h4>Agent Report</h4>
      </div>
    </AjaxValidation>
  );
}
