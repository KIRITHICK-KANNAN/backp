<?php


error_reporting(E_ALL);
ini_set('display_errors', 1);


include_once("../AppCommonIncludes.php");
require("../../../api/DBActions.php");

$requestBody = file_get_contents('php://input');
$ReqBody = json_decode($requestBody, true);


$formData = $ReqBody;

$userID =  isset($formData['user_id']) ? (int) XSSFilter($formData['user_id']) : 0;
$sessionID = isset($formData['session_id']) ? (int) XSSFilter($formData['session_id']) : 0;
$sessionToken = isset($formData['sessionToken']) ? XSSFilter($formData['sessionToken']) : "";



// print_r($headerData);
// echo "\r\n";

$link = DBLink();

$query_session_check = "SELECT * FROM admin_sessions us
                        LEFT JOIN admin_users ud ON us.user_id=ud.user_id WHERE us.user_id = '$userID' AND us.session_id='$sessionID' AND us.session_token='$sessionToken' AND us.login_status=1";
$sessionCount = ExecuteReader($link,$query_session_check);

if(count($sessionCount)==0){
    $retArr["status"] = 3;
    $retArr["msg"] = "Invalid session";
    $retArr["data"] = [];
    die(json_encode($retArr));
}

// exit;
$retArr = array();


        $TmpResult = getReportList($link, $formData);
        // echo "<hr>";
        // print_r($TmpResult);
        // exit;
        if (count($TmpResult) == 0) {
            $retArr["status"] = 2;
            $retArr["msg"] = "No data Found";
            $retArr["data"] = $TmpResult;
            die(json_encode($retArr));
        }

            $retArr["status"] = 1;
            $retArr["type"] = 1;
            $retArr["msg"] = "";
            $retArr["data"] = $TmpResult;
            die(json_encode($retArr));

function ConvertDate($sql_date)
{
    $date = strtotime($sql_date);
    $return_date = date('Y-m-d', $date);
    return $return_date;
}
function ToDate($sql_date)
{
    $date = strtotime($sql_date);
    $return_date = date('d-m-Y', $date);
    return $return_date;
}


function getReportList($argLink, $formData)
{
    $userID =  isset($formData['user_id']) ? (int) XSSFilter($formData['user_id']) : 0;
    $sessionID = isset($formData['session_id']) ? (int) XSSFilter($formData['session_id']) : 0;
    $sessionToken = isset($formData['sessionToken']) ? (int) XSSFilter($formData['sessionToken']) : "";
    
    if(isset($formData["from_date"])) $fromDate=XSSFilter($formData["from_date"]); else $fromDate=date("Y-m-d");
    if(isset($formData["to_date"])) $toDate=XSSFilter($formData["to_date"]); else $toDate=date("Y-m-d");

    $vac_id =  isset($formData['vac_id']) ? (int) XSSFilter($formData['vac_id']) : "";

    $tDate = date("Y-m-d");

    if (isset($fromDate))
        $fromDate = $fromDate;
    else
        $fromDate = $fromDate;

    if (isset($toDate))
        $toDate = $toDate;
    else
        $toDate = $tDate;

    $fDate = ToDate($fromDate);
    $tDate = ToDate($toDate);
    $fromdate_d = ConvertDate($fromDate)." 00:00:00";
    $todate_d = ConvertDate($toDate)." 23:59:59";



    $where = "";

    if (!empty($formData["from_date"]) && !empty($formData["to_date"])) {
        if ($where !== "") $where .= " AND ";
        $where .= "(CONVERT_TZ(dd.verified_on, '+00:00', '+05:30') BETWEEN '$fromdate_d' AND '$todate_d')";
    }	

    if (isset($formData["vac_id"]) && (int)$formData["vac_id"] !== 0) {
        if ($where !== "") $where .= " AND ";
        $where .= "rm.vac_id = '$vac_id'";
    }


    $getQuery = "SELECT 
                DATE_FORMAT(CONVERT_TZ(dd.verified_on, '+00:00', '+05:30'), '%d-%m-%Y') AS dateverified, 
                ud.full_name AS agent_name, 
                vl.vac_name AS location,    
                SUM(CASE WHEN dd.document_status = 6 THEN 1 ELSE 0 END) AS verified_count,
                SUM(CASE WHEN al.document_id IS NOT NULL THEN 1 ELSE 0 END) AS rejected_count,
                SUM(CASE WHEN dd.document_status = 4 THEN 1 ELSE 0 END) AS blocked_count
            FROM document_details dd 
            LEFT JOIN activity_log al ON dd.document_id = al.document_id AND dd.verified_by = al.user_id  
            LEFT JOIN request_master rm ON dd.request_id = rm.request_id   
            LEFT JOIN request_details rd ON rm.request_id = rd.request_id             
            LEFT JOIN vac_list vl ON rm.vac_id = vl.vac_id 
            LEFT JOIN admin_users ud ON dd.verified_by = ud.user_id 
            WHERE dd.document_id IS NOT NULL " . 
            ($where !== "" ? " AND $where" : "") . 
            " GROUP BY DATE(CONVERT_TZ(dd.verified_on, '+00:00', '+05:30')), dd.verified_by, rm.vac_id 
              ORDER BY dd.verified_on ASC";


    // $getQuery = "SELECT 
    //             DATE_FORMAT(CONVERT_TZ(dd.verified_on, '+00:00', '+05:30'), '%d-%m-%Y') AS dateverified, 
    //             ud.full_name AS agent_name, 
    //             vl.vac_name AS location,    
    //             SUM(CASE WHEN dd.document_type = 2 AND dd.document_status = 6 THEN 1 ELSE 0 END) AS passport_verified_count,
    //             SUM(CASE WHEN dd.document_type = 2 AND al.document_id IS NOT NULL THEN 1 ELSE 0 END) AS passport_rejected_count,
    //             SUM(CASE WHEN dd.document_type = 2 AND dd.document_status = 4 THEN 1 ELSE 0 END) AS passport_blocked_count,    
    //             SUM(CASE WHEN dd.document_type = 1 AND dd.document_status = 6 THEN 1 ELSE 0 END) AS nulla_osta_verified_count,
    //             SUM(CASE WHEN dd.document_type = 1 AND al.document_id IS NOT NULL THEN 1 ELSE 0 END) AS nulla_osta_rejected_count,
    //             SUM(CASE WHEN dd.document_type = 1 AND dd.document_status = 4 THEN 1 ELSE 0 END) AS nulla_osta_blocked_count,
    //             SUM(CASE WHEN rd.details_status = 8 AND rd.approved_by IS NOT NULL THEN 1 ELSE 0 END) AS verdict_approved_count,
    //             SUM(CASE WHEN rd.details_status = 10 AND rd.approved_by IS NOT NULL THEN 1 ELSE 0 END) AS verdict_decline_count
    //         FROM document_details dd 
    //         LEFT JOIN activity_log al ON dd.document_id = al.document_id AND dd.verified_by = al.user_id  
    //         LEFT JOIN request_master rm ON dd.request_id = rm.request_id   
    //         LEFT JOIN request_details rd ON rm.request_id = rd.request_id             
    //         LEFT JOIN vac_list vl ON rm.vac_id = vl.vac_id 
    //         LEFT JOIN admin_users ud ON dd.verified_by = ud.user_id 
    //         WHERE dd.document_id IS NOT NULL " . 
    //         ($where !== "" ? " AND $where" : "") . 
    //         " GROUP BY DATE(CONVERT_TZ(dd.verified_on, '+00:00', '+05:30')), dd.verified_by, rm.vac_id 
    //           ORDER BY dd.verified_on ASC";


    $count = rtnRowCount($argLink,$getQuery);
    $TempResult = ExecuteReader($argLink, $getQuery);

    return $TempResult;

}


//===============

?>