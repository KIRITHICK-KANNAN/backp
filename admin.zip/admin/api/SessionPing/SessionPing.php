<?php


error_reporting(E_ALL);
ini_set('display_errors', 1);


include_once("../AppCommonIncludes.php");
include_once("/var/www/html/vfseu_mioot/forms/UAT/ITAIND/api/DBActions.php");

$requestBody = file_get_contents('php://input');
// Decode the JSON data
$ReqBody = json_decode($requestBody, true);


//$userID =  isset($ReqBody['user_id']) ? (int) $ReqBody['user_id'] : 0;
$sessionID = isset($ReqBody['session_id']) ? (int) $ReqBody['session_id'] : 0;
$session_token = isset($ReqBody['session_token']) ? trim($ReqBody['session_token']) : "";
$activity_time = isset($ReqBody['activity_time']) ? trim($ReqBody['activity_time']) : "";

// $userID = $ReqBody['user_id'] ?? 0;
// $sessionID = $ReqBody['session_id'] ?? 0;
// $session_token = trim($ReqBody['session_token']) ?? "";

$link = DBLink();


$retArr = array();

if ($sessionID > 0 && $session_token !== "" && $activity_time !== "") {
    $query_exist = "SELECT * FROM admin_sessions WHERE session_id='$sessionID' AND session_token='$session_token'";
    $existing_Session = rtnRowCount($link,$query_exist);
    if($existing_Session>0){
        $updatePing = updatePing($link,$ReqBody);    
        if($updatePing){
            $retArr["status"] = 1;
            $retArr["msg"] = "success";    
            die(json_encode($retArr));
        }
    }else{
        $retArr["status"] = 3;
        $retArr["msg"] = "invalid user";  
        die(json_encode($retArr));
    } 

}else{
    
    $retArr["status"] = 2;
    $retArr["msg"] = "error";   
    die(json_encode($retArr));
}



function ConvertDate($sql_date)
{
    $date = strtotime($sql_date);
    $return_date = date('Y-m-d', $date);
    return $return_date;
}

function ToDate($sql_date)
{
    $date = strtotime($sql_date);
    $return_date = date('d-m-Y', $date);
    return $return_date;
}

function updatePing($argLink, $ReqBody)
{
    
        $userID =  isset($ReqBody['user_id']) ? (int) $ReqBody['user_id'] : 0;
        $sessionID = isset($ReqBody['session_id']) ? (int) $ReqBody['session_id'] : 0;
        $session_token = isset($ReqBody['session_token']) ? $ReqBody['session_token'] : "";
        $activity_time = isset($ReqBody['activity_time']) ? $ReqBody['activity_time'] : "";

        $result_arr = array();
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $result_arr["status"] = 201;
            $result_arr["msg"] = "invalid method";
            print_r(json_encode($result_arr));
        }

        if (!empty($ReqBody['session_id']) && !empty($ReqBody['session_token'])) {
            $update_ping_qry ="UPDATE admin_sessions SET last_activity='$activity_time',last_ping=NOW() WHERE session_id='$sessionID' AND session_token='$session_token'";
            $updateResult = ExcuteNonQuery($argLink,$update_ping_qry);     
            return $updateResult;
        }else{
            return false;
        }            
			

}

// function getHolidayList($argLink, $ReqBody)
// {
//     $getQuery="SELECT holiday_id,holiday_name, DATE_FORMAT(holiday_date, '%d-%b-%Y') AS formatted_holiday_date
// 							FROM holiday_list
// 								WHERE is_weekend = '0'
// 									ORDER BY holiday_date ASC";				   
//     $TempResult = ExecuteReader($argLink, $getQuery);
//     return $TempResult;
// }


?>