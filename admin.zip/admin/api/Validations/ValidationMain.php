<?php

function ValidationMain($argParamList, $argInputData)
{
    if (ValidationParams($argParamList, $argInputData) == INVALID_PARAMETER) {
        return INVALID_PARAMETER;
    }

    if (ValidationSession($argParamList, $argInputData) == INVALID_SESSION) {
        return INVALID_SESSION;

    }
}

function ValidationParams($argParamList, $argInputData)
{
    if (CheckParamAndResponse($argParamList, $argInputData) != 100) {
        return VALID_PARAMETER;
    }
    return INVALID_PARAMETER;

}

function ValidationDataType($argParamList, $argInputData)
{

}

function ValidationSession($argParamList, $argInputData)
{
    $TempQuery = "CALL ProcSessionValidation('bg655465',1,1,@OutParam); SELECT @OutParam;";

    $pdo = GetPDOConnection();
    // echo "<br>";
    // print_r($pdo);
    // echo "<br>";
    // print_r($argObj);

    $TempParamIn = array();

    // $TempParamIn[":FormID"] = $argObj->FormID;

    $RetResult = ReadDBData($pdo, $TempQuery, $TempParamIn);

    return $RetResult;
}

?>