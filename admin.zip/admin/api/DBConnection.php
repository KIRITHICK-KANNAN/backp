<?php

include_once("/var/www/html/vfseu_mioot/forms/UAT/ITAIND/api/DBConnection.php");

/*define('HOST_ADDRESS',"jaap8.cqnbiw1tqob8.eu-central-1.rds.amazonaws.com");
define('USER_NAME',"neesoft");
define('PASSWORD',"p7w30899UG");
define('DATABASE_NAME',"uat_italy_india");  


function DBLink()
{

	$dbname = DATABASE_NAME;
	$dbUser = USER_NAME;
	$dbPassword = PASSWORD;
	$dbHostName = HOST_ADDRESS;

	$link = mysqli_connect($dbHostName,$dbUser,$dbPassword) or  die('DB ERROR1 :: 100');	
	mysqli_select_db($link,$dbname) or die('DB ERROR1 :: 101-a');	
	
	mysqli_query($link,"SET NAMES 'utf8' COLLATE 'utf8_general_ci'") or die('Error 1');
	return $link;
	
}
function closeConnection($getLink)
{
	mysqli_close($getLink);
}
function writeLog($sendfName,$message)
{
	$currentDate = date("dmy",strtotime('now'));
	$filename = $sendfName."_".$currentDate.'.txt';
	$date =@date('d-M-Y H:i:s');
	$path= '../logfile/';
	$file= $path.$filename;
	$lineBreak = "\r\n";
	$file_open = fopen($file,"a+");
	$file_write = fwrite($file_open,$date.' :: '.$message.' :: '.$lineBreak);
	
	fclose($file_open);
}
*/

















?>
