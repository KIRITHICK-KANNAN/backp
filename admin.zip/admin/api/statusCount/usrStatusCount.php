<?php

		////include_once("../DBConn.php");
		//require("../../../api/DBActions.php");
		include_once("../AppCommonIncludes.php");

		$requestBody = file_get_contents('php://input');
		
		/*$requestBody ='{
  "session_id": "2755",
  "session_token": "90867b30e16e2504ddfe65cfcb02b77d",
  "user_id": 18
}';*/
		
		$ReqBody = json_decode($requestBody, true);
		$retArr = array();

		$user_id =  isset($ReqBody['user_id']) ? (int) $ReqBody['user_id'] : 0;
		$api_name='Dashboard';
		$result = checkApiRateLimit($link, $user_id ,$api_name);
		if (!$result) {
			$retArr["status"] = 10;
			$retArr["msg"] = "API rate limit exceeded. Try again later.";
			die(json_encode($retArr));
		}

		$formData = $ReqBody;
		
		
		
		try
		{

				$userID =  isset($formData['user_id']) ? (int) $formData['user_id'] : 0;
				$sessionID = isset($formData['session_id']) ? (int) $formData['session_id'] : 0;
				$sessionToken = isset($formData['session_token']) ? XSSFilter($formData['session_token']) : "";
				
				$link = DBLink();

				$fromDate=date("Y-m-d");
				$toDate=date("Y-m-d");
				$fromdate_d = ConvertDate($fromDate)." 00:00:00";
				$todate_d = ConvertDate($toDate)." 23:59:59";


				$chkSession = "SELECT * FROM admin_sessions us 
										LEFT JOIN user_details ud ON us.user_id=ud.user_id WHERE us.user_id = $userID AND us.session_id=$sessionID AND us.session_token='$sessionToken' AND us.login_status=1";
				$sessionCount = rtnRowCount($link,$chkSession);

				if($sessionCount==0){
					$retArr["status"] = 2;
					$retArr["data"] = [];
					die(json_encode($retArr));
				}
				
				$statusQry="SELECT 
			SUM(CASE WHEN rm.request_status = 2 THEN 1 ELSE 0 END) AS submit,
			SUM(CASE WHEN rm.request_status = 3 THEN 1 ELSE 0 END) AS review,
			SUM(CASE WHEN rm.request_status = 4 THEN 1 ELSE 0 END) AS blocked,
			SUM(CASE WHEN rm.request_status = 5 THEN 1 ELSE 0 END) AS resubmit,
			SUM(CASE WHEN rm.request_status = 6 THEN 1 ELSE 0 END) AS verified,
			SUM(CASE WHEN rm.request_status = 7 THEN 1 ELSE 0 END) AS pverified,
			SUM(CASE WHEN rm.request_status = 8 THEN 1 ELSE 0 END) AS approved,
			SUM(CASE WHEN rm.request_status = 9 THEN 1 ELSE 0 END) AS parroved,
			SUM(CASE WHEN rm.request_status = 10 THEN 1 ELSE 0 END) AS declined,
			SUM(CASE WHEN rm.request_status = 11 THEN 1 ELSE 0 END) AS pfailure,
			SUM(CASE WHEN rm.request_status = 12 THEN 1 ELSE 0 END) AS paid,
			SUM(CASE WHEN rm.request_status = 13 THEN 1 ELSE 0 END) AS allotted,
			SUM(CASE WHEN rm.request_status = 14 THEN 1 ELSE 0 END) AS paymentlink_expired
		 FROM request_master rm";
		 
			$TempResult = ExecuteReader($link, $statusQry);


			// $statusQry_CurrentDate = "SELECT 
			// 			SUM(CASE WHEN rm.request_status = 2 THEN 1 ELSE 0 END) AS current_submit,
			// 			SUM(CASE WHEN rm.request_status = 3 THEN 1 ELSE 0 END) AS current_review,
			// 			SUM(CASE WHEN rm.request_status = 4 THEN 1 ELSE 0 END) AS current_blocked,
			// 			SUM(CASE WHEN rm.request_status = 5 THEN 1 ELSE 0 END) AS current_resubmit,
			// 			SUM(CASE WHEN rm.request_status = 6 THEN 1 ELSE 0 END) AS current_verified,
			// 			SUM(CASE WHEN rm.request_status = 7 THEN 1 ELSE 0 END) AS current_pverified,
			// 			SUM(CASE WHEN rm.request_status = 8 THEN 1 ELSE 0 END) AS current_approved,
			// 			SUM(CASE WHEN rm.request_status = 9 THEN 1 ELSE 0 END) AS current_parroved,
			// 			SUM(CASE WHEN rm.request_status = 10 THEN 1 ELSE 0 END) AS current_declined,
			// 			SUM(CASE WHEN rm.request_status = 11 THEN 1 ELSE 0 END) AS current_pfailure,
			// 			SUM(CASE WHEN rm.request_status = 12 THEN 1 ELSE 0 END) AS current_paid,
			// 			SUM(CASE WHEN rm.request_status = 13 THEN 1 ELSE 0 END) AS current_allotted,
			// 			SUM(CASE WHEN rm.request_status = 14 THEN 1 ELSE 0 END) AS current_paymentlink_expired
			// 		FROM request_master rm WHERE (rm.submitted_on BETWEEN '$fromdate_d' AND '$todate_d')";

$statusQry_CurrentDate = "SELECT 
						SUM(CASE WHEN rm.request_status = 2 THEN 1 ELSE 0 END) AS current_submit,
						SUM(CASE WHEN rm.request_status = 3 THEN 1 ELSE 0 END) AS current_review,
						SUM(CASE WHEN rm.request_status = 4 THEN 1 ELSE 0 END) AS current_blocked,
						SUM(CASE WHEN rm.request_status = 5 THEN 1 ELSE 0 END) AS current_resubmit,
						SUM(CASE WHEN rm.request_status = 6 THEN 1 ELSE 0 END) AS current_verified,
						SUM(CASE WHEN rm.request_status = 7 THEN 1 ELSE 0 END) AS current_pverified,
						SUM(CASE WHEN rm.request_status = 8 THEN 1 ELSE 0 END) AS current_approved,
						SUM(CASE WHEN rm.request_status = 9 THEN 1 ELSE 0 END) AS current_parroved,
						SUM(CASE WHEN rm.request_status = 10 THEN 1 ELSE 0 END) AS current_declined,
						SUM(CASE WHEN rm.request_status = 11 THEN 1 ELSE 0 END) AS current_pfailure,
						SUM(CASE WHEN rm.request_status = 12 THEN 1 ELSE 0 END) AS current_paid,
						SUM(CASE WHEN rm.request_status = 13 THEN 1 ELSE 0 END) AS current_allotted,
						SUM(CASE WHEN rm.request_status = 14 THEN 1 ELSE 0 END) AS current_paymentlink_expired
					FROM request_master rm WHERE (CONVERT_TZ(rm.added_on, '+00:00', '+05:30') BETWEEN '$fromdate_d' AND '$todate_d')";					



			$TempResult_CurrentDate = ExecuteReader($link, $statusQry_CurrentDate);		
			
			mysqli_close($link);

			$retArr["status"] = 1;
			$retArr["data"] = $TempResult;
			$retArr["current_data"] = $TempResult_CurrentDate;
			
            die(json_encode($retArr));
		}
		catch(Exception $err)
		{
			
		
		}
		catch( Throwable $e)
		{
			
		}
		function XSSFilter($str)
		{ 
			$search = array("<", '>', '&lt;','&gt;','&#x3C;','&#x3E;',"'","&apos;","&#x27;","(",")","%");
			$replace = "";
			
			return str_replace($search, $replace, $str);
		}
		function ConvertDate($sql_date)
		{
			$date = strtotime($sql_date);
			$return_date = date('Y-m-d', $date);
			return $return_date;
		}
		




?>