<?php

		include_once("../DBConn.php");
		require("../../../api/DBActions.php");

		$requestBody = file_get_contents('php://input');
		
		
		$ReqBody = json_decode($requestBody, true);


		$formData = $ReqBody;
		
		$retArr = array();
		
		try
		{

				$userID =  isset($formData['user_id']) ? (int) $formData['user_id'] : 0;
				$sessionID = isset($formData['session_id']) ? (int) $formData['session_id'] : 0;
				$sessionToken = isset($formData['session_token']) ? XSSFilter($formData['session_token']) : "";
				$priority = isset($formData['priority']) ? (int) XSSFilter($formData['priority']) : "";
				$vac_id = isset($formData['vac_id']) ? (int) XSSFilter($formData['vac_id']) : "";
				
				$link = DBLink();

				$fromDate=date("Y-m-d");
				$toDate=date("Y-m-d");
				$fromdate_d = ConvertDate($fromDate)." 00:00:00";
				$todate_d = ConvertDate($toDate)." 23:59:59";


				$chkSession = "SELECT * FROM admin_sessions us 
										LEFT JOIN admin_users ud ON us.user_id=ud.user_id WHERE us.session_id=$sessionID AND us.session_token='$sessionToken' AND us.login_status=1";
				$sessionCount = rtnRowCount($link,$chkSession);

				//echo $sessionCount;exit;

				if($sessionCount==0){
					$retArr["status"] = 4;
					$retArr["data"] = [];
					die(json_encode($retArr));
				}

				$where = "";
				$conditions = [];
				
				if ($priority == 0 || $priority == 1) {
					$conditions[] = "rm.priority = $priority";
				}
				
				if (!empty($vac_id)) {
					$conditions[] = "rm.vac_id = $vac_id";
				}
				
				if (!empty($conditions)) {
					$where = " WHERE " . implode(" AND ", $conditions);
				}
				

					$statusQry = "SELECT 
									SUM(CASE WHEN rm.request_status = 2 THEN 1 ELSE 0 END) AS submit,
									SUM(CASE WHEN rm.request_status = 3 THEN 1 ELSE 0 END) AS review,
									SUM(CASE WHEN rm.request_status = 4 THEN 1 ELSE 0 END) AS blocked,
									SUM(CASE WHEN rm.request_status = 5 THEN 1 ELSE 0 END) AS resubmit,
									SUM(CASE WHEN rm.request_status = 6 THEN 1 ELSE 0 END) AS verified,
									SUM(CASE WHEN rm.request_status = 7 THEN 1 ELSE 0 END) AS pverified,
									SUM(CASE WHEN rm.request_status = 8 THEN 1 ELSE 0 END) AS approved,
									SUM(CASE WHEN rm.request_status = 9 THEN 1 ELSE 0 END) AS parroved,
									SUM(CASE WHEN rm.request_status = 10 THEN 1 ELSE 0 END) AS declined,
									SUM(CASE WHEN rm.request_status = 11 THEN 1 ELSE 0 END) AS pfailure,
									SUM(CASE WHEN rm.request_status = 12 THEN 1 ELSE 0 END) AS paid,
									SUM(CASE WHEN rm.request_status = 13 THEN 1 ELSE 0 END) AS allotted,
									SUM(CASE WHEN rm.request_status = 14 THEN 1 ELSE 0 END) AS paymentlink_expired,
									SUM(CASE WHEN rm.request_status = 15 THEN 1 ELSE 0 END) AS application_received,
									SUM(CASE WHEN rm.request_status = 16 THEN 1 ELSE 0 END) AS partialy_received,
									SUM(CASE WHEN rm.request_status = 17 THEN 1 ELSE 0 END) AS no_show
								FROM request_master rm
								LEFT JOIN request_details rd ON rm.request_id = rd.request_id
								$where"; 
		 
			$TempResult = ExecuteReader($link, $statusQry);

					$where_now = " WHERE (CONVERT_TZ(rm.updated_on, '+00:00', '+05:30') BETWEEN '$fromdate_d' AND '$todate_d')";

					if ($priority == 0 || $priority == 1) {
						$where_now .= " AND rm.priority = $priority";
					}

					if (!empty($vac_id)) {
						$where_now .= " AND rm.vac_id = $vac_id";
					}



					$statusQry_CurrentDate = "SELECT 
						COALESCE(SUM(CASE WHEN rm.request_status = 2 THEN 1 ELSE 0 END), 0) AS current_submit,
						COALESCE(SUM(CASE WHEN rm.request_status = 3 THEN 1 ELSE 0 END), 0) AS current_review,
						COALESCE(SUM(CASE WHEN rm.request_status = 4 THEN 1 ELSE 0 END), 0) AS current_blocked,
						COALESCE(SUM(CASE WHEN rm.request_status = 5 THEN 1 ELSE 0 END), 0) AS current_resubmit,
						COALESCE(SUM(CASE WHEN rm.request_status = 6 THEN 1 ELSE 0 END), 0) AS current_verified,
						COALESCE(SUM(CASE WHEN rm.request_status = 7 THEN 1 ELSE 0 END), 0) AS current_pverified,
						COALESCE(SUM(CASE WHEN rm.request_status = 8 THEN 1 ELSE 0 END), 0) AS current_approved,
						COALESCE(SUM(CASE WHEN rm.request_status = 9 THEN 1 ELSE 0 END), 0) AS current_parroved,
						COALESCE(SUM(CASE WHEN rm.request_status = 10 THEN 1 ELSE 0 END), 0) AS current_declined,
						COALESCE(SUM(CASE WHEN rm.request_status = 11 THEN 1 ELSE 0 END), 0) AS current_pfailure,
						COALESCE(SUM(CASE WHEN rm.request_status = 12 THEN 1 ELSE 0 END), 0) AS current_paid,
						COALESCE(SUM(CASE WHEN rm.request_status = 13 THEN 1 ELSE 0 END), 0) AS current_allotted,
						COALESCE(SUM(CASE WHEN rm.request_status = 14 THEN 1 ELSE 0 END), 0) AS current_paymentlink_expired,
						COALESCE(SUM(CASE WHEN rm.request_status = 15 THEN 1 ELSE 0 END), 0) AS current_application_received,
						COALESCE(SUM(CASE WHEN rm.request_status = 16 THEN 1 ELSE 0 END), 0) AS current_partialy_received,
						COALESCE(SUM(CASE WHEN rm.request_status = 17 THEN 1 ELSE 0 END), 0) AS current_no_show
					FROM request_master rm
					LEFT JOIN request_details rd ON rm.request_id = rd.request_id
					$where_now"; 


			$TempResult_CurrentDate = ExecuteReader($link, $statusQry_CurrentDate);		
			
			mysqli_close($link);

			$retArr["status"] = 1;
			$retArr["data"] = $TempResult;
			$retArr["current_data"] = $TempResult_CurrentDate;
			
            die(json_encode($retArr));
		}
		catch(Exception $err)
		{
			
		
		}
		catch( Throwable $e)
		{
			
		}
		function XSSFilter($str)
		{ 
			$search = array("<", '>', '&lt;','&gt;','&#x3C;','&#x3E;',"'","&apos;","&#x27;","(",")","%");
			$replace = "";
			
			return str_replace($search, $replace, $str);
		}
		function ConvertDate($sql_date)
		{
			$date = strtotime($sql_date);
			$return_date = date('Y-m-d', $date);
			return $return_date;
		}
		




?>