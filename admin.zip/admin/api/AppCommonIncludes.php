<?php

include_once("App.Config.php");
// include_once("EncDecryption/cryptojs-aes.php");  
include_once("EncDecryption/EncDecryption.php");  

include_once("DBConn.php");

include_once("DbPhp/DBConnV2.php");
include_once("DbPhp/DBActionsV2.php");

include_once("CommonFunctions/commonFunction.php");
include_once("Requests/requestHandlr.V3.php");
include_once("Response/responseHandlr.php");
include_once("LogFileHandler/logFile.php");
include_once("APPCONSTANTS.php"); 

include_once("../Includes/ParamChecks.php");
include_once("../Includes/ParamList.php");

include_once("../Validations/ValidationMain.php");

include_once("../Includes/HFEncDecryption.php");

// include_once("EncDecryption/cryptojs-aes.php");  


?>