<?php

$DEV_MODE_ENABLED = (isset($_REQUEST["DEV"]) ? true : false);

if ($DEV_MODE_ENABLED) {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
}

include_once("../AppCommonIncludes.php");

// $tmpJsonRequest = json_decode($ObjRequestData->InputDataNonXSS);
$tmpJsonRequest = json_decode($ObjRequestData->InputData);

$tmpObj = new UpdtDocsGlbMain($tmpJsonRequest);

class UpdtDocsGlbMain
{
    function __construct($InputData)
    {
        PrintResultCombine("UpdtDocsGlbMain", $InputData);

        // $this->glbPartnerID = (isset($InputData->partner_id) ? $InputData->partner_id : 0);

        global $DEV_MODE_ENABLED;

        $this->MainProcess($InputData);
    }
    function MainProcess($InputData)
    {
        global $paramListUpdatDocs;
        PrintResultCombine("MainProcess-IP", $InputData);

        ValidationMain($paramListUpdatDocs, (array) $InputData);
        $this->UpdtGlbCaseList($InputData);
    }

    function UpdtGlbCaseList($InputData)
    {
        // PrintResultCombine("UpdtCaseList-IP", $InputData);

        $pdo = GetPDOConnection();

        $TempParamIn = array();
        $TempParamIn[":ProcessID"] = PROCESS_ID_UPDATEDOCS;
        $TempParamIn[":SessToken"] = $InputData->sessionToken;
        $TempParamIn[":SessID"] = $InputData->session_id;

        $TempParamIn[":RequestID"] = $InputData->reqId;
        $TempParamIn[":DetailsID"] = $InputData->dtlId;
        $TempParamIn[":DocID"] = $InputData->docId;
        $TempParamIn[":DocStatus"] = $InputData->status;
        $TempParamIn[":ReasonCode"] = $InputData->reason;
        // $TempParamIn[":Comments"] = $InputData->comments; 
        $TempParamIn[":Comments"] = HtmlToChars($InputData->comments);
        $TempParamIn[":Token"] = GenerateToken();



        $Query = "CALL ProcUpdateGlbDocs ( :ProcessID, :SessID, :SessToken ,:Token,:RequestID, :DetailsID, :DocID, :DocStatus ,:ReasonCode, :Comments)";

        $QueryLog = "CALL ProcUpdateGlbDocs (" . $TempParamIn[":ProcessID"] . "," . $TempParamIn[":SessID"] . ",'" . $TempParamIn[":SessToken"] . "','" . $TempParamIn[":Token"] . "'," . $TempParamIn[":RequestID"] . "," . $TempParamIn[":DetailsID"] . "," . $TempParamIn[":DocID"] . ",'" . $TempParamIn[":DocStatus"] . "','" . $TempParamIn[":ReasonCode"] . "','" . $TempParamIn[":Comments"] . "')";



        // errorLogV2("UpdtDocsGlbMain-Query::" . print_r($QueryLog, true));


        PrintResultCombine("UpdtDocsGlbMain-Query", $QueryLog);

        $RetResult = ReadDBData($pdo, $Query, $TempParamIn);

        // echo "<hr>SP-RetResult";
        // print_r($RetResult);
        ResponsePlainDefault($RetResult[0]["Result"], SUCCESS_OK);

        return;
    }

    function GetDBParams($aResult)
    {

        $TmpDBArray = array();

        $TmpDBArray["session_id"] = $this->SessionID;


        return $TmpDBArray;


    }


}


?>