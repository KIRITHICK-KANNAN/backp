<?php 

include_once("../AppCommonIncludes.php");

$tmpJsonRequest = json_decode($ObjRequestData->InputData);

$tmpObj = new ChangeVACMain($tmpJsonRequest);

class ChangeVACMain
{
    function __construct($InputData)
    {
        PrintResultCombine("ChangeVACMain", $InputData);

        global $DEV_MODE_ENABLED;

        $this->MainProcess($InputData);
    }
    function MainProcess($InputData)
    {
        global $paramListChangeVac;

        ValidationMain($paramListChangeVac, (array) $InputData);
        $this->UpdateVAC($InputData);
    }

    function UpdateVAC($InputData)
    {
        $pdo = GetPDOConnection();

        $TempParamIn = array();
        $TempParamIn[":ProcessID"] = PROCESS_ID_CASELIST;
        $TempParamIn[":SessID"] = $InputData->session_id;
        $TempParamIn[":SessToken"] = $InputData->session_token;
        $TempParamIn[":ReqestID"] = $InputData->request_id;
        $TempParamIn[":NewVACId"] = $InputData->new_vac_id;
        $TempParamIn[":OldVACId"] = $InputData->old_vac_id;

        $Query = "CALL ProcUpdateVAC ( :ProcessID, :SessID, :SessToken , :ReqestID , :NewVACId,:OldVACId)";

        PrintResultCombine("UpdateVAC-Query", $Query);
        PrintResultCombine("UpdateVAC-DB-ParamIn", $TempParamIn);

        $RetResult = ReadDBData($pdo, $Query, $TempParamIn);
 
        ResponsePlainDefault($RetResult[0]["Result"], SUCCESS_OK); 


        return;
    }
}

?>