<?php

$DEV_MODE_ENABLED = (isset($_REQUEST["DEV"]) ? true : false);

if ($DEV_MODE_ENABLED) {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
}

include_once("../AppCommonIncludes.php");


$tmpJsonRequest = json_decode($ObjRequestData->InputData);

$tmpObj = new SearchCasesMain($tmpJsonRequest);

class SearchCasesMain
{
    function __construct($InputData)
    {
        PrintResultCombine("SearchCasesMain", $InputData);
        // errorLogV2("SearchCasesMain::" . print_r($InputData, true));

        // $this->glbPartnerID = (isset($InputData->partner_id) ? $InputData->partner_id : 0);

        global $DEV_MODE_ENABLED;

        $this->MainProcess($InputData);
    }
    function MainProcess($InputData)
    {
        global $paramListSearcgCases;

        $TmpResponse = array();

        ValidationMain($paramListSearcgCases, (array) $InputData);
        $this->GetCaseList($InputData);
    }

    function GetCaseList($InputData)
    {
        /* 
        { "session_id":20,"sessionToken":"trtr55454vfgf","keyword":"test","keyType":1,"key":"985474","vac":1,"dateType":1,"from":"2024-11-23","to":"2024-11-25","status": 10,"startRecord": 1,"rows": 1}
          */

        $pdo = GetPDOConnection();

        $TempParamIn = array();
        $TempParamIn[":ProcessID"] = PROCESS_ID_SEARCHCASE;
        $TempParamIn[":SessToken"] = $InputData->sessionToken;
        $TempParamIn[":SessID"] = $InputData->session_id;
        // $TempParamIn[":Keyword"] = $InputData->keyword;

        /* 10 mar 25 - VAPT - ENC-DEC */
        $TempParamIn[":Keyword"] = $this->GetDecrytionProcess($pdo, $InputData->session_id, $InputData->keyword, $InputData->keyType);

        $TempParamIn[":KeywordType"] = $InputData->keyType;
        $TempParamIn[":VAC"] = $InputData->vac;
        $TempParamIn[":DateType"] = $InputData->dateType;
        $TempParamIn[":CaseList"] = 0;

        $TempParamIn[":StartAt"] = $InputData->from;
        $TempParamIn[":EndAt"] = $InputData->to;
        $TempParamIn[":NoOfRows"] = $InputData->rows;

        if (isset($InputData->caseList)) {
            $TempParamIn[":ProcessID"] = PROCESS_ID_CASELIST;
            $TempParamIn[":CaseList"] = 1;
        }

        if (isset($InputData->xldwnld)) {
            $TempParamIn[":ProcessID"] = PROCESS_ID_XL_DOWNLOAD;
            $TempParamIn[":NoOfRows"] = 1000000;
        }

        $TempParamIn[":Status"] = $InputData->status;


        if ($InputData->startRecord >= 1) {
            $InputData->startRecord = $InputData->startRecord - 1;
        }
        $TempParamIn[":LimitStart"] = $InputData->startRecord;
        // $TempParamIn[":NoOfRows"] = $InputData->rows;

        if (isset($InputData->priority)) {
            $TempParamIn[":Priority"] = (int) $InputData->priority;

        } else {
            $TempParamIn[":Priority"] = -1;
        }

        if (VERSION_SEARCH_CASE_V2 == 1) {

            $Query = "CALL ProcSearchGetCasesV2(:ProcessID, :SessID, :SessToken, :Keyword, :KeywordType, :VAC, :DateType, :StartAt,:EndAt, :CaseList, :Status, :LimitStart, :NoOfRows, :Priority)";

            $QueryLog = "CALL ProcSearchGetCasesV2 (" . $TempParamIn[":ProcessID"] . "," . $TempParamIn[":SessID"] . ",'" . $TempParamIn[":SessToken"] . "','" . $TempParamIn[":Keyword"] . "'," . $TempParamIn[":KeywordType"] . "," . $TempParamIn[":VAC"] . "," . $TempParamIn[":DateType"] . ",'" . $TempParamIn[":StartAt"] . "','" . $TempParamIn[":EndAt"] . "'," . $TempParamIn[":CaseList"] . "," . $TempParamIn[":Status"] . "," . $TempParamIn[":LimitStart"] . "," . $TempParamIn[":NoOfRows"] . "," . $TempParamIn[":Priority"] . ")";

        } else {
            $Query = "CALL ProcSearchGetCases(:ProcessID, :SessID, :SessToken, :Keyword, :KeywordType, :VAC, :DateType, :StartAt,:EndAt, :CaseList, :Status, :LimitStart, :NoOfRows, :Priority)";

            $QueryLog = "CALL ProcSearchGetCases (" . $TempParamIn[":ProcessID"] . "," . $TempParamIn[":SessID"] . ",'" . $TempParamIn[":SessToken"] . "','" . $TempParamIn[":Keyword"] . "'," . $TempParamIn[":KeywordType"] . "," . $TempParamIn[":VAC"] . "," . $TempParamIn[":DateType"] . ",'" . $TempParamIn[":StartAt"] . "','" . $TempParamIn[":EndAt"] . "'," . $TempParamIn[":CaseList"] . "," . $TempParamIn[":Status"] . "," . $TempParamIn[":LimitStart"] . "," . $TempParamIn[":NoOfRows"] . "," . $TempParamIn[":Priority"] . ")";

        }






        PrintResultCombine("SearchCasesMain-Query", $QueryLog);
        // errorLogV2("SearchCasesMain-Query::" . print_r($QueryLog, true));
        PrintResultCombine("SearchCasesMain-DB-ParamIn", $TempParamIn);

        $RetResult = ReadDBData($pdo, $Query, $TempParamIn);

        PrintResultCombine("SearchCasesMain-DB-Results", $RetResult);

        if (count($RetResult) < 1) {
            ResponseDefault("NOROWS", SUCCESS_OK);

        }

        // ResponseDefault($RetResult, SUCCESS_OK);
        // ResponsePlainDefault($RetResult[0]["Result"], SUCCESS_OK);
        if (PASSPORT_ENCRYPTION == "NO") {
            ResponsePlainDefault($RetResult[0]["Result"], SUCCESS_OK);
        }

        HFEncryptions($RetResult);


        return;
    }

    function GetDecrytionProcess($argConn, $argSessionID, $argKeyword, $argKeyType)
    {
        if ($argKeyType != TYPE_PASSPORTNUMBER) {
            return $argKeyword;

        }

        if (PASSPORT_ENCRYPTION == "NO") {
            return $argKeyword;
        }

        $TempKey = $this->EncryptedKey($argConn, $argSessionID);

        if ($TempKey == "") {
            return $argKeyword;
        }
        PrintResultCombine("GetDecrytionProcess", $TempKey);
        PrintResultCombine("GetDecrytionProcess_VAls", $argKeyword);

        return HFDecryptions($argKeyword, $TempKey);

    }

    function EncryptedKey($argConn, $argSessionID)
    {
        $TempQuery = "SELECT encryption_key FROM admin_sessions WHERE session_id = :SessionID LIMIT 1 ";
        $TempParamIn = array();
        $TempParamIn[":SessionID"] = $argSessionID;

        PrintResultCombine("EncryptedKey_id", $argSessionID);

        $RetResult = ReadDBData($argConn, $TempQuery, $TempParamIn);
        PrintResultCombine("EncryptedKey_1", $RetResult);

        if ($RetResult) {
            $RetResult = $RetResult[0];
            return $RetResult["encryption_key"];
        }

        return "";
    }

    function GetDBParams($aResult)
    {

        $TmpDBArray = array();

        $TmpDBArray["session_id"] = $this->SessionID;


        return $TmpDBArray;


    }


}

function TestProcess()
{
    echo "<hr>TestProcess";
    global $ObjRequestData;

    $ObjRequestData->InputData = TempParamArray();


    echo "<hr>PArams";
    print_r($ObjRequestData->InputData);
    // $TmpRetVal = $this->SendParam($TmpInput);
    // echo "<hr>Results";
    // print_r($TmpRetVal);

}
function TempParamArray()
{
    return '{"session_id":10,"sessionToken":"LGF656565"}';
}

function TempResult()
{
    return '{"final_result":1}';

}


?>