<?php
// include_once("../../../api/commonFns.php");
// require("../../../api/DBConnection.php");
// require("../../../api/DBQueries.php");
// require("../../../api/DBActions.php");
function ApihitCount($argLink, $api_name, $userID){
    $query_check_hits = "SELECT COUNT(*) as hit_count FROM api_hits WHERE user_id ='$userID' AND api_name ='$api_name' AND last_access >= NOW() - INTERVAL 30 SECOND";
    return $hit_count = rtnRowCount($argLink,$query_check_hits);
    //$Result_Count = ExecuteReader($argLink, $query_check_hits);
    if ($hit_count >= 10) {
        return false;
    } else {
        $query_insert_hit = "INSERT INTO api_hits (user_id, api_name, last_access) VALUES ('$userID', '$api_name', NOW())";
        $hit_id = insertIntoDB_GetId($argLink,$query_insert_hit);
        return true;
    }        
}


function checkApiRateLimit($argLink, $userID, $api_name) {
    $query_check_hits = "SELECT COUNT(*) as hit_count 
                         FROM api_hits 
                         WHERE user_id = ? 
                         AND api_name = ? 
                         AND last_access >= NOW() - INTERVAL 30 SECOND";

    $stmt = mysqli_prepare($argLink, $query_check_hits);
    mysqli_stmt_bind_param($stmt, "is", $userID, $api_name);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $hit_count);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if ($hit_count >= 10) {
        return false; // Rate limit exceeded
    }

    // Insert new hit record
    $query_insert_hit = "INSERT INTO api_hits (user_id, api_name, last_access) VALUES (?, ?, NOW())";
    $stmt = mysqli_prepare($argLink, $query_insert_hit);
    mysqli_stmt_bind_param($stmt, "is", $userID, $api_name);
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    return $result; // Returns true if insert succeeds
}


?>