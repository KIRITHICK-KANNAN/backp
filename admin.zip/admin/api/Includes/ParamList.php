<?php
 
$paramListAdminRedFlags =
    [
        "session_id",
        "sessionToken",
        "detailId",
        "isRDFG"

    ];

$paramListAdminUpdatCases =
    [
        "session_id",
        "sessionToken",
        "actionIds"
    ];

//===========================
$paramListAssignMe =
    [
        "session_id",
        "sessionToken",
        "reqIds"
    ];
/* ======================== */
$paramListUpdatDocs =
    [
        "session_id",
        "sessionToken",
        "reqId",
        "dtlId",
        "docId",
        "status",
        "reason",
        "comments"
    ];

$paramListUpdatCases =
    [
        "session_id",
        "sessionToken",
        "reqId",
        "dtlId",
        "dtlStatus"
    ];

$paramListUpdatMaster =
    [
        "session_id",
        "sessionToken",
        "reqId",
        "reqStatus"
    ];


/* ======================== */
$paramListDocumentDetails =
    [
        "session_id",
        "sessionToken",
        // "docIds"
        "docId"
    ];

/* ======================== */




$paramListSearcgCases =
    [
        "session_id",
        "sessionToken",
        "keyword",
        "keyType", 
        "vac",
        "dateType",
        "from",
        "to",

        "status",
        "startRecord",
        "rows"

    ];

$paramListAgentCases =
    [
        "session_id",
        "sessionToken" //,
        // "keyword",
        // "keyType",
        // "key",
        // "vac",
        // "dateType",
        // "from",
        // "to"
    ];


$paramListCases =
    [
        "session_id",
        "sessionToken",
        "keyword"
    ];

$paramListSearchCases = [
    "user_id",
    "session_id",
    "sessionToken",
    "keyword",
    "from",
    "to",
    "searchText"
];

$paramListAgentList =
    [
        "session_id",
        "sessionToken",
        "reqId"
    ];

?>