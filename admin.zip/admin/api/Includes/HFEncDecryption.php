<?php

function HFEncryptions($RetResult)
{
    PrintResultCombine("HFEncryptions-Result", $RetResult);
    $TempJsonData = $RetResult[0]["Result"];
    PrintResultCombine("HFEncryptions-Result_1", $TempJsonData);

    $TempJsonData1 = json_decode($TempJsonData);

    PrintResultCombine("HFEncryptions-Result_2", $TempJsonData1->status);

    $TempFinalCollArray = array();
    $TempDetailCollArray = array();

    if ($TempJsonData1->status == 1) {

        // $MasterData = json_decode($RetResult[0]["Result"]["master"]);

        $MasterData = $TempJsonData1->master;
        $DetailsData = $TempJsonData1->details;
        $DocsData = $TempJsonData1->documents;
        $TotalRows = isset($TempJsonData1->totalRows) ? $TempJsonData1->totalRows : -1;
        $PPKey = isset($TempJsonData1->ppKy) ? $TempJsonData1->ppKy : -1;

        foreach ($DetailsData as $IData) {

            /* 
            JSON_OBJECT('dtlId', details_id,'reqId', dtl.request_id,'fName', first_name, 'lName',last_name, 'phone',mobile_number,  'dob', dob, 'ppn', passport_number, 'wpn', work_permit_number , 'wpndt',work_permit_issue_date, 'approvOn', dtl.approved_on, 'aprovdBy',dtl.approved_by,'dtlStatus',details_status,'slotAt',slot_time)) AS Result 
             */

            // echo "," . $IData->dtlId;
            $TempDetailArray = array();

            $TempDetailArray["dtlId"] = $IData->dtlId;
            $TempDetailArray["reqId"] = $IData->reqId;

            $TempDetailArray["fName"] = $IData->fName;
            $TempDetailArray["lName"] = $IData->lName;
            $TempDetailArray["phone"] = $IData->phone;

            $TempDetailArray["dob"] = $IData->dob;
            // $TempDetailArray["TempVal"] = $IData->ppn;
            // $TempDetailArray["ppk"] = $PPKey;

            // $TempDetailArray["ppn"] = cryptoJsAesEncrypt($IData->ppn,"bbe0a8784f21cec293ffa0d24e8d619b4992563d07d7ba743516a0c8356ce51f");

            // $password = Utils::decrypt($password,$encryption_key);
            // $TempDetailArray["ppn"] = encrypt($IData->ppn, "bbe0a8784f21cec293ffa0d24e8d619b4992563d07d7ba743516a0c8356ce51f");
            $TempDetailArray["ppn"] = encrypt($IData->ppn, $PPKey);

            $TempDetailArray["wpn"] = $IData->wpn;
            $TempDetailArray["wpndt"] = $IData->wpndt;

            $TempDetailArray["approvOn"] = $IData->approvOn;
            $TempDetailArray["aprovdBy"] = $IData->aprovdBy;
            $TempDetailArray["dtlStatus"] = $IData->dtlStatus;
            $TempDetailArray["slotAt"] = $IData->slotAt;

            if (VERSION_RED_FLAGED == 1) {
                $TempDetailArray["application_received_by"] = $IData->application_received_by;
                $TempDetailArray["application_received_on"] = $IData->application_received_on;
                $TempDetailArray["comment"] = $IData->comment;
                $TempDetailArray["red_flag"] = $IData->red_flag;

            }

            if (VERSION_WORK_DAYS == 1) {
                $TempDetailArray["work_permit_issue_days"] = $IData->work_permit_issue_days;
            }

            if (VERSION_SPONSOR == 1) {
                $TempDetailArray["sponsor"] = $IData->sponsor;
            }
            // if (isset($IData->application_received_by)) {
            // }

            // if (isset($IData->application_received_on)) {
            // }

            // if (isset($IData->comment)) {
            // }

            // if (isset($IData->red_flag)) {
            // }

            $TempDetailCollArray[] = $TempDetailArray;
        }

        $TempFinalCollArray["status"] = 1;
        if ($TotalRows != -1) {
            $TempFinalCollArray["totalRows"] = $TotalRows;
        }
        $TempFinalCollArray["master"] = $MasterData;
        $TempFinalCollArray["details"] = $TempDetailCollArray;
        $TempFinalCollArray["documents"] = $DocsData;
        ResponseDefault($TempFinalCollArray, SUCCESS_OK);

        // $DocsData = $RetResult[0]["Result"]["documents"];
    } else {
        ResponsePlainDefault($RetResult[0]["Result"], SUCCESS_OK);
    }



}

function HFDecryptions($argString, $argKey)
{
    return decrypt($argString, $argKey);
}

?>