<?php


function CheckParams($argParamList, $argInputData)
{
    foreach ($argParamList as $key => $value) {
        // echo ":Key:" . print_r($key,true);
        // echo "=:Value:" . print_r($value,true);
        // echo "<br>"; 
        if (!array_key_exists($value, $argInputData)) {
            //echo ",N/A:" . print_r($value);
            return 0;
            // break;
        } else {
            // echo "==::" . print_r($value);
        }
    }

    return 1;
}

function CheckParamAndResponse($argParamList, $argInputData)
{
    if (!CheckParams($argParamList, $argInputData)) {

        ResponseDefault("Invalid Payload", INVALID_PAYLOAD);
        return 0;
    } else {
        // ResponseDefault("VAlid Payload", 400);

    }
    return 100;
}

?>