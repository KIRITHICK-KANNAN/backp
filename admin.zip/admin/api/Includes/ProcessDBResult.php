<?php

    function ProcessDBResult($RetResult)
    {
        foreach($RetResult as $IData)
        {

        }
    }


?>