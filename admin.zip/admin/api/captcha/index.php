<?php 

		// include_once("../AppCommonIncludes.php");
		require("../DBConn.php");		
		require("../../../api/DBActions.php");		
		
		$returnArr=array();
		
		$isValidSession=false;
		$isError=false;
		
		$sessionId=0;
		
		if(!isset($_REQUEST["session_id"]))
		{
			$returnArr["status"]=2;  // Invalid Session
			header('Content-type: application/json');
			echo json_encode($returnArr);
			exit;
		}
		
		$link=DBLink(); 
		try
		{		
			
	
			$sessionId=(int) $_REQUEST["session_id"];
			
			$chkQry="SELECT * FROM admin_sessions WHERE session_id=$sessionId AND login_status=0 LIMIT 1";
			$result=mysqli_query($link,$chkQry);
			
			$count=0;
			
			if($result)
			   $count=mysqli_num_rows($result);	
			
			
			if($count>0)
				$isValidSession=true;
			else
				$returnArr["status"]=2;  // Invalid Session
		}
		catch(Exception $err)
		{
			$returnArr["status"]=3;			// Error in Processing
			$isError=true;
			
			
		}
				
		if((!$isValidSession)||($isError))
		{
			
			header('Content-type: application/json');
			echo json_encode($returnArr);
			exit;
		
		}
	
			$captcha_image_height = 50;
			$captcha_image_width = 130;
			$captcha_image = @imagecreate(
			 $captcha_image_width,
			 $captcha_image_height
			 );
			$background_color = imagecolorallocate(
			 $captcha_image,
			 255,
			 255,
			 255
			 );
			
			$random_captcha_dots = 50;
			$captcha_noise_color = "0x142864";
			$array_noise_color = hextorgb($captcha_noise_color);
			 
			$image_noise_color = imagecolorallocate(
			 $captcha_image,
			 $array_noise_color['red'],
			 $array_noise_color['green'],
			 $array_noise_color['blue']
			 );
			 
			for( $count=0; $count<$random_captcha_dots; $count++ ) {
			imagefilledellipse(
			 $captcha_image,
			 mt_rand(0,$captcha_image_width),
			 mt_rand(0,$captcha_image_height),
			 2,
			 3,
			 $image_noise_color
			 );
			}
			 
			function hextorgb ($hexstring){
			  $integar = hexdec($hexstring);
			  return array("red" => 0xFF & ($integar >> 0x10),
						   "green" => 0xFF & ($integar >> 0x8),
						   "blue" => 0xFF & $integar);
				}
						
			$random_captcha_lines = 25;
			 
			for( $count=0; $count<$random_captcha_lines; $count++ ) {
			imageline(
			 $captcha_image,
			 mt_rand(0,$captcha_image_width),
			 mt_rand(0,$captcha_image_height),
			 mt_rand(0,$captcha_image_width),
			 mt_rand(0,$captcha_image_height),
			 $image_noise_color
			 );
			}
			
			
			$captcha_code = '';
			$total_characters_on_image = 6;
			$possible_captcha_letters = 'EFGHIJKLbcdfghjkmnpqrstvwxyzABCD23456789';
			$captcha_font = '../captcha/monofont.ttf';
			$captcha_text_color = "0x142864";
			 
			$count = 0;
			while ($count < $total_characters_on_image) { 
			$captcha_code .= substr(
			 $possible_captcha_letters,
			 mt_rand(0, strlen($possible_captcha_letters)-1),
			 1);
			$count++;
			}
			
			$upDat="UPDATE admin_sessions SET captcha_id='$captcha_code' WHERE session_id=$sessionId LIMIT 1";
			
			mysqli_query($link,$upDat);// or die(mysqli_error($link));
		
			$captcha_font_size = $captcha_image_height * 0.65;
			 
			$array_text_color = hextorgb($captcha_text_color);
			$captcha_text_color = imagecolorallocate(
			 $captcha_image,
			 $array_text_color['red'],
			 $array_text_color['green'],
			 $array_text_color['blue']
			 );
			 
			$text_box = imagettfbbox(
			 $captcha_font_size,
			 0,
			 $captcha_font,
			 $captcha_code
			 ); 
			$x = ($captcha_image_width - $text_box[4])/2;
			$y = ($captcha_image_height - $text_box[5])/2;
			imagettftext(
			 $captcha_image,
			 $captcha_font_size,
			 0,
			 $x,
			 $y,
			 $captcha_text_color,
			 $captcha_font,
			 $captcha_code
			 );
			 
			mysqli_close($link);
			
			header('Content-Type: image/jpeg'); 
			imagejpeg($captcha_image);
			
	?>