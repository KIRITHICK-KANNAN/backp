<?php
		
		$apiRpJson=array();
		$isOk=false;
		$dbConn="";
		
		
		function XSSFilter($str)
		{ 
			$search = array("<", '>', '&lt;','&gt;','&#x3C;','&#x3E;',"'","&apos;","&#x27;","(",")","%");
			$replace = "";
			
			return str_replace($search, $replace, $str);
		}
		
		function GenerateToken()
		{
			$miootToken=md5(uniqid(rand(), TRUE));
			return $miootToken;
		}
		function getRealIpAddr()
		{
			if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
			{
			  $ip=$_SERVER['HTTP_CLIENT_IP'];
			}
			elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
			{
			  $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
			}
			else
			{
			  $ip=$_SERVER['REMOTE_ADDR'];
			}
			return $ip;
		}
		function generateRandomString($length = 16) 
		{
			$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$randomString = '';
			for ($i = 0; $i < $length; $i++) {
			   $randomString .= $characters[rand(0, strlen($characters) - 1)];
			}
   			 return $randomString;
		}
		function generateRandomNumber($length = 6) 
		{
			$characters = '123456789';
			$randomString = '';
			for ($i = 0; $i < $length; $i++) {
			   $randomString .= $characters[rand(0, strlen($characters) - 1)];
			}
			 return $randomString;
		}
		function generatePassword($length = 8) 
		{
			$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$randomString = '';
			for ($i = 0; $i < $length; $i++) {
			   $randomString .= $characters[rand(0, strlen($characters) - 1)];
			}
   			 return $randomString;
		}
		function IsEmail($emailId) {
			return (!preg_match(
		"^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^", $emailId))
				? FALSE : TRUE;
		}
		function generateEncryptionKey($length = 16) {
			$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; // Upper and lower case letters
			$key = '';
			$maxIndex = strlen($characters) - 1;
			
			for ($i = 0; $i < $length; $i++) {
				$key .= $characters[random_int(0, $maxIndex)];
			}
			
			return $key;
		}
		
		
		

?>
