<?php

$DEV_MODE_ENABLED = (isset($_REQUEST["DEV"]) ? true : false);

if ($DEV_MODE_ENABLED) {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
}

include_once("../AppCommonIncludes.php");

$tmpJsonRequest = json_decode($ObjRequestData->InputData);

$tmpObj = new UpdateRedFlagMain($tmpJsonRequest);

class UpdateRedFlagMain
{
    function __construct($InputData)
    {
        PrintResultCombine("UpdateRedFlagMain", $InputData);

        // $this->glbPartnerID = (isset($InputData->partner_id) ? $InputData->partner_id : 0);

        global $DEV_MODE_ENABLED;

        $this->MainProcess($InputData);
    }
    function MainProcess($InputData)
    {
        global $paramListAdminRedFlags;

        ValidationMain($paramListAdminRedFlags, (array) $InputData);
        $this->UpdtRedFlag($InputData);
    }

    function UpdtRedFlag($InputData)
    {

        $pdo = GetPDOConnection();

        $TempParamIn = array();
        $TempParamIn[":ProcessID"] = PROCESS_ID_UPDATEVERDICT;
        $TempParamIn[":SessToken"] = $InputData->sessionToken;
        $TempParamIn[":SessID"] = $InputData->session_id;
        $TempParamIn[":DetlID"] = $InputData->detailId; 
        $TempParamIn[":RedFlag"] = $InputData->isRDFG; 
 
        $Query = "CALL ProcUpdateRedFlag ( :ProcessID, :SessID, :SessToken ,:DetlID,:RedFlag)";
        PrintResultCombine("UpdtRedFlag", $Query);
        PrintResultCombine("UpdtRedFlagParam", $TempParamIn);

        $RetResult = ReadDBData($pdo, $Query, $TempParamIn);

        // echo "<hr>SP-RetResult";
        // print_r($RetResult);
        ResponsePlainDefault($RetResult[0]["Result"], SUCCESS_OK); 
        return;
    } 

}
 


?>