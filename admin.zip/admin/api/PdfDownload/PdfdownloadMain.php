<?php


error_reporting(E_ALL);
ini_set('display_errors', 1);


include_once("../AppCommonIncludes.php");
require("../../../api/DBActions.php");

require_once("../../../../../PdfGenerator/dompdf/autoload.inc.php");




$requestBody = file_get_contents('php://input');
// Decode the JSON data
$ReqBody = json_decode($requestBody, true);


$formData = $ReqBody;


$userID =  isset($formData['user_id']) ? (int) $formData['user_id'] : 0;
$sessionID = isset($formData['session_id']) ? (int) $formData['session_id'] : 0;
$sessionToken = isset($formData['sessionToken']) ? $formData['sessionToken'] : "";
$from_date = isset($formData['from_date']) ? (int) $formData['from_date'] : "";
$to_date = isset($formData['to_date']) ? (int) $formData['to_date'] : "";

$link = DBLink();


$query_session_check = "SELECT * FROM admin_sessions us
                        LEFT JOIN user_details ud ON us.user_id=ud.user_id WHERE us.user_id = '$userID' AND us.session_id='$sessionID' AND us.session_token='$sessionToken' AND us.login_status=1";
$sessionCount = ExecuteReader($link,$query_session_check);

if(count($sessionCount)==0){
    $retArr["status"] = 3;
    $retArr["msg"] = "Invalid session";
    $retArr["data"] = [];
    die(json_encode($retArr));
}

// exit;
$retArr = array();



$TmpResult = getManifestList($link, $formData);

if (count($TmpResult) == 0) {
    $retArr["status"] = 2;
    $retArr["msg"] = "No data Found";
    $retArr["data"] = $TmpResult;
    die(json_encode($retArr));
}



$fileName = 'Appointment_Manifest_' . $from_date . "_" . $to_date . '.pdf';

$list = '<table class="table accordion table-responsive table-bordered text-left table2excel accordion-collapse p-2" id="grid-table">';	
$list .= '<thead>';
$list .= '<tr>';		
$list .= '<th scope="col">Request ID</th>';
$list .= '<th scope="col">Child Reference No</th>';
$list .= '<th scope="col">Added On</th>';
$list .= '<th scope="col">Submited On</th>';
$list .= '<th scope="col">Full Name</th>';
$list .= '<th scope="col">Email Id</th>';
$list .= '<th scope="col">Passport Number</th>';
$list .= '<th scope="col">Nulla osta No</th>';
$list .= '<th scope="col">Issue Date</th>';
$list .= '<th scope="col">VAC</th>';
$list .= '<th scope="col">Amount</th>';
$list .= '<th scope="col">Tracking ID</th>';
$list .= '<th scope="col">Payment Reference No</th>';		
$list .= '<th scope="col">Slot Date</th>';
$list .= '<th scope="col">Slot Time</th>';
$list .= '</tr>';
$list .= '</thead>';    
$list .= '<tbody style="background:#fff;">';

if(count($TmpResult)>0){

    foreach ($TmpResult as $index => $slot) {
        $list .= '<tr>';
        $list .= '<td align="center">' . htmlspecialchars($slot['request_id']) . '</td>';
        $list .= '<td align="center">' . htmlspecialchars($slot['child_id']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['added_on']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['submitted_on']) . '</td>';
        $list .= '<td style="text-align: left;">' . htmlspecialchars($slot['full_name']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['email_id']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['passport_number']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['work_permit_number']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['work_permit_issue_date']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['vac_name']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['total_amount']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['tracking_id']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['bank_ref_no']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['slot_date']) . '</td>';
        $list .= '<td>' . htmlspecialchars($slot['slot_time']) . '</td>';
        $list .= '</tr>';
    }
    $list .= '</tbody>';			
    $list .= '</table>';
}

$html = $list;


use Dompdf\Dompdf;
use Dompdf\Options;



$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

$canvas = $dompdf->getCanvas();
$font = $dompdf->getFontMetrics()->get_font("Arial", "normal");
$canvas->page_text(270, 820, "Page {PAGE_NUM} of {PAGE_COUNT}", $font, 12, array(0, 0, 0));

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $fileName . '"');
header('Cache-Control: public');

$dompdf->stream($fileName, array("Attachment" => 1));
exit;


// $retArr["status"] = 1;
// $retArr["type"] = 1;
// $retArr["msg"] = "";
// $retArr["data"] = $TmpResult;
// die(json_encode($retArr));


function ConvertDate($sql_date)
{
    $date = strtotime($sql_date);
    $return_date = date('Y-m-d', $date);
    return $return_date;
}
function ToDate($sql_date)
{
    $date = strtotime($sql_date);
    $return_date = date('d-m-Y', $date);
    return $return_date;
}

function getManifestList($argLink, $formData)
{
    $userID =  isset($formData['user_id']) ? (int) $formData['user_id'] : 0;
    $sessionID = isset($formData['session_id']) ? (int) $formData['session_id'] : 0;
    $sessionToken = isset($formData['sessionToken']) ? (int) $formData['sessionToken'] : "";
    
    if(isset($formData["from_date"])) $fromDate=XSSFilter($formData["from_date"]); else $fromDate=date("Y-m-d");
    if(isset($formData["to_date"])) $toDate=XSSFilter($formData["to_date"]); else $toDate=date("Y-m-d");

    $vac_id =  isset($formData['vac_id']) ? (int) $formData['vac_id'] : "";



    $tDate = date("Y-m-d");

    if (isset($fromDate))
        $fromDate = $fromDate;
    else
        $fromDate = $tDate;

    if (isset($toDate))
        $toDate = $toDate;
    else
        $toDate = $tDate;

    $fDate = ToDate($fromDate);
    $tDate = ToDate($toDate);
    $fromdate_d = ConvertDate($fromDate)." 00:00:00";
    $todate_d = ConvertDate($toDate)." 23:59:59";




    $active_status = "";
			$where = "";

    if ($formData["from_date"]!=="" && $formData["to_date"]!=="") {
        if ($where !== "") $where .= " AND ";
        $where .= "(rd.slot_time BETWEEN '$fromdate_d' AND '$todate_d')";
    }	

    if (isset($formData["vac_id"]) && (int)$formData["vac_id"] !== 0) {
        if ($where !== "") {
            $where .= " AND ";
        }
        $vac_id = (int)$formData["vac_id"];
        $where .= " rm.vac_id = '$vac_id'";
    }


    $where .= " AND rd.details_status = '13'";
    $where .= " AND rm.request_status = '13'";


   $getQuery = "SELECT 
                    DATE_FORMAT(DATE(rd.slot_time), '%d-%m-%Y') AS slot_date,
                    TIME_FORMAT(rd.slot_time, '%H:%i') AS slot_time,
                    CONCAT(rd.first_name, ' ', rd.last_name) AS full_name,                    
                    DATE_FORMAT(CONVERT_TZ(rd.added_on, '+00:00', '+05:30'), '%d-%m-%Y %H:%i:%s') AS added_on,
                    DATE_FORMAT(CONVERT_TZ(rm.submitted_on, '+00:00', '+05:30'), '%d-%m-%Y %H:%i') AS submitted_on,
                    rm.email_id,
                    rm.tracking_id,
                    rm.bank_ref_no,
                    rd.mobile_number,
                    rm.total_amount,
                    rd.dob,
                    rd.passport_number,
                    rd.work_permit_number,
                    rd.work_permit_issue_date,
                    rd.details_id,
                    rd.request_id,
                    rm.request_id,
                    rd.child_id,
                    vl.vac_name
                FROM request_details rd
                LEFT JOIN request_master rm ON rd.request_id=rm.request_id
                LEFT JOIN vac_list vl ON rm.vac_id=vl.vac_id
                WHERE rd.details_id IS NOT NULL " .
                ($where !== "" ? " AND $where" : "") .
                " ORDER BY rd.slot_time ASC";     


    $count = rtnRowCount($argLink,$getQuery);
   // echo ",SessionQry:".$TempQry;
    $TempResult = ExecuteReader($argLink, $getQuery);

    return $TempResult;

}


//===============

?>