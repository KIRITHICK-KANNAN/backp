<?php

include("../../Common.php");
include(DBCONNECTION);
include(SLOTAPI);
$db = new DBQuery($__con);
$slot = new Slots($__con);
$slot->slots(); 
exit;

?>