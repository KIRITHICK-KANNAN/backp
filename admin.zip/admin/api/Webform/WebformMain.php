<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
include("../../Common.php");
include("../commonFns.php");
include(DBCONNECTION);
include(SESEXPIREDAPI);
include(HOLIDAYAPI);
//include("/var/www/html/vfseu_mioot/globalAPIs/dataFilters/xss_filter.php");
$db = new DBQuery($__con);
$validator = new XSSFilter();

//$holiday = new Holiday($__con);
//$holiday->getwebFormValues(); 


//public function getwebFormValues($rules=[],$messages=[]) {

	$retArr = array();
    $rules=[];
    $messages=[];
	$data = json_decode(file_get_contents("php://input"),true);
	if(!$data || !count($data)) {
		die(json_encode(["status"=>2,"msg"=>"Invalid credential"]));
	}
	$res = $validator->xssFilter($data,$rules,$messages);
	if(count($res)) {

	}
	extract($data);			


   // print_r($data);exit;

	$res = $db->find("SELECT * FROM admin_sessions WHERE session_id = :session_id AND session_token = :session_token AND login_status = 1",["session_id" => $session_id,"session_token" => $session_token]);

	if (count($res) == 0) {
		$retArr["status"] = 1;
		$retArr["msg"] = "Invalid session";
		$retArr["data"] = [];
		die(json_encode($retArr));
	}

	$status='';


	$status='status';


	if($type==1){

		//$res = $db->query("SELECT * FROM form_on_off", []);
		$res = $db->query("SELECT * FROM vac_list WHERE $status=1 AND is_form_off IS NOT NULL ", []);
		if (count($res) == 0) {
			$retArr["status"] = 1;
			$retArr["msg"] = "No data Found";
			$retArr["data"] = $res;
			die(json_encode($retArr));
		}
	}
	if($type==2){

		$web_form_on_of = (int)$web_form_on_of;
        $priority_is_form_off = $priority_is_form_off;

		if ($priority_is_form_off == 'all' && $vac_id == 'all') {
			$update_qry = "UPDATE vac_list 
						SET priority_is_form_off = :priority_is_form_off,
							is_form_off = :is_form_off,
							updated_on = NOW(),
							updated_by = :user_id 
						WHERE status = 1";
			$update_done = $db->query($update_qry, [
				"priority_is_form_off" => $web_form_on_of,
				"is_form_off" => $web_form_on_of,
				"user_id" => $user_id
			]);
		}

		if ($priority_is_form_off == 0 && $vac_id == 'all') {
			$update_qry = "UPDATE vac_list 
						SET is_form_off = :is_form_off,
							updated_on = NOW(),
							updated_by = :user_id 
						WHERE status = 1";
			$update_done = $db->query($update_qry, [
				"is_form_off" => $web_form_on_of,
				"user_id" => $user_id
			]);
		}

		if ($priority_is_form_off == 1 && $vac_id == 'all') {
			$update_qry = "UPDATE vac_list 
						SET priority_is_form_off = :priority_is_form_off,
							updated_on = NOW(),
							updated_by = :user_id 
						WHERE status = 1";
			$update_done = $db->query($update_qry, [
				"priority_is_form_off" => $web_form_on_of,
				"user_id" => $user_id
			]);
		}

		if ($priority_is_form_off != 'all' && $vac_id != 'all') {
			if ($priority_is_form_off == 0) {
				$update_qry = "UPDATE vac_list 
							SET is_form_off = :is_form_off,
								updated_on = NOW(),
								updated_by = :user_id 
							WHERE status = 1 AND vac_id = :vac_id";
				$update_done = $db->query($update_qry, [
					"is_form_off" => $web_form_on_of,
					"user_id" => $user_id,
					"vac_id" => $vac_id
				]);
			}

			if ($priority_is_form_off == 1) {
				$update_qry = "UPDATE vac_list 
							SET priority_is_form_off = :priority_is_form_off,
								updated_on = NOW(),
								updated_by = :user_id 
							WHERE status = 1 AND vac_id = :vac_id";
				$update_done = $db->query($update_qry, [
					"priority_is_form_off" => $web_form_on_of,
					"user_id" => $user_id,
					"vac_id" => $vac_id
				]);
			}
		}







		
		// else if($priority_is_form_off=='all'){			
		// 	$update_qry = "UPDATE vac_list SET priority_is_form_off = :priority_is_form_off,updated_on = NOW(),updated_by=:user_id WHERE $status=1";
		// 	$update_done = $db->query($update_qry, ["priority_is_form_off" => $priority_is_form_off,"user_id" => $user_id]);
		// }else if($vac_id=='all'){			
		// 	$update_qry = "UPDATE vac_list SET is_form_off = :is_form_off,updated_on = NOW(),updated_by=:user_id WHERE $status=1";
		// 	$update_done = $db->query($update_qry, ["is_form_off" => $web_form_on_of,"user_id" => $user_id]);
		// }else{
		// 	$update_qry = "UPDATE vac_list SET priority_is_form_off=:priority_is_form_off,is_form_off = :is_form_off,updated_on = NOW(),updated_by=:user_id WHERE $status=1 AND vac_id=:vac_id";
		// 	$update_done = $db->query($update_qry, ["priority_is_form_off" => $priority_is_form_off,"is_form_off" => $web_form_on_of,"user_id" => $user_id,"vac_id" => $vac_id]);
		// }
        
        
        // if($vac_id=='all'){			
		// 	$update_qry = "UPDATE vac_list SET priority_is_form_off=:priority_is_form_off,is_form_off = :is_form_off,updated_on = NOW(),updated_by=:user_id WHERE $status=1";
		// 	$update_done = $db->query($update_qry, ["priority_is_form_off" => $priority_is_form_off,"is_form_off" => $web_form_on_of,"user_id" => $user_id]);
		// }else{
		// 	$update_qry = "UPDATE vac_list SET priority_is_form_off=:priority_is_form_off,is_form_off = :is_form_off,updated_on = NOW(),updated_by=:user_id WHERE $status=1 AND vac_id=:vac_id";
		// 	$update_done = $db->query($update_qry, ["priority_is_form_off" => $priority_is_form_off,"is_form_off" => $web_form_on_of,"user_id" => $user_id,"vac_id" => $vac_id]);
		// }

		if($update_done){
			$retArr["status"] = 1;
			$retArr["type"] = $type;
			$retArr["msg"] = "";
			$retArr["data"] = $update_done;
			die(json_encode($retArr));
		}else{
			$retArr["status"] = 2;
			$retArr["type"] = $type;
			$retArr["msg"] = "error";
		}
	}

	$retArr["status"] = 1;
	$retArr["type"] = 1;
	$retArr["msg"] = "";
	$retArr["data"] = $res;
	die(json_encode($retArr));
	
//}

exit;

?>