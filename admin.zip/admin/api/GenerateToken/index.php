<?php

include_once ("GenerateToken.php");

?>