<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);



include_once("../AppCommonIncludes.php");
require("../../../api/DBActions.php");

$requestBody = file_get_contents('php://input');
// Decode the JSON data
$ReqBody = json_decode($requestBody, true);

	
	//$username=isset($ReqBody["username"])? XSSFilter($ReqBody["username"]):"";

	$returnArr=array();


	function generateEncryptionKey($length = 16) {
		$characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; // Upper and lower case letters
		$key = '';
		$maxIndex = strlen($characters) - 1;
		
		for ($i = 0; $i < $length; $i++) {
			$key .= $characters[random_int(0, $maxIndex)];
		}
		
		return $key;
	}
	

	function getRealIpAddr()
		{
			if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
			{
			  $ip=$_SERVER['HTTP_CLIENT_IP'];
			}
			elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
			{
			  $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
			}
			else
			{
			  $ip=$_SERVER['REMOTE_ADDR'];
			}
			return $ip;
		}


	// if((isset($ReqBody['username'])))
	// {
		//if(isset($ReqBody['username'])) $username = trim(XSSFilter($ReqBody['username'])); else $username = '';

		$flag=0;

		$Temp1 = DBLink();
	
		// $TempQry_checkloginattempt = "SELECT * FROM user_details WHERE user_name='$username' LIMIT 1;";
		// $TempResults_checkloginattempt = ExecuteReader($Temp1,$TempQry_checkloginattempt);

		// if (count($TempResults_checkloginattempt)==0)
		// {
		// 	$returnArr["status"]=2;
		// 	$returnArr["msg"]='Invalid Username';
		// 	die (json_encode( $returnArr));
		// }


		//if(count($TempResults_checkloginattempt)>0){

			//$user_id = $TempResults_checkloginattempt[0]['user_id'];
			//$encryption_key = $TempResults_checkloginattempt[0]['encryption_key'];

			$token=GenerateToken();
		
			$request_ip=XSSFilter(getRealIpAddr());
			
			$ranStr = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 12);
			$link=DBLink();	
			
			$encryption_key = generateEncryptionKey(16);

			// $initialInsert="INSERT INTO admin_sessions(session_token,login_time,ip_address,user_id,login_status,document_key,encryption_key)VALUES('$token',NOW(),'$request_ip','0','0','$ranStr','$encryption_key')";
			// $sessionId = insertIntoDB_GetId($link,$initialInsert);		
			
			$initialInsert="INSERT INTO admin_sessions(session_token,login_time,ip_address,user_id,document_key,role_id,login_status,encryption_key)VALUES('$token',NOW(),'$request_ip','0','$ranStr',0,0,'$encryption_key')";
			$session_id = insertIntoDB_GetId($Temp1,$initialInsert);
			$returnArr["session_id"]=$session_id;
			$returnArr["encryption_key"]=$encryption_key;
			$returnArr["status"]=1;


		//}

		
		
	//}	
	echo json_encode($returnArr);	
?>
