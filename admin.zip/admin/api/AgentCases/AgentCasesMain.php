<?php

$DEV_MODE_ENABLED = (isset($_REQUEST["DEV"]) ? true : false);

if ($DEV_MODE_ENABLED) {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
}

include_once("../AppCommonIncludes.php");

$tmpJsonRequest = json_decode($ObjRequestData->InputData);

$tmpObj = new AgentCasesMain($tmpJsonRequest);

class AgentCasesMain
{
    function __construct($InputData)
    {
        PrintResultCombine("AgentCasesMain", $InputData);

        // $this->glbPartnerID = (isset($InputData->partner_id) ? $InputData->partner_id : 0);

        global $DEV_MODE_ENABLED;

        $this->MainProcess($InputData);
    }
    function MainProcess($InputData)
    {
        global $paramListAgentCases;

        ValidationMain($paramListAgentCases, (array) $InputData);
        $this->GetCaseList($InputData);
    }

    function GetCaseList($InputData)
    {

        $pdo = GetPDOConnection();

        $TempParamIn = array();
        $TempParamIn[":ProcessID"] = PROCESS_ID_AGENTCASELISt;
        $TempParamIn[":SessToken"] = $InputData->sessionToken;
        $TempParamIn[":SessID"] = $InputData->session_id;
        // $TempParamIn[":Keyword"] = $InputData->session_id;
        // $TempParamIn[":KeywordType"] = $InputData->session_id;
        // $TempParamIn[":VAC"] = $InputData->session_id;
        // $TempParamIn[":DateType"] = $InputData->session_id;
        // $TempParamIn[":StartAt"] = $InputData->session_id;
        // $TempParamIn[":EndAt"] = $InputData->session_id;


        // CALL ProcAgentGetCases(1,1,'bg655465','test',3,10,1, ' 2024-11-28 08:20:58', '2024-11-28 08:20:58');
/* CREATE PROCEDURE `ProcAgentGetCases`(
	IN `IN_ProcessID` 		INT ,
	IN `IN_SessID` 			INT ,
	IN `IN_SessionToken` 	VARCHAR(20) ,  
	 
	IN `IN_Keyword` 		VARCHAR(20),
	IN `IN_KeywordType`		TINYINT,
	IN `IN_VAC` 			SMALLINT,
	IN `IN_DateType` 		SMALLINT,
	IN `IN_StartAt` 		DATETIME,
	IN `IN_EndAt` 			DATETIME
	
)  */
        /*   $Query = "CALL ProcAgentGetCases ( :ProcessID, :SessID, :SessToken ,:Keyword,:KeywordType,:VAC,:DateType,:StartAt,:EndAt)"; */

        if (isset($InputData->priority)) {
            $TempParamIn[":Priority"] = (int) $InputData->priority;

        } else {
            $TempParamIn[":Priority"] = -1;
        }


        $Query = "CALL ProcAgentPriorityCases ( :ProcessID, :SessID, :SessToken,:Priority )";

        $QueryLog = "CALL ProcAgentPriorityCases (" . $TempParamIn[":ProcessID"] . "," . $TempParamIn[":SessID"] . ",'" . $TempParamIn[":SessToken"] . "," . $TempParamIn[":Priority"] . ")";




        PrintResultCombine("AgentCasesMain-Query", $Query);
        PrintResultCombine("AgentCasesMain-DB-ParamIn", $TempParamIn);

        $RetResult = ReadDBData($pdo, $Query, $TempParamIn);

        // echo "<hr>SP-RetResult";
        // print_r($RetResult);
        if (PASSPORT_ENCRYPTION == "NO") {
            ResponsePlainDefault($RetResult[0]["Result"], SUCCESS_OK);
        }
        HFEncryptions($RetResult);

        return;
    }

    function GetDBParams($aResult)
    {

        $TmpDBArray = array();

        $TmpDBArray["session_id"] = $this->SessionID;


        return $TmpDBArray;


    }


}

function TestProcess()
{
    echo "<hr>TestProcess";
    global $ObjRequestData;

    $ObjRequestData->InputData = TempParamArray();


    echo "<hr>PArams";
    print_r($ObjRequestData->InputData);
    // $TmpRetVal = $this->SendParam($TmpInput);
    // echo "<hr>Results";
    // print_r($TmpRetVal);

}
function TempParamArray()
{
    return '{"session_id":10,"sessionToken":"LGF656565"}';
}

function TempResult()
{
    return '{"final_result":1}';

}


?>