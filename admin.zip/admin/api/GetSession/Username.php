<?php
	include("../../Common.php");
	include(DBCONNECTION);
	include(SESSIONAPI);
	$newSession = new NewSession();
	$newSession->newSession($__con);
	exit;
?>
