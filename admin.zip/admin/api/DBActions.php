<?php

	
	function ExecuteReader($argConn,$query)
	{ 		$tempRows=array();
		
		try
		{
			$result="";
			
			$argConn->next_result();
			
			$result=mysqli_query($argConn,$query);
			
			 if($result){
				while ($row = $result->fetch_assoc()){
					$tempRows[] = $row;
				}
				$result->close();
			}
			
			
			$argConn->next_result();
		    mysqli_next_result($argConn);
			
			
		}
		catch(Exception $err)
		{
			//errorlog("DBGetData","SEND OTP API RESPONSE:".$server_output);
		}
		return $tempRows;
	}
	function rtnRowCount($argConn,$query)
	{
		
		$checkRow=mysqli_query($argConn,$query); // or die(mysqli_error($argConn));
		
		if($checkRow)
			return mysqli_num_rows($checkRow);
		else
			return 0;
	
	}
	function ExcuteNonQuery($argConn,$query)
	{
		
		$res=mysqli_query($argConn,$query);
		
		if($res)
			return TRUE;
		else
			return FALSE;
	}
	function insertIntoDB_GetId($argConn,$query)
	{
		$rtnId=0;
		try
		{
			$isExcuted=mysqli_query($argConn,$query); 
			
			if($isExcuted)
				$rtnId=mysqli_insert_id($argConn);
			
		}
		catch(Exception $err)
		{
			//errorlog("DBGetData","DBGetQuery_insertIntoTable : ".$err);
		}
		return $rtnId;
	}
	function ExecuteScalar($argConn,$query,$keyName)
	{
		$value=0;
			try
			{
				 $result=mysqli_query($argConn,$query);
				  if($result){
						 if(mysqli_num_rows($result)>0)
						 {
							 $tempValue = mysqli_fetch_assoc($result);
							 $value=$tempValue[$keyName];
						 }
						 else
							$value=0;
					
						$result->close();
				
				}
				
				$argConn->next_result();
			}
			catch(Exception $err)
			{
				//errorlog("DBGetQuery_insertIntoTable : ".$err);
			}
			return $value;
			
		
	
	}
	function ExecuteCount($argConn,$query)
	{
		$value=0;
			try
			{
				 $result=mysqli_query($argConn,$query);
				  if($result){
					 if(mysqli_num_rows($result)>0)
					 {
						$value=1;
					 }
				}
				
				$argConn->next_result();
			}
			catch(Exception $err)
			{
				
			}
			return $value;
			
		
	
	}
	
	
	

?>