<?php

include("../../Common.php");
include(DBCONNECTION);
include(MANIFESTAPI);
$db = new DBQuery($__con);
$manifest = new Manifest($__con);
$manifest->getManifest(); 
exit;
?>