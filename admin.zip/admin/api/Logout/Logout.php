<?php

	include("../../Common.php");
	include("../commonFns.php");
	include(DBCONNECTION);
	include(LOGINAPI);
	$login = new Login($__con,true);
	$db = new DBQuery($__con);

	$res = json_decode($login->logOut($_POST),true);
	if($res['status']==1){
		// $removeAssignedCases="DELETE FROM assigned_cases WHERE user_id='$user_id'";
		// $remove_cases = ExcuteNonQuery($Temp1,$removeAssignedCases);		
		if(isset($_POST["Globaluserid"])) $user_id=(int)$_POST["Globaluserid"]; else $user_id=0;
		$res = $db->query("DELETE FROM assigned_cases WHERE user_id=:user_id",["user_id"=>$user_id]);
		if($res){
			header("Location:".REDIRECT_URL);
			exit;			
		}

	}
	exit;

?>
