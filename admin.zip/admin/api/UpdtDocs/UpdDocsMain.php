<?php

$DEV_MODE_ENABLED = (isset($_REQUEST["DEV"]) ? true : false);

if ($DEV_MODE_ENABLED) {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
}

include_once("../AppCommonIncludes.php");

// $tmpJsonRequest = json_decode($ObjRequestData->InputDataNonXSS);
$tmpJsonRequest = json_decode($ObjRequestData->InputData);

$tmpObj = new UpdtDocsMain($tmpJsonRequest);

class UpdtDocsMain
{
    function __construct($InputData)
    {
        PrintResultCombine("UpdtDocsMain", $InputData);

        // $this->glbPartnerID = (isset($InputData->partner_id) ? $InputData->partner_id : 0);

        global $DEV_MODE_ENABLED;

        $this->MainProcess($InputData);
    }
    function MainProcess($InputData)
    {
        global $paramListUpdatDocs;
        PrintResultCombine("MainProcess-IP", $InputData);

        ValidationMain($paramListUpdatDocs, (array) $InputData);
        $this->UpdtCaseList($InputData);
    }

    function UpdtCaseList($InputData)
    {
        // PrintResultCombine("UpdtCaseList-IP", $InputData);

        $pdo = GetPDOConnection();

        $TempParamIn = array();
        $TempParamIn[":ProcessID"] = PROCESS_ID_UPDATEDOCS;
        $TempParamIn[":SessToken"] = $InputData->sessionToken;
        $TempParamIn[":SessID"] = $InputData->session_id;

        $TempParamIn[":RequestID"] = $InputData->reqId;
        $TempParamIn[":DetailsID"] = $InputData->dtlId;
        $TempParamIn[":DocID"] = $InputData->docId;
        $TempParamIn[":DocStatus"] = $InputData->status;
        $TempParamIn[":ReasonCode"] = $InputData->reason;
        // $TempParamIn[":Comments"] = $InputData->comments; 
        $TempParamIn[":Comments"] = HtmlToChars($InputData->comments);
        $TempParamIn[":Token"] = GenerateToken();

        if (REJECT_ALL_DETAILS_GROUP_MAIL == 1) {

            $Query = "CALL ProcUpdateAllDocsMultiTemplates ( :ProcessID, :SessID, :SessToken ,:Token,:RequestID, :DetailsID, :DocID, :DocStatus ,:ReasonCode, :Comments)";

            $QueryLog = "CALL ProcUpdateAllDocsMultiTemplates (" . $TempParamIn[":ProcessID"] . "," . $TempParamIn[":SessID"] . ",'" . $TempParamIn[":SessToken"] . "','" . $TempParamIn[":Token"] . "'," . $TempParamIn[":RequestID"] . "," . $TempParamIn[":DetailsID"] . "," . $TempParamIn[":DocID"] . ",'" . $TempParamIn[":DocStatus"] . "','" . $TempParamIn[":ReasonCode"] . "','" . $TempParamIn[":Comments"] . "')";

        } else if (REJECT_ALL_DETAILS == 1) {

            $Query = "CALL ProcUpdateAllDocs ( :ProcessID, :SessID, :SessToken ,:Token,:RequestID, :DetailsID, :DocID, :DocStatus ,:ReasonCode, :Comments)";

            $QueryLog = "CALL ProcUpdateAllDocs (" . $TempParamIn[":ProcessID"] . "," . $TempParamIn[":SessID"] . ",'" . $TempParamIn[":SessToken"] . "','" . $TempParamIn[":Token"] . "'," . $TempParamIn[":RequestID"] . "," . $TempParamIn[":DetailsID"] . "," . $TempParamIn[":DocID"] . ",'" . $TempParamIn[":DocStatus"] . "','" . $TempParamIn[":ReasonCode"] . "','" . $TempParamIn[":Comments"] . "')";

        } else {
            $Query = "CALL ProcUpdateDocs ( :ProcessID, :SessID, :SessToken ,:Token,:RequestID, :DetailsID, :DocID, :DocStatus ,:ReasonCode, :Comments)";

            $QueryLog = "CALL ProcUpdateDocs (" . $TempParamIn[":ProcessID"] . "," . $TempParamIn[":SessID"] . ",'" . $TempParamIn[":SessToken"] . "','" . $TempParamIn[":Token"] . "'," . $TempParamIn[":RequestID"] . "," . $TempParamIn[":DetailsID"] . "," . $TempParamIn[":DocID"] . ",'" . $TempParamIn[":DocStatus"] . "','" . $TempParamIn[":ReasonCode"] . "','" . $TempParamIn[":Comments"] . "')";

        }




        // errorLogV2("UpdtDocsMain-Query::" . print_r($QueryLog, true));


        PrintResultCombine("UpdtDocsMain-QueryLog", $QueryLog);
        PrintResultCombine("UpdtDocsMain-Query1", $Query);
        PrintResultCombine("UpdtDocsMain-QueryVal", $TempParamIn);

        $RetResult = ReadDBData($pdo, $Query, $TempParamIn);
        PrintResultCombine("UpdtDocsMain-Result", $RetResult);

        // echo "<hr>SP-RetResult";
        // print_r($RetResult);
        ResponsePlainDefault($RetResult[0]["Result"], SUCCESS_OK);

        return;
    }

    function GetDBParams($aResult)
    {

        $TmpDBArray = array();

        $TmpDBArray["session_id"] = $this->SessionID;


        return $TmpDBArray;


    }


}

function TestProcess()
{
    echo "<hr>TestProcess";
    global $ObjRequestData;

    $ObjRequestData->InputData = TempParamArray();


    echo "<hr>PArams";
    print_r($ObjRequestData->InputData);
    // $TmpRetVal = $this->SendParam($TmpInput);
    // echo "<hr>Results";
    // print_r($TmpRetVal);

}
function TempParamArray()
{
    return '{"session_id":10,"sessionToken":"LGF656565"}';
}

function TempResult()
{
    return '{"final_result":1}';

}


?>