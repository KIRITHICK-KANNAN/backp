<?php

$DEV_MODE_ENABLED = (isset($_REQUEST["DEV"]) ? true : false);

if ($DEV_MODE_ENABLED) {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
}

include_once("../AppCommonIncludes.php");

$tmpJsonRequest = json_decode($ObjRequestData->InputData);

$tmpObj = new UpdMastrMain($tmpJsonRequest);

class UpdMastrMain
{
    function __construct($InputData)
    {
        PrintResultCombine("UpdMastrMain", $InputData);

        // $this->glbPartnerID = (isset($InputData->partner_id) ? $InputData->partner_id : 0);

        global $DEV_MODE_ENABLED;

        $this->MainProcess($InputData);
    }
    function MainProcess($InputData)
    {
        global $paramListUpdatMaster;

        ValidationMain($paramListUpdatMaster, (array) $InputData);
        $this->UpdtCaseList($InputData);
    }

    function UpdtCaseList($InputData)
    {

        $pdo = GetPDOConnection();

        $TempParamIn = array();
        $TempParamIn[":ProcessID"] = PROCESS_ID_UPDATEMASTER;
        $TempParamIn[":SessToken"] = $InputData->sessionToken;
        $TempParamIn[":SessID"] = $InputData->session_id;
        $TempParamIn[":ReqID"] = $InputData->reqId;
        $TempParamIn[":reqStatus"] = $InputData->reqStatus;
      
 
        $Query = "CALL ProcUpdateMaster ( :ProcessID, :SessID, :SessToken ,:ReqID, :reqStatus)";

        $RetResult = ReadDBData($pdo, $Query, $TempParamIn);

        // echo "<hr>SP-RetResult";
        // print_r($RetResult);
        ResponsePlainDefault($RetResult[0]["Result"], SUCCESS_OK); 
        return;
    }

    function GetDBParams($aResult)
    {

        $TmpDBArray = array();

        $TmpDBArray["session_id"] = $this->SessionID;


        return $TmpDBArray;


    }


}

function TestProcess()
{
    echo "<hr>TestProcess";
    global $ObjRequestData;

    $ObjRequestData->InputData = TempParamArray();


    echo "<hr>PArams";
    print_r($ObjRequestData->InputData);
    // $TmpRetVal = $this->SendParam($TmpInput);
    // echo "<hr>Results";
    // print_r($TmpRetVal);

}
function TempParamArray()
{
    return '{"session_id":10,"sessionToken":"LGF656565"}';
}

function TempResult()
{
    return '{"final_result":1}';

}


?>