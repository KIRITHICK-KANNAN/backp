<?php

    include("../../Common.php");
	include(DBCONNECTION);
	include(HOLIDAYAPI);
    include(WEEKDAYAPI);
	$holiday = new Holiday($__con);
    //$weekdays = new Weekdays($__con);
    $ReqBody = json_decode(file_get_contents('php://input'), true);
    $type = isset($ReqBody['type']) ? $ReqBody['type'] : 0;
    if($type==1){
        $holiday->holidayList();
    }
    if($type==2){
        $holiday->updateWeekDays();
    }
    if($type==3){
        $holiday->holidayDelete();
    }
    if($type==4){
        $holiday->addHoliday();
    }
	exit;

?>