<?php
	include("../../Common.php");
	include(DBCONNECTION);
	include(LOGINAPI);
	$login = new Login($__con);
	$login->adminReLogin(); 
	exit;
?>
