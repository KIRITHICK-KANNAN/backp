<?php


define("MIOOT_INCLUDE_PATH", "/var/www/html/vfseu_mioot/AppCommonIncludes/");
define("LOG_FILE", "/var/www/html/vfseu_mioot/forms/UAT/ITAIND/logs/");


define("PROCESS_ID_ADMIN", 100);
define("PROCESS_ID_AGENT", 101);
define("PROCESS_ID_AGENTCASELISt", 102);
define("PROCESS_ID_ASSIGNME", 103);
define("PROCESS_ID_SEARCHCASE", 104);

define("PROCESS_ID_UPDATEDOCS", 105);
define("PROCESS_ID_UPDATEDETAILS", 106);
define("PROCESS_ID_UPDATEMASTER", 107);
define("PROCESS_ID_UPDATEVERDICT", 108);
define("PROCESS_ID_CASELIST", 109);

define("PROCESS_ID_DOCSLIST", 110);

define("TYPE_PASSPORTNUMBER", 3);

// define("PASSPORT_ENCRYPTION", "ENC");//ENC - NO
define("PASSPORT_ENCRYPTION", "NO");//ENC - NO

define("REJECT_ALL_DETAILS",1);//ITAKEN,ITAKEN
define("REJECT_ALL_DETAILS_GROUP_MAIL",1);//ITAIND

define("VERSION_RED_FLAGED",1);//ITABDE 
define("VERSION_WORK_DAYS",1);//ITAIND
define("VERSION_SPONSOR",0);//ITAKEN

define("VERSION_SEARCH_CASE_V2",1);//ITAIND


set_include_path(MIOOT_INCLUDE_PATH);

define(
    "ALLOWED_ORIGINs",
    [
        "localhost"
    ]
);

define(
    "ALLOWED_METHODs",
    [
        "GET",
        "POST",
        "OPTIONS"
    ]
);


?>