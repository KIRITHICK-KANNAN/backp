<?php

$DEV_MODE_ENABLED = (isset($_REQUEST["DEV"]) ? true : false);

if ($DEV_MODE_ENABLED) {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
}

include_once("../AppCommonIncludes.php");

$tmpJsonRequest = json_decode($ObjRequestData->InputData);

$tmpObj = new DocumentDetailsMain($tmpJsonRequest);

class DocumentDetailsMain
{
    function __construct($InputData)
    {
        PrintResultCombine("DocumentDetailsMain", $InputData);

        // $this->glbPartnerID = (isset($InputData->partner_id) ? $InputData->partner_id : 0);

        global $DEV_MODE_ENABLED;

        $this->MainProcess($InputData);
    }
    function MainProcess($InputData)
    {
        global $paramListDocumentDetails;

        ValidationMain($paramListDocumentDetails, (array) $InputData);
        $this->GetCaseList($InputData);
    }

    function GetCaseList($InputData)
    {

        $pdo = GetPDOConnection();

        $TempParamIn = array();
        $TempParamIn[":ProcessID"] = PROCESS_ID_DOCSLIST;
        $TempParamIn[":SessToken"] = $InputData->sessionToken;
        $TempParamIn[":SessID"] = $InputData->session_id;
        // $TempParamIn[":DocIDs"] = $InputData->docIds;
        $TempParamIn[":DocIDs"] = $InputData->docId;
      

        $Query = "CALL ProcGetDocLogs ( :ProcessID, :SessID, :SessToken,:DocIDs )";

        $QueryLog = "CALL ProcGetDocLogs (". $TempParamIn[":ProcessID"].",". $TempParamIn[":SessID"] .",'". $TempParamIn[":SessToken"]."',".$TempParamIn[":DocIDs"].")"; 


        PrintResultCombine("DocumentDetailsMain-Query", $QueryLog); 
        
        PrintResultCombine("DocumentDetailsMain-DB-ParamIn", $TempParamIn);

        $RetResult = ReadDBData($pdo, $Query, $TempParamIn);

        // ResponseDefault($RetResult, SUCCESS_OK);
        ResponsePlainDefault($RetResult[0]["Result"], SUCCESS_OK);

        return;
    } 

}
 


?>