<?php
include("sessionValidation.php");
//print_r($_POST);

?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <link rel="icon" type="image/png" sizes="" href="assets/img/fav.ico" />
      <title>ITSLT Dashboard</title>
      <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
      <link href="assets/css/style.css" rel="stylesheet" />
      <link href="assets/css/responsive.css" rel="stylesheet" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
      <script src='js/jquery-3.7.1.min.js'></script>

   </script>
   </head>
   <body class="bg-light">

      <nav class="navbar navbar-expand-sm navbar-dark border-bottom fixed-top bg-header" aria-label="Third navbar example">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.html"><img src="assets/img/vfs_logo3.png" alt="mdo" class="first-logo img-fluid" /></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <form id="mainForm" name="mainForm" method="post">
            <input type="hidden"  id="user_name" name="user_name" value="<?=$user_name;?>">
            <input type="hidden"  id="Globaluserid" name="Globaluserid" value="<?=$Globaluserid;?>" >
            <input type="hidden"  id="Globalsessionid" name="Globalsessionid" value="<?=$Globalsessionid;?>">
            <input type="hidden"  id="Globalsessiontoken" name="Globalsessiontoken" value="<?=$Globalsessiontoken;?>">	
            <input type="hidden"  id="full_name" name="full_name" value="<?=$full_name;?>">
         </form>
          <div class="collapse navbar-collapse" id="navbarsExample03">
            <ul class="navbar-nav me-auto mb-2 mb-sm-0">
               <li class="nav-item">
                 <a class="nav-link" aria-current="page" href="index.html">Home</a>
               </li>
               <li class="nav-item active">
                 <a class="nav-link" href="dash.html">VAC Officer</a>
               </li>
               <li class="nav-item">
                 <a class="nav-link" href="cases.html" tabindex="-1" aria-disabled="true">Cases</a>
               </li>
               <li class="nav-item">
                <a class="nav-link" href="qc.html" tabindex="-1" aria-disabled="true">Quality Control</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="dash4.html" tabindex="-1" aria-disabled="true">Translate</a>
              </li>
              <li class="nav-item">
               <a class="nav-link" href="slot.html" tabindex="-1" aria-disabled="true">QC - Translate</a>
             </li>
             <li class="nav-item">
               <a class="nav-link" href="slot.html" tabindex="-1" aria-disabled="true">Embassy User</a>
             </li>
             <li class="nav-item">
               <a class="nav-link" href="slot.html" tabindex="-1" aria-disabled="true">Report</a>
             </li>
            </ul>
            <ul class="nav nav_logout text-center">
               <li class="nav-item">
                  <a class="nav-link modal-title">Welcome <?=$user_name;?></a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" onClick="menuLoading(1);" style="cursor:pointer;">Logout</a>
               </li>
            </ul>
          </div>
        </div>
      </nav>

      <!-- Nav End -->
      <!-- Main Start -->

      <div id="dash">
         <section class="">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-12">
                     <div class="admin_form_section">

                        <div class="admin_form_card data_table_view">
                           <div class="head_title">
                              <div class="row">
                                 <div class="col-md-12"><h6 class="p-0 m-0">VAC Officer</h6></div>
                              </div>

                              <div class="row mt-2 mb-3">
                                 <div class="col-sm-12">

                                    <div class="privacy_list">
                                       <div class="form-group row">
                                          <div class="col-md-2">
                                             
                                          </div> 
                                          <div class="col-md-2">
                                             
                                          </div>
                                          <div class="col-md-2">
                                             <div>
                                                <select class="form-control" name="keyword" id="keyword">
                                                  <option value="0">---Type of Document---</option>
                                                  <option value=" ">Keyword</option>
                                                  <option value="1">Email Id</option>
                                                </select>
                                             </div>
                                          </div>
                                          <div class="col-md-2">
                                             <div>
                                                <select class="form-control" name="keyword" id="keyword">
                                                  <option value="0">---Language---</option>
                                                  <option value=" ">Keyword</option>
                                                  <option value="1">Email Id</option>
                                                </select>
                                             </div>					
                                          </div>
                                          <div class="col-md-2">
                                             <div>
                                                <select class="form-control" name="keyword" id="keyword">
                                                  <option value="0">---Status---</option>
                                                  <option value=" ">Keyword</option>
                                                  <option value="1">Email Id</option>
                                                </select>
                                             </div>
                                          </div>                                          
                                          <div class="col-md-2">
                                             <div>
                                                <a class="btn w-100 btn-primary btn-lg login-btn" href="#">Search</a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    
                                 </div>
                              </div>

                              <div class="row mt-3 mb-5">
                                 <div class="col-sm-12">
                                    <div class="privacy_list">

                                       <div class="form-group row">
                                          <div class="col-md-12">
                                             <div class="text-right pt-2 pb-2">
                                                <a href="create.html"><button type="button" class="login-btn">Create New</button></a>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="table-responsive">
                                          <table class="table table-responsive table-bordered text-left">
                                            <thead>
                                              <tr>
                                                <th>S.No</th>
                                                <th>Ticket Number</th>
                                                <th>Embassy Barcode Number</th>
                                                <th>Document Number</th>
                                                <th>Passport Number</th>
                                                <th>Applicant Name</th>
                                                <th>Type of Document</th>
                                                <th>Language of Document</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                              <tr>
                                                <td>1</td>
                                                <td>12345</td>
                                                <td>4r3y59hfigf</td>
                                                <td>56576</td>
                                                <td>trytrytu</td>
                                                <td>retertr</td>
                                                <td>Birth Certificate</td>
                                                <td>English</td>
                                                <td>Review</td>
                                                <td>
                                                   <a href="view.html"><button type="button" class="btn btn-link">View</button></a>
                                                </td>
                                              </tr>
                                              <tr>
                                                <td>2</td>
                                                <td>12345</td>
                                                <td>4r3y59hfigf</td>
                                                <td>56576</td>
                                                <td>trytrytu</td>
                                                <td>retertr</td>
                                                <td>Birth Certificate</td>
                                                <td>English</td>
                                                <td>Review</td>
                                                <td>
                                                   <a href="view.html"><button type="button" class="btn btn-link">View</button></a>
                                                </td>
                                              </tr>
                                              <tr>
                                                <td>3</td>
                                                <td>12345</td>
                                                <td>4r3y59hfigf</td>
                                                <td>56576</td>
                                                <td>trytrytu</td>
                                                <td>retertr</td>
                                                <td>Birth Certificate</td>
                                                <td>English</td>
                                                <td>Review</td>
                                                <td>
                                                   <a href="view.html"><button type="button" class="btn btn-link">View</button></a>
                                                </td>
                                              </tr>
                                              <tr>
                                                <td>4</td>
                                                <td>12345</td>
                                                <td>4r3y59hfigf</td>
                                                <td>56576</td>
                                                <td>trytrytu</td>
                                                <td>retertr</td>
                                                <td>Birth Certificate</td>
                                                <td>English</td>
                                                <td>Review</td>
                                                <td>
                                                   <a href="view.html"><button type="button" class="btn btn-link">View</button></a>
                                                </td>
                                              </tr>
                                              <tr>
                                                <td>5</td>
                                                <td>12345</td>
                                                <td>4r3y59hfigf</td>
                                                <td>56576</td>
                                                <td>trytrytu</td>
                                                <td>retertr</td>
                                                <td>Birth Certificate</td>
                                                <td>English</td>
                                                <td>Review</td>
                                                <td>
                                                   <a href="view.html"><button type="button" class="btn btn-link">View</button></a>
                                                </td>
                                              </tr>
                                            </tbody>
                                          </table>
                                       </div>

                                    </div>
                                 </div>
                              </div>
                              
                           </div>
                        </div> 

                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
      
      <!-- Main End -->

      <footer class="footer mt-auto p-3 border-top">
         <div class="container">
            <div class="row">
               <div class="col-sm-12 text-center">
                  <p>Copyright © VFS Global 2024. All Rights Reserved.</p>
               </div>
            </div>
         </div>
      </footer>


      <!-- The Modal Start -->
      <div class="modal" id="myModal">
         <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <h6 class="modal-title">Reference ID</h6>
               <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
               <div class="row">
                  <div class="col-sm-8 border-right">
                     <!-- Nav pills -->
                     <ul class="nav nav-pills" role="tablist">
                        <li class="nav-item">
                        <a class="nav-link active" data-bs-toggle="pill" href="#home">Document</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="pill" href="#menu1">Nulla Osta Document</a>
                        </li>
                     </ul>

                     <!-- Tab panes -->
                     <div class="tab-content tab_scroll">

                        <div id="home" class="container tab-pane active"><br>
                           <div class="img_view text-center">
                              <img src="https://www.shutterstock.com/image-vector/vector-international-passport-template-sample-600nw-588646514.jpg" class="img-fluid">
                           </div>
                        </div>
                        <div id="menu1" class="container tab-pane"><br>
                           <div class="pdf_view">
                              <iframe id="divframe" width="100%" height="500" scrolling="no" frameborder="0" marginheight="0" marginwidth="0" src="https://media.geeksforgeeks.org/wp-content/cdn-uploads/20210101201653/PDF.pdf"></iframe>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="customer_details_sesion">
                        <div class="modal-header">
                           <h6 class="modal-title">Customer Details : </h6>
                        </div>
                        <ul class="featureStatus-list tab_scroll">
                           <li><span>Request Id</span><span>1000</span></li>
                           <li><span>Full Name</span><span>User</span></li>
                           <li><span>Email Id</span><span>user@gmail.com</span></li>
                           <li><span>Passport Number</span><span>AWER1235</span></li>
                           <li><span>Nulla osta No</span><span>123654</span></li>
                           <li><span>Issue Date</span><span>27 June 2024</span></li>
                           <li><span>Submited On</span><span>27 June 2024</span></li>
                           <li><span>VAC</span><span>Chennai</span></li>
                           <li><span>Status</span><span>Open</span></li>
                           <li>
                              <span>Reason</span>
                              <span>
                                 <select class="form-select">
                                    <option>--Select--</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                  </select>                                  
                              </span>
                           </li>
                           <li>
                              <span style="width: 100%;">
                                 <div class="form-group">
                                    <label for="comment">Comments :</label>
                                    <textarea class="form-control" rows="5" id="comment"></textarea>
                                 </div>
                              </span>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="login-btn" data-bs-dismiss="modal">Submit</button>
               <button type="button" class="login-btn" data-bs-dismiss="modal">Verified</button>
            </div>
         </div>
         </div>
      </div>
      <!-- The Modal End -->

      <!-- The Modal 2 Start -->
      <div class="modal" id="myModal22">
         <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <h6 class="modal-title">Reference ID</h6>
               <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
               <div class="row">
                  <div class="col-sm-8 border-right">
                     <!-- Nav pills -->
                     <ul class="nav nav-pills" role="tablist">
                        <li class="nav-item">
                        <a class="nav-link active" data-bs-toggle="pill" href="#dash1">Document</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="pill" href="#dash2">Nulla Osta Document</a>
                        </li>
                     </ul>

                     <!-- Tab panes -->
                     <div class="tab-content tab_scroll">

                        <div id="dash1" class="container tab-pane active"><br>
                           <div class="img_view text-center">
                              <img src="https://www.shutterstock.com/image-vector/vector-international-passport-template-sample-600nw-588646514.jpg" class="img-fluid">
                           </div>
                        </div>
                        <div id="dash2" class="container tab-pane"><br>
                           <div class="pdf_view">
                              <iframe id="divframe" width="100%" height="500" scrolling="no" frameborder="0" marginheight="0" marginwidth="0" src="https://media.geeksforgeeks.org/wp-content/cdn-uploads/20210101201653/PDF.pdf"></iframe>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="customer_details_sesion">
                        <div class="modal-header">
                           <h6 class="modal-title">Customer Details : </h6>
                        </div>
                        <ul class="featureStatus-list tab_scroll">
                           <li><span>Request Id</span><span>1000</span></li>
                           <li><span>Full Name</span><span>User</span></li>
                           <li><span>Email Id</span><span>user@gmail.com</span></li>
                           <li><span>Passport Number</span><span>AWER1235</span></li>
                           <li><span>Nulla osta No</span><span>123654</span></li>
                           <li><span>Issue Date</span><span>27 June 2024</span></li>
                           <li><span>Submited On</span><span>27 June 2024</span></li>
                           <li><span>VAC</span><span>Chennai</span></li>
                           <li><span>Status</span><span>Open</span></li>
                           <li>
                              <span>Reason</span>
                              <span>
                                 <select class="form-select">
                                    <option>--Select--</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                  </select>                                  
                              </span>
                           </li>
                           <li>
                              <span style="width: 100%;">
                                 <div class="form-group">
                                    <label for="comment">Comments :</label>
                                    <textarea class="form-control" rows="5" id="comment"></textarea>
                                 </div>
                              </span>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="login-btn" data-bs-dismiss="modal">Submit</button>
               <button type="button" class="login-btn" data-bs-dismiss="modal">Verified</button>
            </div>
         </div>
         </div>
      </div>
      <!-- The Modal End -->

      

   </body>
</html>


<script src="assets/js/bootstrap.bundle.min.js"></script>

      <script>


         $(".navbar-nav li a").click(function(){
            $(".navbar-nav li a").removeClass("active");
            $(this).addClass("active");
         });

         
         function menuLoading(menu){
               let result = confirm("Are you sure want to logout session!");
               if (result === true) {
                  if(menu==1)
                  {
                  var url ="Logout.php";
                  $('#mainForm').attr('action', url);
                  document.forms["mainForm"].submit();
                  }
               }    

          }
      </script>

      <script src="https://code.jquery.com/jquery-3.7.1.js"></script>  