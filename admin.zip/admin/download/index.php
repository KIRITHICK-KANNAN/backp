<?php

	//ini_set("display_errors",1);
	require("../../api/requestHandlr.php");
	require("../../api/commonFns.php");
	require("../../api/DBConnection.php");
	require("../../api/DBActions.php");
	require '../../api/bucketDetails.php';
	require '../../../../../vendor/autoload.php';		
	
	
	use Aws\S3\S3Client;
	use Aws\S3\Exception\S3Exception;
	
	try
	{
		$params=array();
		$reqParam = explode('?', $_SERVER['REQUEST_URI']);
		
		if(isset($reqParam[1]))
			$params=explode("_",$reqParam[1],3);
		
		//print_r($params);
		
		if(count($params)==3)
		{
			$sessionId=(int) $params[0];
			$docKey=XSSFilter($params[1]);
			$docname=XSSFilter($params[2]);
			
			$docname=urldecode($docname);
			$docname=str_replace('/','',$docname);
			
			$link=DBLink(); 
				
			$checkQry="SELECT * FROM visitor_session WHERE session_id=$sessionId AND document_key='$docKey' AND session_status=1 LIMIT 1";
					
			$resultRow=ExecuteReader($link,$checkQry);
					
			mysqli_close($link);
			if(count($resultRow)>0)
			{
				
					try {
								
								
									$s3 = new S3Client([
									'version' => VERSION,
									'region'  => REGION,
									'credentials' => [
												'key'    => KEY,
												'secret' => SECRET,
											]
										]);
										
									$response = $s3->doesObjectExist(BUCKET, $docname);

									// Success? (Boolean, not a CFResponse object)
									//var_dump($response);
									
									if($response)
									{
										// Get the object.
										$result = $s3->getObject([
											'Bucket' => BUCKET,
											'Key'    => $docname
										]);
									
									
										// Display the object in the browser.
										header("Content-Type: {$result['ContentType']}");
										header('Content-Disposition: inline; filename="'.$docname.'"');
											
										echo $result['Body'];
									}
									else
									{
										header('HTTP/1.0 404 Not Found');
										echo "File not found or inaccessible!";
										exit;
										
									}
									
						} catch (S3Exception $e) {
							//errorlog('download',$e->getMessage());
							
							echo $e;
						}
						
					
					
			
			}
			else
			{
				header('HTTP/1.0 404 Not Found');
				echo "File not found or inaccessible!";
				exit;
			}
		}
		else
		{
			header('HTTP/1.0 404 Not Found');
			echo "File not found or inaccessible!";
			exit;
		}
	}
	catch(Exception $err)
	{
		//errorlog('download',$err->getMessage());
	}
	catch( Throwable $e)
	{
		$msg = $e->getMessage();
		header('HTTP/1.0 404 Not Found');
		echo "File not found or inaccessible!";
		exit;
	}
		
		
		
	
	
	
	
	
	
	
?>

