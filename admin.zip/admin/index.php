<?php

header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
//include("ip_checking.php"); 


include_once("../api/DBConnection.php");
include_once("../api/DBActions.php");

$link=DBLink();
$result_arr = array();

$PASSWORD1 = "";
$msg='';


?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <link rel="icon" type="image/png" sizes="" href="img/fav.ico" />
      <title>ITINE Admin</title>
      <link href="css/bootstrap.min.css" rel="stylesheet" />
      <link href="css/style.css" rel="stylesheet" />
      <link href="css/responsive.css" rel="stylesheet" />
      <script src='js/jquery.min.js'></script>
      <script type="text/javascript" src='js/crypto-js.min.js'></script>
      <script type="text/javascript" src="js/appJS/common.js"></script>
      <script type="text/javascript" src="js/appJS/services.js"></script>
      <script type="text/javascript" src="js/appJS/login.js"></script>
        <style>
            .overlay{
                display: none;
                position: fixed;
                width: 100%;
                height: 100%;
                top: 0;
                left: 0;
                z-index: 999;
                background: rgba(255,255,255,0.8) url("img/loader.gif") center no-repeat;
            }
            body.loading{
                overflow: hidden;   
            }
            body.loading .overlay{
                display: block;
            }
         .error {
             color: var(--red);
             font-size: 0.75rem;
          }         
            </style>
   </head>
   <body class="bg-light">
      <nav class="navbar navbar-expand-sm navbar-dark border-bottom fixed-top bg-header">
         <div class="container">
            <a class="navbar-brand" href="#"><img src="img/vfs_logo3.png" alt="mdo" class="first-logo img-fluid" /></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mynavbar">
               <ul class="navbar-nav invoice-section">
                  <li class="nav-item">
                     <a class="nav-link" href="#">
                        
                     </a>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!-- Nav End -->
      <!-- Main Start -->

      <div id="main">
         <section class="main-one position-relative admin_login_card">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <div class="login_form_section">
                     <form id="mainForm" name="mainForm" method="post">
                        <input type="hidden"  id="Globalsessionid" name="Globalsessionid" >
                        <input type="hidden"  id="Globalsessiontoken" name="Globalsessiontoken" >	
                        <input type="hidden"  id="RoleId" name="RoleId" >	
                    </form>

                        <form class="login-form" id="loginForm" autocomplete="off" method="post" name="loginForm">
                        <div class="login_form_card">
                                 
                                    <!--<h5 class="mb-4">ITSLT Login</h5>-->
					<h5 class="mb-4">Employment Appointments  - Italy</h5>
                                    <div id="divMain">
                                       <div class="form-group row">
                                          <label class="col-sm-12 col-form-label" >Username <span class="star_required">*</span></label>
                                          <div class="col-sm-12">
                                             <input type="text" name="username" id="username" class="form-control" placeholder="User Name" />
                                             <!-- <span id="error-msg" class="error" style="display:none;">Something went Wrong. Please try again after sometime!</span> -->
                                          </div>
                                       </div>
                                       <div class="form-group row pt-2">
                                          <label for="inputPassword" class="col-sm-12 col-form-label" >Password <span class="star_required">*</span></label>
                                          <div class="col-sm-12">
                                             <input type="password" name="password" id="password" placeholder="Password" class="form-control" />
                                          </div>
                                          
                                       </div>

                                       <div class="form-group row pt-2" id="otp_display">
                                          <label class="col-sm-12 col-form-label">Enter OTP <span class="star_required">*</span></label>
                                          <div class="col-sm-12">
                                             <input type="text" id="otp_number" name="otp_number" class="form-control" placeholder="OTP" autocomplete="off"/>
                                          </div>
                                       </div> 


                                       <div class="form-group row pt-2">
                                          <div class="col-sm-12 col-form-label" id="divBtn1">
                                             <a target="_blank"><button type="button" onClick="login()" class="btn login-btn">Login</button></a>
                                          </div>
                                          <div class="col-sm-12 col-form-label" id="divBtn2">
                                             <a target="_blank"><button type="button" onClick="login_success()" class="btn login-btn">Submit</button></a>
                                          </div>                                 
                                       </div>

                                       



                                    </div>
                                 
                              </div> </form>

                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
      <!-- Main End -->

      <footer class="footer mt-auto p-3 border-top">
         <div class="container">
            <div class="row">
               <div class="col-sm-12 text-center">
                  <p>Copyright © ITFR <?php echo date('Y') ?>. All Rights Reserved.</p>
               </div>
            </div>
         </div>
      </footer>


      <script src="js/bootstrap.bundle.min.js"></script>
      <div class="overlay"></div>
   </body>
</html>

