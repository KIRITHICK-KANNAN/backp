<?php

    require("../api/DBConnection.php");
    require("../api/DBQueries.php");
    require("../api/DBActions.php");

    $link=DBLink();


    try{

            $sessionQry = "SELECT * FROM visitor_session WHERE session_status = 1 and request_id>0";
            
            $sessionUsers = ExecuteReader($link,$sessionQry);


            if (!empty($sessionUsers)) {
                $currentTime = new DateTime();
                foreach ($sessionUsers as $session) {
                    // echo "<pre>";
                    // print_r($session);

                    $request_id = $session['request_id'];
                    $session_id = $session['session_id'];

                    if (empty($session['last_ping'])) {
                        //echo "User ID {$session['request_id']} skipped due to missing last_ping.<br>";
                        continue;
                    }

                    $lastPing = new DateTime($session['last_ping']);        
                    $interval = $lastPing->diff($currentTime);
                    $minutes = $interval->days * 24 * 60 + $interval->h * 60 + $interval->i;        
                    if ($minutes > 15) {
                        $updateSql = "UPDATE visitor_session SET session_status = 2 WHERE request_id ='$request_id' AND session_id='$session_id'";
                        $updatedone = ExcuteNonQuery($link,$updateSql);
                    } else {
                        echo "User ID {$session['request_id']} is active. Last ping was {$minutes} minutes ago.<br>";
                    }


                }
            } else {
                echo "No inactive users found.";
            }

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
   







?>