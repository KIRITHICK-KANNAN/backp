<?


		$requestIp="";
		
		$apiUrl="https://vfs.mioot.com/forms/globalIpChecking/";
		
		try
		{
			$requestIp=XSSFilter1(getRealIpAddr1());
			
			$jsonData='{"ipAdd":"'.$requestIp.'"}';
			
			$rtnData=CurlAPIRequest1($apiUrl,$jsonData);
					
			$response=json_decode($rtnData,true);
			
			if(isset($response["status"]))
			{
				$status=(int) $response["status"];
				
				if($status!=1)
				{
					echo "Invalid Network :".$requestIp;
					exit;
				}
			}
			else
			{
				echo "Invalid Network :".$requestIp;
				exit;
			}
				
				
		}
		catch(Exception $err)
		{
		
		}
		
		function XSSFilter1($string1)
		{ 
		
			$search = array("<", '>', '&lt;','&gt;','&#x3C;','&#x3E;',"'","&apos;","&#x27;");
			$replace = array('','','','','','','','','');
			
			return str_replace($search, $replace, $string1);
		}
		function getRealIpAddr1()
		{
			if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
			{
			  $ip=$_SERVER['HTTP_CLIENT_IP'];
			}
			elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
			{
			  $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
			}
			else
			{
			  $ip=$_SERVER['REMOTE_ADDR'];
			}
			return $ip;
		}
		function CurlAPIRequest1($apiUrl,$data)
		{
			$apiResponse="";
			try
			{
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $apiUrl);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_VERBOSE, 1);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
				curl_setopt($ch, CURLOPT_TIMEOUT, 30);
				curl_setopt($ch, CURLOPT_POST,1);
				curl_setopt($ch, CURLOPT_POSTFIELDS,$data); 
				$apiResponse = curl_exec($ch);
				
				$status=curl_getinfo($ch, CURLINFO_HTTP_CODE);
				
				if (curl_errno($ch)) {
						 $apiResponse = curl_error($ch);
				}
				
				curl_close($ch);
				
				
			}
			catch(HttpException $ex)
			{
				$apiResponse=$ex;
			}
			
			return $apiResponse;
			
		}
		
		





		
		
		
		
		
		
?>
