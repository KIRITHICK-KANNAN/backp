<?php
    define("REDIRECT_URL","https://vfseu.mioot.com/forms/UAT/ITAIND/admin/");
    define("SESSIONAPI","/var/www/html/vfseu_mioot/globalAPIs/admin/v1/new_session.php");
    define("DBCONNECTION","/var/www/html/vfseu_mioot/forms/UAT/ITAIND/con.php");
    define("LOGINAPI","/var/www/html/vfseu_mioot/globalAPIs/admin/v1/login.php"); 
    define("HOLIDAYAPI","/var/www/html/vfseu_mioot/globalAPIs/admin/v1/holiday.php"); 
    define("WEEKDAYAPI","/var/www/html/vfseu_mioot/globalAPIs/admin/v1/weekdays.php"); 
    define("SESEXPIREDAPI","/var/www/html/vfseu_mioot/globalAPIs/admin/v1/session.php");
    define("DATAFILTER","/var/www/html/vfseu_mioot/globalAPIs/dataFilters/xss_filter.php");
    define("SLOTAPI","/var/www/html/vfseu_mioot/globalAPIs/admin/v1/slot.php");
    define("MANIFESTAPI","/var/www/html/vfseu_mioot/globalAPIs/admin/v1/manifest.php");
    
?>