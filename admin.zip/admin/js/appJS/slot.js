var SessionId;
var SessionToken;
var UserRole;
var UserId;
var DocKey;
var objStatus;
var objVAC;
var objReason;
var objMaster;
var objDetails;
var objDocument;
var CurrentPassAct = 0;
var CurrentNullaAct = 0;
var isPassport = 0;
var DetailsId;

$(document).ready(function () {

	const today = new Date().toISOString().slice(0, 10);
    $("#from_date").val(today);
	$('#to_date').val(today)
	getLoginAdminDetails();
	//SessionId = 538;
	//SessionToken = "bafb61087d2e77d689728d7bf9f8ae37";
	 
	if($("#formtype").val()==2){

		

		
		
		// $('#select-all-check').on('change', function() {alert(1);
		// 	var isChecked = $(this).prop('checked');
		// 	$('.select-item-box').each(function() {
		// 		if (!$(this).is(':disabled')) {
		// 			$(this).prop('checked', isChecked);
		// 		}
		// 	});
		// });

		$('#body_table').on('change', '.select-item-box', function() {
			var allChecked = $('.select-item-box').not(':disabled').length === $('.select-item-box:checked').length;
			$('#select-all-check').prop('checked', allChecked);
		});

		$('#delete_button').click(function() {

            var selectedDays = getSelectedValues();

			if (selectedDays.length === 0) {
				alert('Please select at least one item to delete.');
				return;
			}
			if (!confirm('Are you sure you want to delete the selected items?')) {
				return;
			}

			deleteSlots(selectedDays);
		});

		getSlotList();

	}



	if($("#formtype").val()==1){
		
		$("#StartTime").datetimepicker({
			datepicker:false,
			format:'H:i',
			step: 5
		});
		$("#EndTime").datetimepicker({
			datepicker:false,
			format:'H:i',
			step: 5
		});
		$("#StartTimeBreak").datetimepicker({
			datepicker:false,
			format:'H:i',
			step: 5
		});
		$("#EndTimeBreak").datetimepicker({
			datepicker:false,
			format:'H:i',
			step: 5
		});

	}

	LoadVAC();

	$("#StartDate").datetimepicker({
		format: "d-M-Y",        
		timepicker: false
	});
	$("#EndDate").datetimepicker({
		format: "d-M-Y",        
		timepicker: false
	});
	
	$("#from_date").datetimepicker({
		format: "Y-m-d",        
		timepicker: false
	});

	$("#to_date").datetimepicker({
		format: "Y-m-d",        
		timepicker: false
	});

	$("#btnBookSlot").click(function() {
        bookSlot();
    });

   
	
});

$(document).ready(function () {
	

	// $('#select-all-check').on('change', function () {
	// 	alert(1); // Debugging: Ensure this runs
	// 	var isChecked = $(this).prop('checked');
	// 	$('.select-item-box').each(function () {
	// 		if (!$(this).is(':disabled')) {
	// 			$(this).prop('checked', isChecked);
	// 		}
	// 	});
	// });

	// $('#select-all-check').click(function(){
	// 	alert('Does this work?');
	// 	var isChecked = $(this).prop('checked');
	// 	$('.select-item-box').each(function () {
	// 		if (!$(this).is(':disabled')) {
	// 			$(this).prop('checked', isChecked);
	// 		}
	// 	});
	// });
	

});

function selectAll(element) {
   // console.log('hi');
    var isChecked = $(element).prop('checked'); // Use the passed element
    $('.select-item-box').each(function () {
        if (!$(this).is(':disabled')) {
            $(this).prop('checked', isChecked);
        }
    });
}




function getSelectedValues() {
    var selectedValues = $('.select-item-box:checked').map(function() {
        return $(this).val();
    }).get();
    //console.log(selectedValues);
    return selectedValues;
}
function deleteSlots(selectedDays){

	var param = {
		user_id: $('#Globaluserid').val(),
		session_id: $('#Globalsessionid').val(),
		session_token: $('#Globalsessiontoken').val(),
		type: 2,
		ids : selectedDays.join(',')
	}
	var chkParameter = JSON.stringify(param);

	$.ajax({
        url: APIURL+'SlotList/',
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (res) {
			//console.log('deleted',res.status);
			HideLoading();
			if(res.status == 1)
			{	
				alert('Slot deleted successfully.');			
				getSlotList();
				return;
			}
			else if(res.status == 2)
			{
               window.location.href=REDIRECTURL;
			}
			else if(res.status == 3)
			{
				alert("error");
				return;
			}
        }
    });

}

function bookSlot() {

	

	var Date1 = $("#StartDate").val().trim();
	var Date2 =  $("#EndDate").val().trim();
	var Time1 =  $("#StartTime").val().trim();
	var Time2 = $("#EndTime").val().trim(); 
	var BTime1 = $("#StartTimeBreak").val().trim();
	var BTime2 = $("#EndTimeBreak").val().trim(); 
	var Inrvl = $("#IntervalTime").val().trim(); 
	var NoOf = $("#NoOfSlot").val().trim();
	var vac = $("#selVacList").val().trim();

	var usrtid = $("#Globaluserid").val().trim();
	var usrsid = $("#Globalsessionid").val().trim();
	var usrstkn = $("#Globalsessiontoken").val().trim();
	var RoleId = $("#RoleId").val().trim();
	var priority = $("#priority").val().trim();

	
	if(vac == 0)
	{
		$("#selVacList").css('border-color', 'red');
		$("#selVacList").focus();
		return false;
	}else{
		$("#selVacList").css('border-color', '');
	}
	

	if(Date1 == "")
	{
		$("#StartDate").css('border-color', 'red');
		$("#StartDate").focus();
		return false;
	}else{
		$("#StartDate").css('border-color', '');
	}

	if(Date2 == "")
	{
		$("#EndDate").css('border-color', 'red');
		$("#EndDate").focus();
		return false;
	}else{
		$("#EndDate").css('border-color', '');
	}

	if(Time1 == "")
	{
		$("#StartTime").css('border-color', 'red');
		$("#StartTime").focus();
		return false;
	}else{
		$("#StartTime").css('border-color', '');
	}

	if(Time2 == "")
	{
		$("#EndTime").css('border-color', 'red');
		$("#EndTime").focus();
		return false;
	}else{
		$("#EndTime").css('border-color', '');
	}

	// if(BTime1 == "")
	// {
	// 	$("#StartTimeBreak").css('border-color', 'red');
	// 	$("#StartTimeBreak").focus();
	// 	return false;
	// }else{
	// 	$("#StartTimeBreak").css('border-color', '');
	// }
	// if(BTime2 == "")
	// {
	// 	$("#EndTimeBreak").css('border-color', 'red');
	// 	$("#EndTimeBreak").focus();
	// 	return false;
	// }else{
	// 	$("#EndTimeBreak").css('border-color', '');
	// }
	if(Inrvl == 0)
	{
		$("#IntervalTime").css('border-color', 'red');
		$("#IntervalTime").focus();
		return false;
	}else{
		$("#IntervalTime").css('border-color', '');
	}

	if(NoOf == 0)
	{
		$("#NoOfSlot").css('border-color', 'red');
		$("#NoOfSlot").focus();
		return false;
	}else{
		$("#NoOfSlot").css('border-color', '');
	}
	if(priority == ""){
		$("#priority").css('border-color', 'red');
		$("#priority").focus();
		return false;
	}else{
		$("#priority").css('border-color', '');
	}

	
	var slotValues = { 
		usrtid: usrtid, 
		usrsid: usrsid, 
		usrstkn: usrstkn , 
		Date1: Date1 ,
		Date2:Date2,
		Time1:Time1,
		Time2:Time2,
		BTime1:BTime1,
		BTime2:BTime2,
		Inrvl:Inrvl,
		NoOf:NoOf,
		vac:vac,
		RoleId:RoleId,
		priority:priority,
		type:3
	}
    var chkParameter_Slot =  JSON.stringify(slotValues);

	//console.log('values',chkParameter_Slot);
    
    $.ajax({
        url: bookSlotProcess,
        type: 'POST',
        data: chkParameter_Slot,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (msg) {			
			console.log('result ',msg);
			if(msg.status==2){

				if(msg.msg=='Success'){
					alert("Slots added successfully!");
					var url_list =ADMIN_URL+"slotlist/";
					$('#mainForm').attr('action', url_list);
					document.forms["mainForm"].submit();
	
				}else{
					alert(msg.msg);
					return false;					
				}
			}else{
				alert("Slots added successfully!");
				var url_list =ADMIN_URL+"slotlist/";
				$('#mainForm').attr('action', url_list);
				document.forms["mainForm"].submit();
			}
			
        }
    });

	return;



}
function getSlotList()
{
	var param = {
		user_id: $('#Globaluserid').val(),
		session_id: $('#Globalsessionid').val(),
		session_token: $('#Globalsessiontoken').val(),
		from_date: $('#from_date').val(),
		to_date: $('#to_date').val(),
		vac_id: $('#selVacList').val(),
		slot_status: $('#slot_status').val(),
		priority:$('#priority').val(),
		type: 1,
        startRecord: 1,
        rows: 1
	}
	var obj = JSON.stringify(param);
	GetSlotList(obj);
	//console.log('loadslot',obj);
}



/*function GetSlotList(chkParameter)
{	
	ShowLoading();
	$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: bookSlotList,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (res) {
			console.log('res>>>>>>>',res.status);
			$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(res.status == 1)
			{	
				objMaster = res.data;
				LoadSlotList(objMaster);
			}
			else if(res.status == 2)
			{
                objMaster = [];
				LoadSlotList(objMaster);
			}
        }
    });
}*/

function ConvertIST(specificDate)
{
	//var specificDate = new Date("2024-12-07 10:00");
const offset = 5.5 * 60 * 60 * 1000; // 5 hours and 30 minutes in milliseconds
const gmt530Date = new Date(specificDate.getTime() + offset);


const options = {
  timeZone: 'Asia/Kolkata',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: false,
};


var dateString = gmt530Date.toLocaleString('en-US', options);
const dateParts = dateString.split(", ");
const [day, month, year] = dateParts[0].split("/").map(Number);
const [hour, minute] = dateParts[1].split(":").map(Number);

// Construct the Date object in the correct timezone
const localDate = new Date(Date.UTC(year, month - 1, day, hour - 5, minute - 30));

const extractedDay = localDate.getDate();
const extractedMonth = localDate.getMonth() + 1; // Months are 0-indexed
const extractedYear = localDate.getFullYear();
const extractedHour = localDate.getHours();
const extractedMinute = localDate.getMinutes();

var dt = extractedDay + "/" + extractedMonth + "/" + extractedYear + " " + extractedHour + ":" + extractedMinute;
//console.log(dt);
return dt;
}

function Logout(menu){
	let result = confirm("Are you sure want to logout session!");
	if (result === true) {
	   if(menu==1)
	   {
	   //var url ="Logout.php";
	   $('#mainForm').attr('action', LogoutURL);
	   document.forms["mainForm"].submit();
	   }
	}    

}
function getLoginAdminDetails()
{
	const Globaluserid = $("#Globaluserid").val();
	const Globalsessionid = $("#Globalsessionid").val();
	const Globalsessiontoken  = $("#Globalsessiontoken").val();
	const user_name = $("#user_name").val();
	const full_name = $("#full_name").val();
	const RoleId = $("#RoleId").val();
		
	/*const Globaluserid = $("#Globaluserid").val();
	const Globalsessionid = $("#Globalsessionid").val();
	const Globalsessiontoken  = $("#Globalsessiontoken").val();
	const user_name = $("#user_name").val();
	const full_name = $("#full_name").val();
	const RoleId = $("#RoleId").val();*/
    
    var chkObj_Session = { Globaluserid: Globaluserid, Globalsessionid: Globalsessionid, Globalsessiontoken: Globalsessiontoken , RoleId: RoleId ,user_name:user_name,full_name:full_name }
    var chkParameter_Session =  JSON.stringify(chkObj_Session);
    
    $.ajax({
        url: sessionajaxvalid,
        type: 'POST',
        data: chkParameter_Session,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			//console.log('session',data);
			SessionId = data.Globalsessionid;
			SessionToken = data.session_token;
			UserRole = data.RoleId;
			UserId = data.Globaluserid;
			objStatus = data.master_status_list;
			objReason = data.reasoncode_list;
			objVAC = data.vac_list;
			DocKey = data.document_key;
			
			$("#spanWelcomeUser").html("Welcome " + " " + data.full_name);
        }
    });
}

function convertToTimeZone(date, offset) {
  const utc = date.getTime() + date.getTimezoneOffset() * 60000;
  return new Date(utc + offset * 60000);
}
function LoadVAC()
{
	var list = "";
	$("#selVacList").empty();
	list += "<option value='0'>---Select VAC---</option>";
	for(var i=0;i<objVAC.length;i++)
	{
		list += "<option value='"+ objVAC[i].vac_id +"'>"+ objVAC[i].vac_name +"</option>";
	}
	$("#selVacList").append(list);
}



function LoadSlotList(objMasterSlot)
{

	if(objMasterSlot != null)
	{
	var list = "", k = 0, l = 0;

	$("#divList").empty();


	//console.log('length',objMasterSlot.length);

	
		list += '<table class="table accordion table-responsive table-bordered text-left accordion-collapse p-2" id="r'+ k +'">';
			
		list += '<thead>';
        list += '<tr>';		
		list += '<th scope="col">S.No</th>';
		list += '<th scope="col">VAC</th>';
        list += '<th scope="col">Slot Date</th>';
        list += '<th scope="col">Slot Time</th>';
		list += '<th scope="col">Priority</th>';
        list += '<th scope="col">Status</th>';
		list += '<th scope="col"><input type="checkbox" id="select-all-check" onclick="selectAll(this)"/>&nbsp;Select All</th>';
        list += '</tr>';
		list += '</thead>';
			
		list += '<tbody style="background:#fff;" id="body_table">';
		
		if(objMasterSlot.length>0){
			$('#delete_button').show();
			
			for(var j = 0;j<objMasterSlot.length;j++)
			{	
				km = j+1;
				var sts1 = "";
				var check_status = (objMasterSlot[j].sl_status == 1) ? '' : 'disabled';
				list += '<td>'+ km + '</td>';
				list += '<td>'+ objMasterSlot[j].vac_name + '</td>';
				list += '<td>'+ objMasterSlot[j].slot_date + '</td>';
				list += '<td>'+ objMasterSlot[j].slot_time + '</td>';
				list += '<td>'+ objMasterSlot[j].priority_status + '</td>';
				list += '<td>'+ objMasterSlot[j].slot_status + '</td>';
				list += '<td><input type="checkbox" class="select-item-box" ' + check_status + ' value="'+objMasterSlot[j].slot_id+'"/></td>';
				list += '</tr>';
			}
			list += '</tbody>';			
			list += '</table>';	

		}else{
			$("#divList").empty();
			$('#delete_button').hide();
			var list = "<table class='table text-center'><thead><tr><th scope='col'>S.No</th><th scope='col'>VAC</th><th scope='col'>Slot Date</th><th scope='col'>Slot Time</th><th scope='col'>Priority</th><th scope='col'>Status</th><th scope='col'>Select All</th></tr></thead><tbody><tr><td colspan='6'>----No Records----</td></tr></tbody></table>";
		}
		

	$("#divList").append(list);


	}
}





function CloseDialog()
{
	isPassport = 1;
	$("#myModal").modal('hide');
}
function ShowDialog(detId)
{
	$("#divBtnVRB").show();	
	var reqId = 0, fullName = "", email = "", submitOn = "",vac = "", sts = "", pass = "", wpn = "", issueDt = "", comments = "", reasonId = 0;
	
	var tempDoc = objDocument.filter(d => d.dtlId == detId);
	if(tempDoc.length >0)
	{
		comments = tempDoc[0].remarks;
		if(comments == null)
		{
			comments = "";
		}
		reasonId = tempDoc[0].reason;
		if(reasonId == null)
		{
			reasonId = 0;
		}
	}
	if(comments != "")
	{
		$("#txtComment").val(comments);
	}
	if(reasonId > 0)
	{
		var list = "";
		$("#ddlReason").empty();
		list += "<option value='0'>---Select---</option>";
		var temp1 = objReason.filter((f) => f.type == 2);
		for (var j = 0; j < temp1.length; j++) {
			list += "<option value=" + temp1[j].id + ">" + temp1[j].reason_code + "</option>";
		}
		$("#ddlReason").append(list);
		$("#ddlReason").val(reasonId);
	}
	
	var temp = objDetails.filter(f => f.dtlId == detId);
	
	DetailsId = detId;
	if(temp.length > 0)
	{
		fullName = temp[0].fName + " " + temp[0].lName;
		pass = temp[0].ppn;
		wpn = temp[0].wpn;
		issueDt = temp[0].wpndt;
	}
	reqId = objMaster[0].reqId;
	email = objMaster[0].mailId;
	
	//submitOn = objMaster[0].submitOn;

	var subDt = new Date(objMaster[0].submitOn);
		var y = subDt.getFullYear();
		var m = subDt.getMonth();
		var d = subDt.getDate().toString().padStart(2, '0');
		var hrs = subDt.getHours();
		var min = subDt.getMinutes();
		//var submitOn = d +"-" + m + "-" + y + " " + hrs + ":" + min;

		var submitOn = y +"-" + m + "-" + d +" " + hrs + ":" + min;

		var submitOnIST = ConvertIST(new Date(submitOn));	
	
	
	
	var tempVac = objVAC.filter(v => v.vac_id == objMaster[0].vac);
	if(tempVac.length >0)
	{
		vac = tempVac[0].vac_name;
	}
	
	var tempSts = objStatus.filter(f => f.request_status_id == objMaster[0].rStatus);
	if(tempSts.length >0)
	{
		sts = tempSts[0].request_status_name;
	}
	var reference_text = "Reference ID -"+reqId;
	$("#show_reference").html(reference_text);
	$("#spanReqId").html(reqId);
	$("#spanFullName").html(fullName);
	$("#spanEmail").html(email);
	$("#spanPassNo").html(pass);
	$("#spanWPN").html(wpn);
	$("#spanIssueDt").html(issueDt);
	$("#spanSubmitDt").html(submitOnIST);
	$("#spanVAC").html(vac);
	$("#spanSts").html(sts);
	ShowPassport();
	$("#myModal").modal('show');
}

function ShowLoading()
{
	var loader=	$('#loader');
	loader.show();	
}
function HideLoading()
{	
	var loader=	$('#loader');
	loader.hide();
}








