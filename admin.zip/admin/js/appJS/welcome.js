var SessionId;
var SessionToken;
var RoleId;



$(function () {	

	//getLoginAdminDetails();
	SessionId = $("#Globalsessionid").val();
	SessionToken  = $("#Globalsessiontoken").val();
	RoleId  = $("#RoleId").val();

	console.log(RoleId);

	$("body").addClass("loading");

	setTimeout(() => {

		$("body").removeClass("loading");

		var form = document.getElementById('mainForm');
		document.getElementById('Globalsessionid').value = SessionId;
		document.getElementById('Globalsessiontoken').value = SessionToken;
		document.getElementById('RoleId').value = RoleId;		
		if(RoleId==1){
			form.action = REDIRECTURL + "list/";
		}else if(RoleId==4){
			form.action = REDIRECTURL + "manifest/";
		}else if(RoleId==5){
			form.action = REDIRECTURL + "manifest/";
		}else{
			form.action = REDIRECTURL + "cases/";
		}			
		form.submit();

	}, 1000);

});


function getLoginAdminDetails()
{
	const Globaluserid = $("#Globaluserid").val();
	const Globalsessionid = $("#Globalsessionid").val();
	const Globalsessiontoken  = $("#Globalsessiontoken").val();
	const user_name = $("#user_name").val();
	const full_name = $("#full_name").val();
	const RoleId = $("#RoleId").val();

    var chkObj_Session = { Globaluserid: Globaluserid, Globalsessionid: Globalsessionid, Globalsessiontoken: Globalsessiontoken , RoleId: RoleId ,user_name:user_name,full_name:full_name }
    var chkParameter_Session =  JSON.stringify(chkObj_Session);
    
    $.ajax({
        url: sessionajaxvalid,
        type: 'POST',
        data: chkParameter_Session,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			//console.log('session',data);
			SessionId = data.Globalsessionid;
			SessionToken = data.session_token;
			UserRole = data.RoleId;
			UserId = data.Globaluserid;
			objStatus = data.master_status_list;
			objReason = data.reasoncode_list;
			objVAC = data.vac_list;
			DocKey = data.document_key;
			
			$("#spanWelcomeUser").html("Welcome " + " " + data.full_name);
        }
    });
}









