var SessionId;
var SessionToken;
var UserRole;
var UserId;
var DocKey;
var objStatus;
var objVAC;
var objReason;
var objMaster;
var objDetails;
var objDocument;
var CurrentPassAct = 0;
var CurrentNullaAct = 0;
var isPassport = 0;
var DetailsId;
var objCustomer;
var objUser;
var objUserList;
var objPassHis = [];
var objNullaHis = [];
var LastActivity;
var isFilter = 0;

var TotalRows = 0;
var StartRecords = 0;
var EndRecords = 0;

var itemsPerPage = 100;
var currentPage = 1;
var sr = 1;
var er = 0;

var EncryptionKey = "";

$(function () {	
	getLoginAdminDetails();
	
	LoadCaseList();
	LoadVAC();
	LoadStatus();
	
	$('#FromDate_Admin').datepicker({
        autoclose: true,
		format: "yyyy-mm-dd"
    });
    $('#ToDate_Admin').datepicker({
        autoclose: true,
		format: "yyyy-mm-dd"
    });
	//$("#myModal1").modal('show');
	
	LastActivity = GetCurrentTime();
	//setInterval(PingServer(SessionId,SessionToken,LastActivity), 300000);
});
function GetCurrentTime()
{
	const now = new Date();
	const year = now.getUTCFullYear();
	const month = now.getUTCMonth() + 1; // Months are 0-indexed
	const day = now.getUTCDate();
	const hours = now.getUTCHours();
	const minutes = now.getUTCMinutes();
	const seconds = now.getUTCSeconds();
	var dt = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
	return dt;
}
function setupPagination_Filter() {
	sr = 1;
	var endRec = 0;
	if(parseInt(TotalRows) < 100)
	{
		EndRecords = parseInt(TotalRows);
		endRec = parseInt(TotalRows);
	}
	else
	{
		EndRecords = itemsPerPage;
		endRec = sr + 99;
		if(endRec >= parseInt(TotalRows) )
		{
			endRec = parseInt(TotalRows);
		}
	}
	
    const totalPages = Math.ceil(parseInt(TotalRows) / itemsPerPage);
    const paginationDiv = document.getElementById("pagination");
    paginationDiv.innerHTML = "";
	
		
	var msg = "Showing " + sr + " to " + endRec + " of " + TotalRows;
	
	console.log(currentPage,"-",sr,"-",endRec,"-",isFilter);
	
	//result
	const paragraph  = document.createElement("p");
	paragraph.textContent = msg;
	paragraph.id = "resPara";
	paginationDiv.appendChild(paragraph);

    // Previous button
    const prevButton = document.createElement("button");
    prevButton.textContent = "Previous";
	prevButton.id = "btnPrevious";
    prevButton.className = currentPage === 1 ? "disabled" : "";
    prevButton.addEventListener("click", () => {
		currentPage--;
		sr = sr - 100;
		if(sr < 0)
		{
			sr = 1;
		}
		LoadCaseList();			
    });
    paginationDiv.appendChild(prevButton);

    // Page number buttons
    for (let i = 1; i <= totalPages; i++) {
        const button = document.createElement("button");
        button.textContent = i;
		button.id = "btn"+i;
        button.className = i === currentPage ? "active" : "";
        button.addEventListener("click", () => {
			
			currentPage = i;
			//StartRecords = (i-1)*100;
			//EndRecords = StartRecords + 100;
			sr = (i-1)*100; 
			sr = sr + 1;
			
			if(i > 0 && i <= totalPages)
			{
				$("#btn"+ (i-1)).removeClass('active');
			}
			
			LoadCaseList();
        });
        paginationDiv.appendChild(button);
    }

    // Next button
    const nextButton = document.createElement("button");
    nextButton.textContent = "Next";
	nextButton.id = "btnNext";
    nextButton.className = currentPage === totalPages ? "disabled" : "";
    nextButton.addEventListener("click", () => {
		
		currentPage++;
		sr = sr + 100;		
		if(isFilter == 0)
		{
			LoadCaseList();
		}
		else
		{
			FilterCase();			
		}
    });
    paginationDiv.appendChild(nextButton);
}
function setupPagination() {
	//sr = 1;
	var endRec = 0;
	if(parseInt(TotalRows) < 100)
	{
		EndRecords = parseInt(TotalRows);
		endRec = parseInt(TotalRows);
	}
	else
	{
		EndRecords = itemsPerPage;
		endRec = sr + 99;
		if(endRec >= parseInt(TotalRows) )
		{
			endRec = parseInt(TotalRows);
		}
	}
	
    const totalPages = Math.ceil(parseInt(TotalRows) / itemsPerPage);
    const paginationDiv = document.getElementById("pagination");
    paginationDiv.innerHTML = "";
	
		
	var msg = "Showing " + sr + " to " + endRec + " of " + TotalRows;
	
	console.log(currentPage,"-",sr,"-",endRec,"-",isFilter);
	
	//result
	const paragraph  = document.createElement("p");
	paragraph.textContent = msg;
	paragraph.id = "resPara";
	paginationDiv.appendChild(paragraph);

    // Previous button
    const prevButton = document.createElement("button");
    prevButton.textContent = "Previous";
	prevButton.id = "btnPrevious";
    prevButton.className = currentPage === 1 ? "disabled" : "";
    prevButton.addEventListener("click", () => {
		currentPage--;
		sr = sr - 100;
		if(sr < 0)
		{
			sr = 1;
		}
		LoadCaseList();			
    });
    paginationDiv.appendChild(prevButton);

    // Page number buttons
    for (let i = 1; i <= totalPages; i++) {
        const button = document.createElement("button");
        button.textContent = i;
		button.id = "btn"+i;
        button.className = i === currentPage ? "active" : "";
        button.addEventListener("click", () => {
			
			currentPage = i;
			//StartRecords = (i-1)*100;
			//EndRecords = StartRecords + 100;
			sr = (i-1)*100; 
			sr = sr + 1;
			
			if(i > 0 && i <= totalPages)
			{
				$("#btn"+ (i-1)).removeClass('active');
			}
			
			LoadCaseList();
        });
        paginationDiv.appendChild(button);
    }

    // Next button
    const nextButton = document.createElement("button");
    nextButton.textContent = "Next";
	nextButton.id = "btnNext";
    nextButton.className = currentPage === totalPages ? "disabled" : "";
    nextButton.addEventListener("click", () => {
		
		currentPage++;
		sr = sr + 100;		
		if(isFilter == 0)
		{
			LoadCaseList();
		}
		else
		{
			FilterCase();			
		}
    });
    paginationDiv.appendChild(nextButton);
}

function LoadCaseList()
{
	var param = {
		session_id: SessionId,
		sessionToken: SessionToken,
		keyword: "",
		keyType: "0",
        dateType: "0",
        vac: "",
        allSts:1,
		status: "0",
        from: "",
        to: "",
        startRecord: sr,
        rows: 1,
		caseList: 1
	}
	var obj = JSON.stringify(param);
	GetCaseList(obj);
	
}
function DownloadExcel()
{
	$("#txtSearchStr_Admin").css('border-color', '#ccc');
	$("#ddlKeyword").css('border-color', '#ccc');
	$("#FromDate_Admin").css('border-color', '#ccc');
	$("#ToDate_Admin").css('border-color', '#ccc');	
	$("#ddlPriority_Admin").css('border-color', '#ccc');	
	
	var searchStr = $("#txtSearchStr_Admin").val().trim();
	var type = $("#ddlKeyword").val();
	var fromDt = $("#FromDate_Admin").val();
	var toDt = $("#ToDate_Admin").val();
	var vId = $("#ddlVAC_Admin").val();
	var sts = $("#ddlStatus_Admin").val();
	var dtType = $("#ddlDateType_Admin").val();
	var pri = $("#ddlPriority_Admin").val();
	
	if(type > 0 && searchStr == "")
	{
		$("#txtSearchStr_Admin").css('border-color', 'red');
		$("#txtSearchStr_Admin").focus();
		return false;
	}
	if(searchStr != "" && type == 0)
	{
		$("#ddlKeyword").css('border-color', 'red');
		$("#ddlKeyword").focus();
		return false;
	}
	
	if(dtType > 0)
	{
		if(fromDt == "")
		{
			$("#FromDate_Admin").css('border-color', 'red');
			$("#FromDate_Admin").focus();
			return false;
		}
		if(toDt == "")
		{
			$("#ToDate_Admin").css('border-color', 'red');
			$("#ToDate_Admin").focus();
			return false;
		}
	}
	if(fromDt != "" && toDt != "")
	{
		if(dtType == 0)
		{
			$("#ddlDateType_Admin").css('border-color', 'red');
			$("#ddlDateType_Admin").focus();
			return false;
		}
	}
	if(type == 0 && dtType == 0 && vId == 0 && sts == 0)
	{
		alert("Select any filter option");
		return false;
	}
	if(pri == -1)
	{
		pri = 0;
	}
	var param = {
		session_id: SessionId,
		sessionToken: SessionToken,
		keyword: searchStr,
		keyType: type,
		dateType: dtType,
		vac: vId,
		status: sts,
		from: fromDt,
		to: toDt,
		startRecord: 1,
		rows: 1,
		caseList: 1,
		xldwnld: 1,
		priority: pri
	}
	console.log("excel-",param);
	var obj = JSON.stringify(param);
	GetExcelRecords(obj);
}
function LoadExcelData(obj, objDet)
{
	var jsonData = [];
	if(obj != null)
	{
		for(var i=0;i<obj.length;i++)
		{
			var vac = "";
			var tempVac = objVAC.filter(v => v.vac_id == obj[i].vac);
			if(tempVac.length >0)
			{
				vac = tempVac[0].vac_name;
			}
			var sts = "";
			var tempSts = objStatus.filter(f => f.request_status_id == obj[i].rStatus);
			if(tempSts.length >0)
			{
				sts = tempSts[0].request_status_name;
			}
			var reqId = obj[i].reqId;
			var addDt = new Date(obj[i].addOn);
			var addOnIST = ConvertIST(addDt);
			var subDt = new Date(obj[i].submitOn);
			var submitOnIST = ConvertIST(subDt);
			
			var temp = objDet.filter(f => f.reqId == reqId);
			for(var j = 0;j<temp.length;j++)
			{
				var sts1 = "";
				var tempSts1 = objStatus.filter(f => f.request_status_id == temp[j].dtlStatus);
				if(tempSts1.length >0)
				{
					sts1 = tempSts1[0].request_status_name;
				}
				
				var issueDt2 = new Date(temp[j].wpndt);
				var y2 = issueDt2.getFullYear();
				var m2 = (issueDt2.getMonth() + 1).toString().padStart(2, '0');
				var d2 = issueDt2.getDate().toString().padStart(2, '0');
				var wpnDt2 = d2 +"/" + m2 + "/" + y2;
				
				var dob = new Date(temp[j].dob);
				var y3 = dob.getFullYear();
				var m3 = (dob.getMonth() + 1).toString().padStart(2, '0');
				var d3 = dob.getDate().toString().padStart(2, '0');
				var dobDt = d3 +"/" + m3 + "/" + y3;
				
				var pass = temp[j].ppn;//decrypt(EncryptionKey, temp[j].ppn);
				
				var params = {
					RequestID: reqId,
					IP: obj[i].IP,
					FullName: temp[j].fName + ' ' + temp[j].lName,
					EmailId: obj[i].mailId,
					PassportNo: pass,
					NullaOstaNo: temp[j].wpn,
					DOB: dobDt,
					IssueDate: wpnDt2,
					SubmitedOn: submitOnIST,
					VAC: vac,
					Status: sts
				}
				jsonData.push(params);
			}
			
			/*var params = {
				RequestID: reqId,
				IP: obj[i].IP,
				AddedOn: addOnIST,
				SubmitedOn: submitOnIST,
				NoOfApplicants: obj[i].noOfUsr,
				VAC: vac,
				Status: sts
			}
			jsonData.push(params);*/
		}
		var name = "Cases.xlsx";
		const worksheet = XLSX.utils.json_to_sheet(jsonData);
		const workbook = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
		const excelBuffer = XLSX.write(workbook, {
			bookType: "xlsx",
			type: "array",
		});

		const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
		const link = document.createElement("a");
		link.href = URL.createObjectURL(blob);
		link.download = name;
		link.click();
		URL.revokeObjectURL(link.href);
	}
}
function ConvertIST(specificDate)
{
	const istOffset = 5.5 * 60 * 60 * 1000; // IST offset in milliseconds
	const localDate = new Date(specificDate.getTime() + istOffset); 
	
	const extractedDay = localDate.getDate().toString().padStart(2, '0');
	const extractedMonth = (localDate.getMonth() + 1).toString().padStart(2, '0'); // Months are 0-indexed
	const extractedYear = localDate.getFullYear();
	const extractedHour = localDate.getHours().toString().padStart(2, '0');
	const extractedMinute = localDate.getMinutes().toString().padStart(2, '0');

	var dt = extractedDay + "/" + extractedMonth + "/" + extractedYear + " " + extractedHour + ":" + extractedMinute;

	return dt;
}

function Logout(menu){
	let result = confirm("Are you sure want to logout session!");
	if (result === true) {
	   if(menu==1)
	   {
	   //var url ="Logout.php";
	   $('#mainForm').attr('action', LogoutURL);
	   document.forms["mainForm"].submit();
	   }
	}    

}
function getLoginAdminDetails()
{
	const Globaluserid = $("#Globaluserid").val();
	const Globalsessionid = $("#Globalsessionid").val();
	const Globalsessiontoken  = $("#Globalsessiontoken").val();
	const user_name = $("#user_name").val();
	const full_name = $("#full_name").val();
	const RoleId = $("#RoleId").val();
		
	/*const Globaluserid = $("#Globaluserid").val();
	const Globalsessionid = $("#Globalsessionid").val();
	const Globalsessiontoken  = $("#Globalsessiontoken").val();
	const user_name = $("#user_name").val();
	const full_name = $("#full_name").val();
	const RoleId = $("#RoleId").val();*/
    
    var chkObj_Session = { Globaluserid: Globaluserid, Globalsessionid: Globalsessionid, Globalsessiontoken: Globalsessiontoken , RoleId: RoleId ,user_name:user_name,full_name:full_name }
    var chkParameter_Session =  JSON.stringify(chkObj_Session);
    
    $.ajax({
        url: sessionajaxvalid,
        type: 'POST',
        data: chkParameter_Session,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			
			SessionId = data.Globalsessionid;
			SessionToken = data.session_token;
			UserRole = data.RoleId;
			UserId = data.Globaluserid;
			objStatus = data.master_status_list;
			objReason = data.reasoncode_list;
			objVAC = data.vac_list;
			DocKey = data.document_key;
			objUserList = data.user_list;
			EncryptionKey = data.encryption_key;
			
			$("#spanWelcomeUser").html("Welcome " + " " + data.full_name);
        }
    });
}
function convertToTimeZone(date, offset) {
  const utc = date.getTime() + date.getTimezoneOffset() * 60000;
  return new Date(utc + offset * 60000);
}
function LoadVAC()
{
	var list = "";
	$("#ddlVAC_Admin").empty();
	list += "<option value='0'>---Select VAC---</option>";
	for(var i=0;i<objVAC.length;i++)
	{
		list += "<option value='"+ objVAC[i].vac_id +"'>"+ objVAC[i].vac_name +"</option>";
	}
	$("#ddlVAC_Admin").append(list);
}
function LoadStatus()
{
	var tempSts = objStatus.filter(s => s.request_status_id>1);
	var list = "";
	$("#ddlStatus_Admin").empty();
	list += "<option value='0'>---Select---</option>";
	for(var i=0;i<tempSts.length;i++)
	{
		list += "<option value='"+ tempSts[i].request_status_id +"'>"+ tempSts[i].request_status_name +"</option>";
	}
	$("#ddlStatus_Admin").append(list);
}
function FilterCase()
{
	isFilter = 1;
	$("#pagination").hide();
	
	$("#txtSearchStr_Admin").css('border-color', '#ccc');
	$("#ddlKeyword").css('border-color', '#ccc');
	$("#FromDate_Admin").css('border-color', '#ccc');
	$("#ToDate_Admin").css('border-color', '#ccc');	
	$("#ddlPriority_Admin").css('border-color', '#ccc');	
	
	var searchStr = $("#txtSearchStr_Admin").val().trim();
	var type = $("#ddlKeyword").val();
	var fromDt = $("#FromDate_Admin").val();
	var toDt = $("#ToDate_Admin").val();
	var vId = $("#ddlVAC_Admin").val();
	var sts = $("#ddlStatus_Admin").val();
	var dtType = $("#ddlDateType_Admin").val();
	var pri = $("#ddlPriority_Admin").val();	
	
	if(type > 0 && searchStr == "")
	{
		$("#txtSearchStr_Admin").css('border-color', 'red');
		$("#txtSearchStr_Admin").focus();
		return false;
	}
	if(searchStr != "" && type == 0)
	{
		$("#ddlKeyword").css('border-color', 'red');
		$("#ddlKeyword").focus();
		return false;
	}
	
	if(dtType > 0)
	{
		if(fromDt == "")
		{
			$("#FromDate_Admin").css('border-color', 'red');
			$("#FromDate_Admin").focus();
			return false;
		}
		if(toDt == "")
		{
			$("#ToDate_Admin").css('border-color', 'red');
			$("#ToDate_Admin").focus();
			return false;
		}
	}
	if(fromDt != "" && toDt != "")
	{
		if(dtType == 0)
		{
			$("#ddlDateType_Admin").css('border-color', 'red');
			$("#ddlDateType_Admin").focus();
			return false;
		}
	}
	if(type == 0 && dtType == 0 && vId == 0 && sts == 0 && pri == -1)
	{
		alert("Select any filter option");
		return false;
	}

	/*if(type == 3)
	{
		var encVal = encrypt(EncryptionKey, searchStr);
		searchStr = encVal;
	}*/
	//removed other filters when keyword search on 18-Apr-2025 as instructed by Kalai
	if(type > 0)
	{
		dtType = 0;
		vId = 0;
		sts = 0;
		fromDt = "";
		toDt = "";
		pri = -1;		
	}
	var param = {
		session_id: SessionId,
		sessionToken: SessionToken,
		keyword: searchStr,
		keyType: type,
		dateType: dtType,
		vac: vId,
		status: sts,
		from: fromDt,
		to: toDt,
		priority: pri,
		startRecord: 1,
		rows: 1,
		caseList: 1
	}
	var obj = JSON.stringify(param);
	
	GetSearchCases(obj, 1);	
}
function editVAC(reqId, vId)
{
	$("#hdnEditVId").val(vId);
	$("#hdnEditRId").val(reqId);
	var temp = objVAC.filter(f => f.vac_id != vId);

	if(temp.length > 0)
	{		
		var list = "";
		$("#modalEditVAC").modal('show');
		$("#divEditVacList").empty();
		list += "<select class='form-select' id='ddlEditVac"+ reqId +"'>";
		list += "<option value='0'>---Select---</option>";
		for(var i=0;i<temp.length;i++)
		{
			list += "<option value='"+ temp[i].vac_id +"'>"+ temp[i].vac_name +"</option>";
		}
		list += "</select>";
		$("#divEditVacList").append(list);
	}
}
function updateVAC(flag)
{
	
	if(flag == 1)
	{
		var oldVacId = $("#hdnEditVId").val();
		var reqId = $("#hdnEditRId").val();
		var newVacId = $("#ddlEditVac"+reqId).val();
		if(newVacId > 0)
		{
			var param = {
				session_id: SessionId,
				session_token: SessionToken,
				request_id: reqId,
				old_vac_id: oldVacId,
				new_vac_id: newVacId,
				user_id: UserId
			}
			var obj = JSON.stringify(param);
			updateLocation(obj);
		}
		else
		{
			alert("Please select the location to change");
		}
	}
	else
	{
		$("#modalEditVAC").modal('hide');
	}
}
function LoadSearchList()
{
	$("#btnVerdict").show();
	$("#spanYes").hide();
	$("#spanNo").hide();
	if(objMaster == null)
	{		
		$("#btnVerdict").hide();
		$("#divList").empty();
		var list1 = "<table class='table'><thead><tr><td style='text-align: center;'>---------- No Records -----------</td></tr></thead></table>";
		$("#divList").append(list1);
		
		$("#btnPrevious").removeClass('disabled');
		$("#pagination").hide();
	}
	if(objMaster != null)
	{
		$("#pagination").show();
	$("#btnVerdict").hide();
	$("#btnAssign").show();
	$("#spanYes").show();
	$("#spanNo").hide();
	var list = "", k = 0, l = 0;
	$("#divList").empty();

	//for(var i=0;i<objMaster.length;i++)
	
	//for(var i=parseInt(StartRecords);i<parseInt(EndRecords);i++)
	//for(var i=0;i<44;i++)
	for(var i=0;i<objMaster.length;i++)
	{
		k = i+1;
		var vac = "", pri = "";
		var tempVac = objVAC.filter(v => v.vac_id == objMaster[i].vac);
		if(tempVac.length >0)
		{
			vac = tempVac[0].vac_name;
		}
		var sts = "";
		var tempSts = objStatus.filter(f => f.request_status_id == objMaster[i].rStatus);
		if(tempSts.length >0)
		{
			sts = tempSts[0].request_status_name;
		}
		var reqId = objMaster[i].reqId;
			
				
		var addDt = new Date(objMaster[i].addOn);
			
		var addOnIST = ConvertIST(addDt);
		
						
		var subDt = new Date(objMaster[i].submitOn);
		
		
		var submitOnIST = ConvertIST(subDt);

		var pr = objMaster[i].priority;
		if(pr == 0)
		{
			pri = "Normal";
		}
		else
		{
			pri = "Priority";
		}
	
		var temp = objDetails.filter(f => f.reqId == reqId);
		var len = temp.length;
		
				
		list += '<div class="table-responsive">';
		list += '<div class="table-responsive">';
		list += '<table class="table accordion table-responsive table-bordered text-left">';
        list += '<thead>';
		
		list += '<tr>';
				
		list += '<th scope="col" class="star_required2">'+ k +'</th>';
		
		list += '<th scope="col" class="star_required2">Request ID :</th>';
		if(pr == 0)
		{			
			list += '<th scope="col" class="star_required2 w-60">'+ reqId +'</th>';
		}
		else
		{
			list += '<th scope="col" class="star_required2 w-60 priClr">'+ reqId +'</th>';
		}
		list += '<th scope="col" class="star_required2">IP :</th>';
        list += '<th scope="col" class="star_required2 w-120">'+ objMaster[i].IP +'</th>';
		
		list += '<th scope="col" class="star_required2">Added On :</th>';
        list += '<th scope="col" class="star_required2">'+ addOnIST +'</th>';
        list += '<th scope="col" class="star_required2">Submited On :</th>';
        list += '<th scope="col" class="star_required2">'+ submitOnIST +'</th>';
        list += '<th scope="col" class="star_required2">No. Of Applicants :</th>';
        list += '<th scope="col" class="star_required2">'+ objMaster[i].noOfUsr +'</th>';
		list += '<th scope="col" class="star_required2">VAC :</th>';
		if(UserRole == 1 || UserRole == 2)
		{
			list += '<th scope="col" class="star_required2 wid-150" style="width: 150px !important;">';
			list += '<div class="d-flex gap-2 align-items-center">';
			list += '<span>'+ vac +'</span>';
			list += '<span><i class="fa fa-pencil-square" aria-hidden="true" style="color : green" onClick="editVAC('+ reqId + ',' + objMaster[i].vac +')"></i></span>';
			list += '</div>';
			list += '</th>';
		}
		else
		{
			list += '<th scope="col" class="star_required2 wid-150" style="width: 150px !important;">'+ vac +'</th>';
		}
        //list += '<th scope="col" class="star_required2 wid-120" style="width: 120px !important;">'+ vac +'</th>';
		list += '<th scope="col" class="star_required2">Priority :</th>';
        list += '<th scope="col" class="star_required2 wid-120" style="width: 120px !important;">'+ pri +'</th>';
        list += '<th scope="col" class="star_required2">Status :</th>';
        list += '<th scope="col" class="star_required2 wid-120" style="width: 120px !important;">'+ sts +'</th>';
		list += '<th data-bs-toggle="collapse" data-bs-target="#r'+ k +'" rowspan="'+ len +'"><i class="fa fa-chevron-down"></i></th>';
		list += "</tr>";
		
		list += '</thead></table></div>';
		
		list += '<table class="table accordion table-responsive table-bordered text-left collapse accordion-collapse p-2" id="r'+ k +'">';
			
		list += '<thead>';
        list += '<tr>';
		
        list += '<th scope="col">Full Name</th>';
        list += '<th scope="col">Email Id</th>';
        list += '<th scope="col">Passport Number</th>';
        list += '<th scope="col">Nulla osta No</th>';
		list += '<th scope="col">DOB</th>';
        list += '<th scope="col">Issue Date</th>';
        list += '<th scope="col">Submited On</th>';
        list += '<th scope="col">VAC</th>';
		list += '<th scope="col">Appointment On</th>';
		list += '<th scope="col">Status</th>';
        list += '<th scope="col">Action</th>';
        list += '</tr>';
		list += '</thead>';
			
		list += '<tbody style="background:#fff;">';
		
		for(var j = 0;j<temp.length;j++)
		{	
			l = j+1;
			var sts1 = "";
			var tempSts1 = objStatus.filter(f => f.request_status_id == temp[j].dtlStatus);
			if(tempSts1.length >0)
			{
				sts1 = tempSts1[0].request_status_name;
			}
			
			var issueDt2 = new Date(temp[j].wpndt);
			var y2 = issueDt2.getFullYear();
			var m2 = (issueDt2.getMonth() + 1).toString().padStart(2, '0');
			var d2 = issueDt2.getDate().toString().padStart(2, '0');
			var wpnDt2 = d2 +"/" + m2 + "/" + y2;
			
			var dob = new Date(temp[j].dob);
			var y3 = dob.getFullYear();
			var m3 = (dob.getMonth() + 1).toString().padStart(2, '0');
			var d3 = dob.getDate().toString().padStart(2, '0');
			var dobDt = d3 +"/" + m3 + "/" + y3;
			
			var appOnIST = "";
			if(temp[j].slotAt != null)
			{
				var appDt = new Date(temp[j].slotAt);				
				appOnIST = ConvertIST(appDt);
			}
			
			var pNo = temp[j].ppn;//decrypt(EncryptionKey, temp[j].ppn);		
			
						
			list += '<td>'+ temp[j].fName + ' ' + temp[j].lName +'</td>';
			list += '<td>'+ objMaster[i].mailId+'</td>';
			list += '<td>'+ pNo +'</td>';
			list += '<td>'+ temp[j].wpn +'</td>';
			list += '<td>'+ dobDt +'</td>';
			list += '<td>'+ wpnDt2 +'</td>';
			list += '<td>'+ submitOnIST +'</td>';
			list += '<td>'+ vac+'</td>';			
			list += '<td>'+ appOnIST +'</td>';
			list += '<td>'+ sts1 +'</td>';
			//list += '<td><button type="button" class="btn btn-link" onClick="ShowDialog_Admin('+ temp[j].dtlId +')">View</button></td>'; 	
			list += '<td><button type="button" class="btn btn-link" onClick="ShowDialog('+ temp[j].dtlId +')">View</button></td>'; 			
			list += '</tr>';
		}
		list += '</tbody>';			
		list += '</table>';	
	}
	list += '</div>';
	
	$("#divList").append(list);
	}
}

function ShowDialog_Admin(detId)
{
	var reqId = 0, fullName = "", email = "", submitOn = "",vac = "", sts = "", pass = "", wpn = "", issueDt = "", comments = "", reasonId = 0;
	
	var tempDoc = objDocument.filter(d => d.dtlId == detId);
	if(tempDoc.length >0)
	{
		comments = tempDoc[0].remarks;
		if(comments == null)
		{
			comments = "";
		}
		reasonId = tempDoc[0].reason;
		if(reasonId == null)
		{
			reasonId = 0;
		}
	}
	if(comments != "")
	{
		$("#txtComment").val(comments);
	}
	

	var temp = objDetails.filter(f => f.dtlId == detId);
	
	DetailsId = detId;
	if(temp.length > 0)
	{
		fullName = temp[0].fName + " " + temp[0].lName;
		pass = temp[0].ppn;
		wpn = temp[0].wpn;
		//issueDt = temp[0].wpndt;
		
		var issueDt2 = new Date(temp[0].wpndt);
		var y2 = issueDt2.getFullYear();
		var m2 = (issueDt2.getMonth() + 1).toString().padStart(2, '0');
		var d2 = issueDt2.getDate().toString().padStart(2, '0');
		issueDt = d2 +"/" + m2 + "/" + y2;
	}
	reqId = objMaster[0].reqId;
	email = objMaster[0].mailId;
	
	var subDt = new Date(objMaster[0].submitOn);
	/*var y = subDt.getFullYear();
	var m = subDt.getMonth();
	var d = subDt.getDate().toString().padStart(2, '0');
	var hrs = subDt.getHours();
	var min = subDt.getMinutes();

	var submitOn = y +"-" + m + "-" + d +" " + hrs + ":" + min;*/
	var submitOnIST = ConvertIST(subDt);	
	
	var tempVac = objVAC.filter(v => v.vac_id == objMaster[0].vac);
	if(tempVac.length >0)
	{
		vac = tempVac[0].vac_name;
	}
	
	var tempSts = objStatus.filter(f => f.request_status_id == objMaster[0].rStatus);
	if(tempSts.length >0)
	{
		sts = tempSts[0].request_status_name;
	}
	//var reference_text = "Reference ID -"+reqId;
	//$("#show_reference").html(reference_text);
	$("#spanReqId").html(reqId);
	$("#spanFullName").html(fullName);
	$("#spanEmail").html(email);
	$("#spanPassNo").html(pass);
	$("#spanWPN").html(wpn);
	$("#spanIssueDt").html(issueDt);
	$("#spanSubmitDt").html(submitOnIST);
	$("#spanVAC").html(vac);
	$("#spanSts").html(sts);
	ShowPassport();
	$("#myModal").modal('show');
    $("#divBtnVRB").hide();	
}
function GetPassportNullaNo(flag, detId)
{
	var no = "", passNo = "", nullaNo = "";
	var temp = objDetails.filter(f => f.dtlId == detId);
	if(temp.length > 0)
	{
		passNo = temp[0].ppn;
		nullaNo = temp[0].wpn;
	}
	if(flag == 1)
	{
		no = nullaNo;
	}
	else
	{
		no = passNo;
	}
	return no;
}
function GetStatusName(cSts)
{
	var name = "";
	var cStsName = objStatus.filter(f => f.request_status_id == cSts);
	if(cStsName.length >0)
	{
		name = cStsName[0].request_status_name;
	}
	return name;
}
function GetUserName(uId)
{
	var name = "";
	var temp = objUserList.filter(f => f.user_id == uId);
	
	if(temp.length > 0)
	{
		name = temp[0].full_name;
	}
	return name;
}
function GetApplicantName(detId)
{
	var name = "";
	var temp = objDetails.filter(f => f.dtlId == detId);
	
	if(temp.length > 0)
	{
		name = temp[0].fName + " " + temp[0].lName;
	}
	return name;
}
function ShowHistory()
{	
	/*$("#liPass").removeClass('active show');
	$("#liNulla").removeClass('active show');
	$("#liHistory").addClass('active show');*/
	
    var rId = 0, stsName = "", spanMsg = "", spanMsg1 = "", passNo = "", nullaNo = "", submitOnIST = "", reviewCount = 0;
	var dIdNulla = 0;
	
	nullaNo = GetPassportNullaNo(1, DetailsId);
	passNo = GetPassportNullaNo(2, DetailsId);
	
	
	var tempDoc1 = objDocument.filter(f => f.type == 1 && f.dtlId == DetailsId);
	
	if(tempDoc1.length > 0)
	{
		rId = tempDoc1[0].reqId;
		reviewCount = tempDoc1[0].revwCount;
		dIdNulla = tempDoc1[0].docId;
		var tempMas = objMaster.filter(m => m.reqId == rId);
		if(tempMas.length > 0)
		{
			var subDt = tempMas[0].submitOn;
			
			submitOnIST = ConvertIST(new Date(subDt));
		}		
	}
	var l = tempDoc1.length - 1;
	var cSts = tempDoc1[l].docStatus;
	var stsName = GetStatusName(cSts);
	if(cSts == 6)
	{
		spanMsg = '<span class="verified-btn"><B>'+ stsName +'</B>';
	}
	else if(cSts == 4)
	{
		spanMsg = '<span class="block-btn"><B>'+ stsName +'</B>';
	}
	else
	{
		spanMsg = '<span><B>'+ stsName +'</B>';
	}
	
	var tempDoc2 = objDocument.filter(f => f.type == 2 && f.dtlId == DetailsId);
	var dId = tempDoc2[0].docId;
	var l1 = tempDoc2.length - 1;
	var cSts1 = tempDoc2[l1].docStatus;
	var stsName1 = GetStatusName(cSts1);
	if(cSts1 == 6)
	{
		spanMsg1 = '<span class="verified-btn"><B>'+ stsName1 +'</B>';
	}
	else if(cSts1 == 4)
	{
		spanMsg1 = '<span class="block-btn"><B>'+ stsName1 +'</B>';
	}
	else
	{
		spanMsg1 = '<span><B>'+ stsName1 +'</B>';
	}
	
	$("#spanStsPassHis").html(spanMsg1);
	$("#spanPassHis").html(passNo);
	$("#spanStsNullaHis").html(spanMsg);
	$("#spanNullaHis").html(nullaNo);
	

	//Passport
	//if(cSts1 == 4 || cSts1 == 5)
	if(cSts1 > 2)
	{
		//LoadPassportData(tempDoc2, submitOnIST);
		var obj = {
			session_id: SessionId,
			sessionToken: SessionToken,
			docId: dId
		}
		var chkParam = JSON.stringify(obj);
		
		GetDetailsList(chkParam, DetailsId, reviewCount, cSts1, 2);
	}
	else
	{
		LoadPassportData(tempDoc2, submitOnIST);
	}
	
	//NullaOsta
	
	//if(cSts == 4 || cSts == 5)
	if(cSts > 2)
	{
		LoadNullaOsta(tempDoc1, submitOnIST);
		var obj = {
			session_id: SessionId,
			sessionToken: SessionToken,
			docId: dIdNulla
		}
		var chkParam = JSON.stringify(obj);
		
		GetDetailsList(chkParam, DetailsId, reviewCount, cSts, 1);
	}
	else
	{
		LoadNullaOsta(tempDoc1, submitOnIST);
	}	
}

function LoadPassportData(tempDoc2, submitOnIST)
{
	var c = 1, list = "", actBy = "", actOn = "", isAgt = "";
	$("#tblPassHis").empty();
	$.each(tempDoc2, function( index, value ) {
		var sts = GetStatusName(value.docStatus);
		var verBy = value.vefifyBy;
		var verOn = value.verifyOn;
		if(verBy == null)
		{
			verBy = "";
		}
		if(verOn == null)
		{
			verOn = "";
		}
		if(value.docStatus == 2)
		{
			actBy = GetApplicantName(DetailsId);
			isAgt = "Applicant";				
		}
		if(value.docStatus == 6)
		{
			isAgt = "Agent";
		}
		if(verBy != "")
		{
			actBy = GetUserName(value.vefifyBy);
		}
		if(verOn != "")
		{
			actOn = ConvertIST(new Date(value.verifyOn));
		}
		else
		{
			actOn = submitOnIST;
		}
		list += "<tr>";
		list += "<td>"+ c +"</td>";
		list += "<td>"+ sts +"</td>";
		list += "<td>"+ actBy +"</td>";
		list += "<td>"+ isAgt +"</td>";
		list += "<td>"+ actOn +"</td>";
		list += "<td><span onclick=DisplayFile('"+ value.file +"')>"+ value.file +"</span></td>";
		list += "</tr>";
		c++;
	});
	$("#tblPassHis").append(list);
	DisplayFile(tempDoc2[0].file,0,2);
}
function LoadNullaOsta(tempDoc1, submitOnIST)
{
	var c1 = 1, list1 = "", actBy1 = "", actOn1= "", isAgt1 = "";
	$("#tblNullaHis").empty();
	$.each(tempDoc1, function( index, value ) {
		var sts1 = GetStatusName(value.docStatus);
		var verBy1 = value.vefifyBy;
		var verOn1 = value.verifyOn;
		if(verBy1 == null)
		{
			verBy1 = "";
		}
		if(verOn1 == null)
		{
			verOn1 = "";
		}
		if(value.docStatus == 2)
		{
			actBy1 = GetApplicantName(DetailsId);	
            isAgt1 = "Applicant";				
		}
		if(value.docStatus == 6)
		{
			isAgt1 = "Agent";
		}
		if(verBy1 != "")
		{
			actBy1 = GetUserName(value.vefifyBy);
		}
		if(value.docStatus == 6)
		{
			isAgt1 = "Agent";
		}
		if(verOn1 != "")
		{
			actOn1 = ConvertIST(new Date(value.verifyOn));
		}
		else
		{
			actOn1 = submitOnIST;
		}
		list1 += "<tr>";
		list1 += "<td>"+ c1 +"</td>";
		list1 += "<td>"+ sts1 +"</td>";
		list1 += "<td>"+ actBy1 +"</td>";
		list1 += "<td>"+ isAgt1 +"</td>";
		list1 += "<td>"+ actOn1 +"</td>";
		list1 += "<td><span onclick=DisplayFile('"+ value.file +"')>"+ value.file +"</span></td>";
		list1 += "</tr>";
		c1++;
	});
	$("#tblNullaHis").append(list1);
}
function DisplayFile(fileName, lId, type)
{
	var comments = "", rId = 0, reason = "";
	var tmp = objPassHis.filter(f => f.log_id == lId);

	if(tmp.length > 0)
	{
		comments = tmp[0].comments;
		rId = tmp[0].reason_id;
	}
	if(rId > 0)
	{
		var t = objReason.filter(r => r.id == rId);
		if(t.length > 0)
		{
			reason = t[0].reason_code;
		}
	}
	if(reason == "" && comments == "")
	{
		$("#tblHis").hide();
	}
	else
	{
		$("#tblHis").show();
	}
	if(reason == "")
	{
		$("#tdHisReason").html("");
	}
	else
	{
		$("#tdHisReason").html(reason);
	}
	if(comments == "")
	{
		$("#tdHisComment").html("");
	}
	else
	{
		$("#tdHisComment").html(comments);
	}
	
	var downloadURL = DownloadURL + "?";
	var url = downloadURL + SessionId + "_" + DocKey + "_" + fileName;
    $('#divframeHistory').attr('src', url);
}
function ShowPassport()
{  	
    LoadCustomerDetails(2, DetailsId);
    $("#liRejBy").hide();
	$("#liRejOn").hide();
	$("#spanRejBy").html("");
	$("#spanRejOn").html("");
	$("#txtComment").val("");
	
	
	$("#liPass").addClass('active');
	$("#liNulla").removeClass('active');
	$("#liHis").removeClass('active');
		
	$("#txtComment").val("");
	$("#txtComment").attr('disabled', false);
	isPassport = 1;
	$("#docPass").addClass('show');
	$("#docPass").addClass('active');
	$("#docNulla").removeClass('show');
	$("#docNulla").removeClass('active');
	
	var list = "", fileName = "", reasonId = 0;
	$("#ddlReason").empty();
	list += "<option value='0'>---Select---</option>";
	var temp1 = objReason.filter(f => f.type == 2);
	for(var j=0;j<temp1.length;j++)
	{
		list += "<option value="+ temp1[j].id +">"+ temp1[j].reason_code +"</option>";
	}
	$("#ddlReason").append(list);
	
	
	
	var tempDoc2 = objDocument.filter(f => f.type == 2 && f.dtlId == DetailsId);	
	
	if(tempDoc2.length > 0)
	{
		fileName = tempDoc2[0].file;
		var docSts = tempDoc2[0].docStatus;
		var reviewCount = tempDoc2[0].revwCount;
		reasonId = tempDoc2[0].reason;
		var dId = tempDoc2[0].docId;
		var sts = "";
		
		/*if(docSts == 4 || docSts == 5)
		{
			if(reviewCount >= 0)
			{
				var obj = {
					session_id: SessionId,
					sessionToken: SessionToken,
					docId: dId
				}
				var chkParam = JSON.stringify(obj);
		
				GetDetailsList(chkParam, dId, reviewCount, 2);
			}
			var liList = "";
			$("#ulTab").empty();
			liList += '<ul  class="nav nav-pills" role="tablist" >';
			liList += '<li class="nav-item">';
			liList += '<a class="nav-link active" data-bs-toggle="pill" onClick="ShowPassport()" id="liPass">Passport Document</a>';
			liList += '</li>';
			liList += '<li class="nav-item">';
			liList += '<a class="nav-link" data-bs-toggle="pill" onClick="ShowNullaOsta()" id="liNulla">Nulla Osta Document</a>';
			liList += '</li>';			
			liList += '</ul>';;
			$("#ulTab").append(liList);
		}
		else
		{
			var liList = "";
			$("#ulTab").empty();
			liList += '<ul  class="nav nav-pills" role="tablist" >';
			liList += '<li class="nav-item">';
			liList += '<a class="nav-link active" data-bs-toggle="pill" onClick="ShowPassport()" id="liPass">Passport Document</a>';
			liList += '</li>';
			liList += '<li class="nav-item">';
			liList += '<a class="nav-link" data-bs-toggle="pill" onClick="ShowNullaOsta()" id="liNulla">Nulla Osta Document</a>';
			liList += '</li>';			
			liList += '</ul>';;
			$("#ulTab").append(liList);
		}*/

		var tempSts = objStatus.filter(f => f.request_status_id == docSts);
		if(tempSts.length >0)
		{
			sts = tempSts[0].request_status_name;
		}
		
		$("#spanSts").html(sts);
		
				
		$("#txtComment").val(tempDoc2[0].remarks);
	}
	
	
	
	if(reasonId > 0)
	{
		$("#ddlReason").val(reasonId);
	}
	else
	{
		$("#ddlReason").val(0);
	}
	$("#ddlReason").attr('disabled', true);
	$("#txtComment").attr('disabled', true);
	
	var downloadURL = DownloadURL + "?";
	//var url = downloadURL + fileName + "&sess_id=" + SessionId + "&document_key=" + DocKey;
	var url = downloadURL + SessionId + "_" + DocKey + "_" + fileName;
    $('#divframe').attr('src', url);
}
function GetHistoryDetails(detId, sts, type)
{
	var objTemp = [];
	var c = 1, act = "", actBy = "", actOn = "", fileName = "", curFileName = "", actName = "", list = "";
	var docSts = 0, reviewCount = 0, docSubmitOn = "", reqId = 0;
	
	$.each(objUser, function( index, value ) {	
        var comment = value.remarks;	
		var rId = value.reason;
		actBy = GetUserName(value.usrId);
		actOn = value.addOn;
		act = "Review";
		actName = "Agent";
		fileName = "";
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,	
			reason_id: rId,
            comments: comment,
            log_id: value.alog,
            type: type				
		}
		objTemp.push(params);
	});
	$.each(objCustomer, function( index, value ) {	
        var fn = objDetails.filter(f => f.dtlId == value.dtlId);	
		if(fn.length > 0)
		{
			actBy = fn[0].fName + " " + fn[0].lName;
		}
		if(value.docStatus == 2)
		{
			act = "Submitted";
		}
		else if(value.docStatus == 5)
		{
			act = "ReSubmitted";
		}
		
		actName = "Applicant";
		fileName = value.file;
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: value.addOn,
			file_name: fileName,
			details_id: detId,	
			reason_id: 0,
            comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	});
	
	//Verified
	var verBy = "", verOn = "";
	var tempDoc2 = objDocument.filter(f => f.type == type && f.dtlId == detId);
	if(tempDoc2.length > 0)
	{
		docAddOn = tempDoc2[0].submitOn;
		curFileName = tempDoc2[0].file;
		docSts = tempDoc2[0].docStatus;
		
		verBy = tempDoc2[0].vefifyBy;
		verOn = tempDoc2[0].verifyOn;
		if(verBy == null)
		{
			verBy = "";
		}
		if(verOn == null)
		{
			verOn = "";
		}
		if(verBy != "")
		{
			verBy = GetUserName(verBy);
		}
		if(verOn != "")
		{
			verOn = verOn;
		}
	}
	if(docSts == 6 || docSts == 8 || docSts == 13 || docSts == 5) 
	{			
		act = "Verified";
		actName = "Agent";
		actBy = verBy;
		actOn = verOn;
		fileName = curFileName;
		
		if(docSts == 5)
		{
			act = "ReSubmitted";
		}
		
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,
			reason_id: 0,
			comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	}
	if(docSts == 8 || docSts == 9 || docSts == 13)
	{
		var appOn = "", appBy = "";
		var tempMas = objMaster.filter(f => f.reqId == reqId);
		if(tempMas.length > 0)
		{
			appOn = tempMas[0].approvOn;
			appBy = tempMas[0].aprovdBy;
		}
		if(appBy == null)
		{
			appBy = "";
		}
		if(appOn == null)
		{
			appOn = "";
		}
		if(appBy != "")
		{
			appBy = GetUserName(appBy);
		}
		if(appOn != "")
		{
			appOn = appOn;
		}
		act = "Approved";
		actName = "Embassy";
		actBy = appBy;
		actOn = appOn;
		fileName = curFileName;
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,
			reason_id: 0,
			comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	}
	
	if(docSts == 13)
	{
		var slotOn = "", appBy = "", slotTm = "";
		var tempDet = objDetails.filter(f => f.dtlId == detId);
		if(tempDet.length > 0)
		{
			slotTm = tempDet[0].slotAt;
		}
		if(slotTm == null)
		{
			slotTm = "";
		}		
		if(slotTm != "")
		{
			slotTm = slotTm;
		}
		act = "Slot Alloted";
		actName = "System";
		actBy = "System";
		actOn = slotTm;
		fileName = curFileName;
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,
			reason_id: 0,
			comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	}
	if(docSts == 10)
	{
		var tempD = objDocument.filter(f => f.type == type && f.dtlId == detId);		

		var verBy = tempD[0].vefifyBy;
		var verOn = tempD[0].verifyOn;
		if(verBy == null)
		{
			verBy = "";
		}
		if(verOn == null)
		{
			verOn = "";
		}
		if(verBy != "")
		{
			verBy = GetUserName(verBy);
		}
		if(verOn != "")
		{
			verOn = verOn;
		}
		act = "Blocked";
		actOn = verOn;
		actBy = verBy;
		actName = "Embassy";
		fileName = "";
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,	
			reason_id: 0,
            comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	}
	
	  const sortedData = objTemp.sort((a, b) => {	  
	  const dateA = new Date(a.action_on);
	  const dateB = new Date(b.action_on);
	  return dateA - dateB; 
	});

	
    $.each(sortedData, function( index, value ) {	    
	    var dt = ConvertIST(new Date(value.action_on));
		
		list += "<tr>";
		list += "<td>"+ c +"</td>";
		list += "<td>"+ value.action +"</td>";
		list += "<td>"+ value.action_by +"</td>";
		list += "<td>"+ value.action_name +"</td>";
		list += "<td>"+ dt +"</td>";
		if(value.file_name == "")
		{
			list += "<td onclick=DisplayFile('',"+ value.log_id +","+ value.type +")></td>";
		}
		else
		{
			list += "<td><span onclick=DisplayFile('"+ value.file_name +"',"+ value.log_id +","+ value.type +")>"+ value.file_name +"</span></td>";
		}
		list += "</tr>";
		c++;
	});
	DisplayFile(sortedData[0].file_name, sortedData[0].log_id, type);
	if(type == 1)
	{
		objNullaHis = objTemp;
	}
	else
	{
		objPassHis = objTemp;
	}
	return list;
}

function GetHistoryDetails_old(detId, sts, type)
{
	var objTemp = [];
	var c = 1, act = "", actBy = "", actOn = "", fileName = "", curFileName = "", actName = "", list = "";
	var docSts = 0, reviewCount = 0, docSubmitOn = "", reqId = 0;
	var tempDoc2 = objDocument.filter(f => f.type == type && f.dtlId == detId);
	
	if(tempDoc2.length > 0)
	{
		docAddOn = tempDoc2[0].submitOn;//ConvertIST(new Date(tempDoc2[0].submitOn));
		curFileName = tempDoc2[0].file;
		docSts = tempDoc2[0].docStatus;
		reviewCount = tempDoc2[0].revwCount;
		docSubmitOn = tempDoc2[0].submitOn;
		reqId = tempDoc2[0].reqId;

		var verBy = tempDoc2[0].vefifyBy;
		var verOn = tempDoc2[0].verifyOn;
		if(verBy == null)
		{
			verBy = "";
		}
		if(verOn == null)
		{
			verOn = "";
		}
		if(verBy != "")
		{
			verBy = GetUserName(verBy);
		}
		if(verOn != "")
		{
			verOn = verOn;//ConvertIST(new Date(verOn));
		}
		if(objCustomer != null)
		{
			var temp = objCustomer.filter(f => f.dtlId == detId);
				
			if(temp.length > 0)
			{
				actOn = temp[0].addOn;//ConvertIST(new Date(temp[0].addOn));
				fileName = temp[0].file;
			}
			else
			{
				actOn = "";
				fileName = "";
			}			
		}
		if((docSts == 6 && reviewCount == 0) || (docSts == 8 || docSts == 13 || docSts == 3))
		{
			fileName = curFileName;
			actOn = docSubmitOn;
		}
		
		actBy = GetApplicantName(detId);
		act = "Submitted";
		actName = "Applicant";
	}
	
	var params = {
		action: act,
		action_by: actBy,
		action_name: actName,
        action_on: actOn,
        file_name: fileName,
        details_id: detId,
		reason_id: 0,
        comments: "",
		log_id: 0,
		type: type		
	}
	objTemp.push(params);
	if((docSts == 6 && reviewCount == 0) || (docSts == 8 || docSts == 13 || docSts == 10))
	{
		act = "Verified";
		actName = "Agent";
		actBy = verBy;
		actOn = verOn;
		fileName = curFileName;
		
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,
			reason_id: 0,
			comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	}
	
	if(docSts == 8 || docSts == 9 || docSts == 13)
	{
		var appOn = "", appBy = "";
		var tempMas = objMaster.filter(f => f.reqId == reqId);
		if(tempMas.length > 0)
		{
			appOn = tempMas[0].approvOn;
			appBy = tempMas[0].aprovdBy;
		}
		if(appBy == null)
		{
			appBy = "";
		}
		if(appOn == null)
		{
			appOn = "";
		}
		if(appBy != "")
		{
			appBy = GetUserName(appBy);
		}
		if(appOn != "")
		{
			appOn = appOn;//ConvertIST(new Date(verOn));
		}
		act = "Approved";
		actName = "Embassy";
		actBy = appBy;
		actOn = appOn;
		fileName = curFileName;
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,
			reason_id: 0,
			comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	}
	
	if(docSts == 13)
	{
		var slotOn = "", appBy = "", slotTm = "";
		var tempDet = objDetails.filter(f => f.dtlId == detId);
		if(tempDet.length > 0)
		{
			slotTm = tempDet[0].slotAt;
		}
		if(slotTm == null)
		{
			slotTm = "";
		}		
		if(slotTm != "")
		{
			slotTm = slotTm;//ConvertIST(new Date(verOn));
		}
		act = "Slot Alloted";
		actName = "System";
		actBy = "System";
		actOn = slotTm;
		fileName = curFileName;
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,
			reason_id: 0,
			comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	}
	if(docSts == 10)
	{
		var tempD = objDocument.filter(f => f.type == type && f.dtlId == detId);
		

		var verBy = tempD[0].vefifyBy;
		var verOn = tempD[0].verifyOn;
		if(verBy == null)
		{
			verBy = "";
		}
		if(verOn == null)
		{
			verOn = "";
		}
		if(verBy != "")
		{
			verBy = GetUserName(verBy);
		}
		if(verOn != "")
		{
			verOn = verOn;//ConvertIST(new Date(verOn));
		}
		act = "Blocked";
		actOn = verOn;
		actBy = verBy;
		actName = "Embassy";
		fileName = "";
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,	
			reason_id: 0,
            comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	}
	$.each(objUser, function( index, value ) {	
        var comment = value.remarks;	
		var rId = value.reason;
		actBy = GetUserName(value.usrId);
		actOn = value.addOn;//ConvertIST(new Date(value.addOn));
		act = "Review";
		actName = "Agent";
		fileName = "";
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,	
			reason_id: rId,
            comments: comment,
            log_id: value.alog,
            type: type				
		}
		objTemp.push(params);
	});
	
	$.each(objCustomer, function( index, value ) {	
        var fn = objDetails.filter(f => f.dtlId == value.dtlId);	
		if(fn.length > 0)
		{
			actBy = fn[0].fName + " " + fn[0].lName;
		}
				
			//actOn = ConvertIST(new Date(value.addOn));
			act = "ReSubmitted";
			actName = "Applicant";
			fileName = value.file;
			var params = {
				action: act,
				action_by: actBy,
				action_name: actName,
				action_on: value.addOn,
				//action_on: docAddOn,
				//file_name: curFileName,
				file_name: fileName,
				details_id: detId,	
				reason_id: 0,
				comments: "",
				log_id: 0,
				type: type				
			}
			
			objTemp.push(params);		
	});
	
	
	
	const sortedData = objTemp.sort((a, b) => {	  
	  const dateA = new Date(a.action_on);
	  const dateB = new Date(b.action_on);
	  return dateA - dateB; 
	});

	
    $.each(sortedData, function( index, value ) {	    
	    var dt = ConvertIST(new Date(value.action_on));
		
		list += "<tr>";
		list += "<td>"+ c +"</td>";
		list += "<td>"+ value.action +"</td>";
		list += "<td>"+ value.action_by +"</td>";
		list += "<td>"+ value.action_name +"</td>";
		list += "<td>"+ value.action_on +"</td>";
		if(value.file_name == "")
		{
			
			list += "<td onclick=DisplayFile('',"+ value.log_id +","+ value.type +")></td>";
		}
		else
		{
		list += "<td><span onclick=DisplayFile('"+ value.file_name +"',"+ value.log_id +","+ value.type +")>"+ value.file_name +"</span></td>";
		}
		list += "</tr>";
		c++;
	});
	DisplayFile(sortedData[0].file_name, sortedData[0].log_id, type);
	if(type == 1)
	{
		objNullaHis = objTemp;
	}
	else
	{
		objPassHis = objTemp;
	}
	return list;
}

function LoadHistory(detId, reviewCount, sts, type)
{
	var list = GetHistoryDetails(detId, sts, type);
	
	if(type == 2)
	{
		$("#tblPassHis").empty();
		$("#tblPassHis").append(list);
	}
	else
	{
		$("#tblNullaHis").empty();
		$("#tblNullaHis").append(list);
	}
}

function ShowNullaOsta()
{	  
	
	LoadCustomerDetails(1, DetailsId);
	var fileName = "", reasonId = 0;
	
	$("#txtComment1").val("");
	$("#txtComment1").attr('disabled', false);
	
	var tempDoc1 = objDocument.filter(f => f.type == 1 && f.dtlId == DetailsId);
	
	if(tempDoc1.length > 0)
	{
		fileName = tempDoc1[0].file;
		var docSts = tempDoc1[0].docStatus;
		var reviewCount = tempDoc1[0].revwCount;
		var comment = tempDoc1[0].remarks;
		var dId = tempDoc1[0].docId;
		reasonId = tempDoc1[0].reason;
		$("#txtComment1").val(comment);
		
		/*if(docSts == 4 || docSts == 5)
		{
			if(reviewCount >= 0)
			{
				var obj = {
					session_id: SessionId,
					sessionToken: SessionToken,
					docId: dId
				}
				var chkParam = JSON.stringify(obj);
		
				GetDetailsList(chkParam, dId, reviewCount, 1);
			}
			var liList = "";
			$("#ulTab").empty();
			liList += '<ul  class="nav nav-pills" role="tablist" >';
			liList += '<li class="nav-item">';
			liList += '<a class="nav-link" data-bs-toggle="pill" onClick="ShowPassport()" id="liPass">Passport Document</a>';
			liList += '</li>';
			liList += '<li class="nav-item">';
			liList += '<a class="nav-link active" data-bs-toggle="pill" onClick="ShowNullaOsta()" id="liNulla">Nulla Osta Document</a>';
			liList += '</li>';			
			liList += '</ul>';;
			$("#ulTab").append(liList);
		}
		else
		{
			var liList = "";
			$("#ulTab").empty();
			liList += '<ul  class="nav nav-pills" role="tablist" >';
			liList += '<li class="nav-item">';
			liList += '<a class="nav-link" data-bs-toggle="pill" onClick="ShowPassport()" id="liPass">Passport Document</a>';
			liList += '</li>';
			liList += '<li class="nav-item">';
			liList += '<a class="nav-link active" data-bs-toggle="pill" onClick="ShowNullaOsta()" id="liNulla">Nulla Osta Document</a>';
			liList += '</li>';			
			liList += '</ul>';;
			$("#ulTab").append(liList);
		}*/
		
	}

	var tempSts = objStatus.filter(f => f.request_status_id == docSts);
	
	if(tempSts.length >0)
	{
		sts = tempSts[0].request_status_name;
	}

	$("#spanSts").html(sts);

	
	isPassport = 0;
	/*$("#docNulla").addClass('show');
	$("#docNulla").addClass('active');
	$("#docPass").removeClass('show');
	$("#docPass").removeClass('active');*/

		
	var list = "";
	$("#ddlReason1").empty();
	list += "<option value='0'>---Select---</option>";
	var temp1 = objReason.filter(f => f.type == 1);
	for(var j=0;j<temp1.length;j++)
	{
		list += "<option value="+ temp1[j].id +">"+ temp1[j].reason_code +"</option>";
	}
	$("#ddlReason1").append(list);
	
	if(reasonId > 0)
	{
		$("#ddlReason1").val(reasonId);
	}
	else
	{
		$("#ddlReason1").val(0);
	}
	$("#ddlReason1").attr('disabled', true);
	$("#txtComment1").attr('disabled', true);
	
	//$("#liPass").removeClass('active');
	//$("#liNulla").addClass('active');
	
	var downloadURL = DownloadURL + "?";
	//var url = downloadURL + fileName + "&sess_id=" + SessionId + "&document_key=" + DocKey;
	var url = downloadURL + SessionId + "_" + DocKey + "_" + fileName;
    $('#divframeNulla').attr('src', url);
}

function CloseDialog()
{
	isPassport = 1;
	$("#myModal").modal('hide');
}
function ShowDialog(detId)
{
	var reqId = 0;
	DetailsId = detId;
	var temp = objDetails.filter(f => f.dtlId == detId);
	if(temp.length > 0)
	{
		reqId = temp[0].reqId;
	}
	
	var reference_text = "Reference ID - "+reqId;
    
	$("#show_reference").html(reference_text);
	
	ShowPassport();
	$("#myModal").modal('show');	
}
function LoadCustomerDetails(flag, detId)
{
	$("#divBtnVRB").show();	
	var reqId = 0, fullName = "", email = "", submitOn = "",vac = "", sts = "", pass = "", wpn = "", issueDt = "", comments = "", reasonId = 0, dob = "", days = 0;
	
	var tempDoc = objDocument.filter(d => d.dtlId == detId);
	if(tempDoc.length >0)
	{
		comments = tempDoc[0].remarks;
		if(comments == null)
		{
			comments = "";
		}
		reasonId = tempDoc[0].reason;
		if(reasonId == null)
		{
			reasonId = 0;
		}
	}
	if(comments != "")
	{
		$("#txtComment").val(comments);
	}
	if(reasonId > 0)
	{
		var list = "";
		$("#ddlReason").empty();
		list += "<option value='0'>---Select---</option>";
		var temp1 = objReason.filter((f) => f.type == 2);
		for (var j = 0; j < temp1.length; j++) {
			list += "<option value=" + temp1[j].id + ">" + temp1[j].reason_code + "</option>";
		}
		$("#ddlReason").append(list);
		$("#ddlReason").val(reasonId);
	}
	
	
	var temp = objDetails.filter(f => f.dtlId == detId);
	
	
	if(temp.length > 0)
	{
		reqId = temp[0].reqId;
		var temp1 = objMaster.filter(f => f.reqId == reqId);
		if(temp1.length > 0)
		{
			email = temp1[0].mailId;
		}
		
		fullName = temp[0].fName + " " + temp[0].lName;
		pass = temp[0].ppn;
		//pass = decrypt(EncryptionKey, temp[0].ppn);
		days = temp[0].work_permit_issue_days;
		wpn = temp[0].wpn;		
		var issueDt1 = temp[0].wpndt;
		
		var isDt = new Date(issueDt1);
		var y1 = isDt.getFullYear();
		var m1 = (isDt.getMonth() + 1).toString().padStart(2, '0');
		var d1 = isDt.getDate().toString().padStart(2, '0');
		issueDt = d1 + "/" + m1 + "/" + y1;
		
		var dob_dt = temp[0].dob;
		
		var dDt = new Date(dob_dt);
		var y2 = dDt.getFullYear();
		var m2 = (dDt.getMonth() + 1).toString().padStart(2, '0');
		var d2 = dDt.getDate().toString().padStart(2, '0');
		dob = d2 + "/" + m2 + "/" + y2;
	}
	/*reqId = objMaster[0].reqId;
	email = objMaster[0].mailId;*/
	
	
	var submitOnIST = "";
	if(objMaster[0].submitOn == null || objMaster[0].submitOn == "0000-00-00 00:00:00.000000")
	{
		submitOnIST = "";
	}
	else
	{
		var subDt = new Date(objMaster[0].submitOn);
		submitOnIST = ConvertIST(subDt);
	}
	
	var tempVac = objVAC.filter(v => v.vac_id == objMaster[0].vac);
	if(tempVac.length >0)
	{
		vac = tempVac[0].vac_name;
	}
	
	var tempSts = objStatus.filter(f => f.request_status_id == objMaster[0].rStatus);
	if(tempSts.length >0)
	{
		sts = tempSts[0].request_status_name;
	}
	//var reference_text = "Reference ID - "+reqId;
	//$("#show_reference").html(reference_text);
	if(flag == 1)
	{		
		$("#spanReqId1").html(reqId);
		$("#spanFullName1").html(fullName);
		$("#spanEmail1").html(email);
		$("#spanPassNo1").html(pass);
		$("#spanWPN1").html(wpn);
		$("#spanDays1").html(days);
		$("#spandob1").html(dob);
		$("#spanIssueDt1").html(issueDt);
		$("#spanSubmitDt1").html(submitOnIST);
		$("#spanVAC1").html(vac);
		$("#spanSts1").html(sts);
	}
	else
	{
		$("#spanReqId").html(reqId);
		$("#spanFullName").html(fullName);
		$("#spanEmail").html(email);
		$("#spanPassNo").html(pass);
		$("#spanWPN").html(wpn);
		$("#spandob").html(dob);
		$("#spanIssueDt").html(issueDt);
		$("#spanSubmitDt").html(submitOnIST);
		$("#spanVAC").html(vac);
		$("#spanSts").html(sts);
	}
}

function ShowLoading()
{
	var loader=	$('#loader');
	loader.show();	
}
function HideLoading()
{	
	var loader=	$('#loader');
	loader.hide();
}
//setInterval(PingServer(SessionId,SessionToken,LastActivity), 300000);
function performTask() {
    //console.log("Task executed at:", new Date());
	PingServer(SessionId,SessionToken,LastActivity);
}

setInterval(performTask, 3 * 60 * 1000);








