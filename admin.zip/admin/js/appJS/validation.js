function ValidateFields(id, str, type, msg)
{
	var res = true;
	$(id).css('border-color', '#ccc');
	if(type == 1)
	{
		if(str == "")
        {
            $(id).css('border-color', 'red');
            $(id).focus();
            res = false;
        }
        else if(str != "")
        {
            var regex = /^[A-Z a-z]+$/;
            var isValid = regex.test(str);
            if (!isValid) {
                $(id).css('border-color', 'red');
                $(id).focus();
                res = false;
            }
            else {
                if (!ValidateXSS(str, msg)) {
                    $(id).css('border-color', 'red');
                    $(id).focus();
                    res = false;
                }
            }
        } 
	}
	else if (type == 2)
    {
		if (str == "") 
		{
			$(id).css('border-color', 'red');
			$(id).focus();
			res = false;
		}
		else if (str != "") 
		{
			var regex = /^[+0-9]+$/;
			var isValid = regex.test(str);
			if (!isValid) {
				$(id).css('border-color', 'red');
				$(id).focus();
				res = false;
			}
			else {
				if (!ValidateXSS(str, msg)) {
					$(id).css('border-color', 'red');
					$(id).focus();
					res = false;
				}
			}
		}		
    }
	else if (type == 3)
    {
        if (str == "") 
		{
            $(id).css('border-color', 'red');
            $(id).focus();
            res = false;
        }
        else if (str != "") 
		{
            var regex = /^([\w+-]+\.)*[\w+-]+@([\w+-]+\.)*[\w+-]+\.[a-zA-Z]{2,4}$/;
            var isValid = regex.test(str);
            if (!isValid) {
                $(id).css('border-color', 'red');
                $(id).focus();
                res = false;
            }
            else {
                if (!ValidateXSS(str, msg)) {
                    $(id).css('border-color', 'red');
                    $(id).focus();
                    res = false;
                }
            }
        }
    }
	else if(type == 4)
	{
		if(str == "")
        {
            $(id).css('border-color', 'red ! important');
            $(id).focus();
            res = false;
        }
        else if(str != "")
        {
            var regex = /^[A-Za-z0-9]+$/;
            var isValid = regex.test(str);
            if (!isValid) {
                $(id).css('border-color', 'red');
                $(id).focus();
                res = false;
            }
            else {
                if (!ValidateXSS(str, msg)) {
                    $(id).css('border-color', 'red');
                    $(id).focus();
                    res = false;
                }
            }
        } 
	}
	else if(type == 5)
	{
		if(str == "")
        {
            $(id).css('border-color', 'red');
            $(id).focus();
            res = false;
        }
        else if(str != "")
		{
			if (!ValidateXSSTextArea(str, "Remarks")) {
				$(id).css('border-color', 'red');
				$(id).focus();
				res = false;
			}
		}
	}
	else if(type == 6)
	{
		if(str == "")
        {
            $(id).css('border-color', 'red');
            $(id).focus();
            res = false;
        }
        else if(str != "")
        {
            var regex = /^[A-Za-z0-9 ]+$/;
            var isValid = regex.test(str);
            if (!isValid) {
                $(id).css('border-color', 'red');
                $(id).focus();
                res = false;
            }
            else {
                if (!ValidateXSS(str, msg)) {
                    $(id).css('border-color', 'red');
                    $(id).focus();
                    res = false;
                }
            }
        } 
	}
	else if(type == 7)
	{
		if(str == 0)
		{
			$(id).css('border-color', 'red');
            $(id).focus();
            res = false;
		}
	}
	else if(type == 8)
	{
		if(str == "")
		{
			$(id).css('border-color', 'red');
            $(id).focus();
            res = false;
		}
		else
		{
			if (!ValidateXSS(str, msg)) {
                $(id).css('border-color', 'red');
                $(id).focus();
                res = false;
            }
		}
	}
	return res;
}

function RemoveSpacesList(temp)
{
	var str = "";
	var arrTemp = temp.split(' ');
	if(arrTemp.length > 0)
	{
		for(var i=0;i<arrTemp.length;i++)
		{
			str += arrTemp[i];
		}
	}
	else
	{
		str = temp;
	}
	return str;
}
function ValidateXSSTextArea(aInput, errorField)
{
    var reg = /[<|>]/g;
	var DefaultMsg = "Invalid";
    if (aInput != "" && reg.test(aInput)) {
        alert(DefaultMsg + errorField + ".");
        return false;
    }
    else {
        return true;
    }
}
function ValidateXSS(aInput, errorField)
{
    var reg = /[<|>()'"\*;:={}]/g;
	var DefaultMsg = "Invalid";
    if (aInput != "" && reg.test(aInput)) {
        alert(DefaultMsg + errorField + ".");
        return false;
    }
    else {
        return true;
    }
}