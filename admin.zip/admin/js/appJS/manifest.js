var SessionId;
var SessionToken;
var UserRole;
var UserId;
var DocKey;
var objStatus;
var objVAC;
var objReason;
var objMaster;
var objDetails;
var objDocument;
var CurrentPassAct = 0;
var CurrentNullaAct = 0;
var isPassport = 0;
var DetailsId;

$(function () {	
	const today = new Date().toISOString().slice(0, 10);
    $("#from_date").val(today);
	$('#to_date').val(today)
	getLoginAdminDetails();	
	$("#from_date").datetimepicker({
		format: "Y-m-d",        
		timepicker: false,
		scrollInput: false,
		onShow: function (ct) {
			this.setOptions({ scrollInput: false }); // Ensures no scrolling on show
		}

	});
	$("#from_date").on("wheel", function (e) {
		e.preventDefault(); // Prevents scrolling
	});
	
	$("#to_date").datetimepicker({
		format: "Y-m-d",        
		timepicker: false,
		scrollInput: false,
	});
	
	readyfunction();
	getManifestList();
	LoadVAC();
   
});

function LoadVAC()
{
	var list = "";
	$("#selVacList").empty();
	list += "<option value='0'>---Select VAC---</option>";
	for(var i=0;i<objVAC.length;i++)
	{
		list += "<option value='"+ objVAC[i].vac_id +"'>"+ objVAC[i].vac_name +"</option>";
	}
	$("#selVacList").append(list);
}
function readyfunction(){

	// $('#export-btn').on('click', function (e) {
	// 	e.preventDefault();	
	
	// 	var filename = "";		
	// 	var fromDate = $('#from_date').val();
	// 	var toDate = $('#to_date').val();
	// 	var currentDate = new Date();
	// 	var formattedDate = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;
	// 	var dt = fromDate + '_To_' + toDate;
	// 	filename = "Manifest_" + dt + "";
	// 	filename = filename.replace(/[\s-]/g, '_');
	
	// 	var csvHeader="";
	// 	var csvContent = [];
	// 	var rows = document.querySelectorAll(".table2excel tr");
		
	// 	for (var i = 0; i < rows.length; i++) {
	// 		var row = [], cols = rows[i].querySelectorAll("td, th");
			
	// 		for (var j = 0; j < cols.length; j++) {
	// 			row.push('"' + cols[j].innerText.replace(/"/g, '""') + '"');
	// 		}
			
	// 		csvContent.push(row.join(","));        
	// 	}
	
	// 	var fullCsvContent = csvHeader + csvContent.join("\n");
	// 	var blob = new Blob([fullCsvContent], { type: 'text/csv' });
	// 	var link = document.createElement("a");
	// 	link.href = URL.createObjectURL(blob);
	// 	link.download = filename + ".csv";
	// 	document.body.appendChild(link);
	// 	link.click();
	// 	document.body.removeChild(link);
	// });

	//22-01-2025
	
	$('#export-btn-excel').on('click', function (e) {
		e.preventDefault();    
	
		var filename = "";        
		var fromDate = $('#from_date').val();
		var toDate = $('#to_date').val();
		var currentDate = new Date();
		var formattedDate = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;
		var dt = fromDate + '_To_' + toDate;
		filename = "Manifest_" + dt + "";
		filename = filename.replace(/[\s-]/g, '_');
	
		var csvHeader = "";
		var csvContent = [];
		var rows = document.querySelectorAll(".table2excel tr");
		
		for (var i = 0; i < rows.length; i++) {
			var row = [], cols = rows[i].querySelectorAll("td, th");
			
			for (var j = 0; j < cols.length; j++) {
				let cellContent = cols[j].innerText.replace(/"/g, '""');
				// Check if the content is a large number
				if (!isNaN(cellContent) && cellContent.length >= 11) {
					// Add a single quote to treat it as text
					//cellContent = `'${cellContent}`;
					cellContent = `${cellContent}`;
				}
				row.push('"' + cellContent + '"');
			}
			
			csvContent.push(row.join(","));        
		}
	
		var fullCsvContent = csvHeader + csvContent.join("\n");
		var blob = new Blob([fullCsvContent], { type: 'text/csv' });
		var link = document.createElement("a");
		link.href = URL.createObjectURL(blob);
		link.download = filename + ".csv";
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	});


	$('#export-btn').on('click', function () {

		var fromDate = $('#from_date').val();
		var toDate = $('#to_date').val();

		var fileName = 'Appointment_Manifest_' + fromDate + "_" + toDate + '.pdf';

		const { jsPDF } = window.jspdf;

		const pdf = new jsPDF({
			orientation: 'landscape',
			unit: 'pt',
			format: 'a4',
		});

		const headers = [["Request ID", "Submitted On", "Name", "Email ID", "Passport No", "Nulla Osta No", "Issue Date", "VAC", "Amount", "Payment Ref.", "Slot Date", "Slot Time"]];
		const rows = [];

		$('#grid-table tbody tr').each(function () {
			const row = [];
			$(this).find('td').each(function (index) {
				if (index !== 1 && index !== 2 && index !== 11) { 
					row.push($(this).text().trim());
				}
		});
			rows.push(row);
		});

		const headerBgColor = hexToRgb('#20c997');

		pdf.autoTable({
			head: headers,
			body: rows,
			startY: 20,
			headStyles: {
				fillColor: headerBgColor,
				textColor: [255, 255, 255],
				fontSize: 8,
				halign: 'left',
				valign: 'middle',
			},
			bodyStyles: {
				fontSize: 8,
				halign: '',
				valign: 'middle',
			},
			columnStyles: {
				0: { cellWidth: 50 },
				1: { cellWidth: 100 },
				2: { cellWidth: 90 },
				3: { cellWidth: 100 },
				4: {halign: 'left' },
				// Add more as needed
			},
			styles: {
				overflow: 'linebreak',
				cellPadding: 3,
			},
			footer: function (rows) {
				return {
					text: `Page ${rows.pageNumber} of ${rows.pageCount}`,
					align: 'center',
					margin: 10,
					fontSize: 10
				};
			}
		

		});



		// Save the generated PDF
		pdf.save(fileName); 
		//downloadPdf();
	});

	
	
}

function downloadPdf(){
	
	var param = {
		user_id: $('#Globaluserid').val(),
		session_id: $('#Globalsessionid').val(),
		session_token: $('#Globalsessiontoken').val(),
		from_date: $('#from_date').val(),
		to_date: $('#to_date').val(),
		vac_id: $('#selVacList').val(),
	}

	var chkParameter = JSON.stringify(param);
	
	$.ajax({
        url: APIURL+'PdfDownload/',
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (res) {
			console.log('pdf',res);
        }
    });
}

function hexToRgb(hex) {
    // Remove the hash at the start if it's there
    hex = hex.replace(/^#/, '');

    // Parse the hex string into RGB components
    const bigint = parseInt(hex, 16);
    const r = (bigint >> 16) & 255;
    const g = (bigint >> 8) & 255;
    const b = bigint & 255;

    return [r, g, b];
}


function getManifestList()
{
	var param = {
		user_id: $('#Globaluserid').val(),
		session_id: $('#Globalsessionid').val(),
		session_token: $('#Globalsessiontoken').val(),
		from_date: $('#from_date').val(),
		to_date: $('#to_date').val(),
		vac_id: $('#selVacList').val(),
		priority: $('#priority').val(),
		type: 1,
        startRecord: 1,
        rows: 1,
		project: 'ITAIND',
	}
	var obj = JSON.stringify(param);

	if($('#priority').val()==""){
		alert("Please select priority");
		return false;
	}
	GetManifestList(obj);
}

function Logout(menu){
	let result = confirm("Are you sure want to logout session!");
	if (result === true) {
	   if(menu==1)
	   {
	   //var url ="Logout.php";
	   $('#mainForm').attr('action', LogoutURL);
	   document.forms["mainForm"].submit();
	   }
	}    

}

function getLoginAdminDetails()
{
	const Globaluserid = $("#Globaluserid").val();
	const Globalsessionid = $("#Globalsessionid").val();
	const Globalsessiontoken  = $("#Globalsessiontoken").val();
	const user_name = $("#user_name").val();
	const full_name = $("#full_name").val();
	const RoleId = $("#RoleId").val();		
    
    var chkObj_Session = { Globaluserid: Globaluserid, Globalsessionid: Globalsessionid, Globalsessiontoken: Globalsessiontoken , RoleId: RoleId ,user_name:user_name,full_name:full_name }
    var chkParameter_Session =  JSON.stringify(chkObj_Session);
    
    $.ajax({
        url: sessionajaxvalid,
        type: 'POST',
        data: chkParameter_Session,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			SessionId = data.Globalsessionid;
			SessionToken = data.session_token;
			UserRole = data.RoleId;
			UserId = data.Globaluserid;
			objStatus = data.master_status_list;
			objReason = data.reasoncode_list;
			objVAC = data.vac_list;
			DocKey = data.document_key;			
			$("#spanWelcomeUser").html("Welcome " + " " + data.full_name);
        }
    });
}


function LoadManifestList(objMasterSlot)
{

	if(objMasterSlot != null)
	{
	var list = "", k = 0, l = 0;

	$("#divList").empty();


	
		//list += '<table class="table accordion table-responsive table-bordered text-left table2excel accordion-collapse p-2" id="r'+ k +'">';
		list += '<table class="table accordion table-responsive table-bordered text-left table2excel accordion-collapse p-2" id="grid-table">';	
		list += '<thead>';
        list += '<tr>';		
		list += '<th scope="col">Request ID</th>';
		list += '<th scope="col">Child Reference No</th>';
		list += '<th scope="col">Added On</th>';
		list += '<th scope="col">Submited On</th>';
		list += '<th scope="col">Full Name</th>';
		list += '<th scope="col">Email Id</th>';
		list += '<th scope="col">Passport Number</th>';
		list += '<th scope="col">Nulla osta No</th>';
		list += '<th scope="col">Issue Date</th>';
		list += '<th scope="col">VAC</th>';
		list += '<th scope="col">Amount</th>';
		list += '<th scope="col">Tracking ID</th>';
		list += '<th scope="col">Payment Reference No</th>';		
		list += '<th scope="col">Slot Type</th>';
        list += '<th scope="col">Slot Date</th>';
        list += '<th scope="col">Slot Time</th>';
        list += '</tr>';
		list += '</thead>';
			
		list += '<tbody style="background:#fff;">';
		
		if(objMasterSlot.length>0){
			
			for(var j = 0;j<objMasterSlot.length;j++)
			{	
				km = j+1;
				// list += '<td>'+ km + '</td>';
				var colorPriority='';
				if(objMasterSlot[j].priority=='Priority'){
					colorPriority='priClr';
				}

				list += '<td align="center" class="' + colorPriority + '">' + objMasterSlot[j].request_id + '</td>';


				list += '<td align="center">'+ objMasterSlot[j].child_id + '</td>';
				list += '<td>'+ objMasterSlot[j].added_on + '</td>';
				list += '<td>'+ objMasterSlot[j].submitted_on + '</td>';
				list += '<td style="text-align: left;">'+ objMasterSlot[j].full_name + '</td>';
				list += '<td>'+ objMasterSlot[j].email_id + '</td>';
				list += '<td>'+ objMasterSlot[j].passport_number + '</td>';
				list += '<td>'+ objMasterSlot[j].work_permit_number + '</td>';
				list += '<td>'+ objMasterSlot[j].work_permit_issue_date + '</td>';	
				list += '<td>'+ objMasterSlot[j].vac_name + '</td>';
				list += '<td>'+ objMasterSlot[j].total_amount + '</td>';
				list += '<td>'+ objMasterSlot[j].tracking_id + '</td>';
				list += '<td>'+ objMasterSlot[j].bank_ref_no + '</td>';
				list += '<td>'+ objMasterSlot[j].priority + '</td>';
				list += '<td>'+ objMasterSlot[j].slot_date + '</td>';
				list += '<td>'+ objMasterSlot[j].slot_time + '</td>';
				list += '</tr>';
			}
			list += '</tbody>';			
			list += '</table>';	

		}else{
			$("#divList").empty();
			
			var list = "<table class='table text-center'><thead><tr><th scope='col'>Request ID</th><th scope='col'>Child Reference No</th><th scope='col'>Tracking ID</th><th scope='col'>Payment Reference No</th><th scope='col'>Added On</th><th scope='col'>Submitted On</th><th scope='col'>Full Name</th><th scope='col'>Email Id</th> <th scope='col'>Passport Number</th> <th scope='col'>Nulla osta No</th> <th scope='col'>Issue Date</th> <th scope='col'>VAC</th><th scope='col'>Slot Date</th> <th scope='col'>Slot Time</th></tr></thead><tbody><tr><td colspan='12'>----No Records----</td></tr></tbody></table>";
		}
		

	$("#divList").append(list);


	}
}

function ShowLoading()
{
	var loader=	$('#loader');
	loader.show();	
}
function HideLoading()
{	
	var loader=	$('#loader');
	loader.hide();
}









