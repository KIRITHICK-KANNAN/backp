var SessionId;
var SessionToken;
let activityTime = getCurrentTime();

var UserId;

$(function (){
	SessionId = $("#Globalsessionid").val();
    SessionToken = $("#Globalsessionid").val();

	setInterval(() => {
		IaminLive(SessionId, SessionToken,activityTime);
	}, 300000); //60000 one minites
	getLoginAdminDetails();
	GetList();
});

function getLoginAdminDetails()
{
	const Globaluserid = $("#Globaluserid").val();
	const Globalsessionid = $("#Globalsessionid").val();
	const Globalsessiontoken  = $("#Globalsessiontoken").val();
	const user_name = $("#user_name").val();
	const full_name = $("#full_name").val();
	const RoleId = $("#RoleId").val();

    
    var chkObj_Session = { Globaluserid: Globaluserid, Globalsessionid: Globalsessionid, Globalsessiontoken: Globalsessiontoken , RoleId: RoleId ,user_name:user_name,full_name:full_name }
    var chkParameter_Session =  JSON.stringify(chkObj_Session);
    
    $.ajax({
        url: sessionajaxvalid,
        type: 'POST',
        data: chkParameter_Session,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			
			SessionId = data.Globalsessionid;
			SessionToken = data.session_token;
			UserId = data.Globaluserid;
			
			$("#spanWelcomeUser").html("Welcome " + " " + data.full_name);
        }
    });
}

function GetList()
{
	var param = {
		session_id: SessionId,
		session_token: SessionToken,
		user_id: UserId
	}
	var obj = JSON.stringify(param);
	//GetStatusCount(obj);
}
function LoadDashList(obj, obj1)
{
	var total = parseInt(obj[0].allotted) + parseInt(obj[0].approved) + parseInt(obj[0].blocked) + parseInt(obj[0].declined) + parseInt(obj[0].paid) + parseInt(obj[0].submit) + parseInt(obj[0].parroved) + parseInt(obj[0].pfailure) + parseInt(obj[0].pverified) + parseInt(obj[0].resubmit) + parseInt(obj[0].review) + parseInt(obj[0].verified) + parseInt(obj[0].paymentlink_expired);
	
	var pfv = parseInt(obj[0].submit) + parseInt(obj[0].resubmit);
	
  	var cur_total = parseInt(obj1[0].current_allotted) + parseInt(obj1[0].current_approved) + parseInt(obj1[0].current_blocked) + parseInt(obj1[0].current_declined) + parseInt(obj1[0].current_paid) + parseInt(obj1[0].current_submit) + parseInt(obj1[0].current_parroved) + parseInt(obj1[0].current_pfailure) + parseInt(obj1[0].current_pverified) + parseInt(obj1[0].current_resubmit) + parseInt(obj1[0].current_review) + parseInt(obj1[0].current_verified) + parseInt(obj1[0].current_paymentlink_expired);
	
	var cur_pfv = parseInt(obj1[0].current_submit) + parseInt(obj1[0].current_resubmit);
	
	
	$("#sts1").text(total);
	$("#sts2").text(pfv);
	$("#sts3").text(obj[0].review);
	$("#sts4").text(obj[0].blocked);
	$("#sts5").text(obj[0].resubmit);
	$("#sts6").text(obj[0].verified);
	$("#sts7").text(obj[0].pverified);
	$("#sts8").text(obj[0].approved);	
	$("#sts10").text(obj[0].declined);
	$("#sts11").text(obj[0].pfailure);
	$("#sts14").text(obj[0].paymentlink_expired);
	$("#sts13").text(obj[0].allotted);
	
	$("#cursts1").text(cur_total);
	$("#cursts2").text(cur_pfv);
	$("#cursts3").text(obj1[0].current_review);
	$("#cursts4").text(obj1[0].current_blocked);
	$("#cursts5").text(obj1[0].current_resubmit);
	$("#cursts6").text(obj1[0].current_verified);
	$("#cursts7").text(obj1[0].current_pverified);
	$("#cursts8").text(obj1[0].current_approved);
	$("#cursts10").text(obj1[0].current_declined);
	$("#cursts11").text(obj1[0].current_pfailure);
	$("#cursts14").text(obj1[0].current_paymentlink_expired);
	$("#cursts13").text(obj1[0].current_allotted);
	
}
function ShowLoading()
{
	var loader=	$('#loader');
	loader.show();	
}
function HideLoading()
{	
	var loader=	$('#loader');
	loader.hide();
}
function Logout(menu)
{
	let result = confirm("Are you sure want to logout session!");
	if (result === true) {
	   if(menu==1)
	   {
	   
	   $('#mainForm').attr('action', LogoutURL);
	   document.forms["mainForm"].submit();
	   }
	}
}
function getCurrentTime() {
    const now = new Date();
	const year = now.getUTCFullYear();
	const month = (now.getUTCMonth() + 1).toString().padStart(2, '0');
	const day = now.getUTCDate().toString().padStart(2, '0');
	const hours = now.getUTCHours();
	const minutes = now.getUTCMinutes();
	const seconds = now.getUTCSeconds();
	var actOn = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
    return actOn;
}

