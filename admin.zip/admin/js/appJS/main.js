var SessionId = 0;
var SessionToken = "";
var EncryptionKey = "";
var OTPVal = 0;
var timerOn = true;


$(function(){
	
});
function encrypt(key, password) {
    const keyHex = CryptoJS.enc.Hex.parse(key);
    const encrypted = CryptoJS.AES.encrypt(password, keyHex, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    });

    return encrypted.toString(); // The output is Base64 encoded
}
function GetOTP()
{
	var userName = $("#txtUsername").val().trim();
	var pass = $("#txtPassword").val().trim();
	var encryptedPassword = encrypt(EncryptionKey, pass);
	CheckLogin(userName, encryptedPassword, LoginURL);
}
function validateLogin()
{
	var res = true;
	var userName = $("#txtUsername").val().trim();
	res = ValidateFields("#txtUsername", userName, 4, "UserName");
	if(res)
	{
		var pass = $("#txtPassword").val().trim();
		res = ValidateFields("#txtPassword", pass, 5, "Password");
	}
	if(res)
	{
		GetNewSession(userName);
	}	
}
function validateOTP()
{
	var res = true;
	var otp = $("#txtOTP").val().trim();
	res = ValidateFields("#txtOTP", otp, 2, "OTP");
	if(res)
	{
		ValidateOTP(otp);
	}
}

function SubmitConfirmAction(id)
{
	if(id == 2)
	{
		$("#myModalConfirm").modal("hide");
	}
	else
	{
		$("#myModalConfirm").modal("hide");
		var userName = $("#txtUsername").val().trim();
		var pass = $("#txtPassword").val().trim();
		var encryptedPassword = encrypt(EncryptionKey, pass);
		CheckLogin(userName, encryptedPassword, ReLoginURL);
	}
}

function startTimerOTP(remaining)
{
	
	    var m = Math.floor(remaining / 60);
        var s = remaining % 60;

        m = m < 10 ? '0' + m : m;
        s = s < 10 ? '0' + s : s;
		
		console.log(m , "-", s);
		
        document.getElementById('timer').innerHTML = 'Time left :' + m + ':' + s;
        remaining -= 1;
        if (remaining >= -1 && timerOn) {
            OtpTimer = setTimeout(function() {
                startTimerOTP(remaining);
            }, 1000);
            return;
        }

        if (!timerOn) {
            // Do validate stuff here
            return;
        }
        if (timerOn) {
			timerOn = false;			
            alert("One Time Password Expired");
            CreateResendOTP();
			//ResendOTP();
        }
        //  console.log(timerOn); 
        // Do timeout stuff here
        document.getElementById('timer').innerHTML = "00:00 .time out please refresh the page";
}

function ShowLoading()
{
	var loader=	$('#loader');
	loader.show();
	
}
function HideLoading()
{	
	var loader=	$('#loader');
	loader.hide();
}
