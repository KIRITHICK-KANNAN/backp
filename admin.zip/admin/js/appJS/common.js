const APIURL = '/forms/UAT/ITAIND/admin/api/'; 
const REDIRECTURL = '/forms/UAT/ITAIND/admin/';
const FULL_URL = 'https://vfseu.mioot.com/forms/UAT/ITAIND/';
const ADMIN_URL = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
//var checkEncryptionKey = APIURL + "Username/";
var checkEncryptionKey = APIURL + "GetSession/";
var LoginURL = APIURL +"Login/";
var ReLoginURL = APIURL +"ReLogin/";
var LogoutURL = APIURL +"Logout/";
var ValidateOtpApi = APIURL+"ValidateOtp/";

var AgentCasesURL = APIURL+"AgentCases/";
var AgentCaseListURL = APIURL+"AgentCaseList/";
var UpdateDocumentURL = APIURL+"UpdtDocs/";
var UpdateCaseURL = APIURL+"UpdtCase/";
var UpdateMasterURL = APIURL+"UpdtMastr/";
//var LogoutURL = "/forms/UAT/ITAIND/admin/Logout.php";
var DownloadURL = FULL_URL+"openDocument/";

var DocDetailURL = APIURL+"DocDtls/";
var AdminCasesURL = APIURL+"AdminCases/";
var SearchCasesURL = APIURL+"SearchCases/";
var AssignMeURL = APIURL+"AssignMe/";
var UpdateVerdictURL = APIURL+"UpdtVrdct/";
var sessionajaxvalid = "/forms/UAT/ITAIND/admin/ajaxvalidation.php";
var sessionLogout = "/forms/UAT/ITAIND/admin/Logout.php";
var bookSlotProcess = APIURL+"SlotProcess/";
var bookSlotList = APIURL+"SlotList/";
var PingURL = APIURL+"SessionPing/";

var ManifestList = APIURL+"Manifest/";

var VisitorLoginURL = APIURL + "GetSession/";
var ValidateOTPURL = APIURL + "ValidateOtp/";


var WebformMainAPI = APIURL + "Webform/";
var DashURL = APIURL+"dashBoard/";
var ChangeURL = APIURL+"changeVAC/";

var CaseObj = {};



function MenuCases(menu)
{console.log(menu);
	if(menu==1)
	{
		var url =ADMIN_URL+"cases/";
		$('#mainForm').attr('action', url);
		document.forms["mainForm"].submit();
				
			/*if (Object.keys(CaseObj).length === 0)
			{
				//console.log("Empty Object");
				
				var url =ADMIN_URL+"cases/";
				$('#mainForm').attr('action', url);
				document.forms["mainForm"].submit();
			}
			else
			{
				console.log("Not Empty Object");
			}*/

	}
	if(menu==2)
	{
	var url =ADMIN_URL+"list/";
	$('#mainForm').attr('action', url);
	document.forms["mainForm"].submit();
	}
	if(menu==3)
	{
	var url =ADMIN_URL+"addslot/";
	$('#mainForm').attr('action', url);
	document.forms["mainForm"].submit();
	}
	if(menu==4)
	{
	var url =ADMIN_URL+"slotlist/";
	$('#mainForm').attr('action', url);
	document.forms["mainForm"].submit();
	}
	if(menu==5)
	{
	var url =ADMIN_URL+"holiday/";
	$('#mainForm').attr('action', url);
	document.forms["mainForm"].submit();
	}
	if(menu==6)
	{
		var url =ADMIN_URL+"manifest/";
		$('#mainForm').attr('action', url);
		document.forms["mainForm"].submit();
	}
	if(menu==7)
	{
		var url =ADMIN_URL+"prioritycases/";
		$('#mainForm').attr('action', url);
		document.forms["mainForm"].submit();
	}
	if(menu==8)
	{
		var url =ADMIN_URL+"dashboard/";
		$('#mainForm').attr('action', url);
		document.forms["mainForm"].submit();
	}
}

function encrypt(key, val) 
{
    const keyHex = CryptoJS.enc.Hex.parse(key);
    const encrypted = CryptoJS.AES.encrypt(val, keyHex, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    });

    return encrypted.toString(); // The output is Base64 encoded
}
function decrypt(key, encVal) 
{
    const keyHex = CryptoJS.enc.Hex.parse(key);
    const decrypted = CryptoJS.AES.decrypt(encVal, keyHex, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    });

    return decrypted.toString(CryptoJS.enc.Utf8); // Convert back to string
}
