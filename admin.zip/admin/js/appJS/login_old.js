
var EncryptionKey;

$(function () {	

	let debounceTimer;

    $('#username').on('input', function () {

        clearTimeout(debounceTimer);

        const username = $(this).val().trim();


        if (username.length === 0) {
            $('#usernameStatus').text('');
            return;
        }

        debounceTimer = setTimeout(() => {

			var chkObj = { username : username }
			var chkParameter =  JSON.stringify(chkObj);
			const errorMsg = document.getElementById("error-msg");
			$.ajax({
				url: checkEncryptionKey,
				type: 'POST',
				data: chkParameter,
				dataType: 'json',
				crossDomain: true,
				jsonp: false,
				cache: false,
				timeout: 30000,
				headers: {"Content-Type": "text/plain"},
				beforeSend: function (xhr) {
		
					if (xhr.overrideMimeType) {
						xhr.overrideMimeType("application/json");
					}
				},
				success: function (data) {

					//console.log(data);					
					if(data.status == 1)
					{				
						$("#session_id").val(data.session_id);
						$("#encryption_key").val(data.encryption_key);
						EncryptionKey = data.encryption_key;
						errorMsg.style.display = "none";
					}
					else if(data.status == 2)
					{
						errorMsg.style.display = "inline";
						$("#username").val("");
						$("#username").focus();
						return false;
					}
				}
			});


        }, 1000);
    });


});

function login()
  {  
	
	  if($("#username").val().trim() === '') {
			alert("Enter Username");
			return false;
		}
		if($("#password").val().trim() === '') {
			alert("Enter Password");
			return false;
		}

        var defaultxss =ValidateXss($("#username").val().trim(),"email id");
        if(!defaultxss)
        {
            alert("Invalid Username values");
            return false;
        }
        var defaultxss1 =ValidateXss($("#password").val().trim(),"email id");
        if(!defaultxss1)
        {
            alert("Invalid Password values");
            return false;
        }
        
        EnK();
	
  }


  
    function EnK()
	{
		//var encryptedBase64Key1 = <?php echo "\"$PASSWORD1\""; ?>; 
        var encryptedBase64Key1 = EncryptionKey; 
		var pt = document.getElementById("password").value;
		//console.log('pass',pt);		
		var t1 = CryptoJS.AES.encrypt(JSON.stringify(pt), encryptedBase64Key1, {format: CryptoJSAesJson}).toString();
		//console.log('TempForPHPServer',t1);
		var t2 =JSON.parse(t1);
		//console.log('TempForPHPServer',t1,t2);
		//console.log('TempForPHPServer-2',t2.ct,t2.iv,t2.s);		
		document.getElementById("p3").value = t2.ct;
		document.getElementById("password").value = t2.ct;
		document.getElementById("p1").value = t2.s;
		document.getElementById("p2").value = t2.iv;

        $("body").addClass("loading");

		var request = $.ajax({
			url: "sessionValidationAjax.php",
			method: "POST",
			data: JSON.stringify({
				username : $("#username").val(),
				password : document.getElementById("password").value, 
				captcha : $("#captcha").val(), 
				p2 : document.getElementById("p2").value, 
				p1 : document.getElementById("p1").value, 
				p3 : document.getElementById("p3").value, 
				session_id : $("#session_id").val(),
                encryption_key : EncryptionKey,
			}),
			contentType: 'application/json; charset=utf-8'
		});
		request.done(function( result ) {			

			var result = JSON.parse(result);

            $("body").removeClass("loading");
			switch (result.status) {
                
				
                case 3:
                    alert("Invalid credentials!");
                    break;
				// case 7:
				// 	let userConfirmed = confirm("You have already logged in. Are you sure you want to re-login?");
				// 	if (userConfirmed) {
				// 		Relogin();
				// 	}
				// 	break;
				case 1:
                    var form = document.getElementById('mainForm');
                    document.getElementById('Globaluserid').value = result.user_id;
                    document.getElementById('Globalsessionid').value = result.session_id;
                    document.getElementById('Globalsessiontoken').value = result.session_token;		
                    document.getElementById('user_name').value = result.user_name;	
                    document.getElementById('full_name').value = result.full_name;		
                    document.getElementById('RoleId').value = result.RoleId;
					if(result.RoleId==1){
                        form.action = REDIRECTURL + "list/";
                     }else if(result.RoleId==4){
                        form.action = REDIRECTURL + "manifest/";
                     }else{
						form.action = REDIRECTURL + "cases/";
					 }					
                     form.submit();
                     break;

				default:
					console.error("Unexpected status:", result.status);
					break;
			}

              
		});	
		

	} 
	function ValidateXss(aInput, errorField) {
        var reg = /<|>/g;
        if (aInput != "" && reg.test(aInput)) {
           // alert("Invalid "+ errorField +"");
            return false;
        } else {
            return true;
        }
    }
