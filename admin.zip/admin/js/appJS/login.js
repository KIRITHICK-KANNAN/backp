var SessionId = 0;
var SessionToken = "";
var EncryptionKey = "";
var OTPVal = 0;
var timerOn = true;


$(function(){
	
});

function GetNewSession(userName)
{
	$("#btnValLog").attr('disabled', true);
	ShowLoading();
    var chkObj = { username: userName }
    var chkParameter =  JSON.stringify(chkObj);
	
    $.ajax({
        url: VisitorLoginURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        //async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			
			if(data.status == 1)
			{	
				SessionId = data.session_id;
				SessionToken = data.session_token;
				EncryptionKey = data.encryption_key;
				$("#txtUsername").attr('disabled', true);
				$("#txtPassword").attr('disabled', true);
				GetOTP();
			}
			else if(data.status == 2)
			{
				$("#btnValLog").attr('disabled', false);
				$("#txtUsername").val("");
				$("#txtPassword").val("");
				alert("Invalid User");
				HideLoading();
			}
        }
    });
}
function CheckLogin(name, pass, url)
{	
    var chkObj = { session_id: SessionId, session_token: SessionToken, username: name, password: pass }
    var chkParameter =  JSON.stringify(chkObj);
	console.log(chkParameter);
    $.ajax({
        url: url,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        //async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			HideLoading();
			if(data.status == 1)
			{	
				$("#isMsg").show();
				$("#divOTP").show();
				$("#divLogin").hide();
				$("#divValOTP").show();
				timerOn = true;
				startTimerOTP(300);
			}
			else if(data.status == 2)
			{
			  alert("Invalid Token");
			}
			else if(data.status == 3)
			{
			  alert("Invalid Credentials");
			}
			else if(data.status == 4)
			{
				$("#myModalConfirm").modal("show");
			}
			else if(data.status == 5)
			{
				alert("Max Attempt Reached ");
				location.reload();
			}
        }
    });
}
function ValidateOTP(otp)
{
	$("#btnValOTP").attr('disabled', true);
	ShowLoading();
    var chkObj = { session_id: SessionId, session_token: SessionToken, otp_number: otp}
    var chkParameter =  JSON.stringify(chkObj);
	console.log(chkParameter);
    $.ajax({
        url: ValidateOTPURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        //async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			$("#btnValOTP").attr('disabled', false);
			HideLoading();
			
			if(data.status == 1)
			{
				timerOn = false;	
				var form = document.getElementById('mainForm');
				document.getElementById('Globalsessiontoken').value = SessionToken;
				document.getElementById('Globalsessionid').value = SessionId;
				form.action = REDIRECTURL+'welcome/';					
				form.submit();
			}
			else if(data.status == 2)
			{
			  alert("Invalid Token");
			  location.reload();
			}
			else if(data.status == 3)
			{
			  alert("Invalid OTP");
			  $("#txtOTP").val("");
			}
			else if(data.status == 5)
			{
				alert("Max Attempt Reached ");
				location.reload();
			}
			else if(data.status == 5)
			{
				alert("OTP Expired");
				location.reload();
			}
        }
    });
}


function encrypt(key, password) {
    const keyHex = CryptoJS.enc.Hex.parse(key);
    const encrypted = CryptoJS.AES.encrypt(password, keyHex, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    });

    return encrypted.toString(); // The output is Base64 encoded
}
function GetOTP()
{
	var userName = $("#txtUsername").val().trim();
	var pass = $("#txtPassword").val().trim();
	var encryptedPassword = encrypt(EncryptionKey, pass);
	CheckLogin(userName, encryptedPassword, LoginURL);
}
function validateLogin()
{
	var res = true;
	var userName = $("#txtUsername").val().trim();
	res = ValidateFields("#txtUsername", userName, 4, "UserName");
	if(res)
	{
		var pass = $("#txtPassword").val().trim();
		res = ValidateFields("#txtPassword", pass, 5, "Password");
	}
	if(res)
	{
		GetNewSession(userName);
	}	
}
function validateOTP()
{
	var res = true;
	var otp = $("#txtOTP").val().trim();
	res = ValidateFields("#txtOTP", otp, 2, "OTP");
	if(res)
	{
		ValidateOTP(otp);
	}
}

function SubmitConfirmAction(id)
{
	if(id == 2)
	{
		$("#myModalConfirm").modal("hide");
	}
	else
	{
		$("#myModalConfirm").modal("hide");
		var userName = $("#txtUsername").val().trim();
		var pass = $("#txtPassword").val().trim();
		var encryptedPassword = encrypt(EncryptionKey, pass);
		CheckLogin(userName, encryptedPassword, ReLoginURL);
	}
}

function startTimerOTP(remaining)
{
	
	    var m = Math.floor(remaining / 60);
        var s = remaining % 60;

        m = m < 10 ? '0' + m : m;
        s = s < 10 ? '0' + s : s;
		
		console.log(m , "-", s);
		
        document.getElementById('timer').innerHTML = 'Time left :' + m + ':' + s;
        remaining -= 1;
        if (remaining >= -1 && timerOn) {
            OtpTimer = setTimeout(function() {
                startTimerOTP(remaining);
            }, 1000);
            return;
        }

        if (!timerOn) {
            // Do validate stuff here
            return;
        }
        if (timerOn) {
			timerOn = false;			
            alert("One Time Password Expired");
            location.reload();
        }
        //  console.log(timerOn); 
        // Do timeout stuff here
        document.getElementById('timer').innerHTML = "00:00 .time out please refresh the page";
}

function ShowLoading()
{
	var loader=	$('#loader');
	loader.show();
	
}
function HideLoading()
{	
	var loader=	$('#loader');
	loader.hide();
}
