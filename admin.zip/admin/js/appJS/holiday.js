var SessionId;
var SessionToken;
var UserRole;
var UserId;
var DocKey;
var objStatus;
var objVAC;
var objReason;
var objMaster;
var objDetails;
var objDocument;
var CurrentPassAct = 0;
var CurrentNullaAct = 0;
var isPassport = 0;
var DetailsId;

$(function () {	


	$("#holiday_date").datetimepicker({
		format: "Y-m-d",
		timepicker: false,
		//minDate: 0,
		minDate: new Date(new Date().setDate(new Date().getDate() + 1))
	});


	getLoginAdminDetails();
	LoadVAC();
	getHolidayList(); 
	doWebformConfirm(1);
});

function Logout(menu){
	let result = confirm("Are you sure want to logout session!");
	if (result === true) {
	   if(menu==1)
	   {
	   //var url ="Logout.php";
	   $('#mainForm').attr('action', LogoutURL);
	   document.forms["mainForm"].submit();
	   }
	}    

}



function SubmitConfirmAction(id)
{
	if(id == 2)
	{
		$("#myModalConfirm").modal("hide");
	}
	else
	{
		$("#myModalConfirm").modal("hide");
		// var userName = $("#txtUsername").val().trim();
		// var pass = $("#txtPassword").val().trim();
		// var encryptedPassword = encrypt(EncryptionKey, pass);
		// CheckLogin(userName, encryptedPassword, ReLoginURL);
		doWebformConfirm(2);
	}
}

function doWebformConfirm(type){

	let selectedValue = $("input[name='open_form']:checked").val();
	let priority_is_form_off = $("#priority_is_form_off").val();

	var param = {
		priority_is_form_off : priority_is_form_off,
		web_form_on_of : selectedValue,
		vac_id: $('#web_vac_id').val(),
		session_id: $('#Globalsessionid').val(),
		session_token: $('#Globalsessiontoken').val(),
		user_id: $('#Globaluserid').val(),
		project: 'italy',
		type: type,
	}

	var chkParameter = JSON.stringify(param);

	$.ajax({
        url: WebformMainAPI,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (res) {
			
				

			    let tbody = $("#body_on_off");
				tbody.empty();
		
				if (res.status == 1 && res.data.length > 0) {
					$.each(res.data, function(index, item) {
						let row = `<tr>
									  <td>${index + 1}</td>
									  <td>${item.vac_name}</td>
									  <td>${parseInt(item.is_form_off) == 0 ? 'Open' : 'Close'}</td>
									  <td>${parseInt(item.priority_is_form_off) == 0 ? 'Open' : 'Close'}</td>					   

								   </tr>`;
						tbody.append(row);
					});
				} else {
					tbody.append('<tr><td colspan="3" align="center">No data found</td></tr>');
				}

			if(res.type==1){
				
				// let is_form_off = parseInt(res.data[0].is_form_off);
				// console.log(is_form_off);
				// $("input[name='open_form'][value='" + (is_form_off ? "1" : "0") + "']").prop("checked", true);			

			}
			if(res.type==2){
				alert('Successfully updated the status');
				let vacSelect = $("#web_vac_id");
				let openFormYes = $("#open_form_yes");
				let openFormNo = $("#open_form_no");
				LoadVAC();
				openFormYes.prop("checked", false);
				openFormNo.prop("checked", false);
				doWebformConfirm(1)
				return;				
			}

			// if(res.status == 1)
			// {	
			// 	mainForm.submit();
			// }
			
        }
    });

}


function updateWebform() {
   
	if ($("#priority_is_form_off").val() === "") {
        alert("Please select Queue type");
        return false;
    }
	if ($("#web_vac_id").val()==0) {
        alert("Please select VAC");
        return false;
    }
	
	if (!$("input[name='open_form']:checked").val()) {
        alert("Please select an webform option");
        return false;
    }
	
	document.querySelector("#myModalConfirm .modal-dialog").style.marginLeft = "500px";


	var selectedText = $("#web_vac_id option:selected").text();

	let Radio = $("input[name='open_form']:checked").val();

	let Displaytext = '';

	if(Radio==1){
		Displaytext = `Please note that the customer journey webform will be <span class="star_required">Closed</span> for Submission (${selectedText}) except the current active sessions. Please confirm.`;
	}else{
		Displaytext = `Please note that the customer  joureny webform will be <span class="star_required">Opened</span> for Submission (${selectedText}) except the current active sessions. Please confirm.`;
	}

	$("#Displaytext").html(Displaytext);


	console.log('selectedText',selectedText);
	console.log('Radio',Radio);

	$("#myModalConfirm").modal("show");
    
  
}


function updateWorkingdays(){
	
	var selectedDays = [];
	$('input[name="days[]"]:checked').each(function() {
		selectedDays.push($(this).val());
	});	

	if (selectedDays.length === 0) {
		alert('Please select at least one item.');
		return;
	}

	var param = {
		days : selectedDays.join(','),
		user_id: $('#Globaluserid').val(),
		session_id: $('#Globalsessionid').val(),
		session_token: $('#Globalsessiontoken').val(),
		type: 2
	}

	var chkParameter = JSON.stringify(param);

	var x = confirm("Are you sure want to update week day(s)?");
	if (x) {

	$.ajax({
        url: APIURL+'HolidayList/',
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (res) {
			console.log('update',res);
			HideLoading();
			if(res.status == 1)
			{	
				mainForm.submit();
			}
			
        }
    });

}else{

}


}


function ValidateXSS(aInput) 
{
	var reg = /<|>/g;
	if (aInput != "" && reg.test(aInput)) 
	return false;
	else 
	return true;		
}

function addHoliday() {

	if($("#vac_id").val()==0)
		{
			$("#vac_id").css('border-color', 'red');
			$("#vac_id").focus();
			return false;
		}	
	if($("#holiday_name").val().length==0)
		{
		$("#holiday_name").css('border-color', 'red');
		$("#holiday_name").focus();
		return false;
		}		
		if(!ValidateXSS($("#holiday_name").val().trim()))
		{
		$("#holiday_name").css('border-color', 'red');
		$("#holiday_name").focus();
		return false;
		}			
		$('#holiday_name').css('border-color', '#ccc');

		if($("#holiday_date").val().length==0)
		{
		$("#holiday_date").css('border-color', 'red');
		$("#holiday_date").focus();
		return false;
		}		
		if(!ValidateXSS($("#holiday_date").val().trim()))
		{
		$("#holiday_date").css('border-color', 'red');
		$("#holiday_date").focus();
		return false;

		}			
		$('#holiday_date').css('border-color', '#ccc');
			
		var param = {
			user_id: $('#Globaluserid').val(),
			session_id: $('#Globalsessionid').val(),
			session_token: $('#Globalsessiontoken').val(),
			type: 4,
			vac_id : $('#vac_id').val(),
			holiday_date : $('#holiday_date').val(),
			holiday_name : $('#holiday_name').val(),
		}
		var chkParameter = JSON.stringify(param);

			$.ajax({
				url: APIURL+'HolidayList/',
				type: 'POST',
				data: chkParameter,
				dataType: 'json',
				crossDomain: true,
				async: false,
				jsonp: false,
				cache: false,
				timeout: 30000,
				headers: {"Content-Type": "text/plain"},
				beforeSend: function (xhr) {
		
					if (xhr.overrideMimeType) {
						xhr.overrideMimeType("application/json");
					}
				},
				success: function (res) {
					console.log('update',res);
					HideLoading();
					if(res.status == 1)
					{	
						 $('#holiday_date').val("");
						 $('#holiday_name').val("");
						 getHolidayList();
					}else if(res.status == 2)
					{
						alert("Holiday already exists for the mentioned date.");
						return false;

					}
					else if(res.status == 3)
					{
						alert("Selected holiday date already has a slot.");
						return false;
					}
					else{
						console.log('error not added');
					}
					
				}
			});

		

	}

function deleteRow(rowId) {
			
	var param = {
		user_id: $('#Globaluserid').val(),
		session_id: $('#Globalsessionid').val(),
		session_token: $('#Globalsessiontoken').val(),
		type: 3,
		holiday_id: rowId
	}
	var chkParameter = JSON.stringify(param);

		var x = confirm("Are you sure want to delete this holiday(s)?");
		if (x) {

			$.ajax({
				url: APIURL+'HolidayList/',
				type: 'POST',
				data: chkParameter,
				dataType: 'json',
				crossDomain: true,
				async: false,
				jsonp: false,
				cache: false,
				timeout: 30000,
				headers: {"Content-Type": "text/plain"},
				beforeSend: function (xhr) {
		
					if (xhr.overrideMimeType) {
						xhr.overrideMimeType("application/json");
					}
				},
				success: function (res) {
					console.log('update',res);
					HideLoading();
					if(res.status == 1)
					{	
						getHolidayList();
					}else{
						console.log('error');
					}
					
				}
			});

		}else{
			
		}

	}
	
	
function getHolidayList()
{
	var param = {
		user_id: $('#Globaluserid').val(),
		session_id: $('#Globalsessionid').val(),
		session_token: $('#Globalsessiontoken').val(),
		type: 1,
	}
	var chkParameter = JSON.stringify(param);

	$.ajax({
        url: APIURL+'HolidayList/',
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (res) {
			console.log('result',res);
			HideLoading();
			if(res.status == 1)
			{	

				var objData = res.data;
				
				  
					var list = "", k = 0;
					
					$("#divList").empty();
				
				
					console.log('length',objData.length);
				
					
						list += '<table class="table accordion table-responsive table-bordered text-left accordion-collapse p-2" id="r'+ k +'">';
							
						list += '<thead>';
						list += '<tr>';		
						list += '<th scope="col">S.No</th>';
						list += '<th scope="col">VAC</th>';
						list += '<th scope="col">Holiday Name</th>';
						list += '<th scope="col">Holiday Date</th>';
						list += '<th scope="col">Action</th>';
						list += '</tr>';
						list += '</thead>';
							
						list += '<tbody style="background:#fff;">';
						
				
							$('#delete_button').show();
							
							for(var j = 0;j<objData.length;j++)
							{	
								km = j+1;
								list += '<tr>';
								list += '<td>'+ km + '</td>';
								list += '<td>'+ objData[j].vac_name + '</td>';
								list += '<td>'+ objData[j].holiday_name + '</td>';
								list += '<td>'+ objData[j].formatted_holiday_date + '</td>';
								list += '<td class="text-right"><a class="btn btn-primary btn-lg login-btn" style="padding:0.1rem 0.8rem;font-size: 11px;" onclick="return deleteRow('+ objData[j].holiday_id + ');">Delete</a></td>';
								list += '</tr>';
							}
						

							
							
						
						if(objData.length==0){							
							$('#delete_button').hide();	
							 list += "<tr><td colspan='5' align='center'>----No Records----</td></tr>";
						}

							list += '</tbody>';			
							list += '</table>';
						
						
				
					$("#divList").append(list);
				
				
					

			}
			else if(res.status == 2)
			{
                console.log("No data found");
				return;
			}
        }
    });
	
}


function ConvertIST(specificDate)
{
	//var specificDate = new Date("2024-12-07 10:00");
	const offset = 5.5 * 60 * 60 * 1000; // 5 hours and 30 minutes in milliseconds
	const gmt530Date = new Date(specificDate.getTime() + offset);


	const options = {
	timeZone: 'Asia/Kolkata',
	year: 'numeric',
	month: '2-digit',
	day: '2-digit',
	hour: '2-digit',
	minute: '2-digit',
	second: '2-digit',
	hour12: false,
	};


	var dateString = gmt530Date.toLocaleString('en-US', options);
	const dateParts = dateString.split(", ");
	const [day, month, year] = dateParts[0].split("/").map(Number);
	const [hour, minute] = dateParts[1].split(":").map(Number);

	// Construct the Date object in the correct timezone
	const localDate = new Date(Date.UTC(year, month - 1, day, hour - 5, minute - 30));

	const extractedDay = localDate.getDate();
	const extractedMonth = localDate.getMonth() + 1; // Months are 0-indexed
	const extractedYear = localDate.getFullYear();
	const extractedHour = localDate.getHours();
	const extractedMinute = localDate.getMinutes();

	var dt = extractedDay + "/" + extractedMonth + "/" + extractedYear + " " + extractedHour + ":" + extractedMinute;
	console.log(dt);
	return dt;
}


function getLoginAdminDetails()
{
	const Globaluserid = $("#Globaluserid").val();
	const Globalsessionid = $("#Globalsessionid").val();
	const Globalsessiontoken  = $("#Globalsessiontoken").val();
	const RoleId = $("#RoleId").val();
	// const Globaluserid = 9;
	// const Globalsessionid = 2538;
	// const Globalsessiontoken  = 'd30bc267891a572c247b644c9df1c5a8';

	// $('#Globaluserid').val(Globaluserid);
	// $('#Globalsessionid').val(Globalsessionid);
	// $('#Globalsessiontoken').val(Globalsessiontoken);

	const user_name = $("#user_name").val();
	const full_name = $("#full_name").val();
    
    var chkObj_Session = { Globaluserid: Globaluserid, Globalsessionid: Globalsessionid, Globalsessiontoken: Globalsessiontoken , RoleId: RoleId ,user_name:user_name,full_name:full_name }
    var chkParameter_Session =  JSON.stringify(chkObj_Session);
    
    $.ajax({
        url: sessionajaxvalid,
        type: 'POST',
        data: chkParameter_Session,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log('session',data);
			SessionId = data.Globalsessionid;
			SessionToken = data.session_token;
			UserRole = data.RoleId;
			UserId = data.Globaluserid;
			objStatus = data.master_status_list;
			objReason = data.reasoncode_list;
			objVAC = data.vac_list;
			DocKey = data.document_key;
			
			$("#spanWelcomeUser").html("Welcome " + " " + data.full_name);
        }
    });
}

function convertToTimeZone(date, offset) {
  const utc = date.getTime() + date.getTimezoneOffset() * 60000;
  return new Date(utc + offset * 60000);
}
function LoadVAC()
{
	var list = "";
	$("#vac_id").empty();
	list += "<option value='0'>Select VAC</option>";
	list += "<option value='all'>All</option>";
	for(var i=0;i<objVAC.length;i++)
	{
		list += "<option value='"+ objVAC[i].vac_id +"'>"+ objVAC[i].vac_name +"</option>";
	}
	$("#vac_id").append(list);

    var listweb = "";
	$("#web_vac_id").empty();
	listweb += "<option value='0'>Select VAC</option>";
	listweb += "<option value='all'>All</option>";
	for(var i=0;i<objVAC.length;i++)
	{
		listweb += "<option value='"+ objVAC[i].vac_id +"'>"+ objVAC[i].vac_name +"</option>";
	}
	$("#web_vac_id").append(listweb);
	
}

function ShowLoading()
{
	var loader=	$('#loader');
	loader.show();	
}
function HideLoading()
{	
	var loader=	$('#loader');
	loader.hide();
}








