function GetCases()
{	
	ShowLoading();
    var chkObj = { session_id: SessionId, sessionToken: SessionToken }
    var chkParameter =  JSON.stringify(chkObj);
	console.log(chkParameter);
    $.ajax({
        url: AgentCasesURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				CaseObj = data.master;
				if(CaseObj == null)
				{
					CaseObj = {};
				}
				LoadList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
			else
			{
				alert(msg);
			}
        }
    });
}
function GetCases_New(reqId)
{	
	//ShowLoading();
    var chkObj = { session_id: SessionId, sessionToken: SessionToken, reqId: reqId }
    var chkParameter =  JSON.stringify(chkObj);
	console.log(chkParameter);
    $.ajax({
        url: AgentCaseListURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			//HideLoading1();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				LoadList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
			else
			{
				alert("");
			}
        }
    });
}
function UpdateDocument(chkParameter, reqId, DetailsId, docId, sts, rId, comments, type)
{
	LastActivity_Cases = GetCurrentTime();
	ShowLoading();
    $.ajax({
        url: UpdateDocumentURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{					
				//GetCases_New(reqId);
				$("#myModal").modal('hide');
				
				CheckStatus(reqId, DetailsId, docId, sts, rId, comments, type);
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function UpdateCaseDetails(chkParameter, reqId)
{
	LastActivity_Cases = GetCurrentTime();
	ShowLoading();
    $.ajax({
        url: UpdateCaseURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{					
				GetCases_New(reqId);
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function UpdateMasterDetails(chkParameter, reqId)
{
	LastActivity_Cases = GetCurrentTime();
	ShowLoading();
    $.ajax({
        url: UpdateMasterURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{					
				GetCases();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function Logout()
{
	var chkObj = { Globalsessionid: SessionId, Globalsessiontoken: SessionToken, Globaluserid: UserId }
    var chkParameter =  JSON.stringify(chkObj);
	$.ajax({
        url: LogoutURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
        }
    });
}
function GetAdminCases()
{	
	ShowLoading();
    var chkObj = { session_id: SessionId, sessionToken: SessionToken }
    var chkParameter =  JSON.stringify(chkObj);
	console.log(chkParameter);
    $.ajax({
        url: AdminCasesURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				LoadAdminList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function UpdateVerdict(chkParameter)
{
	LastActivity_Cases = GetCurrentTime();
	ShowLoading();
    $.ajax({
        url: UpdateVerdictURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1 || data.status == 3)
			{	
				GetAdminCases();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function GetSearchCases(chkParameter)
{	
    LastActivity = GetCurrentTime();
	ShowLoading();
	$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: SearchCasesURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				TotalRows = data.totalRows;
				setupPagination();
				LoadSearchList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function AssignMe(chkParameter)
{
	ShowLoading();
	$.ajax({
        url: AssignMeURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				LoadAdminList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function GetCaseList(chkParameter)
{	
	ShowLoading();
	$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: SearchCasesURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				TotalRows = data.totalRows;
				setupPagination();
				LoadSearchList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function GetDetailsList(chkParameter, dId, reviewCount, sts, type)
{	
	ShowLoading();
	$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: DocDetailURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(data.status == 1)
			{	
				objCustomer = data.CustActivity;
				objUser = data.UsrActivity;
				LoadHistory(dId, reviewCount, sts, type);
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function GetSlotList(chkParameter)
{	
	ShowLoading();
	$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: bookSlotList,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (res) {
			console.log('res>>>>>>>',res.status);
			$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(res.status == 1)
			{	
				objMaster = res.data;
				LoadSlotList(objMaster);
			}
			else if(res.status == 2)
			{
                objMaster = [];
				LoadSlotList(objMaster);
				//window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}

function GetManifestList(chkParameter)
{	
	ShowLoading();
	$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: ManifestList,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (res) {
			$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(res.status == 1)
			{	
				objMaster = res.data;
				LoadManifestList(objMaster);
			}
			else if(res.status == 2)
			{
                objMaster = [];
				LoadManifestList(objMaster);
				//window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}

function PingServer(sId, sTkn, dt)
{
	var chkObj = { session_id: sId, session_token: sTkn, activity_time: dt }
    var chkParameter =  JSON.stringify(chkObj);
	
	$.ajax({
        url: PingURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
		}
	});
}
function CheckActivityTime()
{
	const date1 = new Date(LastActivity); 
	const now = new Date();
	const year = now.getUTCFullYear();
	const month = now.getUTCMonth() + 1; 
	const day = now.getUTCDate();
	const hours = now.getUTCHours();
	const minutes = now.getUTCMinutes();
	const seconds = now.getUTCSeconds();
	var dt = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
    var date2 = new Date(dt);

	const diffInMilliseconds = date2 - date1;

	// Convert the difference to hours
	const diffInHours = diffInMilliseconds / (1000 * 60 * 60);

	console.log(diffInHours);

	if(diffInHours > 1)
	{
		alert("Session Expired !");
		Logout();
	}
}
