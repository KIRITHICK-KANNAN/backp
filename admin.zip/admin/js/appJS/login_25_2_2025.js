var session_id;
var session_token;
var EncryptionKey;

$(function () {	

	$("#otp_display").css("display", "none");
	$("#divBtn1").css("display", "inline");
	$("#divBtn2").css("display", "none");

	let debounceTimer;
	$("#captchaImg").hide();
    $('#username_old').on('input', function () {

        clearTimeout(debounceTimer);

        const username = $(this).val().trim();


        if (username.length === 0) {
            $('#usernameStatus').text('');
            return;
        }

        debounceTimer = setTimeout(() => {

			var chkObj = { username : username }
			var chkParameter =  JSON.stringify(chkObj);
			const errorMsg = document.getElementById("error-msg");
			$.ajax({
				url: checkEncryptionKey,
				type: 'POST',
				data: chkParameter,
				dataType: 'json',
				crossDomain: true,
				jsonp: false,
				cache: false,
				timeout: 30000,
				headers: {"Content-Type": "text/plain"},
				beforeSend: function (xhr) {
		
					if (xhr.overrideMimeType) {
						xhr.overrideMimeType("application/json");
					}
				},
				success: function (data) {

					//console.log(data);					
					if(data.status == 1)
					{				
						$("#session_id").val(data.session_id);
						$("#encryption_key").val(data.encryption_key);
						EncryptionKey = data.encryption_key;
						//errorMsg.style.display = "none";
						GetCaptcha(data.session_id);
						

					}
					else if(data.status == 2)
					{
						//errorMsg.style.display = "inline";
						$("#username").val("");
						$("#username").focus();
						return false;
					}
				}
			});


        }, 1000);
    });

	getSession();
});



function getSession(){


	var chkObj = { username : username }
	var chkParameter =  JSON.stringify(chkObj);
	const errorMsg = document.getElementById("error-msg");
	$.ajax({
		url: checkEncryptionKey,
		dataType: 'json',
		crossDomain: true,
		//jsonp: false,
		cache: false,
		timeout: 30000,
		//headers: {"Content-Type": "text/plain"},
		beforeSend: function (xhr) {

			if (xhr.overrideMimeType) {
				xhr.overrideMimeType("application/json");
			}
		},
		success: function (data) {

			//console.log(data);					
			if(data.status == 1)
			{				
				//$("#session_id").val(data.session_id);
				session_token = data.session_token;
				session_id = data.session_id;
				EncryptionKey = data.encryption_key;

			}
			else if(data.status == 2)
			{
				//errorMsg.style.display = "inline";
				$("#username").val("");
				$("#username").focus();
				return false;
			}
		}
	});




}

function GetCaptcha(SessionId)
{
    var data1 = "api/captcha/?session_id=" + SessionId;
	
    $.ajax({
        type: "GET",
        url: data1,
        mimeType: "text/plain; charset=x-user-defined",
        success: function (data) {
			
            if(data.status == 2)
            {
                alert("Invalid Session");
            }
            else
            {  debounceTimer = setTimeout(() => {
                $("#captchaImg").show();
                $('#captchaImg' ).attr('src', 'data:image/png;base64,' + base64encode(data)); 
			   },1000);
            }
        },
    });
}

function login()
  {  
	
	  if($("#username").val().trim() === '') {
			alert("Enter Username");
			return false;
		}
		if($("#password").val().trim() === '') {
			alert("Enter Password");
			return false;
		}

        var defaultxss =ValidateXss($("#username").val().trim(),"email id");
        if(!defaultxss)
        {
            alert("Invalid Username values");
            return false;
        }
        var defaultxss1 =ValidateXss($("#password").val().trim(),"email id");
        if(!defaultxss1)
        {
            alert("Invalid Password values");
            return false;
        }
		
        EnK();
	
  }


  function EnK()
  {

	
	var password = document.getElementById("password").value;
	$("body").addClass("loading");
	const encryptedPassword = encryptData(password, EncryptionKey);

	  var request = $.ajax({
		  url: LoginURL,
		  method: "POST",
		  data: JSON.stringify({
			username : $("#username").val(),
			password : encryptedPassword,
			session_id : session_id,
			session_token : session_token,
	  }),
		  contentType: 'application/json; charset=utf-8'
	  });
	  request.done(function( result ) {			

		  var result = JSON.parse(result);

		  //console.log('result',result);
		  $("body").removeClass("loading");
		  if(result.status==5){
			alert("Invalid Captcha.");
			document.getElementById("password").value = password;
			return false;	
		}
		if(result.status==6){
			alert("Your account has been blocked.");
			return false;	
		}
		if(result.status==1){
			session_id = result.session_id;
			session_token = result.session_token;
			$("#otp_display").css("display", "inline");
			$("#divBtn1").css("display", "none");
			$("#divBtn2").css("display", "inline");
		}
		if(result.status==7){
			let userConfirmed = confirm("You have active login session already , Conform to terminate the old session.?");
			if (userConfirmed) {
				Relogin();
			}
		}
		if(result.status==2){
			alert("Invalid credentials!");
			return;
		}
		if(result.status==3){
			alert("Invalid Data");
			return;
		}

			
	  });	
	  

  } 
  
    function EnK_OOOLLLD()
	{
		//var encryptedBase64Key1 = <?php echo "\"$PASSWORD1\""; ?>; 
        var encryptedBase64Key1 = EncryptionKey; 
		var pt = document.getElementById("password").value;
		//console.log('pass',pt);		
		var t1 = CryptoJS.AES.encrypt(JSON.stringify(pt), encryptedBase64Key1, {format: CryptoJSAesJson}).toString();
		//console.log('TempForPHPServer',t1);
		var t2 =JSON.parse(t1);
		//console.log('TempForPHPServer',t1,t2);
		//console.log('TempForPHPServer-2',t2.ct,t2.iv,t2.s);		
		document.getElementById("p3").value = t2.ct;
		document.getElementById("password").value = t2.ct;
		document.getElementById("p1").value = t2.s;
		document.getElementById("p2").value = t2.iv;

        $("body").addClass("loading");

		var request = $.ajax({
			url: "sessionValidationAjax.php",
			method: "POST",
			data: JSON.stringify({
				username : $("#username").val(),
				password : document.getElementById("password").value, 
				captcha : $("#txtCaptcha").val(), 
				p2 : document.getElementById("p2").value, 
				p1 : document.getElementById("p1").value, 
				p3 : document.getElementById("p3").value, 
				session_id : $("#session_id").val(),
                encryption_key : EncryptionKey,
			}),
			contentType: 'application/json; charset=utf-8'
		});
		request.done(function( result ) {			

			var result = JSON.parse(result);
			document.getElementById("password").value = pt;
            console.log('result',result);
            $("body").removeClass("loading");
			switch (result.status) {
                
                case 3:
                    alert("Invalid credentials!");
                    break;
				case 5:
					alert("Invalid captcha!");
					break;
				case 6:
					alert("Your account has been blocked.");
					break;	
				case 7:
					let userConfirmed = confirm("You have already logged in. Are you sure you want to re-login?");
					if (userConfirmed) {
						Relogin();
					}
					break;
				case 1:
                    var form = document.getElementById('mainForm');
                    document.getElementById('Globaluserid').value = result.user_id;
                    document.getElementById('Globalsessionid').value = result.session_id;
                    document.getElementById('Globalsessiontoken').value = result.session_token;		
                    document.getElementById('user_name').value = result.user_name;	
                    document.getElementById('full_name').value = result.full_name;		
                    document.getElementById('RoleId').value = result.RoleId;
                     if(result.RoleId==1){
                        form.action = REDIRECTURL + "list/";
                     }else if(result.RoleId==4){
                        form.action = REDIRECTURL + "manifest/";
                     }else{
						form.action = REDIRECTURL + "cases/";
					 }			
                     form.submit();
                     break;

				default:
					console.error("Unexpected status:", result.status);
					break;
			}

              
		});	
		

	}
	
	function base64encode(str) 
	{
	var CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	var out = "", i = 0, len = str.length, c1, c2, c3;
	while (i < len) {
		c1 = str.charCodeAt(i++) & 0xff;
		if (i == len) {
			out += CHARS.charAt(c1 >> 2);
			out += CHARS.charAt((c1 & 0x3) << 4);
			out += "==";
			break;
		}
		c2 = str.charCodeAt(i++);
		if (i == len) {
			out += CHARS.charAt(c1 >> 2);
			out += CHARS.charAt(((c1 & 0x3)<< 4) | ((c2 & 0xF0) >> 4));
			out += CHARS.charAt((c2 & 0xF) << 2);
			out += "=";
			break;
		}
		c3 = str.charCodeAt(i++);
		out += CHARS.charAt(c1 >> 2);
		out += CHARS.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
		out += CHARS.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6));
		out += CHARS.charAt(c3 & 0x3F);
	}
	return out;
	}

 
	function ValidateXss(aInput, errorField) {
        var reg = /<|>/g;
        if (aInput != "" && reg.test(aInput)) {
           // alert("Invalid "+ errorField +"");
            return false;
        } else {
            return true;
        }
    }



	
	
	function Relogin(){
		$("body").addClass("loading");

		var password = document.getElementById("password").value;
        $("body").addClass("loading");
		const encryptedPassword = encryptData(password, EncryptionKey);


		var request1 = $.ajax({
			url: ReLoginURL,
			method: "POST",
			data: JSON.stringify({
				username : $("#username").val(),
				password : encryptedPassword, 
				session_id : session_id,
				session_token : session_token,
			}),
			contentType: 'application/json; charset=utf-8'
		});

		request1.done(function( res ) {
			 $("body").removeClass("loading");
			 var result = JSON.parse(res);
			 console.log('Relogin',result);			 
			 if(result.status==1){
				document.getElementById('Globalsessiontoken').value = result.session_token;
				document.getElementById('Globalsessionid').value = result.session_id;
				session_id = result.session_id;
				session_token = result.session_token;
				$("#otp_display").css("display", "inline");
				$("#divBtn1").css("display", "none");
				$("#divBtn2").css("display", "inline");
			}


			
		});
    }



	function encryptData(data, key) {
		return CryptoJS.AES.encrypt(data, CryptoJS.enc.Hex.parse(key), {
			mode: CryptoJS.mode.ECB,
			padding: CryptoJS.pad.Pkcs7
		}).toString();
	}

	function login_success(){

		var otp_number = $("#otp_number").val().trim();
        if (otp_number === '') {
            $("#otp_number").css('border-color', 'red');
			$("#otp_number").focus();
			return false;        
        }

		var request = $.ajax({
			url: ValidateOtpApi,
			method: "POST",
			data: JSON.stringify({
				otp_number : $("#otp_number").val(),
				session_id : session_id,
                session_token : session_token,
			}),
			contentType: 'application/json; charset=utf-8'
		});

		request.done(function( res ) {
			var result = JSON.parse(res);

			console.log(result);
			console.log(session_token);
			console.log(session_id);


			if(result.status==1){
				var form = document.getElementById('mainForm');
				document.getElementById('Globalsessiontoken').value = session_token;
				document.getElementById('Globalsessionid').value = session_id;
				form.action = REDIRECTURL + "welcome/";				
				// if(result.RoleId==1){
				// 	form.action = REDIRECTURL + "list/";
				//  }else if(result.RoleId==4){
				// 	form.action = REDIRECTURL + "manifest/";
				//  }else{
				// 	form.action = REDIRECTURL + "cases/";
				//  }			
				form.submit();
			}
			if(result.status==2){
				alert("Invalid Otp");
				return false;
			}
			if(result.status==3){
				window.location.href=REDIRECTURL;
			}
			if(result.status==4){
				alert("Expired Otp");
				window.location.href=REDIRECTURL;
			}
              
		});	

	}

