var SessionId;
var SessionToken;
var UserRole;
var UserId;
var DocKey;
var objStatus;
var objVAC;
var objReason;
var objMaster;
var objDetails;
var objDocument;

var objUser;
var objUserList;
var objCustomer;

var objPassHis = [];
var objNullaHis = [];

var isPassport = 0;
var DetailsId;

var AppAct = [];
var LastActivity_Cases;
var EncryptionKey = "";

$(function () {	
	$("#divAgent").hide();
	$("#divEmbassy").hide();
	getLoginAdminDetails();
	if(UserRole == 3)
	{
		$("#divAgent").show();
		GetCases(0);
	}
	else if(UserRole == 2)
	{
		$("#divEmbassy").show();
		GetAdminCases(0);
		LoadVAC();
	}
	
	$('#FromDate_Admin').datepicker({
        autoclose: true,
		format: "yyyy-mm-dd"
    });
    $('#ToDate_Admin').datepicker({
        autoclose: true,
		format: "yyyy-mm-dd"
    });
});
function Logout(menu)
{
	let result = confirm("Are you sure want to logout session!");
	if (result === true) {
	   if(menu==1)
	   {
	   //var url ="Logout.php";
	   $('#mainForm').attr('action', LogoutURL);
	   document.forms["mainForm"].submit();
	   }
	}
}
function getLoginAdminDetails()
{
	const Globaluserid = $("#Globaluserid").val();
	const Globalsessionid = $("#Globalsessionid").val();
	const Globalsessiontoken  = $("#Globalsessiontoken").val();
	const user_name = $("#user_name").val();
	const full_name = $("#full_name").val();
	const RoleId = $("#RoleId").val();
    
    var chkObj_Session = { Globaluserid: Globaluserid, Globalsessionid: Globalsessionid, Globalsessiontoken: Globalsessiontoken , RoleId: RoleId ,user_name:user_name,full_name:full_name }
    var chkParameter_Session =  JSON.stringify(chkObj_Session);
    
    $.ajax({
        url: sessionajaxvalid,
        type: 'POST',
        data: chkParameter_Session,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			SessionId = data.Globalsessionid;
			SessionToken = data.session_token;
			UserRole = data.RoleId;
			UserId = data.Globaluserid;
			objStatus = data.master_status_list;
			objReason = data.reasoncode_list;
			objVAC = data.vac_list;
			DocKey = data.document_key;
			objUserList = data.user_list;
			EncryptionKey = data.encryption_key;
			
			$("#spanWelcomeUser").html("Welcome " + " " + data.full_name);
			
			if(UserRole == 3)
			{
				$("#menuCaseList").hide();
			}
			
			LastActivity_Cases = GetCurrentTime();	
			setInterval(PingServer(SessionId,SessionToken,LastActivity_Cases), 300000);
        }
    });
}
function ConvertIST(specificDate)
{
	const istOffset = 6 * 60 * 60 * 1000; // IST offset in milliseconds
	const localDate = new Date(specificDate.getTime() + istOffset); 
	
	const extractedDay = localDate.getDate();
	const extractedMonth = localDate.getMonth() + 1; // Months are 0-indexed
	const extractedYear = localDate.getFullYear();
	const extractedHour = localDate.getHours();
	const extractedMinute = localDate.getMinutes();

	var dt = extractedDay + "/" + extractedMonth + "/" + extractedYear + " " + extractedHour + ":" + extractedMinute;

	return dt;
}
function LoadList()
{
	if(objMaster == null)
	{
		$("#tblBodyList").empty();
		var list1 = "<table class='table'><thead><tr><td style='text-align: center;'>---------- No Records -----------</td></tr></thead></table>";
		$("#tblBodyList").append(list1);
	}
	if(objMaster != null)
	{
		var list = "",j = 1;
		var detLen = objDetails.length;
		var reqId = objMaster[0].reqId;
		var appNo = objMaster[0].noOfUsr;
		var email = objMaster[0].mailId;
		
		var submitOnIST = "";
		if(objMaster[0].submitOn == null || objMaster[0].submitOn == "0000-00-00 00:00:00.000000")
		{
			submitOnIST = "";
		}
		else
		{	
			var subDt = new Date(objMaster[0].submitOn);
			var y = subDt.getFullYear();
			var m = subDt.getMonth() + 1;
			var d = subDt.getDate().toString().padStart(2, '0');
			var hrs = subDt.getHours().toString().padStart(2, '0');
			var min = subDt.getMinutes().toString().padStart(2, '0');
			var submitOn = y +"-" + m + "-" + d + " " + hrs + ":" + min;
			submitOnIST = ConvertIST(new Date(submitOn));
		}
		
		var reqMasSts = objMaster[0].rStatus;
		var vac = "";
		var tempVac = objVAC.filter(v => v.vac_id == objMaster[0].vac);
		if(tempVac.length >0)
		{
			vac = tempVac[0].vac_name;
		}
		var sts = "";
		var tempSts = objStatus.filter(f => f.request_status_id == objDetails[0].dtlStatus);
		if(tempSts.length >0)
		{
			sts = tempSts[0].request_status_name;
		}

		$("#tblBodyList").empty();
		if(detLen == 0)
		{
			var list1 = "<tr><td>---------- No Records -----------</td></tr>";
			$("#tblBodyList").append(list1);
		}
		else
		{
			var fullName = objDetails[0].fName + " " + objDetails[0].lName;
			var issueDt = new Date(objDetails[0].wpndt);
			var y1 = issueDt.getFullYear();
			var m1 = issueDt.getMonth() + 1;
			var d1 = issueDt.getDate().toString().padStart(2, '0');
			var hrs1 = issueDt.getHours();
			var min1 = issueDt.getMinutes();
			var wpnDt = d1 +"/" + m1 + "/" + y1;// + " " + hrs1 + ":" + min1;
			
			var dob_dt = objDetails[0].dob;
		
			var dDt = new Date(dob_dt);
			var y2 = dDt.getFullYear();
			var m2 = (dDt.getMonth() + 1).toString().padStart(2, '0');
			var d2 = dDt.getDate().toString().padStart(2, '0');
			var dob = d2 + "/" + m2 + "/" + y2;
			console.log(EncryptionKey,"-",objDetails[0].ppn);
			var pNo = decrypt(EncryptionKey, objDetails[0].ppn);
			console.log(pNo);
			list += '<tr class="">';
			list += '<td rowspan="'+ detLen +'">'+ j +'</td>';
			list += '<td rowspan="'+ detLen +'">'+ reqId +'</td>';
			list += '<td rowspan="'+ detLen +'">'+ appNo +'</td>';
			list += '<td>'+ fullName +'</td>';
			list += '<td>'+ email + '</td>';
			list += '<td>'+ pNo +'</td>';
			list += '<td>'+ objDetails[0].wpn +'</td>';
			list += '<td>'+ dob +'</td>';
			list += '<td>'+ wpnDt +'</td>';
			list += '<td>'+ submitOnIST +'</td>';
			list += '<td>'+ vac +'</td>';
			list += '<td>'+ sts +'</td>';
			list += '<td><button type="button" class="btn btn-link" onClick="ShowDialog('+ objDetails[0].dtlId +')">View</button></td>';
			
			for(var i=1;i<detLen;i++)
			{
				var sts1 = "";
				var tempSts1 = objStatus.filter(f => f.request_status_id == objDetails[i].dtlStatus);
				if(tempSts1.length >0)
				{
					sts1 = tempSts1[0].request_status_name;
				}
				var fullName = objDetails[i].fName + " " + objDetails[i].lName;
				
				var dob_dt1 = objDetails[i].dob;
			
				var dDt1 = new Date(dob_dt1);
				var y3 = dDt1.getFullYear();
				var m3 = (dDt1.getMonth() + 1).toString().padStart(2, '0');
				var d3 = dDt1.getDate().toString().padStart(2, '0');
				var dob1 = d3 + "/" + m3 + "/" + y3;
				
				var issueDt2 = new Date(objDetails[i].wpndt);
				var y2 = issueDt2.getFullYear();
				var m2 = issueDt2.getMonth() + 1;
				var d2 = issueDt2.getDate().toString().padStart(2, '0');
				var wpnDt2 = d2 +"/" + m2 + "/" + y2;
				
				var pNo = decrypt(EncryptionKey, objDetails[i].ppn);
				
				list += '<tr>';	
				list += '<td>'+ fullName +'</td>';
				list += '<td>'+ email + '</td>';
				list += '<td>'+ pNo +'</td>';
				list += '<td>'+ objDetails[i].wpn +'</td>';
				list += '<td>'+ dob1 +'</td>';
				list += '<td>'+ wpnDt2 +'</td>';
				list += '<td>'+ submitOn +'</td>';
				list += '<td>'+ vac +'</td>';
				list += '<td>'+ sts1 +'</td>';
				list += '<td><button type="button" class="btn btn-link" onClick="ShowDialog('+ objDetails[i].dtlId +')">View</button></td>';
				list += '</tr>';	
						
			}
			list += '</td>';
			list += '</tr>';
			$("#tblBodyList").append(list);
			CloseMaster(reqId, reqMasSts);
		}
	}
}
function ShowDialog(detId)
{	    
	DetailsId = detId;
	$("#liPass").addClass('active');
	$("#liNulla").removeClass('active');
	$("#liHis").removeClass('active');
	
	$("input[name=rdoAction]").prop("checked",false);
	$("input[name=rdoActionNulla]").prop("checked",false);
	//CheckStatus();
	ShowPassport();	
	$("#myModal").modal('show');
}
function CheckStatus()
{
	var passSts = 0, nullaSts = 0;
	var tempDoc1 = objDocument.filter(f => f.type == 1 && f.dtlId == DetailsId);	
	var tempDoc2 = objDocument.filter(f => f.type == 2 && f.dtlId == DetailsId);
	if(tempDoc1.length > 0)
	{
		nullaSts = tempDoc1[0].docStatus;
	}
	if(tempDoc2.length > 0)
	{
		passSts = tempDoc2[0].docStatus;
	}
	console.log(passSts,"-",nullaSts);	
	if(passSts == 2 || passSts == 3 || passSts == 5)
	{
		$("#liPass").addClass('active');
		$("#liNulla").removeClass('active');
		$("#liHis").removeClass('active');
		$("#docPass").addClass('show');
		$("#docPass").addClass('active');
		$("#docNulla").removeClass('show');
		$("#docNulla").removeClass('active');
		ShowPassport();
	}
	else if(nullaSts == 2 || nullaSts == 3 || nullaSts == 5)
	{
		$("#liNulla").addClass('active');
		$("#liPass").removeClass('active');
		$("#liHis").removeClass('active');
		$("#docNulla").addClass('show');
		$("#docNulla").addClass('active');
		$("#docPass").removeClass('show');
		$("#docPass").removeClass('active');
		ShowNullaOsta();
	}
	else
	{
		$("#liPass").addClass('active');
		$("#liNulla").removeClass('active');
		$("#liHis").removeClass('active');
		$("#docPass").addClass('show');
		$("#docPass").addClass('active');
		$("#docNulla").removeClass('show');
		$("#docNulla").removeClass('active');
		ShowPassport();
	}
}
function ShowPassport()
{
	EnableActionFields(2);
	$("#liPass").addClass('active');
	$("#liNulla").removeClass('active');
	$("#liHis").removeClass('active');
	
    $("#docPass").addClass('show');
	$("#docPass").addClass('active');
	$("#docNulla").removeClass('show');
	$("#docNulla").removeClass('active');
	$("#divHistory").removeClass('show');
	$("#divHistory").removeClass('active');
	
	$("#btnVerify").hide();
	$("#btnReject").hide();
	$("#btnBlock").hide();
	
	$("#txtComment").val("");
	$("#txtComment").attr('disabled', false);
	$("#ddlReason").empty();
	$("#ddlReason").append("<option value='0'>---Select---</option>");
	$("#ddlReason").attr('disabled', false);
	
	isPassport = 1;
	$("#liReason").show();
	var reqId = 0, fullName = "", email = "", submitOn = "",vac = "", sts = "", pass = "", wpn = "", issueDt = "", comments = "", reasonId = 0, reviewCount = 0;
	var list = "", fileName = "", docSts = 0;
	
	var tempDoc = objDocument.filter(d => d.type == 2 && d.dtlId == DetailsId);
	if(tempDoc.length >0)
	{
		fileName = tempDoc[0].file;
		docSts = tempDoc[0].docStatus;
		reviewCount = tempDoc[0].revwCount;
		
		comments = tempDoc[0].remarks;
		if(comments == null)
		{
			comments = "";
		}
		reasonId = tempDoc[0].reason;
		if(reasonId == null)
		{
			reasonId = 0;
		}
	}
	
	if(docSts == 6)
	{
		$("#rdoAction1").prop('checked', true);
		DisableActionFields(2);
	}
	else if(docSts == 4)
	{
		$("#rdoAction3").prop('checked', true);
		DisableActionFields(2);
	}
	else if(docSts == 3)
	{
		$("#rdoAction2").prop('checked', true);
		DisableActionFields(2);
	}
	else if(docSts == 5)
	{
		if(reviewCount >= 4)
		{
			$("#rdoAction2").attr('disabled', true);
		}
	}
	else 
	{
		EnableActionFields(2);
	}
	if(docSts == 2 || docSts == 5)
	{
		$("#txtComment").val("");
		$("#ddlReason").empty();
		$("#ddlReason").append("<option value='0'>---Select---</option>");
	}
	else
	{
		if(comments != "")
		{
			$("#txtComment").val(comments);
		}
		if(reasonId > 0)
		{
			var list = "";
			$("#ddlReason").empty();
			list += "<option value='0'>---Select---</option>";
			var temp1 = objReason.filter((f) => f.type == 2);
			for (var j = 0; j < temp1.length; j++) {
				list += "<option value=" + temp1[j].id + ">" + temp1[j].reason_code + "</option>";
			}
			$("#ddlReason").append(list);
			$("#ddlReason").val(reasonId);
		}
	}

	LoadPassport_NullaOstaApplicantDetails(2);
	var downloadURL = DownloadURL + "?";
	var url = downloadURL + SessionId + "_" + DocKey + "_" + fileName;
    $('#divframe').attr('src', url);
}
function LoadPassport_NullaOstaApplicantDetails(type)
{
	var docSts = 0, dob = "", days = 0;
	var reqId = 0;//objMaster[0].reqId;
	var email = "";//objMaster[0].mailId;
	
	var temp = objDetails.filter(f => f.dtlId == DetailsId);
		
	if(temp.length > 0)
	{
		reqId = temp[0].reqId;
		var temp1 = objMaster.filter(f => f.reqId == reqId);
		if(temp1.length > 0)
		{
			email = temp1[0].mailId;
		}
		
		fullName = temp[0].fName + " " + temp[0].lName;
		days = temp[0].work_permit_issue_days;
		pass = decrypt(EncryptionKey, temp[0].ppn);//temp[0].ppn;
		wpn = temp[0].wpn;
		var issueDt1 = temp[0].wpndt;
		
		var isDt = new Date(issueDt1);
		var y1 = isDt.getFullYear();
		var m1 = (isDt.getMonth() + 1).toString().padStart(2, '0');
		var d1 = isDt.getDate().toString().padStart(2, '0');
		issueDt = d1 + "/" + m1 + "/" + y1;		
		
		var dob_dt = temp[0].dob;
		
		var dDt = new Date(dob_dt);
		var y2 = dDt.getFullYear();
		var m2 = (dDt.getMonth() + 1).toString().padStart(2, '0');
		var d2 = dDt.getDate().toString().padStart(2, '0');
		dob = d2 + "/" + m2 + "/" + y2;
	}
	var submitOnIST = "";
	if(objMaster[0].submitOn == null || objMaster[0].submitOn == "0000-00-00 00:00:00.000000")
	{
		submitOnIST = "";
	}
	else
	{
		var subDt = new Date(objMaster[0].submitOn);
		var y = subDt.getFullYear();
		var m = subDt.getMonth() + 1;//month[subDt.getMonth()];
		var d = subDt.getDate().toString().padStart(2, '0');
		var hrs = subDt.getHours().toString().padStart(2, '0');
		var min = subDt.getMinutes().toString().padStart(2, '0');
		var submitOn = y +"-" + m + "-" + d + " " + hrs + ":" + min;
		submitOnIST = ConvertIST(new Date(submitOn));
	}
	var tempVac = objVAC.filter(v => v.vac_id == objMaster[0].vac);
	if(tempVac.length >0)
	{
		vac = tempVac[0].vac_name;
	}
	var doc = objDocument.filter(d => d.type == type && d.dtlId == DetailsId);
	if(doc.length > 0)
	{
		docSts = doc[0].docStatus;
	}
	var tempSts = objStatus.filter(f => f.request_status_id == docSts);
	if(tempSts.length >0)
	{
		sts = tempSts[0].request_status_name;
	}
	var reference_text = "Reference ID -"+reqId;
	$("#show_reference").html(reference_text);
			
	if(type == 1)
	{
		$("#spanReqId1").html(reqId);
		$("#spanFullName1").html(fullName);
		$("#spanEmail1").html(email);
		$("#spanPassNo1").html(pass);
		$("#spanWPN1").html(wpn);
		$("#spanDays1").html(days);
		$("#spandob1").html(dob);
		$("#spanIssueDt1").html(issueDt);
		$("#spanSubmitDt1").html(submitOnIST);
		$("#spanVAC1").html(vac);
		$("#spanSts1").html(sts);
	}
	else
	{
		$("#spanReqId").html(reqId);
		$("#spanFullName").html(fullName);
		$("#spanEmail").html(email);
		$("#spanPassNo").html(pass);
		$("#spanWPN").html(wpn);
		$("#spandob").html(dob);
		$("#spanIssueDt").html(issueDt);
		$("#spanSubmitDt").html(submitOnIST);
		$("#spanVAC").html(vac);
		$("#spanSts").html(sts);
	}
}
function ShowNullaOsta()
{
	EnableActionFields(1);
	$("#liNulla").addClass('active');
	$("#liPass").removeClass('active');
	$("#liHis").removeClass('active');
	
    $("#docNulla").addClass('show');
	$("#docNulla").addClass('active');
	$("#docPass").removeClass('show');
	$("#docPass").removeClass('active');
	$("#divHistory").removeClass('show');
	$("#divHistory").removeClass('active');
	
	$("#btnVerify").hide();
	$("#btnReject").hide();
	$("#btnBlock").hide();
	
	$("#txtComment1").val("");
	$("#txtComment1").attr('disabled', false);
	$("#ddlReason1").empty();
	$("#ddlReason1").append("<option value='0'>---Select---</option>");
	$("#ddlReason1").attr('disabled', false);
	
	isPassport = 0;
	$("#liReason").show();
	var reqId = 0, fullName = "", email = "", submitOn = "",vac = "", sts = "", pass = "", wpn = "", issueDt = "", comments = "", reasonId = 0, reviewCount = 0;
	var list = "", fileName = "", docSts = 0;
	
	var tempDoc = objDocument.filter(d => d.type == 1 && d.dtlId == DetailsId);
	console.log(tempDoc);
	if(tempDoc.length >0)
	{
		fileName = tempDoc[0].file;
		docSts = tempDoc[0].docStatus;
		reviewCount = tempDoc[0].revwCount;
		
		comments = tempDoc[0].remarks;
		if(comments == null)
		{
			comments = "";
		}
		reasonId = tempDoc[0].reason;
		if(reasonId == null)
		{
			reasonId = 0;
		}
	}	
	if(docSts == 6)
	{
		$("#rdoAction1Nulla").prop('checked', true);
		DisableActionFields(1);
	}
	else if(docSts == 4)
	{
		$("#rdoAction3Nulla").prop('checked', true);
		DisableActionFields(1);
	}
	else if(docSts == 3)
	{
		$("#rdoAction2Nulla").prop('checked', true);
		DisableActionFields(1);
	}
	else if(docSts == 5)
	{
		if(reviewCount >= 4)
		{
			$("#rdoAction2Nulla").attr('disabled', true);
		}
	}
	else 
	{
		EnableActionFields(1);
	}
	if(docSts == 2 || docSts == 5)
	{
		$("#txtComment1").val("");
		$("#ddlReason1").empty();
		$("#ddlReason1").append("<option value='0'>---Select---</option>");
	}
	else
	{
		if(comments != "")
		{
			$("#txtComment1").val(comments);
		}
		if(reasonId > 0)
		{
			var list = "";
			$("#ddlReason1").empty();
			list += "<option value='0'>---Select---</option>";
			var temp1 = objReason.filter((f) => f.type == 1);
			for (var j = 0; j < temp1.length; j++) {
				list += "<option value=" + temp1[j].id + ">" + temp1[j].reason_code + "</option>";
			}
			$("#ddlReason1").append(list);
			$("#ddlReason1").val(reasonId);
		}
	}
	
	LoadPassport_NullaOstaApplicantDetails(1);
	
	var downloadURL = DownloadURL + "?";
	var url = downloadURL + SessionId + "_" + DocKey + "_" + fileName;
    $('#divframeNulla').attr('src', url);	
}
function LoadReasonCode(type)
{
	var list = "";
	if(type == 1)
	{
		$("#ddlReason1").empty();
	}
	else
	{
		$("#ddlReason").empty();
	}
	
	list += "<option value='0'>---Select---</option>";
	var temp1 = objReason.filter((f) => f.type == type);
	for (var j = 0; j < temp1.length; j++) {
		list += "<option value=" + temp1[j].id + ">" + temp1[j].reason_code + "</option>";
	}
	if(type == 1)
	{
		$("#ddlReason1").append(list);
	}
	else
	{
		$("#ddlReason").append(list);
	}	
}
function onChangeAction(act, type)
{
	$("#divBtnVRB").show();	
	$("#btnVerify").hide();
	$("#btnReject").hide();
	$("#btnBlock").hide();
	$("#txtComment").val("");
	$("#txtComment").attr('disabled', false);
	$("#ddlReason").attr('disabled', false);
	
	$("#txtComment1").val("");
	$("#txtComment1").attr('disabled', false);
	$("#ddlReason1").attr('disabled', false);
	
	if(type == 1)
	{
		if(act == 1)
		{
			$("#btnVerify").show();
			$("#liReason1").hide();
		}
		else if(act == 2)
		{
			$("#btnReject").show();
			$("#liReason1").show();
			LoadReasonCode(type);	
		}
		else if(act == 3)
		{
			$("#btnBlock").show();
			$("#liReason1").show();
			LoadReasonCode(type);
		}
	}
	else
	{
		if(act == 1)
		{
			$("#btnVerify").show();
			$("#liReason").hide();
		}
		else if(act == 2)
		{
			$("#btnReject").show();
			$("#liReason").show();
			LoadReasonCode(type);	
		}
		else if(act == 3)
		{
			$("#btnBlock").show();
			$("#liReason").show();
			LoadReasonCode(type);
		}
	}	
}
function DisableActionFields(type)
{
	if(type == 1)
	{
		$("#rdoAction1Nulla").attr('disabled', true);
		$("#rdoAction2Nulla").attr('disabled', true);
		$("#rdoAction3Nulla").attr('disabled', true);
		
		$("#ddlReason1").attr('disabled', true);
		$("#txtComment1").attr('disabled', true);

	}
	else
	{
		$("#rdoAction1").attr('disabled', true);
		$("#rdoAction2").attr('disabled', true);
		$("#rdoAction3").attr('disabled', true);
		
		$("#ddlReason").attr('disabled', true);
		$("#txtComment").attr('disabled', true);
	}
}
function EnableActionFields(type)
{
	if(type == 1)
	{
		$("#rdoAction1Nulla").attr('disabled', false);
		$("#rdoAction2Nulla").attr('disabled', false);
		$("#rdoAction3Nulla").attr('disabled', false);
		
		$("#ddlReason1").attr('disabled', false);
		$("#txtComment1").attr('disabled', false);
	}
	else
	{
		$("#rdoAction1").attr('disabled', false);
		$("#rdoAction2").attr('disabled', false);
		$("#rdoAction3").attr('disabled', false);
		
		$("#ddlReason").attr('disabled', false);
		$("#txtComment").attr('disabled', false);
	}		
}
function CloseDialog()
{
	isPassport = 1;
	$("#myModal").modal('hide');
}
function VerifyReject(act)
{
	if(isPassport == 0)
	{
		var docId = 0;	
		var rId = $("#ddlReason1").val();
		var comments = $("#txtComment1").val().trim();
		if(act == 6)
		{
			if(comments != "")
			{
				if(comments.length > 250)
				{
					alert("Comments should be 250 characters only.");
					$("#txtComment1").focus();
					return false;
				}
				else
				{
					if (!ValidateXSSTextArea(comments, "Remarks")) {
						$("#txtComment1").css('border-color', 'red');
						$("#txtComment1").focus();
						return false;
					}
				}
			}
		}
		if(act == 3 || act == 4)
		{
			if(rId == 0)
			{
				$("#ddlReason1").css('border-color', 'red');
				$("#ddlReason1").focus();
				return false;
			}
			if(comments == "")
			{
				$("#txtComment1").css('border-color', 'red');
				$("#txtComment1").focus();
				return false;
			}
			else
			{
				if(comments.length > 250)
				{
					alert("Comments should be 250 characters only.");
					$("#txtComment1").focus();
					return false;
				}
				else
				{
					if (!ValidateXSSTextArea(comments, "Remarks")) {
						$("#txtComment1").css('border-color', 'red');
						$("#txtComment1").focus();
						return false;
					}
				}
			}
		}

		if(act == 3 || act == 4)
		{
			if(act == 3)
			{
				var reviewCount = 0;
				var tempDoc1 = objDocument.filter(f => f.type == 1 && f.dtlId == DetailsId);
				if(tempDoc1.length > 0)
				{
					reviewCount = tempDoc1[0].revwCount;
					if(reviewCount >= 4)
					{
						act = 4;
					}
				}
			}

			if(rId == 0)
			{
				alert("Please select a reason for rejection .");
				$("#txtComment1").val("");
				return false;
			}
			
		}


		var temp = objDocument.filter(f => f.type == 1 && f.dtlId == DetailsId);
		docId = temp[0].docId;
			
		var reqId = objMaster[0].reqId;
		var params = {
			session_id: SessionId,
			sessionToken: SessionToken,
			reqId: reqId,
			dtlId: DetailsId,
			docId: docId,
			status: act,
			reason: rId,
			comments: comments
		}
		
		var obj = JSON.stringify(params);
		UpdateDocument(obj, reqId, DetailsId, docId, act, rId, comments, 1);
	}
	else
	{
		var docId = 0;	
		var rId = $("#ddlReason").val();
		var comments = $("#txtComment").val().trim();
		if(act == 6)
		{
			if(comments != "")
			{
				if(comments.length > 250)
				{
					alert("Comments should be 250 characters only.");
					$("#txtComment").focus();
					return false;
				}
				else
				{
					if (!ValidateXSSTextArea(comments, "Remarks")) {
						$("#txtComment").css('border-color', 'red');
						$("#txtComment").focus();
						return false;
					}
				}
			}
		}
		if(act == 3 || act == 4)
		{
			if(rId == 0)
			{
				$("#ddlReason").css('border-color', 'red');
				$("#ddlReason").focus();
				return false;
			}
			if(comments == "")
			{
				$("#txtComment").css('border-color', 'red');
				$("#txtComment").focus();
				return false;
			}
			else
			{
				if(comments.length > 250)
				{
					alert("Comments should be 250 characters only.");
					$("#txtComment").focus();
					return false;
				}
				else
				{
					if (!ValidateXSSTextArea(comments, "Remarks")) {
						$("#txtComment").css('border-color', 'red');
						$("#txtComment").focus();
						return false;
					}
				}
			}
		}

		if(act == 3 || act == 4)
		{
			if(act == 3)
			{
				var reviewCount = 0;
				var tempDoc1 = objDocument.filter(f => f.type == 2 && f.dtlId == DetailsId);
				if(tempDoc1.length > 0)
				{
					reviewCount = tempDoc1[0].revwCount;
					if(reviewCount >= 4)
					{
						act = 4;
					}
				}
			}
			if(rId == 0)
			{
				alert("Please select a reason for rejection .");
				$("#txtComment").val("");
				return false;
			}			
		}

		var temp = objDocument.filter(f => f.type == 2 && f.dtlId == DetailsId);
		docId = temp[0].docId;
		
		var reqId = objMaster[0].reqId;
		var params = {
			session_id: SessionId,
			sessionToken: SessionToken,
			reqId: reqId,
			dtlId: DetailsId,
			docId: docId,
			status: act,
			reason: rId,
			comments: comments
		}		
		var obj = JSON.stringify(params);						
		UpdateDocument(obj, reqId, DetailsId, docId, act, rId, comments, 2);
	}
}
function EditDocumentObject(reqId, docId, sts, rId, comments, DetailsId, type)
{	
    var dId = 0, docSts = 0;
	var dt = GetCurrentTime();
	$.each(objDocument, function(idx, val){
		if(val.docId == docId)
		{
			val.docStatus = sts;
			val.remarks = comments;
			val.reason = rId;
			val.vefifyBy = UserId;
			val.verifyOn = dt;
		}
	});
	
	console.log("***Edit***",objDocument);
	if(sts == 4)
	{
		var temp1 = objDocument.filter(t => t.dtlId == DetailsId && t.docStatus != 4);
		
	    if(temp1.length > 0)
		{
			dId = temp1[0].docId;
			docSts = temp1[0].docStatus;
			
			var params = {
				session_id: SessionId,
				sessionToken: SessionToken,
				reqId: reqId,
				dtlId: DetailsId,
				docId: dId,
				status: 4,
				reason: 0,
				comments: "Blocked by the system as the other document was blocked by the user"
			}
			var obj = JSON.stringify(params);
			UpdateDocument(obj, reqId, DetailsId, dId, 4, rId, comments);	
			UpdateCase(reqId, DetailsId, 4);
		}	
	}
}
function CheckStatus(reqId, DetailsId, docId, sts, rId, comments, type)
{
	EditDocumentObject(reqId, docId, sts, rId, comments, DetailsId, type);
	if(sts != 4)
	{
		var temp = objDetails.filter(f => f.dtlId == DetailsId);
		for(var i=0;i<temp.length;i++)
		{
			var passSts = 0, nullSts = 0, sts = 0, reviewCountPass = 0, reviewCountNulla = 0;
			var verifyCount = 0, rejectCount = 0, reviewCount = 0;
			
			sts = temp[i].dtlStatus;
			appNo = temp.length;
			var temp1 = objDocument.filter(f => f.type == 1 && f.dtlId == temp[i].dtlId);
			var temp2 = objDocument.filter(f => f.type == 2 && f.dtlId == temp[i].dtlId);
			if(temp1.length > 0)
			{
				nullSts = temp1[0].docStatus;	
				reviewCountNulla = temp1[0].revwCount;			
			}
			if(temp2.length > 0)
			{
				passSts = temp2[0].docStatus;	
				reviewCountPass = temp2[0].revwCount;	
			}
			
			if(passSts == 6 && nullSts == 6)  //Both verify
			{
				if(sts == 2 || sts == 3 || sts == 4 || sts == 5 || sts == 6)
				{
					UpdateCase(reqId, temp[i].dtlId, 6);
				}
			}
			else if((passSts == 6 && nullSts == 3) || (passSts == 3 && nullSts == 6) || (passSts == 3 && nullSts == 3)) //verify / review
			{
				if(sts == 2 || sts == 3 || sts == 4 || sts == 5 || sts == 6)
				{
					UpdateCase(reqId, temp[i].dtlId, 3);
				}
				
			}
			else if(passSts == 4 || nullSts == 4) //Both Rejected
			{
				if(sts == 2 || sts == 3 || sts == 4 || sts == 5 || sts == 6)
				{
					UpdateCase(reqId, temp[i].dtlId, 4);
				}
			}
			else if((passSts == 6 && nullSts == 4) || (passSts == 4 && nullSts == 6) || (passSts == 4 || nullSts == 4))
			{
				if(reviewCountPass >= 4 && reviewCountNulla>=4)
				{
					if(sts == 2 || sts == 3 || sts == 4 || sts == 5 || sts == 6)
					{
						UpdateCase(reqId, temp[i].dtlId, 4);					
					}				
				}
				else
				{
					if(sts == 2 || sts == 3 || sts == 4 || sts == 5 || sts == 6)
					{
						UpdateCase(reqId, temp[i].dtlId, 3);
					}
				}
			}
		}
	}	
}
function UpdateCase(reqId, detId, sts)
{	
	var param = {
		session_id: SessionId,
		sessionToken: SessionToken,
		reqId: reqId,
		dtlId: detId,
		dtlStatus: sts
	}
	var obj = JSON.stringify(param);
	UpdateCaseDetails(obj, reqId);
}
function CloseMaster(reqId, reqMasSts)
{
	var verifyCount = 0, rejectCount = 0, reviewCount = 0, appNo = 0, masterSts = 0;
	appNo = objDetails.length;
	for(var i=0;i<objDetails.length;i++)
	{
		var sts = objDetails[i].dtlStatus;
		if(sts == 3 || sts == 4 || sts == 5 || sts == 6)
		{
			if(sts == 4)
			{
				rejectCount++;
			}
			else if(sts == 6)
			{
				verifyCount++;
			}
			else if(sts == 3)
			{
				reviewCount++;
			}
		}
	}
	
	if(appNo == verifyCount)
	{
		masterSts = 6;
	}
	else if(appNo == rejectCount)
	{
		masterSts = 4;
	}
	else if(appNo == reviewCount)
	{
		masterSts = 3;
	}
	else 
	{
		if(reviewCount >= 1)
		{
			masterSts = 3;
		}
		else if(rejectCount >= 1)
		{
			if(verifyCount >= 1)
			{
				masterSts = 7;
			}
		}
		else if(rejectCount == 0)
		{
			if(verifyCount >= 1)
			{
				masterSts = 6;
			}
		}
		else if(verifyCount == 0 )
		{
			if(rejectCount >= 1)
			{
				masterSts = 4;
			}
		}
	}
	//console.log("masterSts-",masterSts);  //4,6,10
	var checkTotal = parseInt(verifyCount) + parseInt(rejectCount) + parseInt(reviewCount);
	//console.log(appNo,"-",verifyCount,"-",rejectCount,"-",reviewCount,"-",checkTotal,"-",reqMasSts);  // 3 1 0 0 
	if(masterSts > 0)
	{
		var param = {
			session_id: SessionId,
			sessionToken: SessionToken,
			reqId: reqId,
			reqStatus: masterSts
		}
		var obj = JSON.stringify(param);
		if(reqMasSts == 2 || reqMasSts == 3 || reqMasSts == 5)
		{
			if(parseInt(appNo) == checkTotal)
			{				
				UpdateMasterDetails(obj, reqId, 0);
			}
		}
	}	
}
function onChangeReason1(rId)
{
	if(rId > 0)
	{
		var temp = objReason.filter(f => f.id == rId);
		if(temp.length > 0)
		{
			$("#txtComment1").val(temp[0].reason_comments);
			$("#txtComment1").attr('disabled', true);
		}

		if(rId !== 0){
			$('#btnVerify').hide();
		}
		
		if(rId == 0){
			$('#btnVerify').show();
			$("#txtComment1").val("");
		}
	}
	else
	{
		$("#txtComment1").val("");
		$("#txtComment1").attr('disabled', false);
	}
}
function onChangeReason(rId)
{
	if(rId > 0)
	{
		var temp = objReason.filter(f => f.id == rId);
		if(temp.length > 0)
		{
			$("#txtComment").val(temp[0].reason_comments);
			$("#txtComment").attr('disabled', true);
		}

		if(rId !== 0){
			$('#btnVerify').hide();
		}
		
		if(rId == 0){
			$('#btnVerify').show();
			$("#txtComment").val("");
		}
	}
	else
	{
		$("#txtComment").val("");
		$("#txtComment").attr('disabled', false);
	}
}
function ShowHistory()
{	
    var rId = 0, stsName = "", spanMsg = "", spanMsg1 = "", passNo = "", nullaNo = "", submitOnIST = "", reviewCount = 0;
	var dIdNulla = 0;
	
	nullaNo = GetPassportNullaNo(1, DetailsId);
	passNo = GetPassportNullaNo(2, DetailsId);
	
	
	var tempDoc1 = objDocument.filter(f => f.type == 1 && f.dtlId == DetailsId);
	
	if(tempDoc1.length > 0)
	{
		rId = tempDoc1[0].reqId;
		reviewCount = tempDoc1[0].revwCount;
		dIdNulla = tempDoc1[0].docId;
		var tempMas = objMaster.filter(m => m.reqId == rId);
		if(tempMas.length > 0)
		{
			var subDt = tempMas[0].submitOn;
			
			submitOnIST = ConvertIST(new Date(subDt));
		}		
	}
	var l = tempDoc1.length - 1;
	var cSts = tempDoc1[l].docStatus;
	var stsName = GetStatusName(cSts);
	if(cSts == 6)
	{
		spanMsg = '<span class="verified-btn"><B>'+ stsName +'</B>';
	}
	else if(cSts == 4)
	{
		spanMsg = '<span class="block-btn"><B>'+ stsName +'</B>';
	}
	else
	{
		spanMsg = '<span><B>'+ stsName +'</B>';
	}
	
	var tempDoc2 = objDocument.filter(f => f.type == 2 && f.dtlId == DetailsId);
	var dId = tempDoc2[0].docId;
	var l1 = tempDoc2.length - 1;
	var cSts1 = tempDoc2[l1].docStatus;
	var stsName1 = GetStatusName(cSts1);
	if(cSts1 == 6)
	{
		spanMsg1 = '<span class="verified-btn"><B>'+ stsName1 +'</B>';
	}
	else if(cSts1 == 4)
	{
		spanMsg1 = '<span class="block-btn"><B>'+ stsName1 +'</B>';
	}
	else
	{
		spanMsg1 = '<span><B>'+ stsName1 +'</B>';
	}
	
	$("#spanStsPassHis").html(spanMsg1);
	$("#spanPassHis").html(passNo);
	$("#spanStsNullaHis").html(spanMsg);
	$("#spanNullaHis").html(nullaNo);
	

	//Passport
	
	if(cSts1 >= 2)
	{
		var obj = {
			session_id: SessionId,
			sessionToken: SessionToken,
			docId: dId
		}
		var chkParam = JSON.stringify(obj);
		
		GetDetailsList(chkParam, DetailsId, reviewCount, cSts1, 2);
	}
	
	//NullaOsta
		
	if(cSts >= 2)
	{
		LoadNullaOsta(tempDoc1, submitOnIST);
		var obj = {
			session_id: SessionId,
			sessionToken: SessionToken,
			docId: dIdNulla
		}
		var chkParam = JSON.stringify(obj);
		
		GetDetailsList(chkParam, DetailsId, reviewCount, cSts, 1);
	}
}
function LoadNullaOsta(tempDoc1, submitOnIST)
{
	var c1 = 1, list1 = "", actBy1 = "", actOn1= "", isAgt1 = "";
	$("#tblNullaHis").empty();
	$.each(tempDoc1, function( index, value ) {
		var sts1 = GetStatusName(value.docStatus);
		var verBy1 = value.vefifyBy;
		var verOn1 = value.verifyOn;
		if(verBy1 == null)
		{
			verBy1 = "";
		}
		if(verOn1 == null)
		{
			verOn1 = "";
		}
		if(value.docStatus == 2)
		{
			actBy1 = GetApplicantName(DetailsId);	
            isAgt1 = "Applicant";				
		}
		if(value.docStatus == 6)
		{
			isAgt1 = "Agent";
		}
		if(verBy1 != "")
		{
			actBy1 = GetUserName(value.vefifyBy);
		}
		if(value.docStatus == 6)
		{
			isAgt1 = "Agent";
		}
		if(verOn1 != "")
		{
			actOn1 = ConvertIST(new Date(value.verifyOn));
		}
		else
		{
			actOn1 = submitOnIST;
		}
		list1 += "<tr>";
		list1 += "<td>"+ c1 +"</td>";
		list1 += "<td>"+ sts1 +"</td>";
		list1 += "<td>"+ actBy1 +"</td>";
		list1 += "<td>"+ isAgt1 +"</td>";
		list1 += "<td>"+ actOn1 +"</td>";
		list1 += "<td><span onclick=DisplayFile('"+ value.file +"')>"+ value.file +"</span></td>";
		list1 += "</tr>";
		c1++;
	});
	$("#tblNullaHis").append(list1);
}
function GetPassportNullaNo(flag, detId)
{
	var no = "", passNo = "", nullaNo = "";
	var temp = objDetails.filter(f => f.dtlId == detId);
	if(temp.length > 0)
	{
		passNo = decrypt(EncryptionKey, temp[0].ppn);//temp[0].ppn;
		nullaNo = temp[0].wpn;
	}
	if(flag == 1)
	{
		no = nullaNo;
	}
	else
	{
		no = passNo;
	}
	return no;
}
function GetStatusName(cSts)
{
	var name = "";
	var cStsName = objStatus.filter(f => f.request_status_id == cSts);
	if(cStsName.length >0)
	{
		name = cStsName[0].request_status_name;
	}
	return name;
}
function GetUserName(uId)
{
	var name = "";
	var temp = objUserList.filter(f => f.user_id == uId);
	
	if(temp.length > 0)
	{
		name = temp[0].full_name;
	}
	return name;
}
function GetApplicantName(detId)
{
	var name = "";
	var temp = objDetails.filter(f => f.dtlId == detId);
	
	if(temp.length > 0)
	{
		name = temp[0].fName + " " + temp[0].lName;
	}
	return name;
}
function ValidateXSSTextArea(aInput, errorField)
{
    var reg = /[<|>]/g;
	var DefaultMsg = "Invalid";
    if (aInput != "" && reg.test(aInput)) {
        alert(DefaultMsg + errorField + ".");
        return false;
    }
    else {
        return true;
    }
}
function DisplayFile(fileName, lId, type)
{
	var comments = "", rId = 0, reason = "";
	var tmp = objPassHis.filter(f => f.log_id == lId);
	if(tmp.length > 0)
	{
		comments = tmp[0].comments;
		rId = tmp[0].reason_id;
	}
	if(rId > 0)
	{
		var t = objReason.filter(r => r.id == rId);
		if(t.length > 0)
		{
			reason = t[0].reason_code;
		}
	}
	if(reason == "" && comments == "")
	{
		$("#tblHis").hide();
	}
	else
	{
		$("#tblHis").show();
	}
	if(reason == "")
	{
		$("#tdHisReason").html("");
	}
	else
	{
		$("#tdHisReason").html(reason);
	}
	if(comments == "")
	{
		$("#tdHisComment").html("");
	}
	else
	{
		$("#tdHisComment").html(comments);
	}
	
	var downloadURL = DownloadURL + "?";
	var url = downloadURL + SessionId + "_" + DocKey + "_" + fileName;
    $('#divframeHistory').attr('src', url);
}
function LoadHistory(detId, reviewCount, sts, type)
{
	var list = GetHistoryDetails(detId, sts, type);
	
	if(type == 2)
	{
		$("#tblPassHis").empty();
		$("#tblPassHis").append(list);
	}
	else
	{
		$("#tblNullaHis").empty();
		$("#tblNullaHis").append(list);
	}
}
function GetHistoryDetails(detId, sts, type)
{
	var objTemp = [];
	var c = 1, act = "", actBy = "", actOn = "", fileName = "", curFileName = "", actName = "", list = "";
	var docSts = 0, reviewCount = 0, docSubmitOn = "", reqId = 0;
	
	$.each(objUser, function( index, value ) {	
        var comment = value.remarks;	
		var rId = value.reason;
		actBy = GetUserName(value.usrId);
		actOn = value.addOn;
		act = "Review";
		actName = "Agent";
		fileName = "";
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,	
			reason_id: rId,
            comments: comment,
            log_id: value.alog,
            type: type				
		}
		objTemp.push(params);
	});
	$.each(objCustomer, function( index, value ) {	
        var fn = objDetails.filter(f => f.dtlId == value.dtlId);	
		if(fn.length > 0)
		{
			actBy = fn[0].fName + " " + fn[0].lName;
		}
		if(value.docStatus == 2 || value.docStatus == 5)
		{
			if(value.docStatus == 2)
			{
				act = "Submitted";
			}
			else
			{
				act = "ReSubmitted";
			}
		}
		
		actName = "Applicant";
		fileName = value.file;
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: value.addOn,
			file_name: fileName,
			details_id: detId,	
			reason_id: 0,
            comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	});
	
	//Verified
	var verBy = "", verOn = "";
	var tempDoc2 = objDocument.filter(f => f.type == type && f.dtlId == detId);
	console.log(tempDoc2);
	if(tempDoc2.length > 0)
	{
		docAddOn = tempDoc2[0].submitOn;
		curFileName = tempDoc2[0].file;
		docSts = tempDoc2[0].docStatus;
		
		verBy = tempDoc2[0].vefifyBy;
		verOn = tempDoc2[0].verifyOn;
		if(verBy == null)
		{
			verBy = "";
		}
		if(verOn == null)
		{
			verOn = "";
		}
		if(verBy != "")
		{
			verBy = GetUserName(verBy);
		}
		if(verOn != "")
		{
			verOn = verOn;
		}
	}

	if(docSts == 6 || docSts == 8 || docSts == 13 || docSts == 5) 
	{			
		act = "Verified";
		actName = "Agent";
		actBy = verBy;
		actOn = verOn;
		fileName = curFileName;
		
		if(docSts == 5)
		{
			act = "ReSubmitted";
		}
		
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,
			reason_id: 0,
			comments: "",
            log_id: 0,
            type: type				
		}
		console.log("objTemp-",objTemp);
		console.log("p1",params);
		objTemp.push(params);
	}
	if(docSts == 8 || docSts == 9 || docSts == 13)
	{
		var appOn = "", appBy = "";
		var tempMas = objMaster.filter(f => f.reqId == reqId);
		if(tempMas.length > 0)
		{
			appOn = tempMas[0].approvOn;
			appBy = tempMas[0].aprovdBy;
		}
		if(appBy == null)
		{
			appBy = "";
		}
		if(appOn == null)
		{
			appOn = "";
		}
		if(appBy != "")
		{
			appBy = GetUserName(appBy);
		}
		if(appOn != "")
		{
			appOn = appOn;
		}
		act = "Approved";
		actName = "Embassy";
		actBy = appBy;
		actOn = appOn;
		fileName = curFileName;
		var params = {
			action: act,
			action_by: actBy,
			action_name: actName,
			action_on: actOn,
			file_name: fileName,
			details_id: detId,
			reason_id: 0,
			comments: "",
            log_id: 0,
            type: type				
		}
		objTemp.push(params);
	}
	  const sortedData = objTemp.sort((a, b) => {	  
	  const dateA = new Date(a.action_on);
	  const dateB = new Date(b.action_on);
	  return dateA - dateB; 
	});

	console.log(sortedData);
    $.each(sortedData, function( index, value ) {	    
	    var dt = ConvertIST(new Date(value.action_on));
		console.log(value.action_on,"-",dt);
		list += "<tr>";
		list += "<td>"+ c +"</td>";
		list += "<td>"+ value.action +"</td>";
		list += "<td>"+ value.action_by +"</td>";
		list += "<td>"+ value.action_name +"</td>";
		list += "<td>"+ dt +"</td>";
		if(value.file_name == "")
		{
			list += "<td onclick=DisplayFile('',"+ value.log_id +","+ value.type +")></td>";
		}
		else
		{
			list += "<td><span onclick=DisplayFile('"+ value.file_name +"',"+ value.log_id +","+ value.type +")>"+ value.file_name +"</span></td>";
		}
		list += "</tr>";
		c++;
	});
	DisplayFile(sortedData[0].file_name, sortedData[0].log_id, type);
	if(type == 1)
	{
		objNullaHis = objTemp;
	}
	else
	{
		objPassHis = objTemp;
	}
	return list;
}
function ShowDialog_Admin(detId)
{
	var reqId = 0, fullName = "", email = "", submitOn = "",vac = "", sts = "", pass = "", wpn = "", issueDt = "", comments = "", reasonId = 0;
	
	var tempDoc = objDocument.filter(d => d.dtlId == detId);
	if(tempDoc.length >0)
	{
		comments = tempDoc[0].remarks;
		if(comments == null)
		{
			comments = "";
		}
		reasonId = tempDoc[0].reason;
		if(reasonId == null)
		{
			reasonId = 0;
		}
	}
	if(comments != "")
	{
		$("#txtComment").val(comments);
	}
	if(reasonId > 0)
	{
		var list = "";
		$("#ddlReason").empty();
		list += "<option value='0'>---Select---</option>";
		var temp1 = objReason.filter((f) => f.type == 2);
		for (var j = 0; j < temp1.length; j++) {
			list += "<option value=" + temp1[j].id + ">" + temp1[j].reason_code + "</option>";
		}
		$("#ddlReason").append(list);
		$("#ddlReason").val(reasonId);
	}
	
	var temp = objDetails.filter(f => f.dtlId == detId);
	
	DetailsId = detId;
	if(temp.length > 0)
	{
		fullName = temp[0].fName + " " + temp[0].lName;
		pass = decrypt(EncryptionKey, temp[0].ppn);//temp[0].ppn;
		wpn = temp[0].wpn;
		issueDt = temp[0].wpndt;
	}
	reqId = objMaster[0].reqId;
	email = objMaster[0].mailId;
	
	var subDt = new Date(objMaster[0].submitOn);
	var y = subDt.getFullYear();
	var m = subDt.getMonth();
	var d = subDt.getDate().toString().padStart(2, '0');
	var hrs = subDt.getHours();
	var min = subDt.getMinutes();

	var submitOn = y +"-" + m + "-" + d +" " + hrs + ":" + min;
	var submitOnIST = ConvertIST(new Date(submitOn));	
	
	var tempVac = objVAC.filter(v => v.vac_id == objMaster[0].vac);
	if(tempVac.length >0)
	{
		vac = tempVac[0].vac_name;
	}
	
	var tempSts = objStatus.filter(f => f.request_status_id == objMaster[0].rStatus);
	if(tempSts.length >0)
	{
		sts = tempSts[0].request_status_name;
	}
	var reference_text = "Reference ID -"+reqId;
	$("#show_reference").html(reference_text);
	$("#spanReqId").html(reqId);
	$("#spanFullName").html(fullName);
	$("#spanEmail").html(email);
	$("#spanPassNo").html(pass);
	$("#spanWPN").html(wpn);
	$("#spanIssueDt").html(issueDt);
	$("#spanSubmitDt").html(submitOnIST);
	$("#spanVAC").html(vac);
	$("#spanSts").html(sts);
	ShowPassport();
	$("#myModal").modal('show');
    $("#divBtnVRB").hide();	
}
// Admin Cases
function LoadVAC()
{
	var list = "";
	$("#ddlVAC_Admin").empty();
	list += "<option value='0'>---Select VAC---</option>";
	for(var i=0;i<objVAC.length;i++)
	{
		list += "<option value='"+ objVAC[i].vac_id +"'>"+ objVAC[i].vac_name +"</option>";
	}
	$("#ddlVAC_Admin").append(list);
}
function LoadAdminList()
{
	if(objMaster == null)
	{
		$("#divList").empty();
		var list1 = "<table class='table'><tbody><tr><td style='text-align: center;'>---------- No Records -----------</td></tr></tbody></table>";
		$("#divList").append(list1);
		
		$("#divYesNo").hide();
		$("#btnVerdict").hide();
	}
	$("#btnVerdict").hide();
	$("#btnAssign").hide();
	$("#spanYes").show();
	$("#spanNo").show();
	
	if(objMaster != null)
	{
		$("#divYesNo").show();
		$("#btnVerdict").show();
	var list = "", k = 0, l = 0;
	$("#divList").empty();
	for(var i=0;i<objMaster.length;i++)
	{
		k = i+1;
		var vac = "";
		var tempVac = objVAC.filter(v => v.vac_id == objMaster[i].vac);
		if(tempVac.length >0)
		{
			vac = tempVac[0].vac_name;
		}
		var sts = "";
		var tempSts = objStatus.filter(f => f.request_status_id == objMaster[i].rStatus);
		if(tempSts.length >0)
		{
			sts = tempSts[0].request_status_name;
		}
		var reqId = objMaster[i].reqId;
		
		var addOnIST =  "";
		
		if(objMaster[0].addOn == null || objMaster[0].addOn == "0000-00-00 00:00:00.000000")
		{
			addOnIST = "";
		}
		else
		{		
			var addDt = new Date(objMaster[0].addOn);
			var y1 = addDt.getFullYear();
			var m1 = addDt.getMonth() + 1;
			var d1 = addDt.getDate().toString().padStart(2, '0');
			var hrs1 = addDt.getHours().toString().padStart(2, '0');
			var min1 = addDt.getMinutes().toString().padStart(2, '0');
			var addOn = y1 +"-" + m1 + "-" + d1 + " " + hrs1 + ":" + min1;
			console.log("addOn-",addOn);
			addOnIST = ConvertIST(new Date(addOn));
		}
		var submitOnIST = "";
		
		if(objMaster[0].submitOn == null || objMaster[0].submitOn == "0000-00-00 00:00:00.000000")
		{
			submitOnIST = "";
		}
		else
		{	
			
			var subDt = new Date(objMaster[0].submitOn);
			var y = subDt.getFullYear();
			var m = subDt.getMonth() + 1;//month[subDt.getMonth()];
			var d = subDt.getDate().toString().padStart(2, '0');
			var hrs = subDt.getHours().toString().padStart(2, '0');
			var min = subDt.getMinutes().toString().padStart(2, '0');
			//var submitOn = d +"/" + m + "/" + y + " " + hrs + ":" + min;
			var submitOn = y +"-" + m + "-" + d + " " + hrs + ":" + min;
			submitOnIST = ConvertIST(new Date(submitOn));
		}
		
	
		var temp = objDetails.filter(f => f.reqId == reqId);
		var len = temp.length;
				
		list += '<div class="table-responsive">';
		list += '<div class="table-responsive">';
		list += '<table class="table accordion table-responsive table-bordered text-left">';
        list += '<thead>';
		
		list += '<tr>';
		list += '<th scope="col">';
		list += '<div class="ver_flex">';
		list += '<span><input type="checkbox" id="yes_mas'+ reqId +'" name="verdictYes'+ reqId +'" value="" onchange="CheckAllYes_Master(1,'+ k +','+ reqId +')"> Yes</span>';
		list += '</div></th>';
		list += '<th scope="col">';
		
		list += '<div class="ver_flex">';
		list += '<span><input type="checkbox" id="no_mas'+ k +'" name="verdictNo'+ reqId+'" value="" onchange="CheckAllYes_Master(2,'+ k +','+ reqId +')"> No</span>';
		list += '</div></th>';
		list += '</th>';
		
		list += '<th scope="col" class="star_required2">Request ID :</th>';
		list += '<th scope="col" class="star_required2 w-60">'+ reqId +'</th>';
		list += '<th scope="col" class="star_required2">IP :</th>';
        list += '<th scope="col" class="star_required2 w-150">'+ objMaster[i].IP +'</th>';
		
		list += '<th scope="col" class="star_required2">Added On :</th>';
        list += '<th scope="col" class="star_required2">'+ addOnIST +'</th>';
        list += '<th scope="col" class="star_required2">Submited On :</th>';
        list += '<th scope="col" class="star_required2">'+ submitOnIST +'</th>';
        list += '<th scope="col" class="star_required2">No. Of Applicants :</th>';
        list += '<th scope="col" class="star_required2">'+ objMaster[i].noOfUsr +'</th>';
		list += '<th scope="col" class="star_required2">VAC :</th>';
        list += '<th scope="col" class="star_required2 wid-150" style="width: 150px !important;">'+ vac +'</th>';
        list += '<th scope="col" class="star_required2">Status :</th>';
        list += '<th scope="col" class="star_required2 wid-150" style="width: 150px !important;">'+ sts +'</th>';
		list += '<th data-bs-toggle="collapse" data-bs-target="#r'+ k +'" rowspan="'+ len +'"><i class="fa fa-chevron-down"></i></th>';
		list += "</tr>";
		
		list += '</thead></table></div>';
		
		
		
		list += '<table class="table accordion table-responsive table-bordered text-left collapse accordion-collapse p-2" id="r'+ k +'">';
			
		list += '<thead>';
        list += '<tr>';
		list += '<th scope="col">Verdict</th>';
        list += '<th scope="col">Full Name</th>';
        list += '<th scope="col">Email Id</th>';
        list += '<th scope="col">Passport Number</th>';
        list += '<th scope="col">Nulla osta No</th>';
		list += '<th scope="col">DOB</th>';
        list += '<th scope="col">Issue Date</th>';
        list += '<th scope="col">Submited On</th>';
		list += '<th scope="col">Approved On</th>';
		list += '<th scope="col">Approved By</th>';
        list += '<th scope="col">VAC</th>';
		list += '<th scope="col">Status</th>';
        list += '<th scope="col">Action</th>';
        list += '</tr>';
		list += '</thead>';
			
		list += '<tbody style="background:#fff;">';		
		for(var j = 0;j<temp.length;j++)
		{	
			l = j+1;
			var sts1 = "", verdictSts = 0, appBy = "";
			var tempSts1 = objStatus.filter(f => f.request_status_id == temp[j].dtlStatus);
			if(tempSts1.length >0)
			{
				sts1 = tempSts1[0].request_status_name;
			}
			var app_by = temp[j].aprovdBy;
			if(app_by == null)
			{
				app_by = 0;
			}
			if(app_by > 0)
			{
			var tempUsr = objUserList.filter(u => u.user_id == app_by);
			if(tempUsr.length >0)
			{
				appBy = tempUsr[0].full_name;
			}
			}
			
			verdictSts = temp[j].dtlStatus;
			var approvedOnIST = "";
			if(temp[j].approvOn == null || temp[j].approvOn == "0000-00-00 00:00:00.000000")
			{
				approvedOnIST = "";
			}
			else
			{
				var appDt = new Date(temp[j].approvOn);
				var y2 = appDt.getFullYear();
				var m2 = appDt.getMonth() + 1;
				var d2= appDt.getDate().toString().padStart(2, '0');
				var hrs2 = appDt.getHours().toString().padStart(2, '0');
				var min2 = appDt.getMinutes().toString().padStart(2, '0');
				var approvedOn = d2 +"-" + m2 + "-" + y2 + " " + hrs2 + ":" + min2;
				approvedOnIST = ConvertIST(new Date(approvedOn));
			}
			var issueDt = "";
			if(temp[j].wpndt == null)
			{
				issueDt = "";
			}
			else
			{
				var isDt = new Date(temp[j].wpndt);
				var y3 = isDt.getFullYear();
				var m3 = isDt.getMonth() + 1;
				var d3= isDt.getDate().toString().padStart(2, '0');
				issueDt = d3 +"/" + m3 + "/" + y3;
			}
			var dob = "";
			if(temp[j].dob == null)
			{
				dob = "";
			}
			else
			{
				var dob_dt = new Date(temp[j].dob);
				var y3 = dob_dt.getFullYear();
				var m3 = (dob_dt.getMonth() + 1).toString().padStart(2, '0');
				var d3 = dob_dt.getDate().toString().padStart(2, '0');
				dob = d3 +"/" + m3 + "/" + y3;
			}
			
			list += '<td>';
			list += '<div class="ver_flex">';			
			
			if(verdictSts == 8)
			{
				list += '<span>';
				list += '<input type="checkbox" id="verdict_app'+ temp[j].dtlId +'" name="verdictYesApp'+ reqId +'" value="'+ temp[j].dtlId +'" checked disabled> Yes';
				list += '</span>';
				
				list += '<span>';
				list += '<input type="checkbox" id="no_det_not'+ temp[j].dtlId +'" name="verdictNoNot'+ reqId +'" value="'+ temp[j].dtlId +'" disabled> No';
				list += '</span>';
			}
			else if(verdictSts == 10)
			{
				list += '<span>';
				list += '<input type="checkbox" id="yes_det_not'+ temp[j].dtlId +'" name="verdictYesNot'+ reqId +'" value="'+ temp[j].dtlId +'" disabled> Yes';
				list += '</span>';
				
				list += '<span>';
				list += '<input type="checkbox" id="verdict_rej'+ temp[j].dtlId +'" name="verdictNoRej'+ reqId +'" value="'+ temp[j].dtlId +'" checked disabled> No';
				list += '</span>';
			}
			else
			{
				list += '<span>';
				list += '<input type="checkbox" id="yes_det'+ temp[j].dtlId +'" name="verdictYes'+ reqId +'" value="'+ temp[j].dtlId +'" onchange="CheckYes_Details(1,'+ temp[j].dtlId +')"> Yes';
				list += '</span>';
				
				list += '<span>';
				list += '<input type="checkbox" id="no_det'+ temp[j].dtlId +'" name="verdictNo'+ reqId +'" value="'+ temp[j].dtlId +'" onchange="CheckYes_Details(2,'+ temp[j].dtlId +')"> No';
				list += '</span>';
			}
			var pNo = decrypt(EncryptionKey, temp[j].ppn);
			list += '</div>';
			list += '</td>';
			
			list += '<td>'+ temp[j].fName + ' ' + temp[j].lName +'</td>';
			list += '<td>'+ objMaster[i].mailId+'</td>';
			list += '<td>'+ pNo +'</td>';
			list += '<td>'+ temp[j].wpn +'</td>';
			list += '<td>'+ dob +'</td>';
			list += '<td>'+ issueDt +'</td>';
			list += '<td>'+ submitOnIST +'</td>';
			
			list += '<td>'+ approvedOnIST +'</td>';
			list += '<td>'+ appBy + '</td>';
			
			list += '<td>'+ vac+'</td>';
			list += '<td>'+ sts1 +'</td>';
			list += '<td><button type="button" class="btn btn-link" onClick="ShowDialog_Admin('+ temp[j].dtlId +')">View</button></td>'; 		
			list += '</tr>';
		}
		list += '</tbody>';			
		list += '</table>';
	}
	list += '</div>';
	
	$("#divList").append(list);
}
}
function FilterCase()
{
	$("#txtSearchStr_Admin").css('border-color', '#ccc');
	$("#ddlKeyword").css('border-color', '#ccc');
	$("#FromDate_Admin").css('border-color', '#ccc');
	$("#ToDate_Admin").css('border-color', '#ccc');	
	
	var searchStr = $("#txtSearchStr_Admin").val().trim();
	var type = $("#ddlKeyword").val();
	var fromDt = $("#FromDate_Admin").val();
	var toDt = $("#ToDate_Admin").val();
	var vId = $("#ddlVAC_Admin").val();
	var sts = $("#ddlStatus_Admin").val();
	var dtType = $("#ddlDateType_Admin").val();
	
	if(type > 0 && searchStr == "")
	{
		$("#txtSearchStr_Admin").css('border-color', 'red');
		$("#txtSearchStr_Admin").focus();
		return false;
	}
	if(searchStr != "" && type == 0)
	{
		$("#ddlKeyword").css('border-color', 'red');
		$("#ddlKeyword").focus();
		return false;
	}
	
	if(dtType > 0)
	{
		if(fromDt == "")
		{
			$("#FromDate_Admin").css('border-color', 'red');
			$("#FromDate_Admin").focus();
			return false;
		}
		if(toDt == "")
		{
			$("#ToDate_Admin").css('border-color', 'red');
			$("#ToDate_Admin").focus();
			return false;
		}
	}
	if(fromDt != "" && toDt != "")
	{
		if(dtType == 0)
		{
			$("#ddlDateType_Admin").css('border-color', 'red');
			$("#ddlDateType_Admin").focus();
			return false;
		}
	}
	if(type == 0 && dtType == 0 && vId == 0 && sts == 0)
	{
		alert("Select any filter option");
		return false;
	}
	var param = {
		session_id: SessionId,
		sessionToken: SessionToken,
		keyword: searchStr,
		keyType: type,
		dateType: dtType,
		vac: vId,
		status: sts,
		from: fromDt,
		to: toDt,
		startRecord: 1,
		rows: 1,
		priority: 0
	}
	var obj = JSON.stringify(param);
	console.log(obj);
	GetSearchCases(obj);
}
function CheckAllYes(flag)
{
	if(flag == 1)
	{
		if($("#yesAll").prop("checked") == true)
		{
			$('input[name="verdictYes"]').prop('checked', true);
			for(var i=0;i<objMaster.length;i++)
			{
				$('input[name="verdictYes'+ objMaster[i].reqId +'"]').prop('checked', true);
			}
			
			$('input[name="verdictNo"]').prop('checked', false);
			for(var i=0;i<objMaster.length;i++)
			{
				$('input[name="verdictNo'+ objMaster[i].reqId +'"]').prop('checked', false);
			}
		}
		else
		{
			$('input[name="verdictYes"]').prop('checked', false);
			for(var i=0;i<objMaster.length;i++)
			{
				$('input[name="verdictYes'+ objMaster[i].reqId +'"]').prop('checked', false);
			}
		}
	}
	else
	{
		if($("#noAll").prop("checked") == true)
		{
			$('input[name="verdictNo"]').prop('checked', true);
			for(var i=0;i<objMaster.length;i++)
			{
				$('input[name="verdictNo'+ objMaster[i].reqId +'"]').prop('checked', true);
			}
			
			$('input[name="verdictYes"]').prop('checked', false);
			for(var i=0;i<objMaster.length;i++)
			{
				$('input[name="verdictYes'+ objMaster[i].reqId +'"]').prop('checked', false);
			}
		}
		else
		{
			$('input[name="verdictNo"]').prop('checked', false);
			for(var i=0;i<objMaster.length;i++)
			{
				$('input[name="verdictNo'+ objMaster[i].reqId +'"]').prop('checked', false);
			}			
		}
	}
}
function CheckAllYes_Master(flag, k, reqId)
{
	if(flag == 1)
	{
		if($("#yes_mas"+reqId).prop("checked") == true)
		{
			$('input[name="verdictYes'+ reqId +'"]').prop('checked', true);
			
			$('input[name="verdictNo'+ reqId +'"]').prop('checked', false);
		}
		else
		{
			$('input[name="verdictYes'+ reqId +'"]').prop('checked', false);
		}
	}
	else
	{
		if($("#no_mas"+k).prop("checked") == true)
		{
			$('input[name="verdictNo'+ reqId +'"]').prop('checked', true);
			
			$('input[name="verdictYes'+ reqId +'"]').prop('checked', false);
		}
		else
		{
			$('input[name="verdictNo'+ reqId +'"]').prop('checked', false);
		}
	}
}
function CheckYes_Details(flag, detId)
{
	if(flag == 1)
	{
		if($("#yes_det"+detId).prop("checked") == true)
		{
			$("#yes_det"+detId).prop('checked', true);
			
			$("#no_det"+detId).prop('checked', false);
		}
		else
		{
			$("#yes_det"+detId).prop('checked', false);
		}
	}
	else
	{
		if($("#no_det"+detId).prop("checked") == true)
		{
			$("#no_det"+detId).prop('checked', true);
			
			$("#yes_det"+detId).prop('checked', false);
		}
		else
		{
			console.log("no_det=false");
			$("#no_det"+detId).prop('checked', false);
		}
	}
}
function LoadSearchList()
{
	$("#btnVerdict").show();
	$("#spanYes").hide();
	$("#spanNo").hide();
	if(objMaster == null)
	{
		$("#btnVerdict").hide();
		$("#divList").empty();
		var list1 = "<tr><td colspan='12' style='text-align: center;'>---------- No Records -----------</td></tr>";
		$("#divList").append(list1);
	}
	if(objMaster != null)
	{
	$("#btnVerdict").hide();
	$("#btnAssign").show();
	$("#spanYes").show();
	$("#spanNo").hide();
	
	var list = "", k = 0, l = 0;
	$("#divList").empty();
	for(var i=0;i<objMaster.length;i++)
	{
		k = i+1;
		var vac = "";
		var tempVac = objVAC.filter(v => v.vac_id == objMaster[i].vac);
		if(tempVac.length >0)
		{
			vac = tempVac[0].vac_name;
		}
		var sts = "";
		var tempSts = objStatus.filter(f => f.request_status_id == objMaster[i].rStatus);
		if(tempSts.length >0)
		{
			sts = tempSts[0].request_status_name;
		}
		var reqId = objMaster[i].reqId;
		var addDt = new Date(objMaster[0].addOn);
		var y1 = addDt.getFullYear();
		var m1 = addDt.getMonth() + 1;
		var d1 = addDt.getDate().toString().padStart(2, '0');
		var hrs1 = addDt.getHours().toString().padStart(2, '0');
		var min1 = addDt.getMinutes().toString().padStart(2, '0');
		var addOn = d1 +"/" + m1 + "/" + y1 + " " + hrs1 + ":" + min1;
		
						
		var subDt = new Date(objMaster[0].submitOn);
		var y = subDt.getFullYear();
		var m = subDt.getMonth() + 1;//month[subDt.getMonth()];
		var d = subDt.getDate().toString().padStart(2, '0');
		var hrs = subDt.getHours().toString().padStart(2, '0');
		var min = subDt.getMinutes().toString().padStart(2, '0');
		var submitOn = d +"/" + m + "/" + y + " " + hrs + ":" + min;
	
		var temp = objDetails.filter(f => f.reqId == reqId);
		var len = temp.length;
		
		list += '<div class="table-responsive">';
		list += '<div class="table-responsive">';
		list += '<table class="table accordion table-responsive table-bordered text-left">';
        list += '<thead>';
		
		list += '<tr>';
		list += '<th scope="col">';
		list += '<div class="ver_flex">';
		list += '<span><input type="checkbox" id="yes_mas'+ reqId +'" name="verdictYes'+ reqId +'" value="" onchange="CheckAllYes_Master(1,'+ k +','+ reqId +')"> Yes</span>';
		list += '</div></th>';
		
		list += '<th scope="col" class="star_required2">Request ID :</th>';
		list += '<th scope="col" class="star_required2 w-60">'+ reqId +'</th>';
		list += '<th scope="col" class="star_required2">IP :</th>';
        list += '<th scope="col" class="star_required2 w-150">'+ objMaster[i].IP +'</th>';
		
		list += '<th scope="col" class="star_required2">Added On :</th>';
        list += '<th scope="col" class="star_required2">'+ addOn +'</th>';
        list += '<th scope="col" class="star_required2">Submited On :</th>';
        list += '<th scope="col" class="star_required2">'+ submitOn +'</th>';
        list += '<th scope="col" class="star_required2">No. Of Applicants :</th>';
        list += '<th scope="col" class="star_required2">'+ objMaster[i].noOfUsr +'</th>';
		list += '<th scope="col" class="star_required2">VAC :</th>';
        list += '<th scope="col" class="star_required2 wid-150" style="width: 150px !important;">'+ vac +'</th>';
        list += '<th scope="col" class="star_required2">Status :</th>';
        list += '<th scope="col" class="star_required2 wid-150" style="width: 150px !important;">'+ sts +'</th>';
		list += '<th data-bs-toggle="collapse" data-bs-target="#r'+ k +'" rowspan="'+ len +'"><i class="fa fa-chevron-down"></i></th>';
		list += "</tr>";
		
		list += '</thead></table></div>';
		
		list += '<table class="table accordion table-responsive table-bordered text-left collapse accordion-collapse p-2" id="r'+ k +'">';
			
		list += '<thead>';
        list += '<tr>';
		list += '<th scope="col">Verdict</th>';
        list += '<th scope="col">Full Name</th>';
        list += '<th scope="col">Email Id</th>';
        list += '<th scope="col">Passport Number</th>';
        list += '<th scope="col">Nulla osta No</th>';
        list += '<th scope="col">Issue Date</th>';
        list += '<th scope="col">Submited On</th>';
        list += '<th scope="col">VAC</th>';
		list += '<th scope="col">Status</th>';
        list += '<th scope="col">Action</th>';
        list += '</tr>';
		list += '</thead>';
			
		list += '<tbody style="background:#fff;">';
		
		for(var j = 0;j<temp.length;j++)
		{	
			l = j+1;
			var sts1 = "";
			var tempSts1 = objStatus.filter(f => f.request_status_id == temp[j].dtlStatus);
			if(tempSts1.length >0)
			{
				sts1 = tempSts1[0].request_status_name;
			}
			var pNo = decrypt(EncryptionKey, temp[j].ppn);
			list += '<td>';
			list += '<div class="ver_flex">';
			list += '<span>';
			list += '<input type="checkbox" id="yes_det'+ temp[j].dtlId +'" name="verdictYes'+ reqId +'" value="'+ temp[j].dtlId +'" onchange="CheckYes_Details(1,'+ temp[j].dtlId +')"> Yes';
			list += '</span>';
			
			list += '</div>';
			list += '</td>';
			
			list += '<td>'+ temp[j].fName + ' ' + temp[j].lName +'</td>';
			list += '<td>'+ objMaster[i].mailId+'</td>';
			list += '<td>'+ pNo +'</td>';
			list += '<td>'+ temp[j].wpn +'</td>';
			list += '<td>'+ temp[j].wpndt +'</td>';
			list += '<td>'+ submitOn +'</td>';
			list += '<td>'+ vac+'</td>';
			list += '<td>'+ sts1 +'</td>';
			list += '<td><button type="button" class="btn btn-link" onClick="ShowDialog_Admin('+ temp[j].dtlId +')">View</button></td>'; 		
			list += '</tr>';
		}
		list += '</tbody>';			
		list += '</table>';	
	}
	list += '</div>';
	
	$("#divList").append(list);
	}
}
function SubmitVerdict()
{
	var arrDetailIds = [];
	for(var i=0;i<objMaster.length;i++)
	{
		var id = "yes_mas"+objMaster[i].reqId;
		
		if($("#"+id).prop("checked") == true)
		{
			var temp = objDetails.filter(f => f.reqId == objMaster[i].reqId);
			if(temp.length > 0)
			{
				for(var j=0;j<temp.length;j++)
				{
					var flag = 0;
					var yId = "yes_det" + temp[j].dtlId;
					var yesId = $("#"+yId).val();
					
					var nId = "no_det" + temp[j].dtlId;
					var noId = $("#"+nId).val();
					
					if($("#"+yId).prop("checked") == true)
					{
						//flag = 1;
						var params = {
							Id: temp[j].dtlId,
							sts: 1
						}
						arrDetailIds.push(params);
					}
					if($("#"+nId).prop("checked") == true)
					{
						//flag = 0;
						var params = {
							Id: temp[j].dtlId,
							sts: 0
						}
						arrDetailIds.push(params);
					}
					/*var params = {
						Id: temp[j].dtlId,
						sts: flag
					}
					arrDetailIds.push(params);*/
				}
			}
		}
		else
		{
			var tempDet = objDetails.filter(f => f.reqId == objMaster[i].reqId);
			if(tempDet.length > 0)
			{
				for(var j=0;j<tempDet.length;j++)
				{
					var flag = 2;
					var yId = "yes_det" + tempDet[j].dtlId;
					var yesId = $("#"+yId).val();
					
					var nId = "no_det" + tempDet[j].dtlId;
					var noId = $("#"+nId).val();
					
					if($("#"+yId).prop("checked") == true)
					{
						//flag = 1;
						var params = {
							Id: tempDet[j].dtlId,
							sts: 1
						}
						arrDetailIds.push(params);
					}
					if($("#"+nId).prop("checked") == true)
					{
						//flag = 0;
						var params = {
							Id: tempDet[j].dtlId,
							sts: 0
						}
						arrDetailIds.push(params);
					}
					/*var params = {
						Id: tempDet[j].dtlId,
						sts: flag
					}
					arrDetailIds.push(params);*/
				}
			}
		}
	}
	
	if(arrDetailIds.length > 0)
	{
		var obj = {
			session_id: SessionId,
			sessionToken: SessionToken,
			actionIds: arrDetailIds
		}
		var chkParam = JSON.stringify(obj);
		console.log(chkParam);
		UpdateVerdict(chkParam, 0);
	}
}
function AssignCases()
{
	var arrReqIDs = [];
	for(var i=0;i<objMaster.length;i++)
	{
		var id = "yes_mas"+objMaster[i].reqId;
		
		if($("#"+id).prop("checked") == true)
		{
			var params = {
				Id: objMaster[i].reqId
			}
			arrReqIDs.push(params);
		}
	}
	if(arrReqIDs.length > 0)
	{
		var obj = {
			session_id: SessionId,
			sessionToken: SessionToken,
			reqIds: arrReqIDs
		}
		var chkParam = JSON.stringify(obj);
		AssignMe(chkParam);
	}
}
// ---
function ShowLoading()
{
	var loader=	$('#loader');
	loader.show();	
}
function HideLoading()
{	
	var loader=	$('#loader');
	loader.hide();
}
function GetCurrentTime()
{
	const now = new Date();
	const year = now.getUTCFullYear();
	const month = now.getUTCMonth() + 1; 
	const day = now.getUTCDate();
	const hours = now.getUTCHours();
	const minutes = now.getUTCMinutes();
	const seconds = now.getUTCSeconds();
	var dt = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
	return dt;
}
//setInterval(PingServer(SessionId,SessionToken,LastActivity_Cases), 300000);
function performTask() {
    //console.log("Task executed at:", new Date());
	PingServer(SessionId,SessionToken,LastActivity_Cases);
}

setInterval(performTask, 3 * 60 * 1000);