function GetNewSession(userName)
{
	$("#btnValLog").attr('disabled', true);
	ShowLoading();
    var chkObj = { username: userName }
    var chkParameter =  JSON.stringify(chkObj);
	
    $.ajax({
        url: VisitorLoginURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			if(data.status == 1)
			{	
				SessionId = data.session_id;
				SessionToken = data.session_token;
				EncryptionKey = data.encryption_key;
				$("#txtUsername").attr('disabled', true);
				$("#txtPassword").attr('disabled', true);
				GetOTP();
			}
			else if(data.status == 2)
			{
				$("#btnValLog").attr('disabled', false);
				$("#txtUsername").val("");
				$("#txtPassword").val("");
				alert("Invalid User");
				HideLoading();
			}
        }
    });
}
function CheckLogin(name, pass, url)
{	
    var chkObj = { session_id: SessionId, session_token: SessionToken, username: name, password: pass }
    var chkParameter =  JSON.stringify(chkObj);
	console.log(chkParameter);
    $.ajax({
        url: url,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			HideLoading();
			if(data.status == 1)
			{	
				$("#isMsg").show();
				$("#divOTP").show();
				$("#divLogin").hide();
				$("#divValOTP").show();
				timerOn = true;
				startTimerOTP(300);
			}
			else if(data.status == 2)
			{
			  alert("Invalid Token");
			}
			else if(data.status == 3)
			{
			  alert("Invalid Credentials");
			}
			else if(data.status == 4)
			{
				$("#myModalConfirm").modal("show");
			}
			else if(data.status == 5)
			{
				alert("Max Attempt Reached ");
				location.reload();
			}
        }
    });
}
function ValidateOTP(otp)
{
	$("#btnValOTP").attr('disabled', true);
	ShowLoading();
    var chkObj = { session_id: SessionId, session_token: SessionToken, otp_number: otp}
    var chkParameter =  JSON.stringify(chkObj);
	console.log(chkParameter);
    $.ajax({
        url: ValidateOTPURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			$("#btnValOTP").attr('disabled', false);
			HideLoading();
			if(data.status == 1)
			{	
				timerOn = false;			
				$("#Globalsessionid").val(SessionId);	
				$("#Globalsessiontoken").val(SessionToken);
				document.forms["mainForm"].submit();	
			}
			else if(data.status == 2)
			{
			  alert("Invalid Token");
			  location.reload();
			}
			else if(data.status == 3)
			{
			  alert("Invalid OTP");
			  $("#txtOTP").val("");
			}
			else if(data.status == 5)
			{
				alert("Max Attempt Reached ");
				location.reload();
			}
			else if(data.status == 6)
			{
				alert("OTP Expired");
				location.reload();
			}
        }
    });
}
function GetCases(pri)
{	
	ShowLoading();
    var chkObj = { session_id: SessionId, sessionToken: SessionToken, priority: pri }
    var chkParameter =  JSON.stringify(chkObj);
	console.log(chkParameter);
    $.ajax({
        url: AgentCasesURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				CaseObj = data.master;
				if(CaseObj == null)
				{
					CaseObj = {};
				}
				LoadList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
			else
			{
				alert(msg);
			}
        }
    });
}
function GetCases_New(reqId)
{	
	//ShowLoading();
    SessionId = $("#Globalsessionid").val();
    SessionToken = $("#Globalsessiontoken").val();

    var chkObj = { session_id: SessionId, sessionToken: SessionToken, reqId: reqId }
    var chkParameter =  JSON.stringify(chkObj);
	console.log(chkParameter);
    $.ajax({
        url: AgentCaseListURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			//HideLoading1();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				LoadList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
			else
			{
				alert("");
			}
        }
    });
}
function UpdateDocument(chkParameter, reqId, DetailsId, docId, sts, rId, comments, type)
{
	LastActivity_Cases = GetCurrentTime();
	ShowLoading();
    $.ajax({
        url: UpdateDocumentURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{					
				//isCloseModel(reqId, DetailsId, docId, sts, rId, comments, type);
				$("#myModal").modal('hide');
				
				CheckStatus(reqId, DetailsId, docId, sts, rId, comments, type);
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function UpdateCaseDetails(chkParameter, reqId)
{
	LastActivity_Cases = GetCurrentTime();
	ShowLoading();
    $.ajax({
        url: UpdateCaseURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{					
				GetCases_New(reqId);
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function UpdateMasterDetails(chkParameter, reqId, pri)
{
	LastActivity_Cases = GetCurrentTime();
	ShowLoading();
    $.ajax({
        url: UpdateMasterURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{					
				GetCases(pri);
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function Logout()
{
	var chkObj = { Globalsessionid: SessionId, Globalsessiontoken: SessionToken, Globaluserid: UserId }
    var chkParameter =  JSON.stringify(chkObj);
	$.ajax({
        url: LogoutURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
        }
    });
}
function GetAdminCases(pri)
{	

	ShowLoading();
    var chkObj = { session_id: SessionId, sessionToken: SessionToken, priority: pri }
    var chkParameter =  JSON.stringify(chkObj);
	console.log(chkParameter);
    $.ajax({
        url: AdminCasesURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				LoadAdminList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function UpdateVerdict(chkParameter, pri)
{
	LastActivity_Cases = GetCurrentTime();
	ShowLoading();
    $.ajax({
        url: UpdateVerdictURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1 || data.status == 3)
			{	
				GetAdminCases(pri);
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function GetSearchCases(chkParameter)
{	
    LastActivity = GetCurrentTime();
	ShowLoading();
	$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: SearchCasesURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				TotalRows = data.totalRows;
				//setupPagination();
				setupPagination_Filter();
				LoadSearchList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function AssignMe(chkParameter)
{
	ShowLoading();
	$.ajax({
        url: AssignMeURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			HideLoading();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				LoadAdminList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function GetCaseList(chkParameter)
{	
	ShowLoading();
	$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: SearchCasesURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(data.status == 1)
			{	
				objMaster = data.master;
				objDetails = data.details;
				objDocument = data.documents;
				TotalRows = data.totalRows;
				setupPagination();
				LoadSearchList();
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function GetDetailsList(chkParameter, dId, reviewCount, sts, type)
{	
	ShowLoading();
	$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: DocDetailURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
			$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(data.status == 1)
			{	
				objCustomer = data.CustActivity;
				objUser = data.UsrActivity;
				LoadHistory(dId, reviewCount, sts, type);
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function GetSlotList(chkParameter)
{	
	ShowLoading();
	$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: bookSlotList,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (res) {
			console.log('res>>>>>>>',res.status);
			$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(res.status == 1)
			{	
				objMaster = res.data;
				LoadSlotList(objMaster);
			}
			else if(res.status == 2)
			{
                objMaster = [];
				LoadSlotList(objMaster);
				//window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}
function PingServer(sId, sTkn, dt)
{
	var chkObj = { session_id: sId, session_token: sTkn, activity_time: dt }
    var chkParameter =  JSON.stringify(chkObj);
	
	$.ajax({
        url: PingURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			console.log(data);
		}
	});
}
function CheckActivityTime()
{
	const date1 = new Date(LastActivity); 
	const now = new Date();
	const year = now.getUTCFullYear();
	const month = now.getUTCMonth() + 1; 
	const day = now.getUTCDate();
	const hours = now.getUTCHours();
	const minutes = now.getUTCMinutes();
	const seconds = now.getUTCSeconds();
	var dt = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;
    var date2 = new Date(dt);

	const diffInMilliseconds = date2 - date1;

	// Convert the difference to hours
	const diffInHours = diffInMilliseconds / (1000 * 60 * 60);

	console.log(diffInHours);

	if(diffInHours > 1)
	{
		alert("Session Expired !");
		Logout();
	}
}
function GetExcelRecords(chkParameter)
{	
    LastActivity = GetCurrentTime();
	ShowLoading();
	//$("#btnSearch").attr('disabled', true);
    $.ajax({
        url: SearchCasesURL,
        type: 'POST',
        data: chkParameter,
        dataType: 'json',
        crossDomain: true,
        async: false,
        jsonp: false,
        cache: false,
        timeout: 30000,
        headers: {"Content-Type": "text/plain"},
        beforeSend: function (xhr) {

            if (xhr.overrideMimeType) {
                xhr.overrideMimeType("application/json");
            }
        },
        success: function (data) {
			//$("#btnSearch").attr('disabled', false);
			HideLoading();
			if(data.status == 1)
			{			
				LoadExcelData(data.master,data.details);
			}
			else if(data.status == 2)
			{
				window.location.href = 'https://vfseu.mioot.com/forms/UAT/ITAIND/admin/';
			}
        }
    });
}