<?php
        //ini_set("display_errors",1);
	//include_once("requestHandlr.php");
	include_once("cryptojs-aes.php");
	include_once("../api/commonFns.php");
	require("../api/DBConnection.php");
	require("../api/DBQueries.php");
	require("../api/DBActions.php");
	
	$ReqBody = json_decode(file_get_contents("php://input"),true);
	$buildCon_list='';

	global $Globaluserid;
	global $Globalsessionid;
	global $Globalsessiontoken;
	global $RoleId;
	$error_msg='';
	$message="";
	
	$Globaluserid=isset($_POST["Globaluserid"])?(int)$_POST["Globaluserid"]:0;
	$Globalsessionid=isset($_POST["Globalsessionid"])?(int)$_POST["Globalsessionid"]:0;
	$Globalsessiontoken=isset($_POST["Globalsessiontoken"])? XSSFilter($_POST["Globalsessiontoken"]):0;
	$user_name=isset($_POST["user_name"])? XSSFilter($_POST["user_name"]):0;
	

	$returnArr=array();

	

	if((isset($ReqBody['username']))&&(isset($ReqBody['password']))&&(isset($ReqBody['p1']))&&(isset($ReqBody['p2']))&&(isset($ReqBody['p3'])))
	{
		if(isset($ReqBody['username'])) $username = trim(XSSFilter($ReqBody['username'])); else $username = '';
		if(isset($ReqBody['password'])) $password = trim(XSSFilter($ReqBody['password'])); else $password = '';
		if(isset($ReqBody['p2'])) $iv = trim(XSSFilter($ReqBody['p2'])); else $iv = '';
		if(isset($ReqBody['p1'])) $salt = trim(XSSFilter($ReqBody['p1'])); else $salt = '';
		if(isset($ReqBody['p3'])) $Etext = trim(XSSFilter($ReqBody['p3'])); else $Etext = '';

		if(isset($ReqBody['session_id'])) $session_id = (int)$ReqBody['session_id']; else $session_id = 0;
		if(isset($ReqBody['r_id'])) $r_id = (int)$ReqBody['r_id']; else $r_id = 0;
		
		if(isset($ReqBody['encryption_key'])) $encryption_key = trim(XSSFilter($ReqBody['encryption_key'])); else $encryption_key = '';
		$PASSWORD1 = $encryption_key;
		$flag=0;
		
		if($iv != '' && $salt != '' && $Etext != '' && $username != '' && $password != '')
		{
			$TmpPassword = cryptoJsAesDecryptV2($PASSWORD1, $iv,$salt,$Etext);
		}
		else
		{
			$returnArr["status"]=3;
			$returnArr["msg"]='Invalid Data';
			$flag=1;
			die (json_encode( $returnArr));
		}
		

		if(isset($TmpPassword)) $decryPassword = trim(XSSFilter($TmpPassword)); else $decryPassword = '';
				
		$myip=$_SERVER['REMOTE_ADDR'];			 
		$ipint = ip2long($myip);
		$Temp1 = DBLink();
		$user_id=0;
		$user_name="";
		$attempt_count=0;		

	
		$TempQry_checkloginattempt = "SELECT login_attempt,user_name,full_name,user_id,role_id FROM user_details WHERE user_name='$username' AND password='$decryPassword' AND user_status = 1 LIMIT 1;	";
		$TempResults_checkloginattempt = ExecuteReader($Temp1,$TempQry_checkloginattempt);

		// echo count($TempResults_checkloginattempt);
		// print_r($TempResults_checkloginattempt);exit;

		if (count($TempResults_checkloginattempt)==0)
		{
			$returnArr["status"]=3;
			$returnArr["msg"]='Invalid Username or Password';
			$flag=1;
			die (json_encode( $returnArr));
		}        

		for ($i = 0; $i < count($TempResults_checkloginattempt); $i++) {
			if(isset($TempResults_checkloginattempt[$i]['login_attempt'])) $attempt_count=(int)$TempResults_checkloginattempt[$i]['login_attempt']; else $attempt_count=0;
			if(isset($TempResults_checkloginattempt[$i]['user_id'])) $user_id=(int)$TempResults_checkloginattempt[$i]['user_id']; else $user_id=0;
			if(isset($TempResults_checkloginattempt[$i]['user_name'])) $user_name=$TempResults_checkloginattempt[$i]['user_name']; else $user_name="";
			if(isset($TempResults_checkloginattempt[$i]['role_id'])) $role_id=(int)$TempResults_checkloginattempt[$i]['role_id']; else $role_id=0;
			if(isset($TempResults_checkloginattempt[$i]['full_name'])) $full_name=(int)$TempResults_checkloginattempt[$i]['full_name']; else $full_name="";

		}

		if(count($TempResults_checkloginattempt)>0){
			$update_userid_qry1="UPDATE admin_sessions SET login_status=1,user_id='$user_id',role_id='$role_id' WHERE session_id=$session_id";
			$update_qry1 = ExcuteNonQuery($Temp1,$update_userid_qry1);

		}

		$query_exist = "SELECT * FROM admin_sessions WHERE user_id = '$user_id' AND login_status=1";
		$existing_Session = rtnRowCount($Temp1,$query_exist);		
		$result_exist = ExecuteReader($Temp1,$query_exist);
		
		if ($existing_Session > 0) {
			$logoutQry1="UPDATE admin_sessions SET login_status=2 WHERE user_id='$user_id' and session_id!='$session_id'";
			$TempResults12 = ExcuteNonQuery($Temp1,$logoutQry1);		  
		}

		$query1 = "SELECT * FROM admin_sessions WHERE user_id = '$user_id' AND session_id=$session_id AND login_status=1";
		$existingSession = rtnRowCount($Temp1,$query1);		
		$result_data = ExecuteReader($Temp1,$query1);
		
		// if ($existingSession > 0) {
		// 	  $returnArr["status"]=7;
		// 	  $returnArr["msg"]='';
		// 	  $flag=1;
		// }

		if(count($result_data)>0){
			$Globalsessionid = $session_id;
			$Globaluserid = $user_id;
			$Globalsessiontoken =$result_data[0]['session_token'];
			$role_id =$result_data[0]['role_id'];
		}		 
		$returnArr["status"]=1;
		$returnArr["session_id"]=$session_id;
		$returnArr["user_id"]=$user_id;
		$returnArr["user_name"]=$user_name;
		$returnArr["session_token"]=$Globalsessiontoken;
		$returnArr["full_name"]=$full_name;
		$returnArr["RoleId"]=$role_id;	
		
	}	
		echo json_encode($returnArr);	
?>
