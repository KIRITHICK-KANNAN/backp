<?php


ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
include_once("../api/commonFns.php");
require("../api/DBConnection.php");
require("../api/DBQueries.php");
require("../api/DBActions.php");


function GenerateSessToken()
	{
		$miootToken=md5(uniqid(rand(), TRUE));
		return $miootToken;
	}

function XSSFilter1($string1)
{ 

    $search = array("<", '>', '&lt;','&gt;','&#x3C;','&#x3E;',"'","&apos;","&#x27;");
    $replace = array('','','','','','','','','');
    
    return str_replace($search, $replace, $string1);
}

function getRealIpAddr1()
		{
			if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
			{
			  $ip=$_SERVER['HTTP_CLIENT_IP'];
			}
			elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
			{
			  $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
			}
			else
			{
			  $ip=$_SERVER['REMOTE_ADDR'];
			}
			return $ip;
		}


// Generate random CAPTCHA text
$ranStr = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 14);

$Temp1 = DBLink();

$SessToken=GenerateSessToken();

 $ipAdd=XSSFilter1(getRealIpAddr1());

$userId=0;

$login_status=0;

$roleId=0;

$initialInsert="INSERT INTO admin_sessions(session_token,login_time,ip_address,user_id,document_key,role_id,login_status)VALUES('$SessToken',NOW(),'$ipAdd','$userId','$ranStr',0,'$login_status')";
$session_id = insertIntoDB_GetId($Temp1,$initialInsert);



// Return JSON response
echo json_encode([
    'session_id' => $session_id
]);


?>
