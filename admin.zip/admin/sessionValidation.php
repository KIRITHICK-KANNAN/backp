<?php

include_once("../../api/commonFns.php");
require("../../api/requestHandlr.php");
require("../../api/DBConnection.php");
require("../../api/DBQueries.php");
require("../../api/DBActions.php");

$Dblink = DBLink();



$Globaluserid=isset($_POST["Globaluserid"])?(int)$_POST["Globaluserid"]:0;
$Globalsessionid=isset($_POST["Globalsessionid"])?(int)trim(XSSFilter($_POST["Globalsessionid"])):0;
$Globalsessiontoken=isset($_POST["Globalsessiontoken"])? trim(XSSFilter($_POST["Globalsessiontoken"])):0;
$user_name=isset($_POST["user_name"])? trim(XSSFilter($_POST["user_name"])):"";
$full_name=isset($_POST["full_name"])? trim(XSSFilter($_POST["full_name"])):"";
$user_name=isset($_POST["user_name"])? trim(XSSFilter($_POST["user_name"])):"";
//$RoleId=isset($_POST["RoleId"])? (int)$_POST["RoleId"]:0;
$RoleId=0;


$query_check_session = "SELECT s.role_id,s.user_id,a.full_name FROM admin_sessions s 
                        LEFT JOIN admin_users a ON s.user_id=a.user_id WHERE  s.session_token = '$Globalsessiontoken' AND s.session_id='$Globalsessionid' AND s.login_status=1";
$TempResult = ExecuteReader($Dblink, $query_check_session);

$count = rtnRowCount($Dblink,$query_check_session);
if(count($TempResult)>0){
    $RoleId=isset($TempResult[0]['role_id'])?$TempResult[0]['role_id']:0;
    $full_name=$TempResult[0]['full_name'];
    $user_name=$TempResult[0]['full_name'];
    $Globaluserid=$TempResult[0]['user_id'];
}

if($count===0){

    $logoutq="UPDATE admin_sessions SET login_status=2 WHERE  session_token = '$Globalsessiontoken' and session_id=$Globalsessionid";
    $TempResults12 = ExcuteNonQuery($Dblink,$logoutq);
    header("Location:https://vfseu.mioot.com/forms/UAT/ITAIND/admin/");
	exit;
}




?>
