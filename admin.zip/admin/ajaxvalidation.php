<?php

require("../api/DBConnection.php");
require("../api/DBQueries.php");
require("../api/DBActions.php");
//include("sessionValidation.php");

$requestBody = file_get_contents('php://input');
// Decode the JSON data
$data = json_decode($requestBody, true);
if (json_last_error() === JSON_ERROR_NONE) {

    $link=DBLink();
    // Access the data
    $globalUserId = $data['Globaluserid'] ?? null;
    $globalSessionId = $data['Globalsessionid'] ?? null;
    $globalSessionToken = $data['Globalsessiontoken'] ?? null;
    $roleId = $data['RoleId'] ?? null;
    $userName = $data['user_name'] ?? null;
    $fullName = $data['full_name'] ?? null;


    $returnArr = [];
    
    $check_Sessions = "SELECT * FROM admin_sessions WHERE login_status=1 AND user_id='$globalUserId' AND session_id='$globalSessionId' AND session_token='$globalSessionToken'";
	$res_session_count = rtnRowCount($link,$check_Sessions);

    if($res_session_count>0){

        $query1_vac = "SELECT us.encryption_key,d.user_name,d.full_name,us.user_id,us.role_id,us.session_id,us.session_token,us.document_key FROM admin_users d         
        left join  admin_sessions us on d.user_id=us.user_id WHERE us.login_status=1 AND us.user_id='$globalUserId' AND d.user_id='$globalUserId' AND us.session_id='$globalSessionId' LiMIT 1";
		$session_result = ExecuteReader($link,$query1_vac);

        $query1_vac = "SELECT v.vac_id,v.vac_name FROM vac_list v
                        LEFT JOIN vac_map vm on v.vac_id=vm.vac_id WHERE v.status=1 AND vm.user_id='$globalUserId' GROUP BY vm.vac_id";
		$vac_result = ExecuteReader($link,$query1_vac);

        $query_reason = "SELECT * FROM reason_code WHERE status=1";
		$reasoncode_result = ExecuteReader($link,$query_reason);

        $query1_masters = "SELECT * FROM master_status";
		$mstatus_result = ExecuteReader($link,$query1_masters);


        if($roleId>0){
            //$qry_userlist_role2 = "SELECT full_name,user_id FROM admin_users WHERE role_id='2' AND user_status='1'";
            $qry_userlist_role2 = "SELECT full_name,user_id FROM admin_users WHERE user_status='1'";
            $role2_result = ExecuteReader($link,$qry_userlist_role2);
        }

        $returnArr["Globalsessionid"]=$session_result[0]['session_id'];
        $returnArr["Globaluserid"]=$session_result[0]['user_id'];
        $returnArr["user_name"]=$session_result[0]['user_name'];
        $returnArr["session_token"]=$session_result[0]['session_token'];
        $returnArr["full_name"]=$session_result[0]['full_name'];
        $returnArr["RoleId"]=$session_result[0]['role_id'];
        $returnArr["document_key"]=$session_result[0]['document_key'];
        $returnArr["encryption_key"]=$session_result[0]['encryption_key'];
        $returnArr["vac_list"]=$vac_result;
        $returnArr["reasoncode_list"]=$reasoncode_result;
        $returnArr["master_status_list"]=$mstatus_result;
        $returnArr["user_list"]=$role2_result;
        $returnArr["status"]=1;
        $returnArr["msg"]="success";
    }else{
        $returnArr["status"]=2;
        $returnArr["msg"]="error";
    }

    
} 
// Return JSON response
header('Content-Type: application/json');
echo json_encode($returnArr);	


?>