<?php

    require("../api/DBConnection.php");
    require("../api/DBQueries.php");
    require("../api/DBActions.php");

    $link=DBLink();


    try{

            $sessionQry = "SELECT * FROM admin_sessions WHERE login_status = 1 and user_id>0";            
            $sessionUsers = ExecuteReader($link,$sessionQry);
            if (!empty($sessionUsers)) {
                $currentTime = new DateTime();
                foreach ($sessionUsers as $session) {
                    // echo "<pre>";
                    // print_r($session);

                    $user_id = $session['user_id'];
                    $session_id = $session['session_id'];

                    if (empty($session['last_ping'])) {
                        continue;
                    }

                    $lastPing = new DateTime($session['last_ping']);        
                    $interval = $lastPing->diff($currentTime);
                    $minutes = $interval->days * 24 * 60 + $interval->h * 60 + $interval->i;   
                         
                    if ($minutes > 15) {
                        $updateSql = "UPDATE admin_sessions SET login_status = 2 WHERE user_id ='$user_id' AND session_id='$session_id'";
                        $updatedone = ExcuteNonQuery($link,$updateSql);

                        $delete_qry = "DELETE FROM assigned_cases WHERE user_id ='$user_id'";
                        $delete_done = ExcuteNonQuery($link,$delete_qry);
                        
                    } else {
                        echo "User ID {$session['user_id']} is active. Last ping was {$minutes} minutes ago.<br>";
                    }
                }


                ///Last activity

                foreach ($sessionUsers as $session) {
                    // echo "<pre>";
                    // print_r($session);

                    $user_id = $session['user_id'];
                    $session_id = $session['session_id'];

                    if (empty($session['last_activity'])) {
                        continue;
                    }

                    $lastActivity = new DateTime($session['last_activity']);        
                    $interval_a = $lastActivity->diff($currentTime);
                    $minutes_a = $interval_a->days * 24 * 60 + $interval_a->h * 60 + $interval_a->i;   
                         
                    if ($minutes_a > 30) {
                        $updateSql = "UPDATE admin_sessions SET login_status = 2 WHERE user_id ='$user_id' AND session_id='$session_id'";
                        $updatedone = ExcuteNonQuery($link,$updateSql);

                        $delete_qry = "DELETE FROM assigned_cases WHERE user_id ='$user_id'";
                        $delete_done = ExcuteNonQuery($link,$delete_qry);
                        
                    } else {
                        echo "User ID {$session['user_id']} is active. Last ping was {$minutes_a} minutes ago.<br>";
                    }
                }

            } else {
                echo "No inactive users found.";
            }

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
   







?>