<?php
//echo ',212';
//$tempVar = "{\"ct\":\"0aFmItoRi+oOS8Lf1vuGSGbltAzvPqRTqzPnjqKstZkFyjYBjnvIc0ERFIxVHHld\",\"iv\":\"e4860a17457b2789cf7a8ce11895d011\",\"s\":\"4801fc1b2acee7f1\"}";

//$tempPhrase = "my secret passphrase";

//cryptoJsAesDecrypt($tempPhrase, $tempVar);
  
 
/**
* Helper library for CryptoJS AES encryption/decryption
* Allow you to use AES encryption on client side and server side vice versa
*
* @author BrainFooLong (bfldev.com)
* @link https://github.com/brainfoolong/cryptojs-aes-php
*/

/**
* Decrypt data from a CryptoJS json encoding string
*
* @param mixed $passphrase
* @param mixed $jsonString
* @return mixed
*/
function cryptoJsAesDecrypt($passphrase, $jsonString){
    $jsondata = json_decode($jsonString, true);
	//echo ',1:WHERE R U? <br/><br/>::' ;
	
	//echo ':26:'.$jsondata;
	
	
    try {
         
		 $salt = hex2bin($jsondata["s"]);
		 
        $iv  = hex2bin($jsondata["iv"]);
    } catch(Exception $e) {
		echo ',2:WHERE R U? <br/><br/>::' ;
		return null; 
		}
	//echo ':35:'.$salt;
	
    $ct = base64_decode($jsondata["ct"]);
    $concatedPassphrase = $passphrase.$salt;

    $md5 = array();
    $md5[0] = md5($concatedPassphrase, true);	
    $result = $md5[0];
    for ($i = 1; $i < 3; $i++) {
        $md5[$i] = md5($md5[$i - 1].$concatedPassphrase, true);
        $result .= $md5[$i];
    }
	
	 
   $key = substr($result, 0, 32);
	 

	//echo ':ct:'.$ct.',key:'.$key.',IV:'.$iv;
	 
    $data = openssl_decrypt($ct, 'aes-256-cbc', $key, true, $iv);
	
	//echo ',DATA:'.$data.'::'.json_decode($data, true).'##';
	
    return json_decode($data, true);
}

function cryptoJsAesDecryptV2($Apassphrase, $Aiv,$Asalt,$AText){
    
	//echo "cryptoJsAesDecryptV2,".$Apassphrase.",".$Aiv.",".$Asalt.",".$AText;
	
	//echo ':26:'.$jsondata;
	
	
    try {
         
		 $salt = hex2bin($Asalt);
		 
        $iv  = hex2bin($Aiv);
    } catch(Exception $e) {
		//echo ',2:WHERE R U? <br/><br/>::' ;
		return null; 
		}
	//echo ':35:'.$salt;
	
    $ct = base64_decode($AText);
    $concatedPassphrase = $Apassphrase.$salt;

    $md5 = array();
    $md5[0] = md5($concatedPassphrase, true);	
    $result = $md5[0];
    for ($i = 1; $i < 3; $i++) {
        $md5[$i] = md5($md5[$i - 1].$concatedPassphrase, true);
        $result .= $md5[$i];
    }
	
	 
   $key = substr($result, 0, 32);
	 

	//echo ':ct:'.$ct.',key:'.$key.',IV:'.$iv;
	 
    $data = openssl_decrypt($ct, 'aes-256-cbc', $key, true, $iv);
	
	//echo ',DATA:'.$data.'::'.json_decode($data, true).'##';
	
    return json_decode($data, true);
}


/**
* Encrypt value to a cryptojs compatiable json encoding string
*
* @param mixed $passphrase
* @param mixed $value
* @return string
*/
function cryptoJsAesEncrypt($passphrase, $value){
    $salt = openssl_random_pseudo_bytes(8);
    $salted = '';
    $dx = '';
    while (strlen($salted) < 48) {
        $dx = md5($dx.$passphrase.$salt, true);
        $salted .= $dx;
    }
    $key = substr($salted, 0, 32);
    $iv  = substr($salted, 32,16);
    $encrypted_data = openssl_encrypt(json_encode($value), 'aes-256-cbc', $key, true, $iv);
    $data = array("ct" => base64_encode($encrypted_data), "iv" => bin2hex($iv), "s" => bin2hex($salt));
    return json_encode($data);
}

function cryptoJsAesEncryptV2($Apassphrase, $Aiv,$Asalt,$AText){
   // echo "cryptoJsAesEncryptV2,".$Apassphrase.",".$Aiv.",".$Asalt.",".$AText;
	
	//echo ':26:'.$jsondata;
	
	
    try {
         
		 $salt = hex2bin($Asalt);
		 
        $iv  = hex2bin($Aiv);
    } catch(Exception $e) {
		echo ',2:WHERE R U? <br/><br/>::' ;
		return null; 
		}
	//echo ':35:'.$salt;
	
    $ct = base64_decode($AText);
    $concatedPassphrase = $Apassphrase.$salt;

    $md5 = array();
    $md5[0] = md5($concatedPassphrase, true);	
    $result = $md5[0];
    for ($i = 1; $i < 3; $i++) {
        $md5[$i] = md5($md5[$i - 1].$concatedPassphrase, true);
        $result .= $md5[$i];
    }
	
	 
   $key = substr($result, 0, 32);
	 

	//echo ':ct:'.$ct.',key:'.$key.',IV:'.$iv;
	 
    $data = openssl_encrypt($ct, 'aes-256-cbc', $key, true, $iv);
	echo ':26:'.$data;
	//echo ',DATA:'.$data.'::'.json_decode($data, true).'##';
	
    return json_decode($data, true);
}

