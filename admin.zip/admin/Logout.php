<?php	

	error_reporting(E_ALL);
	ini_set('display_errors', 0);
	include_once("../api/commonFns.php");
	require("../api/DBConnection.php");
	require("../api/DBQueries.php");
	require("../api/DBActions.php");
	
	if(isset($_POST["Globalsessionid"])) $sessid=(int)$_POST["Globalsessionid"]; else $sessid=0;
	if(isset($_POST["Globalsessiontoken"])) $sesstoken = trim(XSSFilter($_POST["Globalsessiontoken"])); else $sesstoken = '';
	if(isset($_POST["Globaluserid"])) $user_id=(int)$_POST["Globaluserid"]; else $user_id=0;
	
	try {
		if(!isset($_POST["Globaluserid"]))
		{
			header('Location: index.php');
			exit();	
		}
		
		$Temp1 = DBLink();
		$logoutQry="UPDATE admin_sessions SET login_status=2,last_ping=NOW() WHERE session_id='$sessid' AND session_token='$sesstoken'  LIMIT 1";
		$TempResults = ExcuteNonQuery($Temp1,$logoutQry);	
		$removeAssignedCases="DELETE FROM assigned_cases WHERE user_id='$user_id'";
		$remove_cases = ExcuteNonQuery($Temp1,$removeAssignedCases);
		header('Location: index.php');
		exit();
	} catch (Exception $e) {
		// error_log("Logout error: " . $e->getMessage());
		// echo "An error occurred during logout. Please try again later.";
		header('Location: index.php');
		exit();
	}

?>
