// src/hooks/useSessionPing.js
import { useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { sessionPing } from "../api/client";
import { useAuth } from "../context/AuthContext";

function fmt(dt = new Date()) {
  // "2025-8-12 9:49:32" (no zero-padding, matches your backend samples)
  const y = dt.getFullYear();
  const m = dt.getMonth() + 1;
  const d = dt.getDate();
  const h = dt.getHours();
  const mi = dt.getMinutes();
  const s = dt.getSeconds();
  return `${y}-${m}-${d} ${h}:${mi}:${s}`;
}

/**
 * Starts after login (i.e., when session exists). Pings every 5 min.
 * If lastActivity does not change for 30 min -> expire, logout, redirect.
 */
export function useSessionPing({
  pingEveryMs = 5 * 60 * 1000, // 5 minutes
  expireAfterMs = 30 * 60 * 1000, // 30 minutes
} = {}) {
  const { authData, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const lastActivityRef = useRef(Date.now());
  const intervalRef = useRef(null);

  // Any user action updates "activity time"
  useEffect(() => {
    if (!authData?.session_id || !authData?.session_token) return;

    const bump = () => {
      lastActivityRef.current = Date.now();
    };
    bump(); // count current entry as activity
    window.addEventListener("click", bump);
    window.addEventListener("keydown", bump);
    window.addEventListener("mousemove", bump);
    window.addEventListener("touchstart", bump);
    window.addEventListener("scroll", bump);

    return () => {
      window.removeEventListener("click", bump);
      window.removeEventListener("keydown", bump);
      window.removeEventListener("mousemove", bump);
      window.removeEventListener("touchstart", bump);
      window.removeEventListener("scroll", bump);
    };
  }, [authData?.session_id, authData?.session_token]);

  // Consider route change as activity as well
  useEffect(() => {
    if (!authData?.session_id || !authData?.session_token) return;
    lastActivityRef.current = Date.now();
  }, [location.pathname, authData?.session_id, authData?.session_token]);

  // Ping every 5 minutes; expire if inactivity ≥ 30 minutes
  useEffect(() => {
    if (!authData?.session_id || !authData?.session_token) return;

    const tick = async () => {
      const inactiveMs = Date.now() - lastActivityRef.current;

      // If inactive for 30+ minutes -> expire locally
      if (inactiveMs >= expireAfterMs) {
        alert("Session expired due to inactivity. Please login again.");
        logout();
        navigate("/", { replace: true });
        return;
      }

      // Send ping with the user's last activity time
      const activity_time = fmt(new Date(lastActivityRef.current));
      try {
        const res = await sessionPing({
          session_id: authData.session_id,
          session_token: authData.session_token,
          activity_time,
        });

        // If server signals expiry (e.g., status 4/2 in your PHP), handle it
        if (res?.status === 4 || res?.status === 2) {
          alert("Session expired. Please login again.");
          logout();
          navigate("/", { replace: true });
        }
      } catch {
        // network/server error: don’t crash app; next tick will retry
      }
    };

    // fire immediately once after login, then every 5 minutes
    tick();
    intervalRef.current = setInterval(tick, pingEveryMs);
    return () => clearInterval(intervalRef.current);
  }, [
    authData?.session_id,
    authData?.session_token,
    logout,
    navigate,
    pingEveryMs,
    expireAfterMs,
  ]);
}
