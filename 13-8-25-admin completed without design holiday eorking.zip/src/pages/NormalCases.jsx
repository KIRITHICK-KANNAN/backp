import React from "react";

export default function NormalCases() {
  return <div>NormalCases</div>;
}
