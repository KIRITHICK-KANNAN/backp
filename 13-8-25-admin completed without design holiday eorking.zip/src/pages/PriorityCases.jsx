import React from "react";
import AjaxValidation from "../hooks/AjaxValidation";
export default function PriorityCases() {
  return (
    <AjaxValidation>
      <div>PriorityCases</div>
    </AjaxValidation>
  );
}
