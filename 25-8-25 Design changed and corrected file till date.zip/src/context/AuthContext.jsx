// src/context/AuthContext.jsx
import {
  createContext,
  useContext,
  useState,
  useMemo,
  useCallback,
} from "react";

const AuthCtx = createContext();

const initial = {
  session_id: "",
  session_token: "",
  user: null,
  role_id: null,
  document_key: null,
  encryption_key: null,
  ajaxPayload: null, // <- will be filled by page-level AjaxValidation
};

export function AuthProvider({ children }) {
  const [authData, setAuthData] = useState(initial);

  // login: ONLY basic session info (no ajaxPayload here)
  const login = useCallback((payload) => {
    setAuthData({
      session_id: payload.session_id || "",
      session_token: payload.session_token || "",
      user: payload.user || null,
      role_id: payload.role_id ?? null,
      document_key: payload.document_key ?? null,
      encryption_key: payload.encryption_key ?? null,
      ajaxPayload: null, // <- explicitly empty after login
    });
  }, []);

  // patch/merge: used by page-level AjaxValidation to add ajaxPayload
  const patchAuth = useCallback((updates) => {
    setAuthData((prev) => ({ ...prev, ...updates }));
  }, []);

  const logout = useCallback(() => setAuthData(initial), []);

  const value = useMemo(
    () => ({ authData, login, patchAuth, logout }),
    [authData, login, patchAuth, logout]
  );

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export const useAuth = () => useContext(AuthCtx);
