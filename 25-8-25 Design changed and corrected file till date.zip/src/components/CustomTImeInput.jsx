// // components/CustomTimeInput.jsx
// import React from "react";
// import { BsClock } from "react-icons/bs";

// const CustomTimeInput = React.forwardRef(({ value, onClick }, ref) => (
//   <div
//     onClick={onClick}
//     ref={ref}
//     style={{
//       display: "flex",
//       alignItems: "center",
//       border: "1px solid #dee2e6",
//       padding: "6px 12px",
//       fontSize: "0.75rem",
//       borderRadius: "6px",
//       width: "100%",
//       cursor: "pointer",
//       backgroundColor: "#fff",
//       justifyContent: "space-between",
//     }}
//   >
//     {" "}
//     <span style={{ marginRight: 8 }}>{value || "Select Time"}</span>{" "}
//     <BsClock color="#555" />{" "}
//   </div>
// ));
// export default CustomTimeInput;

// components/CustomTimeInput.jsx
import React from "react";
import { BsClock } from "react-icons/bs";

const CustomTimeInput = React.forwardRef(function CustomTimeInput(props, ref) {
  const {
    value,
    onClick,
    className = "",
    style = {},
    placeholder = "Select Time",
    ...rest
  } = props;

  // If react-datepicker applied "is-invalid", force border red
  const isInvalid = className.includes("is-invalid");
  const mergedStyle = {
    display: "flex",
    alignItems: "center",
    border: "1px solid #dee2e6",
    padding: "6px 12px",
    fontSize: "0.75rem",
    borderRadius: "6px",
    width: "100%",
    cursor: "pointer",
    backgroundColor: "#fff",
    justifyContent: "space-between",
    ...(isInvalid ? { borderColor: "#dc3545" } : null),
    ...style,
  };

  return (
    <div
      onClick={onClick}
      ref={ref}
      className={className} // keep bootstrap classes like is-invalid
      style={mergedStyle} // allow external inline styles
      tabIndex={0} // make focusable
      aria-invalid={isInvalid || undefined}
      {...rest}
    >
      <span style={{ marginRight: 8 }}>{value || placeholder}</span>
      <BsClock color="#555" />
    </div>
  );
});

export default CustomTimeInput;
