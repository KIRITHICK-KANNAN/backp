import api from "./axios";

// Basic login (not used in this flow, kept for completeness)
export const login = async (username, password) => {
  const res = await api.post("api/Login/", { username, password });
  return res.data;
};

// ✅ SessionValidation API (used on /validate page)
export const validateSession = async (session_id, session_token) => {
  const res = await api.post("api/SessionValidation/", {
    session_id,
    session_token, // <-- OTP goes here
  });
  return res.data;
};
