import React, { useState } from "react";
import { Modal, Button, Form, InputGroup } from "react-bootstrap";
import { FaEye, FaEyeSlash } from "react-icons/fa";

const ProfileModal = ({ show, onHide, onUpdatePassword }) => {
  const [form, setForm] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [showPassword, setShowPassword] = useState({
    old: false,
    new: false,
    confirm: false,
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setForm((prev) => ({ ...prev, [id]: value }));
  };

  const toggleVisibility = (field) => {
    setShowPassword((prev) => ({ ...prev, [field]: !prev[field] }));
  };

  const handleSubmit = () => {
    if (!form.oldPassword || !form.newPassword || !form.confirmPassword) {
      alert("All fields are required.");
      return;
    }
    if (form.newPassword !== form.confirmPassword) {
      alert("New and Confirm Passwords do not match.");
      return;
    }

    onUpdatePassword(form); // Pass back to parent for API call
    setForm({ oldPassword: "", newPassword: "", confirmPassword: "" });
    onHide();
  };

  return (
    <Modal
      show={show}
      onHide={onHide}
      centered
      backdrop="static"
      keyboard={false}
    >
      <Modal.Header closeButton>
        <Modal.Title>
          <h6>Update Password</h6>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          {/* Old Password */}
          <Form.Group className="mb-2" controlId="oldPassword">
            <Form.Label>Old Password</Form.Label>
            <InputGroup>
              <Form.Control
                type={showPassword.old ? "text" : "password"}
                placeholder="Enter old password"
                value={form.oldPassword}
                onChange={handleChange}
              />
              <InputGroup.Text
                onClick={() => toggleVisibility("old")}
                style={{ cursor: "pointer" }}
              >
                {showPassword.old ? <FaEye /> : <FaEyeSlash />}
              </InputGroup.Text>
            </InputGroup>
          </Form.Group>

          {/* New Password */}
          <Form.Group className="mb-2" controlId="newPassword">
            <Form.Label>New Password</Form.Label>
            <InputGroup>
              <Form.Control
                type={showPassword.new ? "text" : "password"}
                placeholder="Enter new password"
                value={form.newPassword}
                onChange={handleChange}
              />
              <InputGroup.Text
                onClick={() => toggleVisibility("new")}
                style={{ cursor: "pointer" }}
              >
                {showPassword.new ? <FaEye /> : <FaEyeSlash />}
              </InputGroup.Text>
            </InputGroup>
          </Form.Group>

          {/* Confirm Password */}
          <Form.Group className="mb-2" controlId="confirmPassword">
            <Form.Label>Confirm Password</Form.Label>
            <InputGroup>
              <Form.Control
                type={showPassword.confirm ? "text" : "password"}
                placeholder="Confirm new password"
                value={form.confirmPassword}
                onChange={handleChange}
              />
              <InputGroup.Text
                onClick={() => toggleVisibility("confirm")}
                style={{ cursor: "pointer" }}
              >
                {showPassword.confirm ? <FaEye /> : <FaEyeSlash />}
              </InputGroup.Text>
            </InputGroup>
          </Form.Group>

          <Button className="w-100 btn login-btn" onClick={handleSubmit}>
            Update Password
          </Button>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default ProfileModal;
