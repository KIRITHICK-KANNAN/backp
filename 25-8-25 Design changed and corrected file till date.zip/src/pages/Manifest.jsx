// import React from "react";
// import { fetchManifest, exportManifestExcel } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import AjaxValidation from "../hooks/AjaxValidation";
// import excel from "../assets/excel.png";
// import * as XLSX from "xlsx";

// /* helpers */
// function toYMD(date) {
//   const d = new Date(date);
//   if (Number.isNaN(d.getTime())) return "";
//   return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(
//     2,
//     "0"
//   )}-${String(d.getDate()).padStart(2, "0")}`;
// }
// function safe(v) {
//   if (v === null || v === undefined || v === "" || v === "null") return "-";
//   return v;
// }

// export default function Manifest() {
//   const { authData } = useAuth();

//   // Filters
//   const [vac, setVac] = React.useState("0");
//   // If you want “Normal” preselected (like your screenshot), start with "0".
//   // If you want it blank initially, set to "" instead.
//   const [priority, setPriority] = React.useState("");
//   const [from, setFrom] = React.useState(() => toYMD(new Date())); // today
//   const [to, setTo] = React.useState(() => toYMD(new Date())); // today

//   // Data/UI
//   const [rows, setRows] = React.useState([]);
//   const [loading, setLoading] = React.useState(false);
//   const [error, setError] = React.useState("");

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const user_id = authData?.user_id ?? authData?.userid ?? authData?.id ?? "";
//   const session_id = authData?.session_id || "";
//   const session_token = authData?.session_token || "";
//   // const sessionReady = Boolean(user_id && session_id && session_token);

//   async function handleSearch() {
//     // No alerts, no button gating — just try the call.

//     setLoading(true);
//     setError("");
//     try {
//       const data = await fetchManifest({
//         user_id,
//         session_id,
//         session_token,
//         vac_id: vac || "0",
//         // Pass whatever is chosen; if you want blank allowed, keep as is.
//         priority, // "" | "0" | "1"
//         from_date: from || "", // allow empty if you want
//         to_date: to || "",
//         type: 1,
//         startRecord: 1,
//         rows: 1,
//         project: "ITAIND",
//       });
//       setRows(Array.isArray(data) ? data : []);
//     } catch (e) {
//       setRows([]);
//       setError(e.message || "Failed to fetch manifest.");
//     } finally {
//       setLoading(false);
//     }
//   }

//   // Optional: auto-load on session ready with the defaults above
//   // React.useEffect(() => {
//   //   if (sessionReady) handleSearch();
//   //   // eslint-disable-next-line react-hooks/exhaustive-deps
//   // }, [sessionReady]);

//   const renderCell = (v) => <td>{safe(v)}</td>;

//   return (
//     <AjaxValidation>
//       <div className="container-fluid py-3">
//         <h4 className="mb-3">Manifest</h4>

//         {/* Filters row */}
//         <div
//           className="d-flex gap-2 align-items-center flex-wrap p-2 mb-3"
//           style={{ background: "#ECEFF3", borderRadius: 8 }}
//         >
//           <select
//             className="form-control"
//             style={{ maxWidth: 320 }}
//             value={vac}
//             onChange={(e) => setVac(e.target.value)}
//           >
//             <option value="0">---Select VAC---</option>
//             {vacOptions.map((v) => (
//               <option key={v.vac_id} value={v.vac_id}>
//                 {v.vac_name}
//               </option>
//             ))}
//           </select>

//           <select
//             className="form-control"
//             style={{ maxWidth: 320 }}
//             value={priority}
//             onChange={(e) => setPriority(e.target.value)}
//           >
//             <option value="">---Select Priority---</option>
//             <option value="0">Normal</option>
//             <option value="1">Priority</option>
//           </select>

//           <input
//             type="date"
//             className="form-control"
//             style={{ maxWidth: 220 }}
//             value={from}
//             onChange={(e) => setFrom(e.target.value)}
//           />
//           <input
//             type="date"
//             className="form-control"
//             style={{ maxWidth: 220 }}
//             value={to}
//             onChange={(e) => setTo(e.target.value)}
//           />

//           {/* Always enabled; only disabled while loading */}
//           <button
//             className="btn text-white"
//             style={{ backgroundColor: "#f26722", minWidth: 110 }}
//             onClick={handleSearch}
//             disabled={loading}
//           >
//             {loading ? "Search" : "Search"}
//           </button>

//           <img
//             src={excel}
//             alt="Excel"
//             style={{ width: "32px", cursor: "pointer" }}
//             onClick={() => exportManifestExcel(rows)}
//             title="Export current table to Excel"
//             disabled={!rows.length}
//           />
//         </div>

//         {/* Table */}
//         <div
//           className="table-responsive"
//           style={{ maxHeight: "60vh", overflowY: "auto" }}
//         >
//           <table className="table table-hover" id="grid-table">
//             <thead
//               style={{
//                 position: "sticky",
//                 top: 0,
//                 background: "#f2f2f2",
//                 zIndex: 1,
//               }}
//             >
//               <tr>
//                 <th>Request ID</th>
//                 <th>Child Reference No</th>
//                 <th>Added On</th>
//                 <th>Submitted On</th>
//                 <th>Full Name</th>
//                 <th>Email Id</th>
//                 <th>Passport Number</th>
//                 <th>Nulla osta No</th>
//                 <th>Issue Date</th>
//                 <th>VAC</th>
//                 <th>Amount</th>
//                 <th>Tracking ID</th>
//                 <th>Payment Reference No</th>
//                 <th>Slot Type</th>
//                 <th>Slot Date</th>
//                 <th>Slot Time</th>
//               </tr>
//             </thead>
//             <tbody>
//               {loading ? (
//                 <tr>
//                   <td colSpan={16} className="text-center py-4">
//                     Loading...
//                   </td>
//                 </tr>
//               ) : error ? (
//                 <tr>
//                   <td colSpan={16} className="text-danger">
//                     {error}
//                   </td>
//                 </tr>
//               ) : !rows.length ? (
//                 <tr>
//                   <td colSpan={16} className="text-muted text-center py-4">
//                     No records found.
//                   </td>
//                 </tr>
//               ) : (
//                 rows.map((r, idx) => {
//                   const pri =
//                     r.priority === 1 || String(r.priority) === "1"
//                       ? "Priority"
//                       : "Normal";
//                   return (
//                     <tr key={idx}>
//                       {renderCell(r.request_id ?? r.reqId ?? r.req_id)}
//                       {renderCell(r.child_id ?? r.child_no)}
//                       {renderCell(r.added_on ?? r.addOn ?? r.addedOn)}
//                       {renderCell(r.submitted_on ?? r.submitOn)}
//                       {renderCell(
//                         r.full_name ??
//                           [r.first_name, r.last_name].filter(Boolean).join(" ")
//                       )}
//                       {renderCell(r.email_id ?? r.email)}
//                       {renderCell(r.passport_number ?? r.passport_no ?? r.ppn)}
//                       {renderCell(
//                         r.work_permit_number ??
//                           r.null_osta_no ??
//                           r.wpn ??
//                           r.nulla
//                       )}
//                       {renderCell(r.work_permit_issue_date)}
//                       {renderCell(r.vac_name ?? r.vac)}
//                       {renderCell(r.total_amount)}
//                       {renderCell(r.tracking_id)}
//                       {renderCell(r.bank_ref_no)}
//                       {renderCell(pri)}
//                       {renderCell(r.slot_date)}
//                       {renderCell(r.slot_time)}
//                     </tr>
//                   );
//                 })
//               )}
//             </tbody>
//           </table>
//         </div>
//       </div>
//     </AjaxValidation>
//   );
// }
import React from "react";
import { fetchManifest, exportManifestExcel } from "../api/client";
import { useAuth } from "../context/AuthContext";
import AjaxValidation from "../hooks/AjaxValidation";
import excel from "../assets/excel.png";

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { BsCalendar2Check } from "react-icons/bs";

/* ================= helpers ================= */
function safe(v) {
  if (v === null || v === undefined || v === "" || v === "null") return "-";
  return v;
}
function toYMDFromDate(d) {
  if (!(d instanceof Date) || Number.isNaN(d.getTime())) return "";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}
function getReqId(r) {
  return r.request_id ?? r.reqId ?? r.req_id ?? "";
}
function getChildId(r) {
  return r.child_id ?? r.child_no ?? r.child_reference_no ?? "";
}
function numOrInf(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : Number.POSITIVE_INFINITY;
}
/** Keep request groups in original API order, but sort child_id ascending inside each request. */
function sortByReqThenChild(rows) {
  if (!Array.isArray(rows) || rows.length === 0) return [];
  const firstIdxForReq = new Map();
  rows.forEach((r, i) => {
    const k = String(getReqId(r));
    if (!firstIdxForReq.has(k)) firstIdxForReq.set(k, i);
  });
  return [...rows].sort((a, b) => {
    const ra = String(getReqId(a));
    const rb = String(getReqId(b));
    const ga = firstIdxForReq.get(ra);
    const gb = firstIdxForReq.get(rb);
    if (ga !== gb) return ga - gb; // keep group order
    const ca = numOrInf(getChildId(a));
    const cb = numOrInf(getChildId(b));
    if (ca !== cb) return ca - cb; // sort children
    return 0;
  });
}

/* ================= page ================= */
export default function Manifest() {
  const { authData } = useAuth();

  // Filters
  const [vac, setVac] = React.useState("0");
  const [priority, setPriority] = React.useState(""); // ❗ mandatory
  const [fromDate, setFromDate] = React.useState(() => new Date()); // today
  const [toDate, setToDate] = React.useState(() => new Date()); // today

  // Data/UI
  const [rows, setRows] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const user_id = authData?.user_id ?? authData?.userid ?? authData?.id ?? "";
  const session_id = authData?.session_id || "";
  const session_token = authData?.session_token || "";

  const minDate = React.useMemo(() => new Date(2000, 0, 1), []);
  const maxDate = React.useMemo(() => new Date(2099, 11, 31), []);

  // datepicker refs (open via icon)
  const fromRef = React.useRef(null);
  const toRef = React.useRef(null);

  async function handleSearch() {
    if (!priority) {
      alert("Please select Priority");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const data = await fetchManifest({
        user_id,
        session_id,
        session_token,
        vac_id: vac || "0",
        priority, // "0" Normal | "1" Priority
        from_date: toYMDFromDate(fromDate),
        to_date: toYMDFromDate(toDate),
        type: 1,
        startRecord: 1,
        rows: 1,
        project: "ITAIND",
      });
      setRows(Array.isArray(data) ? data : []);
    } catch (e) {
      setRows([]);
      setError(e.message || "Failed to fetch manifest.");
    } finally {
      setLoading(false);
    }
  }

  const sortedRows = React.useMemo(() => sortByReqThenChild(rows), [rows]);
  const renderCell = (v) => <td>{safe(v)}</td>;

  return (
    <AjaxValidation>
      <div className="container-fluid py-3">
        <h6 className="m-0 p-0">Manifest</h6>

        {/* Filters */}
        <div class="row mt-2">
          <div class="col-sm-12">
            <div className="box_card">
              <div className="form-group row">
                <div className="col-sm-12">
                  <div className="main_agent_form">
                    <div className="one">
                      <select
                        className="form-control"
                        value={vac}
                        onChange={(e) => setVac(e.target.value)}
                      >
                        <option value="0">---Select VAC---</option>
                        {vacOptions.map((v) => (
                          <option key={v.vac_id} value={v.vac_id}>
                            {v.vac_name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="one">
                      <select
                        className="form-control"
                        value={priority}
                        onChange={(e) => setPriority(e.target.value)}
                      >
                        <option value="">---Select Priority---</option>
                        <option value="0">Normal</option>
                        <option value="1">Priority</option>
                      </select>
                    </div>

                    {/* From date */}
                    <div className="one">
                      <div
                        className="input-group date_pick"
                        style={{ flexWrap: "nowrap" }}
                      >
                        <DatePicker
                          ref={fromRef}
                          selected={fromDate}
                          onChange={(d) => setFromDate(d)}
                          className="form-control border_right_radius"
                          placeholderText="From Date"
                          dateFormat="dd-MM-yyyy"
                          minDate={minDate}
                          maxDate={maxDate}
                          popperPlacement="bottom-start"
                          popperClassName="z-2000" // ensure above sticky header
                        />
                        <span
                          className="input-group-text"
                          role="button"
                          style={{ cursor: "pointer" }}
                          onClick={() => fromRef.current?.setOpen(true)}
                        >
                          <BsCalendar2Check />
                        </span>
                      </div>
                    </div>

                    {/* To date */}
                    <div className="one">
                      <div
                        className="input-group date_pick"
                        style={{ flexWrap: "nowrap" }}
                      >
                        <DatePicker
                          ref={toRef}
                          selected={toDate}
                          onChange={(d) => setToDate(d)}
                          className="form-control border_right_radius"
                          placeholderText="To Date"
                          dateFormat="dd-MM-yyyy"
                          minDate={minDate}
                          maxDate={maxDate}
                          popperPlacement="bottom-start"
                          popperClassName="z-2000"
                        />
                        <span
                          className="input-group-text date_picker"
                          role="button"
                          style={{ cursor: "pointer" }}
                          onClick={() => toRef.current?.setOpen(true)}
                        >
                          <BsCalendar2Check />
                        </span>
                      </div>
                    </div>

                    <div
                      className="one gap-2"
                      style={{ color: "red", textAlign: "center" }}
                    >
                      <button
                        className="btn-lg go-btn"
                        style={{ backgroundColor: "#f26722" }}
                        onClick={handleSearch}
                        disabled={loading}
                      >
                        {loading ? "Search" : "Search"}
                      </button>

                      {/* Excel always visible/clickable */}
                      <img
                        src={excel}
                        alt="Excel"
                        style={{ width: 25, cursor: "pointer" }}
                        onClick={() => exportManifestExcel(sortedRows)}
                        title="Export current table to Excel"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div class="dropdown-divider"></div>
              <div
                className="table-responsive"
                style={{ maxHeight: "60vh", overflowY: "auto" }}
              >
                <table className="table table-bordered mb-0" id="grid-table">
                  <thead
                    className="table-light"
                    style={{
                      position: "sticky",
                      top: 0,
                      background: "#f2f2f2",
                      zIndex: 1,
                    }}
                  >
                    <tr>
                      <th>Request ID</th>
                      <th>Child Reference No</th>
                      <th>Added On</th>
                      <th>Submitted On</th>
                      <th>Full Name</th>
                      <th>Email Id</th>
                      <th>Passport Number</th>
                      <th>Nulla osta No</th>
                      <th>Issue Date</th>
                      <th>VAC</th>
                      <th>Amount</th>
                      <th>Tracking ID</th>
                      <th>Payment Reference No</th>
                      <th>Slot Type</th>
                      <th>Slot Date</th>
                      <th>Slot Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {error ? (
                      <tr>
                        <td colSpan={16} className="text-danger">
                          {error}
                        </td>
                      </tr>
                    ) : !sortedRows.length ? (
                      <tr>
                        <td colSpan={16} className="text-muted text-center">
                          No records found.
                        </td>
                      </tr>
                    ) : (
                      sortedRows.map((r, idx) => {
                        const pri =
                          r.priority === 1 || String(r.priority) === "1"
                            ? "Priority"
                            : "Normal";
                        return (
                          <tr key={`${getReqId(r)}-${getChildId(r)}-${idx}`}>
                            {renderCell(getReqId(r))}
                            {renderCell(getChildId(r))}
                            {renderCell(r.added_on ?? r.addOn ?? r.addedOn)}
                            {renderCell(r.submitted_on ?? r.submitOn)}
                            {renderCell(
                              r.full_name ??
                                [r.first_name, r.last_name]
                                  .filter(Boolean)
                                  .join(" ")
                            )}
                            {renderCell(r.email_id ?? r.email)}
                            {renderCell(
                              r.passport_number ?? r.passport_no ?? r.ppn
                            )}
                            {renderCell(
                              r.work_permit_number ??
                                r.null_osta_no ??
                                r.wpn ??
                                r.nulla
                            )}
                            {renderCell(
                              r.work_permit_issue_date ?? r.issue_date
                            )}
                            {renderCell(r.vac_name ?? r.vac)}
                            {renderCell(r.total_amount ?? r.amount)}
                            {renderCell(r.tracking_id)}
                            {renderCell(
                              r.bank_ref_no ?? r.payment_reference_no
                            )}
                            {renderCell(pri)}
                            {renderCell(r.slot_date)}
                            {renderCell(r.slot_time)}
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* Loading overlay */}
        {loading && (
          <div
            style={{
              position: "fixed",
              inset: 0,
              background: "rgba(0,0,0,0.35)",
              zIndex: 1050,
              display: "grid",
              placeItems: "center",
            }}
          >
            <div className="spinner-border text-light" role="status" />
          </div>
        )}

        {/* Table */}
      </div>
    </AjaxValidation>
  );
}
