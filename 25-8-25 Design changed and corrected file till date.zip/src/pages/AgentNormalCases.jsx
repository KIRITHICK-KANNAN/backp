// import React, { useEffect, useMemo, useState } from "react";
// import Modal from "react-bootstrap/Modal";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { useAuth } from "../context/AuthContext";
// import {
//   agentCases,
//   agentCaseList,
//   updtDocs,
//   updtMastr,
//   agentCaseList as getAgentCaseList,
//   updtCase, // must be exported from ../api/client
//   docHistory, // DocDtls API
// } from "../api/client";

// /* ---------------- helpers ---------------- */
// const fmtDMY = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   return `${String(d.getDate()).padStart(2, "0")}/${String(
//     d.getMonth() + 1
//   ).padStart(2, "0")}/${d.getFullYear()}`;
// };
// const toIST = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d)) return "";
//   const ist = new Date(d.getTime() + 5.5 * 3600 * 1000);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// };

// const statusText = (s) =>
//   s === 6
//     ? "Verified"
//     : s === 4
//     ? "Blocked"
//     : s === 3
//     ? "Rejected"
//     : s === 5
//     ? "Re‑Submitted"
//     : s === 2
//     ? "Submitted"
//     : "Pending";

// const statusIsFinal = (s) => s === 6 || s === 4 || s === 3;

// const DOC = { NULLA: 1, PASS: 2 };
// const statusMap = { verify: 6, reject: 3, block: 4 };

// const PASSPORT_REASON_OPTIONS = [
//   { id: 16, label: "NOT ELIGIBLE" },
//   { id: 17, label: "DOCUMENT NOT CLEAR" },
//   { id: 19, label: "DETAILS MISMATCH" },
//   { id: 21, label: "DUPLICATE ENTRY" },
//   { id: 22, label: "EXPIRED PASSPORT" },
//   { id: 23, label: "INCOMPLETE PASSPORT" },
//   { id: 26, label: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY" },
// ];
// const NULLA_REASON_OPTIONS = [
//   { id: 1, label: "NOT ELIGIBLE" },
//   { id: 2, label: "NOT A NULLA OSTA" },
//   { id: 3, label: "DOCUMENT NOT CLEAR" },
//   { id: 4, label: "INCOMPLETE DOCUMENT" },
//   { id: 5, label: "INVALID DATE OF ISSUE" },
//   { id: 6, label: "DETAILS MISMATCH" },
//   { id: 7, label: "BLOCKED ISSUE DATE" },
//   { id: 8, label: "DUPLICATE ENTRY" },
// ];

// const AUTO_COMMENTS = {
//   1: "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   2: "Not a Nulla Osta",
//   3: "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   4: "Nulla osta uploaded is not complete",
//   5: "The date of issue is not correct for the attached Nulla Osta.",
//   6: "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   7: "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   8: "The Nulla Osta and Passport have already been submitted for appointment",

//   16: "NOT ELIGIBLE",
//   17: "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   18: "Document uploaded is not matching the format of a Passport",
//   19: "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   20: "The Passport uploaded is expired. Kindly renew your passport and apply again. Kindly upload both front and back page of a valid passport.",
//   21: "The Nulla Osta and Passport have already been submitted for appointment",
//   22: "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   23: "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   24: "The uploaded Nulla Osta documents do not have the same inviting person. Kindly note that only applicants having the same inviting person are allowed to apply.",
//   25: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   26: "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
// };

// /* ---------------- tiny helpers to compute finality ---------------- */
// function getDoc(row, dtlId, type) {
//   return (row?.documents || []).find(
//     (d) => String(d.dtlId) === String(dtlId) && Number(d.type) === Number(type)
//   );
// }
// function getDocStatus(row, dtlId, type) {
//   const d = getDoc(row, dtlId, type);
//   return d?.docStatus ?? 0;
// }
// function computeDtlStatusFromDocs(passSts, nullaSts) {
//   if (!statusIsFinal(passSts) || !statusIsFinal(nullaSts)) return null;
//   if (passSts === 4 || nullaSts === 4) return 4;
//   if (passSts === 6 && nullaSts === 6) return 6;
//   return 3;
// }
// function computeMasterStatus(allDtlStatuses) {
//   const finals = allDtlStatuses.filter((s) => s !== null);
//   if (finals.length !== allDtlStatuses.length) return null;
//   const all6 = allDtlStatuses.every((s) => s === 6);
//   const all4 = allDtlStatuses.every((s) => s === 4);
//   if (all6) return 6;
//   if (all4) return 4;
//   return 7; // partially verified
// }

// /* =========================================================
//    Modal
// ========================================================= */
// function CaseModal({ show, onClose, row, onAfterChain }) {
//   const { authData } = useAuth();
//   const [tab, setTab] = useState("passport"); // passport|nulla|history
//   const [act, setAct] = useState(""); // verify|reject|block
//   const [reason, setReason] = useState("0");
//   const [comments, setComments] = useState("");
//   const [saving, setSaving] = useState(false);
//   const [history, setHistory] = useState({ usr: [], cust: [] });
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const det = row?.detail || {};
//   const reqId =
//     row?.master?.reqId ||
//     row?.master?.request_id ||
//     row?.master?.reqid ||
//     row?.master?.reqIdFk ||
//     "";

//   const passDoc =
//     row?.documents?.find(
//       (d) =>
//         Number(d.type) === DOC.PASS && String(d.dtlId) === String(det?.dtlId)
//     ) ||
//     row?.documents?.find(
//       (d) =>
//         /pass/i.test(String(d.file)) && String(d.dtlId) === String(det?.dtlId)
//     );

//   const nullaDoc =
//     row?.documents?.find(
//       (d) =>
//         Number(d.type) === DOC.NULLA && String(d.dtlId) === String(det?.dtlId)
//     ) ||
//     row?.documents?.find(
//       (d) =>
//         /nulla|osta/i.test(String(d.file)) &&
//         String(d.dtlId) === String(det?.dtlId)
//     );

//   const activeDoc =
//     tab === "passport" ? passDoc : tab === "nulla" ? nullaDoc : null;
//   const activeDocStatus = activeDoc?.docStatus ?? 0;
//   const isReadOnly = statusIsFinal(activeDocStatus);

//   const buildOpenUrl = (fileName) =>
//     fileName
//       ? `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${authData.session_id}_${sessionToken}_${fileName}`
//       : "";

//   const iframeSrc =
//     tab === "passport"
//       ? buildOpenUrl(passDoc?.file)
//       : tab === "nulla"
//       ? buildOpenUrl(nullaDoc?.file)
//       : "";

//   useEffect(() => {
//     setTab("passport");
//     setAct("");
//     setReason("0");
//     setComments("");
//     setHistory({ usr: [], cust: [] });
//   }, [row]);

//   useEffect(() => {
//     if ((act === "reject" || act === "block") && reason !== "0") {
//       const txt = AUTO_COMMENTS[Number(reason)];
//       if (txt) setComments(txt);
//     }
//   }, [reason, act]);

//   // Load history when tab is selected
//   useEffect(() => {
//     const loadHistory = async () => {
//       if (tab !== "history") return;
//       try {
//         setLoadingHistory(true);
//         // we show Nulla Osta doc on the right. For history we can fetch by docId if you prefer,
//         // here we use nullaDoc?.docId if present, else passport
//         const docId = nullaDoc?.docId || passDoc?.docId;
//         if (!docId) {
//           setHistory({ usr: [], cust: [] });
//           return;
//         }
//         const res = await docHistory({
//           session_id: authData.session_id,
//           sessionToken,
//           docId,
//         });
//         setHistory({
//           usr: res?.UsrActivity || [],
//           cust: res?.CustActivity || [],
//         });
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     loadHistory();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, nullaDoc?.docId, passDoc?.docId]);

//   // ——— NO REFRESH AFTER UpdtDocs ———
//   // We update local modal state, then only when *both docs* are final we:
//   // UpdtCase -> AgentCaseList(reqId). If all applicants final -> UpdtMastr -> AgentCases().
//   async function handleSave() {
//     if (!activeDoc?.docId) {
//       alert("No document found.");
//       return;
//     }
//     if (!act) {
//       alert("Choose Verify / Reject / Block.");
//       return;
//     }
//     if ((act === "reject" || act === "block") && reason === "0") {
//       alert("Select a reason.");
//       return;
//     }

//     try {
//       setSaving(true);

//       // 1) Update only this doc on server
//       await updtDocs({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//         dtlId: det?.dtlId,
//         docId: activeDoc.docId,
//         status: statusMap[act],
//         reason: act === "verify" ? "0" : String(reason || "0"),
//         comments: comments || "",
//       });

//       // 2) Update local doc status immediately (no refresh yet)
//       const newRow = { ...row, documents: [...(row.documents || [])] };
//       const idx = newRow.documents.findIndex(
//         (d) => String(d.docId) === String(activeDoc.docId)
//       );
//       if (idx !== -1)
//         newRow.documents[idx] = {
//           ...newRow.documents[idx],
//           docStatus: statusMap[act],
//         };

//       // 3) Check if both docs for this applicant are now final
//       const pSts = getDocStatus(newRow, det?.dtlId, DOC.PASS);
//       const nSts = getDocStatus(newRow, det?.dtlId, DOC.NULLA);
//       const dtlFinal = computeDtlStatusFromDocs(pSts, nSts);

//       if (dtlFinal !== null) {
//         // 3a) UpdtCase for this applicant
//         await updtCase({
//           session_id: authData.session_id,
//           sessionToken,
//           reqId,
//           dtlId: det?.dtlId,
//           dtlStatus: dtlFinal,
//         });

//         // 3b) Now refresh *this request* from server
//         const fresh = await getAgentCaseList({
//           session_id: authData.session_id,
//           sessionToken,
//           reqId,
//         });

//         // 3c) If all applicants of this request are final -> UpdtMastr, then parent will reload AgentCases()
//         const merged = {
//           master:
//             (fresh?.master || []).find(
//               (m) => String(m.reqId) === String(reqId)
//             ) || row.master,
//           details: (fresh?.details || []).filter(
//             (d) => String(d.reqId) === String(reqId)
//           ),
//           documents: (fresh?.documents || []).filter(
//             (d) => String(d.reqId) === String(reqId)
//           ),
//         };
//         const allDtl = merged.details.map((d) =>
//           computeDtlStatusFromDocs(
//             getDocStatus(merged, d.dtlId, DOC.PASS),
//             getDocStatus(merged, d.dtlId, DOC.NULLA)
//           )
//         );

//         let reqCompleted = false;
//         if (allDtl.every((s) => s !== null)) {
//           const reqStatus = computeMasterStatus(allDtl);
//           if (reqStatus !== null) {
//             await updtMastr({
//               session_id: authData.session_id,
//               sessionToken,
//               reqId,
//               reqStatus,
//             });
//             reqCompleted = true; // parent will call AgentCases()
//           }
//         }

//         // 3d) inform parent with fresh status
//         onAfterChain?.({ reqCompleted, reqId });
//       } else {
//         // still not final (must verify the other doc). Stay in modal, no refresh.
//         onAfterChain?.({ reqCompleted: false, reqId: null });
//       }

//       alert("Saved.");
//       // reset action panel but keep modal and current tab
//       setAct("");
//       setReason("0");
//       setComments("");
//     } catch (e) {
//       console.error(e);
//       alert(e?.message || "Server error while saving.");
//     } finally {
//       setSaving(false);
//     }
//   }

//   const reasons =
//     tab === "passport" ? PASSPORT_REASON_OPTIONS : NULLA_REASON_OPTIONS;
//   const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();

//   return (
//     <Modal show={show} onHide={onClose} size="xl" centered backdrop="static">
//       <Modal.Header closeButton>
//         <Modal.Title>Reference ID - {reqId}</Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="row g-3">
//           {/* Left: tabs + content */}
//           <div className="col-sm-8">
//             <div className="mb-2 d-flex gap-2 flex-wrap">
//               <button
//                 className={`btn btn-sm ${
//                   tab === "passport" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("passport")}
//               >
//                 Passport Document — {statusText(passDoc?.docStatus ?? 0)}
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "nulla" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("nulla")}
//               >
//                 Nulla Osta Document — {statusText(nullaDoc?.docStatus ?? 0)}
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "history" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("history")}
//                 disabled={!nullaDoc?.docId && !passDoc?.docId}
//               >
//                 Document History
//               </button>
//             </div>

//             {/* Left body: For history we render the two small tables (like your screenshot) */}
//             {tab === "history" ? (
//               <div
//                 className="border rounded p-2"
//                 style={{ maxHeight: 520, overflow: "auto" }}
//               >
//                 {loadingHistory ? (
//                   <div className="p-3">Loading history…</div>
//                 ) : (
//                   <>
//                     <div className="mb-2 fw-semibold">
//                       Passport : <span>{det?.ppn || "-"}</span>&nbsp;&nbsp;
//                       Status :{" "}
//                       <span>{statusText(passDoc?.docStatus ?? 0)}</span>
//                     </div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned By</th>
//                             <th>Actioned On</th>
//                             <th>Uploaded Passport</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.usr || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.usr.map((u, i) => (
//                               <tr key={u.alog || i}>
//                                 <td>{i + 1}</td>
//                                 <td>{u.alog}</td>
//                                 <td>{u.user || "Applicant"}</td>
//                                 <td>{toIST(u.addOn)}</td>
//                                 <td>{u.file}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>

//                     <div className="mb-2 fw-semibold mt-3">
//                       Nulla Osta : <span>{det?.wpn || "-"}</span>&nbsp;&nbsp;
//                       Status :{" "}
//                       <span>{statusText(nullaDoc?.docStatus ?? 0)}</span>
//                     </div>
//                     <div className="table-responsive">
//                       <table className="table table-bordered table-sm">
//                         <thead className="table-active">
//                           <tr>
//                             <th>#</th>
//                             <th>Action</th>
//                             <th>Actioned By</th>
//                             <th>Actioned On</th>
//                             <th>Uploaded Nulla Osta</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {(history.cust || []).length === 0 ? (
//                             <tr>
//                               <td colSpan={5} className="text-muted">
//                                 —
//                               </td>
//                             </tr>
//                           ) : (
//                             history.cust.map((c, i) => (
//                               <tr key={c.dlog || i}>
//                                 <td>{i + 1}</td>
//                                 <td>{c.alog || "Submitted"}</td>
//                                 <td>{c.user || "Applicant"}</td>
//                                 <td>{toIST(c.addOn)}</td>
//                                 <td>{c.file}</td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </table>
//                     </div>
//                   </>
//                 )}
//               </div>
//             ) : (
//               <div
//                 style={{
//                   height: 520,
//                   border: "1px solid #ddd",
//                   borderRadius: 6,
//                   overflow: "hidden",
//                 }}
//               >
//                 {iframeSrc ? (
//                   <iframe
//                     title="doc"
//                     src={iframeSrc}
//                     width="100%"
//                     height="100%"
//                     frameBorder="0"
//                   />
//                 ) : (
//                   <div className="p-3 text-muted">No file found.</div>
//                 )}
//               </div>
//             )}
//           </div>

//           {/* Right:
//                - For history tab show the **Nulla Osta document** iframe (like your screenshot).
//                - For doc tabs show the details + action controls. */}
//           <div className="col-sm-4">
//             {tab === "history" ? (
//               <div className="border rounded p-2">
//                 <div className="mb-2 fw-semibold">Nulla Osta Document</div>
//                 <div
//                   style={{
//                     height: 520,
//                     border: "1px solid #ddd",
//                     borderRadius: 6,
//                     overflow: "hidden",
//                   }}
//                 >
//                   {nullaDoc?.file ? (
//                     <iframe
//                       title="nulla-history"
//                       src={buildOpenUrl(nullaDoc.file)}
//                       width="100%"
//                       height="100%"
//                       frameBorder="0"
//                     />
//                   ) : (
//                     <div className="p-3 text-muted">No Nulla Osta file.</div>
//                   )}
//                 </div>
//               </div>
//             ) : (
//               <div className="border rounded p-2">
//                 <div className="fw-semibold mb-2">Customer Details :</div>
//                 <div className="d-grid gap-1 small">
//                   <div className="d-flex justify-content-between border-bottom py-1">
//                     <span>Full Name</span>
//                     <span>{fullName || "-"}</span>
//                   </div>
//                   <div className="d-flex justify-content-between border-bottom py-1">
//                     <span>Email Id</span>
//                     <span>{row?.master?.mailId || "-"}</span>
//                   </div>
//                   <div className="d-flex justify-content-between border-bottom py-1">
//                     <span>Passport Number</span>
//                     <span>{det?.ppn || "-"}</span>
//                   </div>
//                   <div className="d-flex justify-content-between border-bottom py-1">
//                     <span>Nulla osta No</span>
//                     <span>{det?.wpn || "-"}</span>
//                   </div>
//                   <div className="d-flex justify-content-between border-bottom py-1">
//                     <span>DOB</span>
//                     <span>{fmtDMY(det?.dob) || "-"}</span>
//                   </div>
//                   <div className="d-flex justify-content-between border-bottom py-1">
//                     <span>Issue Date</span>
//                     <span>{fmtDMY(det?.wpndt) || "-"}</span>
//                   </div>
//                   <div className="d-flex justify-content-between border-bottom py-1">
//                     <span>Submited On</span>
//                     <span>{toIST(row?.master?.submitOn) || "-"}</span>
//                   </div>
//                   <div className="d-flex justify-content-between border-bottom py-1">
//                     <span>VAC</span>
//                     <span>{row?.master?.vac || "-"}</span>
//                   </div>
//                   <div className="d-flex justify-content-between border-bottom py-1">
//                     <span>Status</span>
//                     <span>{statusText(activeDocStatus)}</span>
//                   </div>
//                 </div>

//                 <div className="mt-3 small">
//                   <div className="mb-2">Action</div>
//                   <div className="d-flex gap-3">
//                     <label className="d-flex align-items-center gap-1">
//                       <input
//                         type="radio"
//                         name="act"
//                         value="verify"
//                         checked={act === "verify"}
//                         onChange={() => {
//                           setAct("verify");
//                           setReason("0");
//                         }}
//                         disabled={isReadOnly}
//                       />
//                       Verify
//                     </label>
//                     <label className="d-flex align-items-center gap-1">
//                       <input
//                         type="radio"
//                         name="act"
//                         value="reject"
//                         checked={act === "reject"}
//                         onChange={() => setAct("reject")}
//                         disabled={isReadOnly}
//                       />
//                       Reject
//                     </label>
//                     <label className="d-flex align-items-center gap-1">
//                       <input
//                         type="radio"
//                         name="act"
//                         value="block"
//                         checked={act === "block"}
//                         onChange={() => setAct("block")}
//                         disabled={isReadOnly}
//                       />
//                       Block
//                     </label>
//                   </div>

//                   {(act === "reject" || act === "block") && (
//                     <div className="mt-2">
//                       <div className="mb-1">Reason</div>
//                       <select
//                         className="form-select form-select-sm"
//                         value={reason}
//                         onChange={(e) => setReason(e.target.value)}
//                         disabled={isReadOnly}
//                       >
//                         <option value="0">---Select---</option>
//                         {(tab === "passport"
//                           ? PASSPORT_REASON_OPTIONS
//                           : NULLA_REASON_OPTIONS
//                         ).map((r) => (
//                           <option key={r.id} value={r.id}>
//                             {r.label}
//                           </option>
//                         ))}
//                       </select>
//                     </div>
//                   )}

//                   <div className="mt-2">
//                     <div className="mb-1">Comments :</div>
//                     <textarea
//                       className="form-control"
//                       rows={5}
//                       value={comments}
//                       onChange={(e) => setComments(e.target.value)}
//                       disabled={isReadOnly}
//                     />
//                   </div>

//                   <div className="d-flex gap-2 mt-3">
//                     <button
//                       className="btn btn-secondary w-50"
//                       onClick={onClose}
//                     >
//                       Close
//                     </button>
//                     <button
//                       className="btn btn-primary w-50"
//                       onClick={handleSave}
//                       disabled={
//                         isReadOnly ||
//                         saving ||
//                         !act ||
//                         ((act === "reject" || act === "block") &&
//                           reason === "0")
//                       }
//                     >
//                       {saving ? "Saving…" : "Save"}
//                     </button>
//                   </div>
//                 </div>
//               </div>
//             )}
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* =========================================================
//    Single table (no expansion). Group rows by reqId, show
//    Request Id & No. Of Applicants only on first row.
// ========================================================= */
// export default function AgentNormalCases() {
//   const { authData } = useAuth();
//   const [groups, setGroups] = useState([]); // [{ master, details, documents }]
//   const [loading, setLoading] = useState(false);
//   const [active, setActive] = useState(null); // { master, detail, documents }

//   const sessionToken =
//     authData.session_token ||
//     authData.sessionToken ||
//     authData.Globalsessiontoken;

//   const cols = useMemo(
//     () => [
//       "Request Id",
//       "No. Of Applicants",
//       "Full Name",
//       "Email Id",
//       "Passport Number",
//       "Nulla osta No",
//       "DOB",
//       "Issue Date",
//       "Appointment On",
//       "Submited On",
//       "VAC",
//       "Status",
//       "Action",
//     ],
//     []
//   );

//   async function loadAgentCases() {
//     setLoading(true);
//     try {
//       const res = await agentCases({
//         session_id: authData.session_id,
//         sessionToken,
//         priority: 0,
//       });

//       if (Array.isArray(res?.master)) {
//         const out = res.master.map((m) => ({
//           master: m,
//           details: (res.details || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//           documents: (res.documents || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//         }));
//         setGroups(out);
//       } else {
//         setGroups([]);
//       }
//     } catch (e) {
//       console.error(e);
//       setGroups([]);
//       alert("Failed to load cases.");
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     loadAgentCases();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   // If request completed -> reload AgentCases; else just refresh that request
//   function onAfterChain({ reqCompleted, reqId }) {
//     if (reqCompleted) {
//       loadAgentCases();
//     } else if (reqId) {
//       refreshRequest(reqId);
//     }
//   }

//   async function refreshRequest(reqId) {
//     try {
//       const fresh = await agentCaseList({
//         session_id: authData.session_id,
//         sessionToken,
//         reqId,
//       });
//       setGroups((prev) =>
//         prev.map((g) => {
//           if (String(g.master.reqId) !== String(reqId)) return g;
//           return {
//             master:
//               (fresh?.master || []).find(
//                 (m) => String(m.reqId) === String(reqId)
//               ) || g.master,
//             details: (fresh?.details || []).filter(
//               (d) => String(d.reqId) === String(reqId)
//             ),
//             documents: (fresh?.documents || []).filter(
//               (d) => String(d.reqId) === String(reqId)
//             ),
//           };
//         })
//       );
//     } catch (e) {
//       console.error("refreshRequest failed", e);
//     }
//   }

//   return (
//     <AjaxValidation>
//       <div className="mt-2">
//         <div className="container-fluid">
//           <h6>Agent Normal Cases</h6>

//           <div class="row mt-2 mb-3">
//             <div class="col-sm-12">
//               <div className="box_card">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <div className="table-responsive holiday-container">
//                       <table className="table table-bordered">
//                         <thead className="table-light">
//                           <tr>
//                             {cols.map((c) => (
//                               <th key={c}>{c}</th>
//                             ))}
//                           </tr>
//                         </thead>

//                         <tbody>
//                           {loading ? (
//                             <tr>
//                               <td colSpan={cols.length}>Loading…</td>
//                             </tr>
//                           ) : groups.length === 0 ? (
//                             <tr>
//                               <td colSpan={cols.length} className="text-muted">
//                                 No records
//                               </td>
//                             </tr>
//                           ) : (
//                             groups.flatMap((grp) => {
//                               const reqId = grp.master.reqId;
//                               const total = grp.details?.length || 0;

//                               return (grp.details || []).map((d, idx) => {
//                                 const firstRow = idx === 0;
//                                 const ps = getDocStatus(grp, d.dtlId, DOC.PASS);
//                                 const ns = getDocStatus(
//                                   grp,
//                                   d.dtlId,
//                                   DOC.NULLA
//                                 );
//                                 const derived = computeDtlStatusFromDocs(
//                                   ps,
//                                   ns
//                                 );

//                                 return (
//                                   <tr key={`${reqId}-${d.dtlId}`}>
//                                     <td>{firstRow ? reqId : ""}</td>
//                                     <td>{firstRow ? total : ""}</td>
//                                     <td>
//                                       {`${d.fName || ""} ${
//                                         d.lName || ""
//                                       }`.trim() || "-"}
//                                     </td>
//                                     <td>{grp.master.mailId || "-"}</td>
//                                     <td>{d.ppn || "-"}</td>
//                                     <td>{d.wpn || "-"}</td>
//                                     <td>{fmtDMY(d.dob) || "-"}</td>
//                                     <td>{fmtDMY(d.wpndt) || "-"}</td>
//                                     <td>{toIST(d.slotAt) || "-"}</td>
//                                     <td>
//                                       {firstRow
//                                         ? toIST(grp.master.submitOn) || "-"
//                                         : ""}
//                                     </td>
//                                     <td>
//                                       {firstRow ? grp.master.vac || "-" : ""}
//                                     </td>
//                                     <td>
//                                       {derived === null
//                                         ? "Pending"
//                                         : statusText(derived)}
//                                     </td>
//                                     <td>
//                                       <button
//                                         className="btn btn-link p-0"
//                                         onClick={() =>
//                                           setActive({
//                                             master: grp.master,
//                                             detail: d,
//                                             documents: grp.documents,
//                                           })
//                                         }
//                                       >
//                                         View
//                                       </button>
//                                     </td>
//                                   </tr>
//                                 );
//                               });
//                             })
//                           )}
//                         </tbody>
//                       </table>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>

//           {active && (
//             <CaseModal
//               show={!!active}
//               row={active}
//               onClose={() => setActive(null)}
//               onAfterChain={onAfterChain}
//             />
//           )}
//         </div>
//       </div>
//     </AjaxValidation>
//   );
// }

// import React, { useEffect, useMemo, useState } from "react";
// import Modal from "react-bootstrap/Modal";
// import AjaxValidation from "../hooks/AjaxValidation";
// import { useAuth } from "../context/AuthContext";
// import {
//   agentCases,
//   updtDocs,
//   updtMastr,
//   agentCaseList,
//   updtCase,
//   docHistory,
// } from "../api/client";

// /* ---------- tiny utils (fixed date parsing) ---------- */
// const fmtDMY = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d.getTime())) return "";
//   return `${String(d.getDate()).padStart(2, "0")}/${String(
//     d.getMonth() + 1
//   ).padStart(2, "0")}/${d.getFullYear()}`;
// };
// const toIST = (s) => {
//   if (!s) return "";
//   const d = new Date(s);
//   if (Number.isNaN(d.getTime())) return "";
//   const ist = new Date(d.getTime() + 5.5 * 3600 * 1000);
//   const dd = String(ist.getDate()).padStart(2, "0");
//   const mm = String(ist.getMonth() + 1).padStart(2, "0");
//   const yyyy = ist.getFullYear();
//   const hh = String(ist.getHours()).padStart(2, "0");
//   const mi = String(ist.getMinutes()).padStart(2, "0");
//   return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
// };
// const statusText = (s) =>
//   String(s) === "6"
//     ? "Verified"
//     : String(s) === "4"
//     ? "Blocked"
//     : String(s) === "3"
//     ? "Rejected"
//     : String(s) === "5"
//     ? "Re-Submitted"
//     : String(s) === "2"
//     ? "Submitted"
//     : "-";
// const statusIsFinal = (s) => ["6", "4", "3"].includes(String(s));
// const statusMap = { verify: 6, reject: 3, block: 4 };
// const docType = { NULLA: 1, PASS: 2 };

// /* ---------- fallbacks (only used if reasoncode_list missing) ---------- */
// const PASSPORT_REASON_FALLBACK = [
//   { id: "16", reason_code: "NOT ELIGIBLE", reason_comments: "NOT ELIGIBLE" },
//   {
//     id: "17",
//     reason_code: "DOCUMENT NOT CLEAR",
//     reason_comments:
//       "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
//   },
//   {
//     id: "19",
//     reason_code: "DETAILS MISMATCH",
//     reason_comments:
//       "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
//   },
//   {
//     id: "21",
//     reason_code: "DUPLICATE ENTRY",
//     reason_comments:
//       "The Nulla Osta and Passport have already been submitted for appointment",
//   },
//   {
//     id: "22",
//     reason_code: "EXPIRED PASSPORT",
//     reason_comments:
//       "The Passport uploaded is expired. Kindly renew your passport and apply again.",
//   },
//   {
//     id: "23",
//     reason_code: "INCOMPLETE PASSPORT",
//     reason_comments:
//       "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
//   },
//   {
//     id: "26",
//     reason_code: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY",
//     reason_comments:
//       "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
//   },
// ];
// const NULLA_REASON_FALLBACK = [
//   {
//     id: "1",
//     reason_code: "NOT ELIGIBLE",
//     reason_comments:
//       "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
//   },
//   {
//     id: "2",
//     reason_code: "NOT A NULLA OSTA",
//     reason_comments: "Not a Nulla Osta",
//   },
//   {
//     id: "3",
//     reason_code: "DOCUMENT NOT CLEAR",
//     reason_comments:
//       "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
//   },
//   {
//     id: "4",
//     reason_code: "INCOMPLETE DOCUMENT",
//     reason_comments: "Nulla osta uploaded is not complete",
//   },
//   {
//     id: "5",
//     reason_code: "INVALID DATE OF ISSUE",
//     reason_comments:
//       "The date of issue is not correct for the attached Nulla Osta.",
//   },
//   {
//     id: "6",
//     reason_code: "DETAILS MISMATCH",
//     reason_comments:
//       "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
//   },
//   {
//     id: "7",
//     reason_code: "BLOCKED ISSUE DATE",
//     reason_comments:
//       "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
//   },
//   {
//     id: "8",
//     reason_code: "DUPLICATE ENTRY",
//     reason_comments:
//       "The Nulla Osta and Passport have already been submitted for appointment",
//   },
// ];

// /* ---------------- doc helpers ---------------- */
// const getDoc = (row, dtlId, type) =>
//   (row?.documents || []).find(
//     (d) => String(d.dtlId) === String(dtlId) && Number(d.type) === Number(type)
//   );
// const getDocStatus = (row, dtlId, type) =>
//   getDoc(row, dtlId, type)?.docStatus ?? 0;

// const computeDtlStatusFromDocs = (passSts, nullaSts) => {
//   if (!statusIsFinal(passSts) || !statusIsFinal(nullaSts)) return null;
//   if (String(passSts) === "4" || String(nullaSts) === "4") return 4;
//   if (String(passSts) === "6" && String(nullaSts) === "6") return 6;
//   return 3;
// };
// const computeMasterStatus = (allDtlStatuses) => {
//   const finals = allDtlStatuses.filter((s) => s !== null && statusIsFinal(s));
//   if (finals.length !== allDtlStatuses.length) return null;
//   const all6 = allDtlStatuses.every((s) => String(s) === "6");
//   const all4 = allDtlStatuses.every((s) => String(s) === "4");
//   if (all6) return 6;
//   if (all4) return 4;
//   return 7; // partially verified / mixed
// };

// const statusToAct = (s) => {
//   const c = String(s);
//   if (c === "6") return "verify";
//   if (c === "4") return "block";
//   if (c === "3") return "reject";
//   return "";
// };

// // Try common backend fields to recover saved reason id
// const readReasonIdFromDoc = (d) => {
//   const cand = [
//     d?.reason,
//     d?.reasonId,
//     d?.reason_id,
//     d?.reason_code_id,
//     d?.reject_reason_id,
//     d?.block_reason_id,
//   ];
//   for (const v of cand) {
//     if (
//       v !== undefined &&
//       v !== null &&
//       String(v) !== "" &&
//       String(v) !== "0"
//     ) {
//       return String(v);
//     }
//   }
//   return "0";
// };

// // Try common backend fields to recover saved comments/remarks
// const readCommentsFromDoc = (d) => {
//   const cand = [
//     d?.comments,
//     d?.comment,
//     d?.verifyComments,
//     d?.verify_comments,
//     d?.remarks,
//     d?.remark,
//   ];
//   for (const v of cand) {
//     if (v && String(v).trim() !== "") return String(v);
//   }
//   return "";
// };

// /* ========================= Modal (editable) ========================= */
// function CaseModal({ show, onClose, row, onWholeListRefresh, refreshRow }) {
//   const { authData } = useAuth();
//   const [tab, setTab] = useState("passport"); // passport | nulla | history
//   const [saving, setSaving] = useState(false);

//   // dynamic reasons (fallbacks if list missing)
//   const reasonList = authData?.ajaxPayload?.reasoncode_list || [];
//   const nullaReasonOptions =
//     reasonList.length > 0
//       ? reasonList
//           .filter(
//             (r) => String(r.type) === "1" && String(r.status ?? "1") === "1"
//           )
//           .map((r) => ({
//             id: String(r.id),
//             reason_code: r.reason_code,
//             reason_comments: r.reason_comments || "",
//           }))
//       : NULLA_REASON_FALLBACK;
//   const passportReasonOptions =
//     reasonList.length > 0
//       ? reasonList
//           .filter(
//             (r) => String(r.type) === "2" && String(r.status ?? "1") === "1"
//           )
//           .map((r) => ({
//             id: String(r.id),
//             reason_code: r.reason_code,
//             reason_comments: r.reason_comments || "",
//           }))
//       : PASSPORT_REASON_FALLBACK;

//   const autoCommentMap = useMemo(() => {
//     const m = {};
//     [...nullaReasonOptions, ...passportReasonOptions].forEach((r) => {
//       m[String(r.id)] = r.reason_comments || "";
//     });
//     return m;
//   }, [nullaReasonOptions, passportReasonOptions]);

//   const statusNameById = useMemo(() => {
//     const list = authData?.ajaxPayload?.master_status_list || [];
//     const map = {};
//     for (const s of list)
//       map[String(s.request_status_id)] = s.request_status_name;
//     return map;
//   }, [authData?.ajaxPayload?.master_status_list]);

//   const statusChip = (code) => {
//     const c = String(code || "");
//     const cls =
//       c === "6"
//         ? "text-success fw-semibold"
//         : c === "4"
//         ? "text-danger fw-semibold"
//         : "text-secondary";
//     const nm = statusNameById[c] || statusText(c);
//     return <span className={cls}>{nm}</span>;
//   };

//   // keep each doc’s chosen act/reason/comments & lock state so they don’t clear
//   const [docUiState, setDocUiState] = useState({});
//   const [loadingHistory, setLoadingHistory] = useState(false);

//   const det = row?.detail || {};
//   const reqId =
//     row?.master?.reqId ||
//     row?.master?.request_id ||
//     row?.master?.reqid ||
//     row?.master?.reqIdFk ||
//     "";

//   const passDoc =
//     row?.documents?.find(
//       (d) => Number(d.type) === 2 && String(d.dtlId) === String(det?.dtlId)
//     ) ||
//     row?.documents?.find(
//       (d) =>
//         /pass/i.test(String(d.file || d.file_name || "")) &&
//         String(d.dtlId) === String(det?.dtlId)
//     );
//   const nullaDoc =
//     row?.documents?.find(
//       (d) => Number(d.type) === 1 && String(d.dtlId) === String(det?.dtlId)
//     ) ||
//     row?.documents?.find(
//       (d) =>
//         /nulla|osta/i.test(String(d.file || d.file_name || "")) &&
//         String(d.dtlId) === String(det?.dtlId)
//     );

//   // NEW: openDocument URL uses session_id + document_key
//   const buildOpenUrl = (fileName) => {
//     const f = fileName || "";
//     if (!f) return "";
//     const sessionId = authData?.session_id;
//     const documentKey =
//       authData?.ajaxPayload?.document_key ?? authData?.document_key;
//     if (!sessionId || !documentKey) return "";
//     return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${sessionId}_${documentKey}_${f}`;
//   };

//   const activeType = tab === "passport" ? docType.PASS : docType.NULLA;
//   const activeDoc = tab === "passport" ? passDoc : nullaDoc;
//   const activeKey = `${det?.dtlId}:${activeType}`;

//   // iframe src for normal tabs
//   const activeIframeSrc =
//     tab === "history"
//       ? ""
//       : buildOpenUrl(activeDoc?.file || activeDoc?.file_name);

//   /* ================= History (richer; two tracks + right preview) ================= */
//   const [historyFocus, setHistoryFocus] = useState("nulla"); // 'passport' | 'nulla'
//   const [historyOverrideFile, setHistoryOverrideFile] = useState(null);
//   const [passUsrActs, setPassUsrActs] = useState([]);
//   const [passCusActs, setPassCusActs] = useState([]);
//   const [nullaUsrActs, setNullaUsrActs] = useState([]);
//   const [nullaCusActs, setNullaCusActs] = useState([]);

//   const rightPreviewUrl = useMemo(() => {
//     const base =
//       historyFocus === "passport"
//         ? passDoc?.file || passDoc?.file_name
//         : nullaDoc?.file || nullaDoc?.file_name;
//     const file = historyOverrideFile || base;
//     return buildOpenUrl(file);
//   }, [
//     historyFocus,
//     historyOverrideFile,
//     passDoc?.file,
//     passDoc?.file_name,
//     nullaDoc?.file,
//     nullaDoc?.file_name,
//   ]);

//   useEffect(() => {
//     let abort = false;
//     const load = async (doc, setUsr, setCus) => {
//       const docId = doc?.docId || doc?.id;
//       if (!docId) {
//         setUsr([]);
//         setCus([]);
//         return;
//       }
//       const res = await docHistory({
//         session_id: authData.session_id,
//         sessionToken:
//           authData.session_token ||
//           authData.sessionToken ||
//           authData.Globalsessiontoken,
//         docId,
//       });
//       if (abort) return;
//       setUsr(Array.isArray(res?.UsrActivity) ? res.UsrActivity : []);
//       setCus(Array.isArray(res?.CustActivity) ? res.CustActivity : []);
//     };

//     const run = async () => {
//       if (tab !== "history") return;
//       try {
//         setLoadingHistory(true);
//         setHistoryFocus("nulla");
//         setHistoryOverrideFile(null);
//         await Promise.all([
//           load(passDoc, setPassUsrActs, setPassCusActs),
//           load(nullaDoc, setNullaUsrActs, setNullaCusActs),
//         ]);
//       } finally {
//         setLoadingHistory(false);
//       }
//     };
//     run();
//     return () => {
//       abort = true;
//     };
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [tab, authData?.session_id]);

//   const buildHistoryRows = (kind) => {
//     const usr = kind === "passport" ? passUsrActs : nullaUsrActs;
//     const cus = kind === "passport" ? passCusActs : nullaCusActs;
//     const docObj = kind === "passport" ? passDoc : nullaDoc;
//     const docFile = docObj?.file || docObj?.file_name;

//     // Map action from current doc status
//     const rawStat = docObj?.docStatus ?? docObj?.docStstus;
//     const actionNm = statusNameById[String(rawStat)] ?? statusText(rawStat);
//     const byNm = docObj?.vefifyBy || docObj?.verifyby || "-";

//     const rows = [];
//     let idx = 1;

//     const pushRow = (action, by, on, file) =>
//       rows.push({
//         idx: idx++,
//         action,
//         by,
//         on: toIST(on) || "-",
//         file: file || "-",
//       });

//     if (Array.isArray(cus) && cus.length) {
//       cus.forEach((c) =>
//         pushRow(actionNm, byNm, c.verifyOn || c.addOn, c.file)
//       );
//     } else if (docFile) {
//       pushRow(actionNm, byNm, docObj?.verifyOn || docObj?.addOn, docFile);
//     }

//     // (Optionally add usr/system rows similarly if needed)
//     return rows;
//   };

//   const passportRows = buildHistoryRows("passport");
//   const nullaRows = buildHistoryRows("nulla");

//   // local UI state for act/reason/comments + lock
//   const lockedFromBackend = statusIsFinal(activeDoc?.docStatus);
//   const baseUi = docUiState[activeKey] || {
//     act: "",
//     reason: "0",
//     comments: "",
//   };

//   const fallbackAct = statusToAct(activeDoc?.docStatus);
//   const fallbackReason = readReasonIdFromDoc(activeDoc);
//   const fallbackComments = readCommentsFromDoc(activeDoc);

//   const current = {
//     ...baseUi,
//     act: baseUi.act || (lockedFromBackend ? fallbackAct : ""),
//     reason:
//       baseUi.reason && baseUi.reason !== "0"
//         ? baseUi.reason
//         : lockedFromBackend
//         ? fallbackReason
//         : "0",
//     comments: baseUi.comments || (lockedFromBackend ? fallbackComments : ""),
//     locked: lockedFromBackend,
//   };

//   // lock states follow backend statuses
//   useEffect(() => {
//     setDocUiState((p) => {
//       const next = { ...p };

//       const passKey = `${det?.dtlId}:${docType.PASS}`;
//       const nullaKey = `${det?.dtlId}:${docType.NULLA}`;

//       const passLocked = statusIsFinal(passDoc?.docStatus);
//       const nullaLocked = statusIsFinal(nullaDoc?.docStatus);

//       const prevP = p[passKey] || { act: "", reason: "0", comments: "" };
//       next[passKey] = {
//         ...prevP,
//         locked: passLocked,
//         act: prevP.act || (passLocked ? statusToAct(passDoc?.docStatus) : ""),
//         reason:
//           prevP.reason && prevP.reason !== "0"
//             ? prevP.reason
//             : passLocked
//             ? readReasonIdFromDoc(passDoc)
//             : "0",
//         comments:
//           prevP.comments || (passLocked ? readCommentsFromDoc(passDoc) : ""),
//       };

//       const prevN = p[nullaKey] || { act: "", reason: "0", comments: "" };
//       next[nullaKey] = {
//         ...prevN,
//         locked: nullaLocked,
//         act: prevN.act || (nullaLocked ? statusToAct(nullaDoc?.docStatus) : ""),
//         reason:
//           prevN.reason && prevN.reason !== "0"
//             ? prevN.reason
//             : nullaLocked
//             ? readReasonIdFromDoc(nullaDoc)
//             : "0",
//         comments:
//           prevN.comments || (nullaLocked ? readCommentsFromDoc(nullaDoc) : ""),
//       };

//       return next;
//     });
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [det?.dtlId, passDoc?.docStatus, nullaDoc?.docStatus]);

//   // auto-fill comments when picking a reason on reject/block
//   useEffect(() => {
//     if (current.act !== "reject" && current.act !== "block") return;
//     if (current.reason && current.reason !== "0") {
//       const auto = autoCommentMap[String(current.reason)] || "";
//       setDocUiState((p) => ({
//         ...p,
//         [activeKey]: { ...current, comments: auto },
//       }));
//     }
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [current.reason, activeKey]);

//   const setAct = (v) =>
//     setDocUiState((p) => ({
//       ...p,
//       [activeKey]: {
//         ...current,
//         act: v,
//         reason: v === "verify" ? "0" : current.reason,
//       },
//     }));
//   const setReason = (v) =>
//     setDocUiState((p) => ({
//       ...p,
//       [activeKey]: { ...current, reason: v },
//     }));
//   const setComments = (v) =>
//     setDocUiState((p) => ({
//       ...p,
//       [activeKey]: { ...current, comments: v },
//     }));

//   const disableInputs = !!current.locked;

//   async function maybeAdvanceStatusesAfterDocs() {
//     // refresh server truth for this req
//     const fresh = await agentCaseList({
//       session_id: authData.session_id,
//       sessionToken:
//         authData.session_token ||
//         authData.sessionToken ||
//         authData.Globalsessiontoken,
//       reqId,
//     });

//     const mergedRow = {
//       master:
//         (fresh?.master || []).find((m) => String(m.reqId) === String(reqId)) ||
//         row.master,
//       details: (fresh?.details || []).filter(
//         (d) => String(d.reqId) === String(reqId)
//       ),
//       documents: (fresh?.documents || []).filter(
//         (d) => String(d.reqId) === String(reqId)
//       ),
//     };

//     // Applicant (detail) status
//     const dId = det?.dtlId;
//     const pSts = getDocStatus(mergedRow, dId, docType.PASS);
//     const nSts = getDocStatus(mergedRow, dId, docType.NULLA);
//     const dtlFinal = computeDtlStatusFromDocs(pSts, nSts);

//     if (dtlFinal !== null) {
//       await updtCase({
//         session_id: authData.session_id,
//         sessionToken:
//           authData.session_token ||
//           authData.sessionToken ||
//           authData.Globalsessiontoken,
//         reqId,
//         dtlId: dId,
//         dtlStatus: dtlFinal,
//       });
//       await refreshRow?.(reqId);
//     }

//     // Master status (when all details final)
//     const allDtlStatuses = mergedRow.details.map((d) => {
//       const ps = getDocStatus(mergedRow, d.dtlId, docType.PASS);
//       const ns = getDocStatus(mergedRow, d.dtlId, docType.NULLA);
//       return computeDtlStatusFromDocs(ps, ns);
//     });

//     if (allDtlStatuses.every((s) => s !== null)) {
//       const mas = computeMasterStatus(allDtlStatuses);
//       if (mas !== null) {
//         await updtMastr({
//           session_id: authData.session_id,
//           sessionToken:
//             authData.session_token ||
//             authData.sessionToken ||
//             authData.Globalsessiontoken,
//           reqId,
//           reqStatus: mas,
//         });
//         await onWholeListRefresh?.();
//       }
//     }
//   }

//   async function handleSave(e) {
//     e?.preventDefault();

//     const { act, reason, comments } = current;

//     if (!act) {
//       alert("Please choose Verify / Reject / Block.");
//       return;
//     }

//     if ((act === "reject" || act === "block") && (!reason || reason === "0")) {
//       alert("Please select a reason for Reject/Block.");
//       return;
//     }

//     if (act === "verify" && !String(comments || "").trim()) {
//       alert("Please enter comments before Verifying.");
//       return;
//     }

//     if (!(activeDoc?.docId || activeDoc?.id)) {
//       alert("No document found to update.");
//       return;
//     }

//     try {
//       setSaving(true);

//       await updtDocs({
//         session_id: authData.session_id,
//         sessionToken:
//           authData.session_token ||
//           authData.sessionToken ||
//           authData.Globalsessiontoken,
//         reqId,
//         dtlId: det?.dtlId,
//         docId: activeDoc.docId || activeDoc.id,
//         status: statusMap[act],
//         reason: act === "verify" ? "0" : String(reason || "0"),
//         comments: comments || "",
//       });

//       setDocUiState((p) => ({
//         ...p,
//         [activeKey]: { ...p[activeKey], locked: true },
//       }));

//       await maybeAdvanceStatusesAfterDocs();
//     } catch (e) {
//       console.error(e);
//       alert(e?.message || "Server rejected the update.");
//     } finally {
//       setSaving(false);
//     }
//   }
//   const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();

//   return (
//     <Modal
//       show={show}
//       onHide={onClose}
//       size="xl"
//       centered
//       className="newcase_modal-dialog"
//       backdrop="static"
//     >
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <h6 className="fs-6">Reference ID - {reqId}</h6>
//         </Modal.Title>
//       </Modal.Header>

//       <Modal.Body>
//         <div className="row g-3">
//           {/* Left side */}
//           <div className="col-sm-8">
//             <div className="mb-2 d-flex gap-2 flex-wrap">
//               <button
//                 className={`btn btn-sm ${
//                   tab === "passport" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("passport")}
//               >
//                 Passport Document
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "nulla" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("nulla")}
//               >
//                 Nulla Osta Document
//               </button>
//               <button
//                 className={`btn btn-sm ${
//                   tab === "history" ? "btn-primary" : "btn-outline-primary"
//                 }`}
//                 onClick={() => setTab("history")}
//               >
//                 Document History
//               </button>
//             </div>

//             {tab !== "history" ? (
//               <div
//                 style={{
//                   height: 520,
//                   border: "1px solid #ddd",
//                   borderRadius: 6,
//                   overflow: "hidden",
//                   background: "#fff",
//                 }}
//               >
//                 {activeIframeSrc ? (
//                   <iframe
//                     title="doc"
//                     src={activeIframeSrc}
//                     width="100%"
//                     height="100%"
//                     frameBorder="0"
//                   />
//                 ) : (
//                   <div className="p-3 text-muted">No file found.</div>
//                 )}
//               </div>
//             ) : (
//               <div className="pdf_view tab_scroll">
//                 <style>{`
//                   .history_table>:not(caption)>*>*{border-width:0 1px!important;font-size:12px!important}
//                   .status-flex{display:flex;justify-content:space-between;align-items:center;text-align:center;padding:.5rem 1rem;border:1px solid #dee2e6;font-size:14px}
//                   .history-row{cursor:pointer}
//                   .clickable{cursor:pointer;text-decoration:underline}
//                 `}</style>

//                 {/* Passport block */}
//                 <div
//                   className="status-flex"
//                   onClick={() => {
//                     setHistoryFocus("passport");
//                     setHistoryOverrideFile(null);
//                   }}
//                 >
//                   <div>
//                     Passport : <span>{det?.ppn || "-"}</span>
//                   </div>
//                   <div>Status : {statusChip(passDoc?.docStatus)}</div>
//                 </div>
//                 <div className="table-responsive mt-2">
//                   <table className="table table-bordered history_table text-left">
//                     <thead className="table-active">
//                       <tr>
//                         <th>#</th>
//                         <th>Action</th>
//                         <th>Actioned By</th>
//                         <th>Actioned On</th>
//                         <th>Uploaded Passport</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {loadingHistory ? (
//                         <tr>
//                           <td colSpan={5}>Loading…</td>
//                         </tr>
//                       ) : passportRows.length === 0 ? (
//                         <tr>
//                           <td colSpan={5} className="text-muted">
//                             —
//                           </td>
//                         </tr>
//                       ) : (
//                         passportRows.map((r) => (
//                           <tr
//                             key={`pr-${r.idx}`}
//                             className="history-row"
//                             onClick={() => {
//                               setHistoryFocus("passport");
//                               if (r.file && r.file !== "-")
//                                 setHistoryOverrideFile(r.file);
//                             }}
//                           >
//                             <td>{r.idx}</td>
//                             <td>{r.action}</td>
//                             <td>{r.by}</td>
//                             <td>{r.on}</td>
//                             <td className="clickable">{r.file || "-"}</td>
//                           </tr>
//                         ))
//                       )}
//                     </tbody>
//                   </table>
//                 </div>

//                 {/* Nulla block */}
//                 <div
//                   className="status-flex mt-3"
//                   onClick={() => {
//                     setHistoryFocus("nulla");
//                     setHistoryOverrideFile(null);
//                   }}
//                 >
//                   <div>
//                     Nulla Osta : <span>{det?.wpn || "-"}</span>
//                   </div>
//                   <div>Status : {statusChip(nullaDoc?.docStatus)}</div>
//                 </div>
//                 <div className="table-responsive mt-2">
//                   <table className="table table-bordered history_table text-left">
//                     <thead className="table-active">
//                       <tr>
//                         <th>#</th>
//                         <th>Action</th>
//                         <th>Actioned By</th>
//                         <th>Actioned On</th>
//                         <th>Uploaded Nulla Osta</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {loadingHistory ? (
//                         <tr>
//                           <td colSpan={5}>Loading…</td>
//                         </tr>
//                       ) : nullaRows.length === 0 ? (
//                         <tr>
//                           <td colSpan={5} className="text-muted">
//                             —
//                           </td>
//                         </tr>
//                       ) : (
//                         nullaRows.map((r) => (
//                           <tr
//                             key={`nr-${r.idx}`}
//                             className="history-row"
//                             onClick={() => {
//                               setHistoryFocus("nulla");
//                               if (r.file && r.file !== "-")
//                                 setHistoryOverrideFile(r.file);
//                             }}
//                           >
//                             <td>{r.idx}</td>
//                             <td>{r.action}</td>
//                             <td>{r.by}</td>
//                             <td>{r.on}</td>
//                             <td className="clickable">{r.file || "-"}</td>
//                           </tr>
//                         ))
//                       )}
//                     </tbody>
//                   </table>
//                 </div>
//               </div>
//             )}
//           </div>

//           {/* Right side */}
//           <div className="col-sm-4">
//             {tab === "history" ? (
//               <div
//                 className="img_view text-center"
//                 style={{
//                   height: 520,
//                   border: "1px solid #ddd",
//                   borderRadius: 6,
//                   overflow: "hidden",
//                   background: "#fff",
//                 }}
//               >
//                 {rightPreviewUrl ? (
//                   <iframe
//                     title="history-preview"
//                     src={rightPreviewUrl}
//                     width="100%"
//                     height="100%"
//                     frameBorder="0"
//                   />
//                 ) : (
//                   <div className="p-3 text-muted">No file to preview.</div>
//                 )}
//               </div>
//             ) : (
//               <div className="border rounded p-2">
//                 <div className="fw-semibold mb-2">Customer Details :</div>
//                 <div className="newcase-container">
//                   {[
//                     ["Full Name", fullName || "-"],
//                     ["Email Id", row?.master?.mailId || "-"],
//                     ["Passport Number", det?.ppn || "-"],
//                     ["Nulla osta No", det?.wpn || "-"],
//                     ["DOB", fmtDMY(det?.dob) || "-"],
//                     ["Issue Date", fmtDMY(det?.wpndt) || "-"],
//                     ["Submited On", toIST(row?.master?.submitOn) || "-"],
//                     ["VAC", row?.master?.vac || "-"],
//                     ["Status", statusText(activeDoc?.docStatus)],
//                   ].map(([l, v], i) => (
//                     <div className="form-group row border-bottom" key={i}>
//                       <div className="col-sm-6">
//                         <label className="form-label">{l}</label>
//                       </div>
//                       <div className="col-sm-6">
//                         <label className="form-label">{v}</label>
//                       </div>
//                     </div>
//                   ))}

//                   {/* actions (hidden on history) */}
//                   <div className="form-group row">
//                     <div className="col-sm-12">
//                       <div className="mt-2 small">
//                         <div className="mb-2">Action</div>
//                         <div className="d-flex gap-3">
//                           <label className="d-flex align-items-center gap-1">
//                             <input
//                               type="radio"
//                               name={`act-${activeKey}`}
//                               value="verify"
//                               checked={current.act === "verify"}
//                               onChange={() => setAct("verify")}
//                               disabled={disableInputs}
//                             />
//                             Verify
//                           </label>
//                           <label className="d-flex align-items-center gap-1">
//                             <input
//                               type="radio"
//                               name={`act-${activeKey}`}
//                               value="reject"
//                               checked={current.act === "reject"}
//                               onChange={() => setAct("reject")}
//                               disabled={disableInputs}
//                             />
//                             Reject
//                           </label>
//                           <label className="d-flex align-items-center gap-1">
//                             <input
//                               type="radio"
//                               name={`act-${activeKey}`}
//                               value="block"
//                               checked={current.act === "block"}
//                               onChange={() => setAct("block")}
//                               disabled={disableInputs}
//                             />
//                             Block
//                           </label>
//                         </div>

//                         {(current.act === "reject" ||
//                           current.act === "block") && (
//                           <div className="mt-2">
//                             <div className="mb-1">Reason</div>
//                             <select
//                               className="form-select form-select-sm"
//                               value={current.reason}
//                               onChange={(e) => setReason(e.target.value)}
//                               disabled={disableInputs}
//                             >
//                               <option value="0">---Select---</option>
//                               {(tab === "passport"
//                                 ? passportReasonOptions
//                                 : nullaReasonOptions
//                               ).map((r) => (
//                                 <option key={r.id} value={String(r.id)}>
//                                   {r.reason_code}
//                                 </option>
//                               ))}
//                             </select>
//                           </div>
//                         )}

//                         <div className="mt-2">
//                           <div className="mb-1">Comments :</div>
//                           <textarea
//                             className="form-control"
//                             rows={5}
//                             value={current.comments}
//                             onChange={(e) => setComments(e.target.value)}
//                             disabled={disableInputs}
//                           />
//                         </div>
//                         {/*
//                         <div className="d-flex gap-2 mt-3">
//                           <button className="btn-lg go-btn" onClick={onClose}>
//                             Close
//                           </button>
//                           <button
//                             className="btn-lg go-btn"
//                             onClick={handleSave}
//                             disabled={
//                               disableInputs ||
//                               saving ||
//                               !current.act ||
//                               ((current.act === "reject" ||
//                                 current.act === "block") &&
//                                 current.reason === "0")
//                             }
//                             // disabled={disableInputs || saving}
//                           >
//                             {saving ? "Submit" : "Submit"}
//                           </button>
//                         </div> */}
//                         {!current.locked && (
//                           <div className="d-flex gap-2 mt-3">
//                             <button className="btn-lg go-btn" onClick={onClose}>
//                               Close
//                             </button>
//                             <button
//                               className="btn-lg go-btn"
//                               onClick={handleSave}
//                               disabled={
//                                 disableInputs ||
//                                 saving ||
//                                 !current.act ||
//                                 ((current.act === "reject" ||
//                                   current.act === "block") &&
//                                   current.reason === "0")
//                               }
//                             >
//                               {saving ? "Submitting…" : "Submit"}
//                             </button>
//                           </div>
//                         )}
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             )}
//           </div>
//         </div>
//       </Modal.Body>
//     </Modal>
//   );
// }

// /* =========================================================
//    Main (flat table, no VAC edit, editable modal)
// ========================================================= */
// export default function AgentPriorityCases() {
//   const { authData } = useAuth();
//   const [rows, setRows] = useState([]); // array of {master, details[], documents[]}
//   const [loading, setLoading] = useState(false);
//   const [active, setActive] = useState(null); // {master, detail, documents}

//   const cols = useMemo(
//     () => [
//       "Request Id",
//       "No. Of Applicants",
//       "Full Name",
//       "Email Id",
//       "Passport Number",
//       "Nulla osta No",
//       "DOB",
//       "Issue Date",
//       "Submited On",
//       "VAC",
//       "Status",
//       "Action",
//     ],
//     []
//   );

//   async function load() {
//     setLoading(true);
//     try {
//       const res = await agentCases({
//         session_id: authData.session_id,
//         sessionToken:
//           authData.session_token ||
//           authData.sessionToken ||
//           authData.Globalsessiontoken,
//         priority: 0,
//       });

//       if (Array.isArray(res?.master)) {
//         const out = res.master.map((m) => ({
//           master: m,
//           details: (res.details || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//           documents: (res.documents || []).filter(
//             (d) => String(d.reqId) === String(m.reqId)
//           ),
//         }));
//         setRows(out);
//       } else {
//         setRows([]);
//       }
//     } catch (e) {
//       console.error(e);
//       setRows([]);
//       alert("Failed to load cases.");
//     } finally {
//       setLoading(false);
//     }
//   }

//   useEffect(() => {
//     load();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   const refreshRow = async (reqId) => {
//     try {
//       const fresh = await agentCaseList({
//         session_id: authData.session_id,
//         sessionToken:
//           authData.session_token ||
//           authData.sessionToken ||
//           authData.Globalsessiontoken,
//         reqId,
//       });
//       setRows((prev) =>
//         prev.map((r) => {
//           if (String(r.master.reqId) !== String(reqId)) return r;
//           return {
//             master:
//               (fresh?.master || []).find(
//                 (m) => String(m.reqId) === String(reqId)
//               ) || r.master,
//             details: (fresh?.details || []).filter(
//               (d) => String(d.reqId) === String(reqId)
//             ),
//             documents: (fresh?.documents || []).filter(
//               (d) => String(d.reqId) === String(reqId)
//             ),
//           };
//         })
//       );
//     } catch (e) {
//       console.error("refreshRow failed", e);
//     }
//   };

//   // flatten rows for table; hold reqId/noOfUsr only on first row for that request
//   const flat = [];
//   rows.forEach((r) => {
//     const n = r.details?.length || 0;
//     (r.details || []).forEach((d, idx) => {
//       flat.push({
//         reqId: idx === 0 ? r.master.reqId : "",
//         noOfUsr: idx === 0 ? n : "",
//         master: r.master,
//         detail: d,
//         documents: r.documents,
//       });
//     });
//   });

//   return (
//     <AjaxValidation>
//       <div className="mt-2">
//         <div className="container-fluid">
//           <h6>Agent Priority Cases</h6>

//           <div className="row mt-2 mb-3">
//             <div className="col-sm-12">
//               <div className="box_card">
//                 <div className="form-group row">
//                   <div className="col-sm-12">
//                     <div className="table-responsive holiday-container">
//                       <table className="table table-bordered">
//                         <thead className="table-light">
//                           <tr>
//                             {cols.map((c) => (
//                               <th key={c}>{c}</th>
//                             ))}
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {loading ? (
//                             <tr>
//                               <td colSpan={cols.length}>Loading…</td>
//                             </tr>
//                           ) : flat.length === 0 ? (
//                             <tr>
//                               <td colSpan={cols.length} className="text-muted">
//                                 No records
//                               </td>
//                             </tr>
//                           ) : (
//                             flat.map((r, i) => {
//                               const first = r.detail || {};
//                               return (
//                                 <tr
//                                   key={`${r.master?.reqId}-${first?.dtlId}-${i}`}
//                                 >
//                                   <td>{r.reqId}</td>
//                                   <td>{r.noOfUsr}</td>
//                                   <td>
//                                     {`${first.fName || ""} ${
//                                       first.lName || ""
//                                     }`.trim() || "-"}
//                                   </td>
//                                   <td>{r.master?.mailId || "-"}</td>
//                                   <td>{first.ppn || "-"}</td>
//                                   <td>{first.wpn || "-"}</td>
//                                   <td>{fmtDMY(first.dob) || "-"}</td>
//                                   <td>{fmtDMY(first.wpndt) || "-"}</td>
//                                   <td>{toIST(r.master?.submitOn) || "-"}</td>
//                                   <td>{r.master?.vac || "-"}</td>
//                                   <td>Submitted</td>
//                                   <td>
//                                     <button
//                                       className="btnlink"
//                                       onClick={() =>
//                                         setActive({
//                                           master: r.master,
//                                           detail: r.detail,
//                                           documents: r.documents,
//                                         })
//                                       }
//                                     >
//                                       View
//                                     </button>
//                                   </td>
//                                 </tr>
//                               );
//                             })
//                           )}
//                         </tbody>
//                       </table>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>

//           {active && (
//             <CaseModal
//               show={!!active}
//               row={active}
//               onClose={() => setActive(null)}
//               onWholeListRefresh={load}
//               refreshRow={refreshRow}
//             />
//           )}
//         </div>
//       </div>
//     </AjaxValidation>
//   );
// }

import React, { useEffect, useMemo, useState } from "react";
import Modal from "react-bootstrap/Modal";
import AjaxValidation from "../hooks/AjaxValidation";
import { useAuth } from "../context/AuthContext";
import {
  agentCases,
  updtDocs,
  updtMastr,
  agentCaseList,
  updtCase,
  docHistory,
} from "../api/client";

/* ---------- tiny utils (fixed date parsing) ---------- */
const fmtDMY = (s) => {
  if (!s) return "";
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return "";
  return `${String(d.getDate()).padStart(2, "0")}/${String(
    d.getMonth() + 1
  ).padStart(2, "0")}/${d.getFullYear()}`;
};
const toIST = (s) => {
  if (!s) return "";
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return "";
  const ist = new Date(d.getTime() + 5.5 * 3600 * 1000);
  const dd = String(ist.getDate()).padStart(2, "0");
  const mm = String(ist.getMonth() + 1).padStart(2, "0");
  const yyyy = ist.getFullYear();
  const hh = String(ist.getHours()).padStart(2, "0");
  const mi = String(ist.getMinutes()).padStart(2, "0");
  return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
};
const statusText = (s) =>
  String(s) === "6"
    ? "Verified"
    : String(s) === "4"
    ? "Blocked"
    : String(s) === "3"
    ? "Rejected"
    : String(s) === "5"
    ? "Re-Submitted"
    : String(s) === "2"
    ? "Submitted"
    : "-";
const statusIsFinal = (s) => ["6", "4", "3"].includes(String(s));
const statusMap = { verify: 6, reject: 3, block: 4 };
const docType = { NULLA: 1, PASS: 2 };

/* ---------- fallbacks (only used if reasoncode_list missing) ---------- */
const PASSPORT_REASON_FALLBACK = [
  { id: "16", reason_code: "NOT ELIGIBLE", reason_comments: "NOT ELIGIBLE" },
  {
    id: "17",
    reason_code: "DOCUMENT NOT CLEAR",
    reason_comments:
      "Passport copy uploaded is not legible due to low resolution or clarity in scanning",
  },
  {
    id: "19",
    reason_code: "DETAILS MISMATCH",
    reason_comments:
      "Personal details (First name or last name or date of birth or passport No.) entered do not match the passport copy",
  },
  {
    id: "21",
    reason_code: "DUPLICATE ENTRY",
    reason_comments:
      "The Nulla Osta and Passport have already been submitted for appointment",
  },
  {
    id: "22",
    reason_code: "EXPIRED PASSPORT",
    reason_comments:
      "The Passport uploaded is expired. Kindly renew your passport and apply again.",
  },
  {
    id: "23",
    reason_code: "INCOMPLETE PASSPORT",
    reason_comments:
      "The passport copy uploaded is incomplete. Kindly upload first and last page of your passport",
  },
  {
    id: "26",
    reason_code: "GROUP SUBMISSION SENT BACK FOR RE_ENTRY",
    reason_comments:
      "Please note that the form of one or more applicants in your group submission has been sent back for re-entry. Kindly re-enter the form carefully checking that all details match.",
  },
];
const NULLA_REASON_FALLBACK = [
  {
    id: "1",
    reason_code: "NOT ELIGIBLE",
    reason_comments:
      "The Nulla Osta uploaded is not eligible for Family Reunion Visa",
  },
  {
    id: "2",
    reason_code: "NOT A NULLA OSTA",
    reason_comments: "Not a Nulla Osta",
  },
  {
    id: "3",
    reason_code: "DOCUMENT NOT CLEAR",
    reason_comments:
      "Nulla Osta uploaded is not legible due to low resolution or clarity in scanning",
  },
  {
    id: "4",
    reason_code: "INCOMPLETE DOCUMENT",
    reason_comments: "Nulla osta uploaded is not complete",
  },
  {
    id: "5",
    reason_code: "INVALID DATE OF ISSUE",
    reason_comments:
      "The date of issue is not correct for the attached Nulla Osta.",
  },
  {
    id: "6",
    reason_code: "DETAILS MISMATCH",
    reason_comments:
      "Nulla Osta Protocol number or (First name or last name or date of birth or passport No.) do not match the Nulla Osta copy",
  },
  {
    id: "7",
    reason_code: "BLOCKED ISSUE DATE",
    reason_comments:
      "The Uploaded Nulla Osta does not qualify for Priority Queue. Please upload the details in the Normal Queue",
  },
  {
    id: "8",
    reason_code: "DUPLICATE ENTRY",
    reason_comments:
      "The Nulla Osta and Passport have already been submitted for appointment",
  },
];

/* ---------------- doc helpers ---------------- */
const getDoc = (row, dtlId, type) =>
  (row?.documents || []).find(
    (d) => String(d.dtlId) === String(dtlId) && Number(d.type) === Number(type)
  );
const getDocStatus = (row, dtlId, type) =>
  getDoc(row, dtlId, type)?.docStatus ?? 0;

const computeDtlStatusFromDocs = (passSts, nullaSts) => {
  if (!statusIsFinal(passSts) || !statusIsFinal(nullaSts)) return null;
  if (String(passSts) === "4" || String(nullaSts) === "4") return 4;
  if (String(passSts) === "6" && String(nullaSts) === "6") return 6;
  return 3;
};
const computeMasterStatus = (allDtlStatuses) => {
  const finals = allDtlStatuses.filter((s) => s !== null && statusIsFinal(s));
  if (finals.length !== allDtlStatuses.length) return null;
  const all6 = allDtlStatuses.every((s) => String(s) === "6");
  const all4 = allDtlStatuses.every((s) => String(s) === "4");
  if (all6) return 6;
  if (all4) return 4;
  return 7; // partially verified / mixed
};

const statusToAct = (s) => {
  const c = String(s);
  if (c === "6") return "verify";
  if (c === "4") return "block";
  if (c === "3") return "reject";
  return "";
};

const readReasonIdFromDoc = (d) => {
  const cand = [
    d?.reason,
    d?.reasonId,
    d?.reason_id,
    d?.reason_code_id,
    d?.reject_reason_id,
    d?.block_reason_id,
    d?.block_reason,
  ];
  for (const v of cand) {
    if (
      v !== undefined &&
      v !== null &&
      String(v) !== "" &&
      String(v) !== "0"
    ) {
      return String(v);
    }
  }
  return "0";
};

const readCommentsFromDoc = (d) => {
  const cand = [
    d?.comments,
    d?.comment,
    d?.verifyComments,
    d?.verify_comments,
    d?.remarks,
    d?.remark,
    d?.block_reason_text,
    d?.reject_reason_text,
  ];
  for (const v of cand) {
    if (v && String(v).trim() !== "") return String(v);
  }
  return "";
};

/* ========================= Modal (editable, always mounted) ========================= */
function CaseModal({ show, onClose, row, onWholeListRefresh, refreshRow }) {
  const { authData } = useAuth();
  const [tab, setTab] = useState("passport"); // passport | nulla | history
  const [saving, setSaving] = useState(false);
  // const [submitted, setSubmitted] = useState(false);
  const [submittedKeys, setSubmittedKeys] = useState({});
  // SAFETY: never early-return; keep hooks order stable.
  const safeRow = row || { master: {}, detail: {}, documents: [] };

  // dynamic reasons (fallbacks if list missing)
  const reasonList = authData?.ajaxPayload?.reasoncode_list || [];
  const nullaReasonOptions =
    reasonList.length > 0
      ? reasonList
          .filter(
            (r) => String(r.type) === "1" && String(r.status ?? "1") === "1"
          )
          .map((r) => ({
            id: String(r.id),
            reason_code: r.reason_code,
            reason_comments: r.reason_comments || "",
          }))
      : NULLA_REASON_FALLBACK;
  const passportReasonOptions =
    reasonList.length > 0
      ? reasonList
          .filter(
            (r) => String(r.type) === "2" && String(r.status ?? "1") === "1"
          )
          .map((r) => ({
            id: String(r.id),
            reason_code: r.reason_code,
            reason_comments: r.reason_comments || "",
          }))
      : PASSPORT_REASON_FALLBACK;

  const autoCommentMap = useMemo(() => {
    const m = {};
    [...nullaReasonOptions, ...passportReasonOptions].forEach((r) => {
      m[String(r.id)] = r.reason_comments || "";
    });
    return m;
  }, [nullaReasonOptions, passportReasonOptions]);

  const statusNameById = useMemo(() => {
    const list = authData?.ajaxPayload?.master_status_list || [];
    const map = {};
    for (const s of list)
      map[String(s.request_status_id)] = s.request_status_name;
    return map;
  }, [authData?.ajaxPayload?.master_status_list]);

  const statusChip = (code) => {
    const c = String(code || "");
    const cls =
      c === "6"
        ? "text-success fw-semibold"
        : c === "4"
        ? "text-danger fw-semibold"
        : "text-secondary";
    const nm = statusNameById[c] || statusText(c);
    return <span className={cls}>{nm}</span>;
  };

  const [docUiState, setDocUiState] = useState({});
  const [loadingHistory, setLoadingHistory] = useState(false);

  const det = safeRow?.detail || {};
  const reqId =
    safeRow?.master?.reqId ||
    safeRow?.master?.request_id ||
    safeRow?.master?.reqid ||
    safeRow?.master?.reqIdFk ||
    "";

  const passDoc =
    safeRow?.documents?.find(
      (d) => Number(d.type) === 2 && String(d.dtlId) === String(det?.dtlId)
    ) ||
    safeRow?.documents?.find(
      (d) =>
        /pass/i.test(String(d.file || d.file_name || "")) &&
        String(d.dtlId) === String(det?.dtlId)
    );
  const nullaDoc =
    safeRow?.documents?.find(
      (d) => Number(d.type) === 1 && String(d.dtlId) === String(det?.dtlId)
    ) ||
    safeRow?.documents?.find(
      (d) =>
        /nulla|osta/i.test(String(d.file || d.file_name || "")) &&
        String(d.dtlId) === String(det?.dtlId)
    );

  // openDocument URL uses session_id + document_key
  const buildOpenUrl = (fileName) => {
    const f = fileName || "";
    if (!f) return "";
    const sessionId = authData?.session_id;
    const documentKey =
      authData?.ajaxPayload?.document_key ?? authData?.document_key;
    if (!sessionId || !documentKey) return "";
    return `https://vfseu.mioot.com/forms/UAT/ITAIND/openDocument/?${sessionId}_${documentKey}_${f}`;
  };

  const activeType = tab === "passport" ? docType.PASS : docType.NULLA;
  const activeDoc = tab === "passport" ? passDoc : nullaDoc;
  const activeKey = `${det?.dtlId}:${activeType}`;

  const activeIframeSrc =
    tab === "history"
      ? ""
      : buildOpenUrl(activeDoc?.file || activeDoc?.file_name);

  /* ================= History (two tracks + right preview) ================= */
  const [historyFocus, setHistoryFocus] = useState("nulla"); // 'passport' | 'nulla'
  const [historyOverrideFile, setHistoryOverrideFile] = useState(null);
  const [passUsrActs, setPassUsrActs] = useState([]);
  const [passCusActs, setPassCusActs] = useState([]);
  const [nullaUsrActs, setNullaUsrActs] = useState([]);
  const [nullaCusActs, setNullaCusActs] = useState([]);

  const rightPreviewUrl = useMemo(() => {
    const base =
      historyFocus === "passport"
        ? passDoc?.file || passDoc?.file_name
        : nullaDoc?.file || nullaDoc?.file_name;
    const file = historyOverrideFile || base;
    return buildOpenUrl(file);
  }, [
    historyFocus,
    historyOverrideFile,
    passDoc?.file,
    passDoc?.file_name,
    nullaDoc?.file,
    nullaDoc?.file_name,
  ]);

  useEffect(() => {
    // guard: only when history tab AND doc IDs available
    if (tab !== "history") return;
    let abort = false;

    const load = async (doc, setUsr, setCus) => {
      const docId = doc?.docId || doc?.id;
      if (!docId) {
        setUsr([]);
        setCus([]);
        return;
      }
      try {
        const res = await docHistory({
          session_id: authData?.session_id,
          sessionToken:
            authData?.session_token ||
            authData?.sessionToken ||
            authData?.Globalsessiontoken,
          docId,
        });
        if (abort) return;
        setUsr(Array.isArray(res?.UsrActivity) ? res.UsrActivity : []);
        setCus(Array.isArray(res?.CustActivity) ? res.CustActivity : []);
      } catch {
        if (!abort) {
          setUsr([]);
          setCus([]);
        }
      }
    };

    (async () => {
      setLoadingHistory(true);
      setHistoryFocus("nulla");
      setHistoryOverrideFile(null);
      await Promise.all([
        load(passDoc, setPassUsrActs, setPassCusActs),
        load(nullaDoc, setNullaUsrActs, setNullaCusActs),
      ]);
      if (!abort) setLoadingHistory(false);
    })();

    return () => {
      abort = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, authData?.session_id, passDoc?.docId, nullaDoc?.docId]);

  const buildHistoryRows = (kind) => {
    const cus = kind === "passport" ? passCusActs : nullaCusActs;
    const docObj = kind === "passport" ? passDoc : nullaDoc;
    const docFile = docObj?.file || docObj?.file_name;

    const rawStat = docObj?.docStatus ?? docObj?.docStstus;
    const actionNm = statusNameById[String(rawStat)] ?? statusText(rawStat);
    const byNm = docObj?.vefifyBy || docObj?.verifyby || "-";

    const rows = [];
    let idx = 1;

    const pushRow = (action, by, on, file) =>
      rows.push({
        idx: idx++,
        action,
        by,
        on: toIST(on) || "-",
        file: file || "-",
      });

    if (Array.isArray(cus) && cus.length) {
      cus.forEach((c) =>
        pushRow(actionNm, byNm, c.verifyOn || c.addOn, c.file)
      );
    } else if (docFile) {
      pushRow(actionNm, byNm, docObj?.verifyOn || docObj?.addOn, docFile);
    }

    return rows;
  };

  const passportRows = buildHistoryRows("passport");
  const nullaRows = buildHistoryRows("nulla");

  // local UI state for act/reason/comments + lock
  const lockedFromBackend = statusIsFinal(activeDoc?.docStatus);
  const baseUi = docUiState[activeKey] || {
    act: "",
    reason: "0",
    comments: "",
  };

  const fallbackAct = statusToAct(activeDoc?.docStatus);
  const fallbackReason = readReasonIdFromDoc(activeDoc);
  const fallbackComments = readCommentsFromDoc(activeDoc);

  const current = {
    ...baseUi,
    act: baseUi.act || (lockedFromBackend ? fallbackAct : ""),
    reason:
      baseUi.reason && baseUi.reason !== "0"
        ? baseUi.reason
        : lockedFromBackend
        ? fallbackReason
        : "0",
    comments: baseUi.comments || (lockedFromBackend ? fallbackComments : ""),
    locked: lockedFromBackend,
  };

  // lock states follow backend statuses; guard when we don't have dtlId
  useEffect(() => {
    if (!det?.dtlId) return;

    setDocUiState((p) => {
      const next = { ...p };

      const passKey = `${det?.dtlId}:${docType.PASS}`;
      const nullaKey = `${det?.dtlId}:${docType.NULLA}`;

      const passLocked = statusIsFinal(passDoc?.docStatus);
      const nullaLocked = statusIsFinal(nullaDoc?.docStatus);

      const prevP = p[passKey] || { act: "", reason: "0", comments: "" };
      next[passKey] = {
        ...prevP,
        locked: passLocked,
        act: prevP.act || (passLocked ? statusToAct(passDoc?.docStatus) : ""),
        reason:
          prevP.reason && prevP.reason !== "0"
            ? prevP.reason
            : passLocked
            ? readReasonIdFromDoc(passDoc)
            : "0",
        comments:
          prevP.comments || (passLocked ? readCommentsFromDoc(passDoc) : ""),
      };

      const prevN = p[nullaKey] || { act: "", reason: "0", comments: "" };
      next[nullaKey] = {
        ...prevN,
        locked: nullaLocked,
        act: prevN.act || (nullaLocked ? statusToAct(nullaDoc?.docStatus) : ""),
        reason:
          prevN.reason && prevN.reason !== "0"
            ? prevN.reason
            : nullaLocked
            ? readReasonIdFromDoc(nullaDoc)
            : "0",
        comments:
          prevN.comments || (nullaLocked ? readCommentsFromDoc(nullaDoc) : ""),
      };

      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [det?.dtlId, passDoc?.docStatus, nullaDoc?.docStatus]);

  // auto-fill comments when picking a reason on reject/block
  useEffect(() => {
    if (!det?.dtlId) return;
    if (current.act !== "reject" && current.act !== "block") return;
    if (current.reason && current.reason !== "0") {
      const auto = autoCommentMap[String(current.reason)] || "";
      setDocUiState((p) => ({
        ...p,
        [activeKey]: { ...current, comments: auto },
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current.reason, activeKey]);

  // const setAct = (v) =>
  //   setDocUiState((p) => ({
  //     ...p,
  //     [activeKey]: {
  //       ...current,
  //       act: v,
  //       reason: v === "verify" ? "0" : current.reason,
  //     },
  //   }));

  const setAct = (v) =>
    setDocUiState((p) => ({
      ...p,
      [activeKey]: {
        ...current,
        act: v,
        // always clear on action change
        reason: "0",
        comments: "",
        // keep existing locked flag if present
        locked: current.locked,
      },
    }));
  const setReason = (v) =>
    setDocUiState((p) => ({
      ...p,
      [activeKey]: { ...current, reason: v },
    }));
  const setComments = (v) =>
    setDocUiState((p) => ({
      ...p,
      [activeKey]: { ...current, comments: v },
    }));

  // disable while saving OR once locked by backend or post-submit
  // const disableInputs = saving || !!current.locked || submitted;
  const disableInputs =
    saving || !!current.locked || !!submittedKeys[activeKey];
  async function maybeAdvanceStatusesAfterDocs() {
    if (!reqId) return;

    const fresh = await agentCaseList({
      session_id: authData?.session_id,
      sessionToken:
        authData?.session_token ||
        authData?.sessionToken ||
        authData?.Globalsessiontoken,
      reqId,
    });

    const mergedRow = {
      master:
        (fresh?.master || []).find((m) => String(m.reqId) === String(reqId)) ||
        safeRow.master,
      details: (fresh?.details || []).filter(
        (d) => String(d.reqId) === String(reqId)
      ),
      documents: (fresh?.documents || []).filter(
        (d) => String(d.reqId) === String(reqId)
      ),
    };

    const dId = det?.dtlId;
    if (!dId) return;

    const pSts = getDocStatus(mergedRow, dId, docType.PASS);
    const nSts = getDocStatus(mergedRow, dId, docType.NULLA);
    const dtlFinal = computeDtlStatusFromDocs(pSts, nSts);

    if (dtlFinal !== null) {
      await updtCase({
        session_id: authData?.session_id,
        sessionToken:
          authData?.session_token ||
          authData?.sessionToken ||
          authData?.Globalsessiontoken,
        reqId,
        dtlId: dId,
        dtlStatus: dtlFinal,
      });
      await refreshRow?.(reqId);
    }

    const allDtlStatuses = mergedRow.details.map((d) => {
      const ps = getDocStatus(mergedRow, d.dtlId, docType.PASS);
      const ns = getDocStatus(mergedRow, d.dtlId, docType.NULLA);
      return computeDtlStatusFromDocs(ps, ns);
    });

    if (allDtlStatuses.every((s) => s !== null)) {
      const mas = computeMasterStatus(allDtlStatuses);
      if (mas !== null) {
        await updtMastr({
          session_id: authData?.session_id,
          sessionToken:
            authData?.session_token ||
            authData?.sessionToken ||
            authData?.Globalsessiontoken,
          reqId,
          reqStatus: mas,
        });
        await onWholeListRefresh?.();
      }
    }
  }

  async function handleSave(e) {
    e?.preventDefault();

    const { act, reason, comments } = current;

    if (!act) {
      alert("Please choose Verify / Reject / Block.");
      return;
    }

    if ((act === "reject" || act === "block") && (!reason || reason === "0")) {
      alert("Please select a reason for Reject/Block.");
      return;
    }

    // if (act === "verify" && !String(comments || "").trim()) {
    //   alert("Please enter comments before Verifying.");
    //   return;
    // }

    if (!(activeDoc?.docId || activeDoc?.id)) {
      alert("No document found to update.");
      return;
    }

    try {
      setSaving(true);

      await updtDocs({
        session_id: authData?.session_id,
        sessionToken:
          authData?.session_token ||
          authData?.sessionToken ||
          authData?.Globalsessiontoken,
        reqId,
        dtlId: det?.dtlId,
        docId: activeDoc.docId || activeDoc.id,
        status: statusMap[act],
        reason: act === "verify" ? "0" : String(reason || "0"),
        comments: comments || "",
      });

      // Lock this document's UI locally so it stays disabled even after close/reopen
      setDocUiState((p) => ({
        ...p,
        [activeKey]: { ...p[activeKey], locked: true },
      }));
      // setSubmitted(true);
      setSubmittedKeys((m) => ({ ...m, [activeKey]: true }));
      await maybeAdvanceStatusesAfterDocs();
    } catch (e) {
      console.error(e);
      alert(e?.message || "Server rejected the update.");
    } finally {
      setSaving(false);
    }
  }

  const fullName = `${det?.fName || ""} ${det?.lName || ""}`.trim();
  const vacNameById = useMemo(() => {
    const vacList = authData?.ajaxPayload?.vac_list || [];
    const m = {};
    for (const v of vacList) {
      // try common field names for id & name
      const id = String(v.vac_id ?? v.id ?? v.code ?? v.vacCode ?? v.vac ?? "");
      const nm = v.vac_name ?? v.name ?? v.vac ?? id;
      if (id) m[id] = nm;
    }
    return m;
  }, [authData?.ajaxPayload?.vac_list]);

  const getVacName = (id) => vacNameById[String(id)] ?? id ?? "-";
  return (
    <Modal
      show={show}
      onHide={onClose}
      size="xl"
      centered
      className="newcase_modal-dialog"
      backdrop="static"
    >
      <Modal.Header closeButton>
        <Modal.Title>
          <h6 className="fs-6">Reference ID - {reqId || ""}</h6>
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="row g-3">
          {/* Left side */}
          <div className="col-sm-8">
            <div className="mb-2 d-flex gap-2 flex-wrap">
              <button
                // className={`btn btn-sm ${tab === "passport" ? "btn" : ""}`}
                className={`btn ${tab === "passport" ? "text-white" : ""}`}
                style={{
                  backgroundColor: tab === "passport" ? "#f26722" : "#f6e6df",
                  fontSize: "0.8rem",
                }}
                onClick={() => setTab("passport")}
                disabled={saving}
              >
                Passport Document
              </button>
              <button
                className={`btn ${tab === "nulla" ? "text-white" : ""}`}
                style={{
                  backgroundColor: tab === "nulla" ? "#f26722" : "#f6e6df",
                  fontSize: "0.8rem",
                }}
                onClick={() => setTab("nulla")}
                disabled={saving}
              >
                Nulla Osta Document
              </button>
              <button
                className={`btn ${tab === "history" ? "text-white" : ""}`}
                style={{
                  backgroundColor: tab === "history" ? "#f26722" : "#f6e6df",
                  fontSize: "0.8rem",
                }}
                onClick={() => setTab("history")}
                disabled={saving}
              >
                Document History
              </button>
            </div>

            {tab !== "history" ? (
              <div
                style={{
                  height: 520,
                  border: "1px solid #ddd",
                  borderRadius: 6,
                  overflow: "hidden",
                  background: "#fff",
                }}
              >
                {activeIframeSrc ? (
                  <iframe
                    title="doc"
                    src={activeIframeSrc}
                    width="100%"
                    height="100%"
                    frameBorder="0"
                  />
                ) : (
                  <div className="p-3 text-muted">No file found.</div>
                )}
              </div>
            ) : (
              <div className="pdf_view tab_scroll">
                <style>{`
                  .history_table>:not(caption)>*>*{border-width:0 1px!important;font-size:12px!important}
                  .status-flex{display:flex;justify-content:space-between;align-items:center;text-align:center;padding:.5rem 1rem;border:1px solid #dee2e6;font-size:14px}
                  .history-row{cursor:pointer}
                  .clickable{cursor:pointer;text-decoration:underline}
                `}</style>

                {/* Passport block */}
                <div
                  className="status-flex"
                  onClick={() => {
                    setHistoryFocus("passport");
                    setHistoryOverrideFile(null);
                  }}
                >
                  <div>
                    Passport : <span>{det?.ppn || "-"}</span>
                  </div>
                  <div>Status : {statusChip(passDoc?.docStatus)}</div>
                </div>
                <div className="table-responsive mt-2">
                  <table className="table table-bordered history_table text-left">
                    <thead className="table-active">
                      <tr>
                        <th>#</th>
                        <th>Action</th>
                        <th>Actioned By</th>
                        <th>Actioned On</th>
                        <th>Uploaded Passport</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loadingHistory ? (
                        <tr>
                          <td colSpan={5}>Loading…</td>
                        </tr>
                      ) : passportRows.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="text-muted">
                            —
                          </td>
                        </tr>
                      ) : (
                        passportRows.map((r) => (
                          <tr
                            key={`pr-${r.idx}`}
                            className="history-row"
                            onClick={() => {
                              setHistoryFocus("passport");
                              if (r.file && r.file !== "-")
                                setHistoryOverrideFile(r.file);
                            }}
                          >
                            <td>{r.idx}</td>
                            <td>{r.action}</td>
                            <td>{r.by}</td>
                            <td>{r.on}</td>
                            <td className="clickable">{r.file || "-"}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Nulla block */}
                <div
                  className="status-flex mt-3"
                  onClick={() => {
                    setHistoryFocus("nulla");
                    setHistoryOverrideFile(null);
                  }}
                >
                  <div>
                    Nulla Osta : <span>{det?.wpn || "-"}</span>
                  </div>
                  <div>Status : {statusChip(nullaDoc?.docStatus)}</div>
                </div>
                <div className="table-responsive mt-2">
                  <table className="table table-bordered history_table text-left">
                    <thead className="table-active">
                      <tr>
                        <th>#</th>
                        <th>Action</th>
                        <th>Actioned By</th>
                        <th>Actioned On</th>
                        <th>Uploaded Nulla Osta</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loadingHistory ? (
                        <tr>
                          <td colSpan={5}>Loading…</td>
                        </tr>
                      ) : nullaRows.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="text-muted">
                            —
                          </td>
                        </tr>
                      ) : (
                        nullaRows.map((r) => (
                          <tr
                            key={`nr-${r.idx}`}
                            className="history-row"
                            onClick={() => {
                              setHistoryFocus("nulla");
                              if (r.file && r.file !== "-")
                                setHistoryOverrideFile(r.file);
                            }}
                          >
                            <td>{r.idx}</td>
                            <td>{r.action}</td>
                            <td>{r.by}</td>
                            <td>{r.on}</td>
                            <td className="clickable">{r.file || "-"}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* Right side */}
          <div className="col-sm-4">
            {tab === "history" ? (
              <div
                className="img_view text-center"
                style={{
                  height: 520,
                  border: "1px solid #ddd",
                  borderRadius: 6,
                  overflow: "hidden",
                  background: "#fff",
                }}
              >
                {rightPreviewUrl ? (
                  <iframe
                    title="history-preview"
                    src={rightPreviewUrl}
                    width="100%"
                    height="100%"
                    frameBorder="0"
                  />
                ) : (
                  <div className="p-3 text-muted">No file to preview.</div>
                )}
              </div>
            ) : (
              <div className="border rounded p-2">
                <div className="fw-semibold mb-2">Customer Details :</div>
                <div className="newcase-container">
                  {[
                    ["Full Name", fullName || "-"],
                    ["Email Id", safeRow?.master?.mailId || "-"],
                    ["Passport Number", det?.ppn || "-"],
                    ["Nulla osta No", det?.wpn || "-"],
                    ["DOB", fmtDMY(det?.dob) || "-"],
                    ["Issue Date", fmtDMY(det?.wpndt) || "-"],
                    ["Submited On", toIST(safeRow?.master?.submitOn) || "-"],
                    ["VAC", getVacName(row?.master?.vac)],
                    ["Status", statusText(activeDoc?.docStatus)],
                  ].map(([l, v], i) => (
                    <div className="form-group row border-bottom" key={i}>
                      <div className="col-sm-6">
                        <label className="form-label">{l}</label>
                      </div>
                      <div className="col-sm-6">
                        <label className="form-label">{v}</label>
                      </div>
                    </div>
                  ))}

                  {/* actions (hidden on history) */}
                  <div className="form-group row">
                    <div className="col-sm-12">
                      <div className="mt-2 small">
                        <div className="mb-2">Action</div>
                        <div className="d-flex gap-3">
                          <label className="d-flex align-items-center gap-1">
                            <input
                              type="radio"
                              name={`act-${activeKey}`}
                              value="verify"
                              checked={current.act === "verify"}
                              onChange={() => setAct("verify")}
                              disabled={disableInputs}
                            />
                            Verify
                          </label>
                          <label className="d-flex align-items-center gap-1">
                            <input
                              type="radio"
                              name={`act-${activeKey}`}
                              value="reject"
                              checked={current.act === "reject"}
                              onChange={() => setAct("reject")}
                              disabled={disableInputs}
                            />
                            Reject
                          </label>
                          <label className="d-flex align-items-center gap-1">
                            <input
                              type="radio"
                              name={`act-${activeKey}`}
                              value="block"
                              checked={current.act === "block"}
                              onChange={() => setAct("block")}
                              disabled={disableInputs}
                            />
                            Block
                          </label>
                        </div>

                        {(current.act === "reject" ||
                          current.act === "block") && (
                          <div className="mt-2">
                            <div className="mb-1">Reason</div>
                            <select
                              className="form-select form-select-sm"
                              value={current.reason}
                              onChange={(e) => setReason(e.target.value)}
                              disabled={disableInputs}
                            >
                              <option value="0">---Select---</option>
                              {(tab === "passport"
                                ? passportReasonOptions
                                : nullaReasonOptions
                              ).map((r) => (
                                <option key={r.id} value={String(r.id)}>
                                  {r.reason_code}
                                </option>
                              ))}
                            </select>
                          </div>
                        )}

                        <div className="mt-2">
                          <div className="mb-1">Comments :</div>
                          <textarea
                            className="form-control"
                            rows={5}
                            value={current.comments}
                            onChange={(e) => setComments(e.target.value)}
                            disabled={disableInputs}
                          />
                        </div>

                        <div className="d-flex gap-2 mt-3">
                          <button className="btn-lg go-btn" onClick={onClose}>
                            Close
                          </button>
                          <button
                            className="btn-lg go-btn"
                            onClick={handleSave}
                            disabled={disableInputs || saving}
                          >
                            {saving ? "Submit" : "Submit"}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

/* =========================================================
   Main (flat table, no VAC edit, editable modal)
========================================================= */
export default function AgentNormalCases() {
  const { authData } = useAuth();
  const [rows, setRows] = useState([]); // array of {master, details[], documents[]}
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(null); // {master, detail, documents}
  const vacNameById = useMemo(() => {
    const vacList = authData?.ajaxPayload?.vac_list || [];
    const m = {};
    for (const v of vacList) {
      // try common field names for id & name
      const id = String(v.vac_id ?? v.id ?? v.code ?? v.vacCode ?? v.vac ?? "");
      const nm = v.vac_name ?? v.name ?? v.vac ?? id;
      if (id) m[id] = nm;
    }
    return m;
  }, [authData?.ajaxPayload?.vac_list]);

  const getVacName = (id) => vacNameById[String(id)] ?? id ?? "-";
  const cols = useMemo(
    () => [
      "Request Id",
      "No. Of Applicants",
      "Full Name",
      "Email Id",
      "Passport Number",
      "Nulla osta No",
      "DOB",
      "Issue Date",
      "Submited On",
      "VAC",
      "Status",
      "Action",
    ],
    []
  );

  async function load() {
    setLoading(true);
    try {
      const res = await agentCases({
        session_id: authData?.session_id,
        sessionToken:
          authData?.session_token ||
          authData?.sessionToken ||
          authData?.Globalsessiontoken,
        priority: 0,
      });

      if (Array.isArray(res?.master)) {
        const out = res.master.map((m) => ({
          master: m,
          details: (res.details || []).filter(
            (d) => String(d.reqId) === String(m.reqId)
          ),
          documents: (res.documents || []).filter(
            (d) => String(d.reqId) === String(m.reqId)
          ),
        }));
        setRows(out);
      } else {
        setRows([]);
      }
    } catch (e) {
      console.error(e);
      setRows([]);
      alert("Failed to load cases.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refreshRow = async (reqId) => {
    try {
      const fresh = await agentCaseList({
        session_id: authData?.session_id,
        sessionToken:
          authData?.session_token ||
          authData?.sessionToken ||
          authData?.Globalsessiontoken,
        reqId,
      });
      setRows((prev) =>
        prev.map((r) => {
          if (String(r.master.reqId) !== String(reqId)) return r;
          return {
            master:
              (fresh?.master || []).find(
                (m) => String(m.reqId) === String(reqId)
              ) || r.master,
            details: (fresh?.details || []).filter(
              (d) => String(d.reqId) === String(reqId)
            ),
            documents: (fresh?.documents || []).filter(
              (d) => String(d.reqId) === String(reqId)
            ),
          };
        })
      );
    } catch (e) {
      console.error("refreshRow failed", e);
    }
  };

  // flatten rows for table; hold reqId/noOfUsr only on first row for that request
  const flat = [];
  rows.forEach((r) => {
    const n = r.details?.length || 0;
    (r.details || []).forEach((d, idx) => {
      flat.push({
        reqId: idx === 0 ? r.master.reqId : "",
        noOfUsr: idx === 0 ? n : "",
        master: r.master,
        detail: d,
        documents: r.documents,
      });
    });
  });

  return (
    <AjaxValidation>
      <div className="mt-2">
        <div className="container-fluid">
          <h6>Agent Normal Cases</h6>

          <div className="row mt-2 mb-3">
            <div className="col-sm-12">
              <div className="box_card">
                <div className="form-group row">
                  <div className="col-sm-12">
                    <div className="table-responsive holiday-container">
                      <table className="table table-bordered">
                        <thead className="table-light">
                          <tr>
                            {cols.map((c) => (
                              <th key={c}>{c}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {loading ? (
                            <tr>
                              <td colSpan={cols.length}>Loading…</td>
                            </tr>
                          ) : flat.length === 0 ? (
                            <tr>
                              <td colSpan={cols.length} className="text-muted">
                                No records
                              </td>
                            </tr>
                          ) : (
                            flat.map((r, i) => {
                              const first = r.detail || {};
                              return (
                                <tr
                                  key={`${r.master?.reqId}-${first?.dtlId}-${i}`}
                                >
                                  <td>{r.reqId}</td>
                                  <td>{r.noOfUsr}</td>
                                  <td>
                                    {`${first.fName || ""} ${
                                      first.lName || ""
                                    }`.trim() || "-"}
                                  </td>
                                  <td>{r.master?.mailId || "-"}</td>
                                  <td>{first.ppn || "-"}</td>
                                  <td>{first.wpn || "-"}</td>
                                  <td>{fmtDMY(first.dob) || "-"}</td>
                                  <td>{fmtDMY(first.wpndt) || "-"}</td>
                                  <td>{toIST(r.master?.submitOn) || "-"}</td>
                                  <td>{getVacName(r.master?.vac)}</td>
                                  {/* <td>{r.master?.vac || "-"}</td> */}

                                  <td>Submitted</td>
                                  <td>
                                    <button
                                      className="btnlink"
                                      onClick={() =>
                                        setActive({
                                          master: r.master,
                                          detail: r.detail,
                                          documents: r.documents,
                                        })
                                      }
                                    >
                                      View
                                    </button>
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Keep the modal mounted at all times; pass row=null when closed */}
          <CaseModal
            show={!!active}
            row={active}
            onClose={() => setActive(null)}
            onWholeListRefresh={load}
            refreshRow={refreshRow}
          />
        </div>
      </div>
    </AjaxValidation>
  );
}
