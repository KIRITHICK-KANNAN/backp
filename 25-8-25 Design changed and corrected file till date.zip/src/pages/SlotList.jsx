// import React from "react";
// import { fetchSlots, deleteSlots } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import AjaxValidation from "../hooks/AjaxValidation";

// /* ---------- small helpers ---------- */
// function toYMD(date) {
//   if (!date) return "";
//   const d = new Date(date);
//   if (Number.isNaN(d.getTime())) return "";
//   const y = d.getFullYear();
//   const m = String(d.getMonth() + 1).padStart(2, "0");
//   const dd = String(d.getDate()).padStart(2, "0");
//   return `${y}-${m}-${dd}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yy = d.getFullYear();
//   return `${dd}-${mm}-${yy}`;
// }
// function fmtTime(hms) {
//   if (!hms) return "";
//   try {
//     if (typeof hms === "string" && hms.includes(":")) return hms;
//     const d = new Date(hms);
//     if (Number.isNaN(d.getTime())) return "";
//     return `${String(d.getHours()).padStart(2, "0")}:${String(
//       d.getMinutes()
//     ).padStart(2, "0")}:${String(d.getSeconds()).padStart(2, "0")}`;
//   } catch {
//     return "";
//   }
// }

// /* ---------- page ---------- */
// export default function SlotList() {
//   const { authData } = useAuth?.() || { authData: null };

//   // Filters
//   const [vac, setVac] = React.useState("0");
//   const [status, setStatus] = React.useState("0"); // 0 All, 1 Available, 2 Booked
//   const [priority, setPriority] = React.useState(""); // "" All, 0 Normal, 1 Priority
//   const [from, setFrom] = React.useState("");
//   const [to, setTo] = React.useState("");

//   // Data + UI
//   const [rows, setRows] = React.useState([]);
//   const [loading, setLoading] = React.useState(false);
//   const [error, setError] = React.useState("");
//   const [selected, setSelected] = React.useState(() => new Set());
//   const [selectAll, setSelectAll] = React.useState(false);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];

//   // session bits (map robustly)
//   const user_id = authData?.user_id ?? authData?.userid ?? authData?.id ?? "";
//   const session_id = authData?.session_id || "";
//   const session_token = authData?.session_token || "";

//   // Default dates: today .. today+1
//   React.useEffect(() => {
//     const today = new Date();
//     const tomorrow = new Date(Date.now() + 24 * 3600 * 1000);
//     setFrom(toYMD(today));
//     setTo(toYMD(tomorrow));
//   }, []);

//   async function handleSearch() {
//     if (!session_id || !session_token) {
//       setError("Missing session. Please sign in.");
//       return;
//     }
//     setError("");
//     setLoading(true);
//     setSelected(new Set());
//     setSelectAll(false);

//     try {
//       const data = await fetchSlots({
//         user_id,
//         session_id,
//         session_token,
//         vac, // -> vac_id
//         status, // -> slot_status
//         priority, // -> priority
//         from, // -> from_date
//         to, // -> to_date
//         type: 1,
//         startRecord: 1,
//         rows: 1,
//       });
//       setRows(data);
//     } catch (e) {
//       setError(e.message || "Failed to fetch slot list");
//       setRows([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   function toggleSelectOne(id) {
//     setSelected((prev) => {
//       const n = new Set(prev);
//       if (n.has(id)) n.delete(id);
//       else n.add(id);
//       return n;
//     });
//   }

//   function toggleSelectAll() {
//     setSelectAll((p) => !p);
//     setSelected(() => {
//       // When checking "Select All", grab all current row IDs
//       if (!selectAll) {
//         return new Set(
//           rows.map((r) =>
//             String(
//               r.slot_id ?? r.id ?? `${r.vac_id}-${r.slot_time}-${r.slot_date}`
//             )
//           )
//         );
//       }
//       // When unchecking, clear
//       return new Set();
//     });
//   }

//   async function handleDelete() {
//     const ids = Array.from(selected).filter(Boolean);
//     if (!ids.length) {
//       alert("Please select at least one slot to delete.");
//       return;
//     }
//     if (!window.confirm(`Delete ${ids.length} selected slot(s)?`)) return;

//     try {
//       setLoading(true);
//       await deleteSlots({
//         user_id,
//         session_id,
//         session_token,
//         slotIds: ids,
//       });
//       await handleSearch();
//       alert("Deleted successfully.");
//     } catch (e) {
//       console.error(e);
//       alert("Delete failed.");
//     } finally {
//       setLoading(false);
//     }
//   }

//   return (
//     <AjaxValidation>
//       <div className="container-fluid py-3">
//         <h4 className="mb-3">Slot List</h4>

//         {/* Filters */}
//         <div
//           className="d-flex gap-2 align-items-center flex-wrap p-2 mb-3"
//           style={{ background: "#f5f7fa", borderRadius: 8 }}
//         >
//           {/* VAC */}
//           <select
//             className="form-control"
//             style={{ maxWidth: 320 }}
//             value={vac}
//             onChange={(e) => setVac(e.target.value)}
//           >
//             <option value="0">---Select VAC---</option>
//             {vacOptions.map((v) => (
//               <option key={v.vac_id} value={v.vac_id}>
//                 {v.vac_name}
//               </option>
//             ))}
//           </select>

//           {/* Status */}
//           <select
//             className="form-control"
//             style={{ maxWidth: 320 }}
//             value={status}
//             onChange={(e) => setStatus(e.target.value)}
//           >
//             <option value="0">---Select Status---</option>
//             <option value="1">Available</option>
//             <option value="2">Booked</option>
//           </select>

//           {/* Priority */}
//           <select
//             className="form-control"
//             style={{ maxWidth: 320 }}
//             value={priority}
//             onChange={(e) => setPriority(e.target.value)}
//           >
//             <option value="">---Select Priority---</option>
//             <option value="0">Normal</option>
//             <option value="1">Priority</option>
//           </select>

//           {/* From / To */}
//           <input
//             type="date"
//             className="form-control"
//             style={{ maxWidth: 220 }}
//             value={from}
//             onChange={(e) => setFrom(e.target.value)}
//           />
//           <input
//             type="date"
//             className="form-control"
//             style={{ maxWidth: 220 }}
//             value={to}
//             onChange={(e) => setTo(e.target.value)}
//           />

//           {/* Buttons */}
//           <button
//             className="btn text-white"
//             style={{ backgroundColor: "#f26722", minWidth: 110 }}
//             onClick={handleSearch}
//             disabled={loading}
//           >
//             {loading ? "Search" : "Search"}
//           </button>

//           <button
//             className="btn btn-outline-danger"
//             style={{ minWidth: 110 }}
//             onClick={handleDelete}
//             disabled={loading || selected.size === 0}
//           >
//             Delete
//           </button>
//         </div>

//         {/* Table */}
//         <div
//           className="table-responsive"
//           style={{ maxHeight: "60vh", overflowY: "auto" }}
//         >
//           <table className="table table-striped table-hover align-middle">
//             <thead
//               style={{ position: "sticky", top: 0, background: "#eef1f5" }}
//             >
//               <tr>
//                 <th style={{ width: 80 }}>S.No</th>
//                 <th>VAC</th>
//                 <th>Slot Date</th>
//                 <th>Slot Time</th>
//                 <th>Priority</th>
//                 <th>Status</th>
//                 <th style={{ width: 140 }}>
//                   <div className="d-flex align-items-center gap-2">
//                     <input
//                       type="checkbox"
//                       checked={selectAll}
//                       onChange={toggleSelectAll}
//                       aria-label="Select All"
//                     />
//                     <span className="fw-semibold">Select All</span>
//                   </div>
//                 </th>
//               </tr>
//             </thead>

//             <tbody>
//               {loading ? (
//                 <tr>
//                   <td colSpan={7} className="text-center py-4">
//                     Loading...
//                   </td>
//                 </tr>
//               ) : error ? (
//                 <tr>
//                   <td colSpan={7} className="text-danger">
//                     {error}
//                   </td>
//                 </tr>
//               ) : rows.length === 0 ? (
//                 <tr>
//                   <td colSpan={7} className="text-muted text-center py-4">
//                     No records found.
//                   </td>
//                 </tr>
//               ) : (
//                 rows.map((r, i) => {
//                   const id = String(
//                     r.slot_id ??
//                       r.id ??
//                       `${r.vac_id}-${r.slot_time}-${r.slot_date}`
//                   );
//                   const vacName = r.vac_name ?? r.vac ?? "-";
//                   const slotDate = fmtDMY(r.slot_date);
//                   const slotTime = fmtTime(r.slot_time);
//                   const pri =
//                     r.priority === 1 || String(r.priority) === "1"
//                       ? "Priority"
//                       : "Normal";
//                   const sts =
//                     r.status === 2 || String(r.status) === "2"
//                       ? "Booked"
//                       : "Available";

//                   return (
//                     <tr key={id}>
//                       <td>{i + 1}</td>
//                       <td>{vacName}</td>
//                       <td>{slotDate}</td>
//                       <td>{slotTime}</td>
//                       <td>{pri}</td>
//                       <td>{sts}</td>
//                       <td>
//                         <input
//                           type="checkbox"
//                           checked={selected.has(id)}
//                           onChange={() => toggleSelectOne(id)}
//                           aria-label={`select ${id}`}
//                         />
//                       </td>
//                     </tr>
//                   );
//                 })
//               )}
//             </tbody>
//           </table>
//         </div>
//       </div>
//     </AjaxValidation>
//   );
// }

// import React from "react";
// import { fetchSlots, deleteSlots } from "../api/client";
// import { useAuth } from "../context/AuthContext";
// import AjaxValidation from "../hooks/AjaxValidation";

// // /* ---------- small helpers ---------- */
// function toYMD(date) {
//   if (!date) return "";
//   const d = new Date(date);
//   if (Number.isNaN(d.getTime())) return "";
//   const y = d.getFullYear();
//   const m = String(d.getMonth() + 1).padStart(2, "0");
//   const dd = String(d.getDate()).padStart(2, "0");
//   return `${y}-${m}-${dd}`;
// }
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yy = d.getFullYear();
//   return `${dd}-${mm}-${yy}`;
// }
// function fmtTime(hms) {
//   if (!hms) return "";
//   try {
//     if (typeof hms === "string" && hms.includes(":")) return hms;
//     const d = new Date(hms);
//     if (Number.isNaN(d.getTime())) return "";
//     return `${String(d.getHours()).padStart(2, "0")}:${String(
//       d.getMinutes()
//     ).padStart(2, "0")}:${String(d.getSeconds()).padStart(2, "0")}`;
//   } catch {
//     return "";
//   }
// }
// export default function SlotList() {
//   const { authData } = useAuth?.() || { authData: null };

//   const [vac, setVac] = React.useState("0");
//   const [status, setStatus] = React.useState("0");
//   const [priority, setPriority] = React.useState("");
//   const [from, setFrom] = React.useState("");
//   const [to, setTo] = React.useState("");

//   const [rows, setRows] = React.useState([]);
//   const [loading, setLoading] = React.useState(false);
//   const [error, setError] = React.useState("");
//   const [selected, setSelected] = React.useState(() => new Set()); // holds slot_id only
//   const [selectAll, setSelectAll] = React.useState(false);

//   const vacOptions = authData?.ajaxPayload?.vac_list || [];
//   const user_id = authData?.user_id ?? authData?.userid ?? authData?.id ?? "";
//   const session_id = authData?.session_id || "";
//   const session_token = authData?.session_token || "";

//   React.useEffect(() => {
//     const today = new Date();
//     const tomorrow = new Date(Date.now() + 24 * 3600 * 1000);
//     setFrom(toYMD(today));
//     setTo(toYMD(tomorrow));
//   }, []);

//   async function handleSearch() {
//     if (!session_id || !session_token) {
//       setError("Missing session. Please sign in.");
//       return;
//     }
//     setError("");
//     setLoading(true);
//     setSelected(new Set());
//     setSelectAll(false);

//     try {
//       const data = await fetchSlots({
//         user_id,
//         session_id,
//         session_token,
//         vac,
//         status,
//         priority,
//         from,
//         to,
//         type: 1,
//         startRecord: 1,
//         rows: 1,
//       });
//       setRows(data);
//     } catch (e) {
//       setError(e.message || "Failed to fetch slot list");
//       setRows([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   function toggleSelectOne(slotId) {
//     if (!slotId) return;
//     setSelected((prev) => {
//       const n = new Set(prev);
//       n.has(slotId) ? n.delete(slotId) : n.add(slotId);
//       return n;
//     });
//   }

//   function toggleSelectAll() {
//     setSelectAll((p) => !p);
//     setSelected(() => {
//       if (!selectAll) {
//         // select only those rows that have a concrete slot_id
//         return new Set(
//           rows
//             .map((r) => r.slot_id ?? r.id)
//             .filter((x) => x !== undefined && x !== null)
//             .map(String)
//         );
//       }
//       return new Set();
//     });
//   }

//   async function handleDelete() {
//     const ids = Array.from(selected);
//     if (!ids.length) {
//       alert("Please select at least one slot to delete.");
//       return;
//     }
//     if (!window.confirm(`Are you sure want to delete this slot`)) return;

//     try {
//       setLoading(true);
//       await deleteSlots({
//         user_id,
//         session_id,
//         session_token,
//         ids, // can be array; api client will join with commas
//       });
//       await handleSearch();
//       alert("Deleted successfully.");
//     } catch (e) {
//       console.error(e);
//       alert("Delete failed.");
//     } finally {
//       setLoading(false);
//     }
//   }

//   return (
//     <AjaxValidation>
//       <div className="container-fluid py-3">
//         <h6 className="mb-3">Slot List</h6>

//         <div
//           className="d-flex gap-2 align-items-center flex-wrap p-2 mb-3"
//           style={{ background: "#f5f7fa", borderRadius: 8 }}
//         >
//           <select
//             className="form-control"
//             style={{ maxWidth: 320 }}
//             value={vac}
//             onChange={(e) => setVac(e.target.value)}
//           >
//             <option value="0">---Select VAC---</option>
//             {vacOptions.map((v) => (
//               <option key={v.vac_id} value={v.vac_id}>
//                 {v.vac_name}
//               </option>
//             ))}
//           </select>

//           <select
//             className="form-control"
//             style={{ maxWidth: 320 }}
//             value={status}
//             onChange={(e) => setStatus(e.target.value)}
//           >
//             <option value="0">---Select Status---</option>
//             <option value="1">Available</option>
//             <option value="2">Booked</option>
//           </select>

//           <select
//             className="form-control"
//             style={{ maxWidth: 320 }}
//             value={priority}
//             onChange={(e) => setPriority(e.target.value)}
//           >
//             <option value="">---Select Priority---</option>
//             <option value="0">Normal</option>
//             <option value="1">Priority</option>
//           </select>

//           <input
//             type="date"
//             className="form-control"
//             style={{ maxWidth: 220 }}
//             value={from}
//             onChange={(e) => setFrom(e.target.value)}
//           />
//           <input
//             type="date"
//             className="form-control"
//             style={{ maxWidth: 220 }}
//             value={to}
//             onChange={(e) => setTo(e.target.value)}
//           />

//           <button
//             className="btn text-white"
//             style={{ backgroundColor: "#f26722", minWidth: 110 }}
//             onClick={handleSearch}
//             disabled={loading}
//           >
//             {loading ? "Searching..." : "Search"}
//           </button>

//           <button
//             className="btn btn-outline-danger"
//             style={{ minWidth: 110 }}
//             onClick={handleDelete}
//             disabled={loading || selected.size === 0}
//           >
//             Delete
//           </button>
//         </div>

//         <div
//           className="table-responsive"
//           style={{ maxHeight: "60vh", overflowY: "auto" }}
//         >
//           <table className="table table-striped table-hover align-middle">
//             <thead
//               style={{ position: "sticky", top: 0, background: "#eef1f5" }}
//             >
//               <tr>
//                 <th style={{ width: 80 }}>S.No</th>
//                 <th>VAC</th>
//                 <th>Slot Date</th>
//                 <th>Slot Time</th>
//                 <th>Priority</th>
//                 <th>Status</th>
//                 <th style={{ width: 140 }}>
//                   <div className="d-flex align-items-center gap-2">
//                     <input
//                       type="checkbox"
//                       checked={selectAll}
//                       onChange={toggleSelectAll}
//                     />
//                     <span className="fw-semibold">Select All</span>
//                   </div>
//                 </th>
//               </tr>
//             </thead>
//             <tbody>
//               {loading ? (
//                 <tr>
//                   <td colSpan={7} className="text-center py-4">
//                     Loading...
//                   </td>
//                 </tr>
//               ) : error ? (
//                 <tr>
//                   <td colSpan={7} className="text-danger">
//                     {error}
//                   </td>
//                 </tr>
//               ) : rows.length === 0 ? (
//                 <tr>
//                   <td colSpan={7} className="text-muted text-center py-4">
//                     No records found.
//                   </td>
//                 </tr>
//               ) : (
//                 rows.map((r, i) => {
//                   const key = String(
//                     r.slot_id ??
//                       r.id ??
//                       `${r.vac_id}-${r.slot_time}-${r.slot_date}`
//                   );
//                   const slotId = String(r.slot_id ?? r.id ?? ""); // used for selection/deletion
//                   const vacName = r.vac_name ?? r.vac ?? "-";
//                   const slotDate = fmtDMY(r.slot_date);
//                   const slotTime = fmtTime(r.slot_time);
//                   const pri =
//                     r.priority === 1 || String(r.priority) === "1"
//                       ? "Priority"
//                       : "Normal";
//                   const sts =
//                     r.status === 2 || String(r.status) === "2"
//                       ? "Booked"
//                       : "Available";

//                   return (
//                     <tr key={key}>
//                       <td>{i + 1}</td>
//                       <td>{vacName}</td>
//                       <td>{slotDate}</td>
//                       <td>{slotTime}</td>
//                       <td>{pri}</td>
//                       <td>{sts}</td>
//                       <td>
//                         <input
//                           type="checkbox"
//                           disabled={!slotId}
//                           checked={slotId ? selected.has(slotId) : false}
//                           onChange={() => toggleSelectOne(slotId)}
//                         />
//                       </td>
//                     </tr>
//                   );
//                 })
//               )}
//             </tbody>
//           </table>
//         </div>
//       </div>
//     </AjaxValidation>
//   );
// }

import React from "react";
import { fetchSlots, deleteSlots } from "../api/client";
import { useAuth } from "../context/AuthContext";
import AjaxValidation from "../hooks/AjaxValidation";

/* ---------- helpers ---------- */
function toYMD(date) {
  if (!date) return "";
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return "";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}
// function fmtDMY(dateLike) {
//   if (!dateLike) return "";
//   const d = new Date(dateLike);
//   if (Number.isNaN(d.getTime())) return "";
//   const dd = String(d.getDate()).padStart(2, "0");
//   const mm = String(d.getMonth() + 1).padStart(2, "0");
//   const yy = d.getFullYear();
//   return `${dd}-${mm}-${yy}`;
// }
function fmtTime(hms) {
  if (!hms) return "";
  try {
    if (typeof hms === "string" && hms.includes(":")) return hms;
    const d = new Date(hms);
    if (Number.isNaN(d.getTime())) return "";
    return `${String(d.getHours()).padStart(2, "0")}:${String(
      d.getMinutes()
    ).padStart(2, "0")}:${String(d.getSeconds()).padStart(2, "0")}`;
  } catch {
    return "";
  }
}

/* ---------- page ---------- */
export default function SlotList() {
  const { authData } = useAuth?.() || { authData: null };

  // Filters (all optional)
  const [vac, setVac] = React.useState("0");
  const [status, setStatus] = React.useState("0"); // 0=All, 1=Available, 2=Booked
  const [priority, setPriority] = React.useState(""); // ""=All, 0=Normal, 1=Priority

  // ✅ Initialize BOTH dates to today (API requires them)
  const [from, setFrom] = React.useState(() => toYMD(new Date()));
  const [to, setTo] = React.useState(() => toYMD(new Date()));

  // Data + UI
  const [rows, setRows] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");
  const [selected, setSelected] = React.useState(() => new Set());
  const [selectAll, setSelectAll] = React.useState(false);

  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const user_id = authData?.user_id ?? authData?.userid ?? authData?.id ?? "";
  const session_id = authData?.session_id || "";
  const session_token = authData?.session_token || "";

  // 🔁 Auto-load once the session is available, using today's dates
  React.useEffect(() => {
    if (!session_id || !session_token) return;
    handleSearch(); // uses current state: vac=0, status=0, priority="", from=today, to=today
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session_id, session_token]);

  async function handleSearch() {
    if (!session_id || !session_token) {
      setError("Missing session. Please sign in.");
      return;
    }
    setError("");
    setLoading(true);
    setSelected(new Set());
    setSelectAll(false);

    try {
      const data = await fetchSlots({
        user_id,
        session_id,
        session_token,
        vac, // -> vac_id
        status, // -> slot_status
        priority, // -> priority
        from, // -> from_date (now today by default)
        to, // -> to_date   (now today by default)
        type: 1,
        startRecord: 1,
        rows: 1,
      });
      setRows(data);
    } catch (e) {
      setError(e.message || "Failed to fetch slot list");
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  function toggleSelectOne(slotId) {
    if (!slotId) return;
    setSelected((prev) => {
      const n = new Set(prev);
      n.has(slotId) ? n.delete(slotId) : n.add(slotId);
      return n;
    });
  }

  function toggleSelectAll() {
    setSelectAll((p) => !p);
    setSelected(() => {
      if (!selectAll) {
        return new Set(
          rows
            .map((r) => r.slot_id ?? r.id)
            .filter((x) => x !== undefined && x !== null)
            .map(String)
        );
      }
      return new Set();
    });
  }

  async function handleDelete() {
    const ids = Array.from(selected);
    if (!ids.length) {
      alert("Please select at least one slot to delete.");
      return;
    }
    if (!window.confirm(`Are you sure want to delete selected slot?`)) return;

    try {
      setLoading(true);
      await deleteSlots({
        user_id,
        session_id,
        session_token,
        ids, // API expects CSV; api/client joins it
      });
      await handleSearch(); // refresh with current (optional) filters
      alert("Deleted successfully.");
    } catch (e) {
      console.error(e);
      alert("Delete failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AjaxValidation>
      <div className="container-fluid py-3">
        <h6 className="p-0 m-0">Slot List</h6>

        <div class="row mt-2 mb-3">
          <div class="col-sm-12">
            <div className="box_card">
              <div className="form-group row">
                <div className="col-sm-12">
                  {/* Filters (all optional) */}
                  <div className="main_agent_form">
                    {/* Dates are optional; leave blank to fetch all */}
                    <div className="one">
                      <select
                        className="form-select form-control"
                        style={{ maxWidth: 320 }}
                        value={vac}
                        onChange={(e) => setVac(e.target.value)}
                      >
                        <option value="0">--Select VAC--</option>
                        {vacOptions.map((v) => (
                          <option key={v.vac_id} value={v.vac_id}>
                            {v.vac_name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="one">
                      <select
                        className="form-select form-control"
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                      >
                        <option value="0">--Select Status--</option>
                        <option value="1">Available</option>
                        <option value="2">Booked</option>
                      </select>
                    </div>
                    <div className="one">
                      <select
                        className=" form-select form-control"
                        value={priority}
                        onChange={(e) => setPriority(e.target.value)}
                      >
                        <option value="">--Select Priority--</option>
                        <option value="0">Normal</option>
                        <option value="1">Priority</option>
                      </select>
                    </div>
                    <div className="one">
                      <input
                        type="date"
                        className="form-control"
                        value={from}
                        onChange={(e) => setFrom(e.target.value)}
                        placeholder="From"
                      />
                    </div>
                    <div className="one">
                      <input
                        type="date"
                        className="form-control"
                        value={to}
                        onChange={(e) => setTo(e.target.value)}
                        placeholder="To"
                      />
                    </div>
                    <div className="one gap-2">
                      <button
                        className="btn-lg go-btn"
                        onClick={handleSearch}
                        disabled={loading}
                      >
                        {loading ? "Search" : "Search"}
                      </button>

                      <button
                        // className="btn btn-outline-danger"
                        className="btn-lg go-btn"
                        onClick={handleDelete}
                        disabled={loading || selected.size === 0}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="dropdown-divider"></div>
              <div
                className="table-responsive"
                style={{ maxHeight: "60vh", overflowY: "auto" }}
              >
                <table className="m-0 table table-bordered">
                  <thead
                    className="table-card"
                    style={{
                      position: "sticky",
                      top: 0,
                    }}
                  >
                    <tr>
                      <th style={{ width: 80 }}>S.No</th>
                      <th>VAC</th>
                      <th>Slot Date</th>
                      <th>Slot Time</th>
                      <th>Priority</th>
                      <th>Status</th>
                      <th style={{ width: 140 }}>
                        <div className="d-flex align-items-center gap-2">
                          <input
                            type="checkbox"
                            checked={selectAll}
                            onChange={toggleSelectAll}
                            aria-label="Select All"
                          />
                          <span className="fw-semibold">Select All</span>
                        </div>
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {loading ? (
                      <div className="p-3 text-center">
                        <div
                          style={{
                            position: "fixed",
                            inset: 0,
                            background: "rgba(0,0,0,0.35)",
                            zIndex: 1050,
                            display: "grid",
                            placeItems: "center",
                          }}
                        >
                          <div
                            className="spinner-border text-light"
                            role="status"
                          />
                        </div>
                      </div>
                    ) : error ? (
                      <tr>
                        <td colSpan={7} className="text-danger">
                          {error}
                        </td>
                      </tr>
                    ) : rows.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-muted text-center">
                          No records found.
                        </td>
                      </tr>
                    ) : (
                      rows.map((r, i) => {
                        const key = String(
                          r.slot_id ??
                            r.id ??
                            `${r.vac_id}-${r.slot_time}-${r.slot_date}`
                        );
                        const slotId = String(r.slot_id ?? r.id ?? "");
                        const vacName = r.vac_name ?? r.vac ?? "-";
                        const slotDate = r.slot_date;
                        const slotTime = fmtTime(r.slot_time);
                        const pri =
                          r.priority === 1 || String(r.priority) === "1"
                            ? "Priority"
                            : "Normal";
                        const sts =
                          r.status === 2 || String(r.status) === "2"
                            ? "Booked"
                            : "Available";

                        return (
                          <tr key={key}>
                            <td>{i + 1}</td>
                            <td>{vacName}</td>
                            <td>{slotDate}</td>
                            <td>{slotTime}</td>
                            <td>{pri}</td>
                            <td>{sts}</td>
                            <td>
                              <input
                                type="checkbox"
                                disabled={!slotId}
                                checked={slotId ? selected.has(slotId) : false}
                                onChange={() => toggleSelectOne(slotId)}
                                aria-label={`select ${slotId}`}
                              />
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AjaxValidation>
  );
}
