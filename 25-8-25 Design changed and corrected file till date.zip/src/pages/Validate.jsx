import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { validateSession } from "../api/auth";
import { useAuth } from "../context/AuthContext";

export default function Validate() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const { login } = useAuth();

  useEffect(() => {
    if (!state?.session_id || !state?.otp) {
      navigate("/login", { replace: true });
      return;
    }

    let cancelled = false;

    (async () => {
      try {
        const res = await validateSession(state.session_id, state.otp);
        if (!cancelled) {
          if (res?.status === 1) {
            login(res); // persist in context
            navigate("/", { replace: true });
          } else {
            navigate("/login", { replace: true });
          }
        }
      } catch {
        if (!cancelled) navigate("/login", { replace: true });
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [state, login, navigate]);

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-6 text-center">
          <h5>Validating session…</h5>
        </div>
      </div>
    </div>
  );
}
