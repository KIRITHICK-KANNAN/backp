import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { ajaxValidation } from "../api/client";
import { useNavigate } from "react-router-dom";

export default function AjaxValidation({ children }) {
  const { authData, patchAuth, logout } = useAuth();
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    if (!authData.session_id || !authData.session_token) {
      // no session at all → bounce
      logout();
      navigate("/", { replace: true });
      return;
    }

    const ac = new AbortController();
    let mounted = true;

    (async () => {
      try {
        // Call using raw session (NOT ajaxPayload)
        const res = await ajaxValidation({
          session_id: authData.session_id,
          session_token: authData.session_token,
          signal: ac.signal, // (api/client should ignore unknown fields)
        });

        if (!mounted) return;

        // Accept both shapes safely
        const sid = String(res?.Globalsessionid ?? res?.session_id ?? "");
        const tok = String(res?.Globalsessiontoken ?? res?.session_token ?? "");

        // If backend returns explicit invalid/expired code, then logout
        if (res?.status === 2 || (!sid && !tok)) {
          logout();
          navigate("/", { replace: true });
          return;
        }

        // Good enough → patch context and continue
        patchAuth({
          session_id: sid || authData.session_id,
          session_token: tok || authData.session_token,
          role_id: String(res?.RoleId ?? authData.role_id ?? ""),
          user: {
            id: String(res?.Globaluserid ?? authData.user?.id ?? "") || null,
            username: res?.user_name ?? authData.user?.username ?? null,
            full_name: res?.full_name ?? authData.user?.full_name ?? null,
          },
          ajaxPayload: {
            Globalsessionid: sid,
            Globalsessiontoken: tok,
            Globaluserid: String(res?.Globaluserid ?? ""),
            RoleId: String(res?.RoleId ?? ""),
            user_name: res?.user_name ?? "",
            full_name: res?.full_name ?? "",
            vac_list: res?.vac_list || [],
            master_status_list: res?.master_status_list || [],
            document_key: res.document_key,
          },
        });

        setChecking(false);
      } catch (err) {
        if (!mounted || err?.name === "AbortError") return;
        // Network blip: don't nuke the session immediately; show the page
        // (or you can show a toast here)
        setChecking(false);
      }
    })();

    return () => {
      mounted = false;
      ac.abort();
    };
  }, [
    authData.session_id,
    authData.session_token,
    patchAuth,
    logout,
    navigate,
  ]);

  if (checking) {
    return (
      <div style={{ minHeight: "40vh", display: "grid", placeItems: "center" }}>
        {/* <div
          // className="spinner-border"
          className="spinner-bor"
          role="status"
          aria-label="Validating session..."
        /> */}
        {checking && (
          <div
            style={{
              position: "fixed",
              inset: 0,
              background: "rgba(0,0,0,0.35)",
              zIndex: 1050,
              display: "grid",
              placeItems: "center",
            }}
          >
            <div className="spinner-border text-light" role="status" />
          </div>
        )}
      </div>
    );
  }

  return children;
}
