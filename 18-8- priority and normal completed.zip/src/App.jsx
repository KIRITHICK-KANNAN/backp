// import { Routes, Route } from "react-router-dom";
// import Navbar from "./components/Navbar";
// import Sidebar from "./components/Sidebar";
// import ProtectedRoute from "./components/ProtectedRoute";
// import Login from "./pages/Login";
// import Dashboard from "./pages/Dashboard";
// import NormalCases from "./pages/NormalCases";
// import PriorityCases from "./pages/PriorityCases";
// import CaseList from "./pages/CaseList";
// import AddSlot from "./pages/AddSlot";
// import SlotList from "./pages/SlotList";
// import Holiday from "./pages/Holiday";
// import Manifest from "./pages/Manifest";
// import AgentReport from "./pages/AgentReport";

// export default function App() {
//   return (
//     <div className="d-flex">
//       <Sidebar />
//       <div className="flex-grow-1 p-3">
//         <Routes>
//           <Route path="/login" element={<Login />} />
//           <Route
//             path="/dashboard"
//             element={
//               <ProtectedRoute>
//                 <Dashboard />
//               </ProtectedRoute>
//             }
//           />
//           <Route
//             path="/normal-cases"
//             element={
//               <ProtectedRoute>
//                 <NormalCases />
//               </ProtectedRoute>
//             }
//           />
//           <Route
//             path="/priority-cases"
//             element={
//               <ProtectedRoute>
//                 <PriorityCases />
//               </ProtectedRoute>
//             }
//           />
//           <Route
//             path="/case-list"
//             element={
//               <ProtectedRoute>
//                 <CaseList />
//               </ProtectedRoute>
//             }
//           />
//           <Route
//             path="/add-slot"
//             element={
//               <ProtectedRoute>
//                 <AddSlot />
//               </ProtectedRoute>
//             }
//           />
//           <Route
//             path="/slot-list"
//             element={
//               <ProtectedRoute>
//                 <SlotList />
//               </ProtectedRoute>
//             }
//           />
//           <Route
//             path="/holiday"
//             element={
//               <ProtectedRoute>
//                 <Holiday />
//               </ProtectedRoute>
//             }
//           />
//           <Route
//             path="/manifest"
//             element={
//               <ProtectedRoute>
//                 <Manifest />
//               </ProtectedRoute>
//             }
//           />
//           <Route
//             path="/agent-report"
//             element={
//               <ProtectedRoute>
//                 <AgentReport />
//               </ProtectedRoute>
//             }
//           />
//         </Routes>
//       </div>
//     </div>
//   );
// // }
// import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
// import { useAuth } from "./context/AuthContext";
// import Header from "./pages/Header";
// import Footer from "./pages/Footer";
// import Login from "./pages/Login";
// import Validate from "./pages/Validate";
// import Dashboard from "./pages/Dashboard"; // your home/protected page
// import "./styles/global.css"; // global styles

// // Protected Route Component
// const ProtectedRoute = ({ children }) => {
//   const { authData } = useAuth();

//   // If no valid session, go back to login
//   if (!authData?.session_id || !authData?.session_token) {
//     return <Navigate to="/" replace />;
//   }

//   return children;
// };

// export default function App() {
//   return (
//     <BrowserRouter>
//       <Header />
//       <Routes>
//         {/* Public Routes */}
//         <Route path="/" element={<Login />} />

//         {/* Protected Routes */}
//         <Route
//           path="/dashboard"
//           element={
//             <ProtectedRoute>
//               <Dashboard />
//             </ProtectedRoute>
//           }
//         />

//         {/* Fallback to login */}
//         <Route path="*" element={<Navigate to="/" replace />} />
//       </Routes>
//       <Footer />
//     </BrowserRouter>
//   );
// // }
// import {
//   BrowserRouter,
//   Routes,
//   Route,
//   Navigate,
//   useLocation,
//   useNavigate,
// } from "react-router-dom";
// import { useAuth } from "./context/AuthContext";
// import Header from "./pages/Header";
// import Footer from "./pages/Footer";
// import Login from "./pages/Login";
// import Dashboard from "./pages/Dashboard";
// import { useEffect, useRef, useState } from "react";
// import { getRole } from "./api/client";
// import "./styles/global.css";

// // Validate-on-first-visit-per-path using ajaxvalidation.php
// const ProtectedRoute = ({ children }) => {
//   const { authData, login, logout } = useAuth();
//   const location = useLocation();
//   const navigate = useNavigate();

//   const validatedPathsRef = useRef(new Set());
//   const [checking, setChecking] = useState(true);

//   useEffect(() => {
//     let cancelled = false;

//     const run = async () => {
//       if (!authData?.session_id || !authData?.session_token) {
//         navigate("/", { replace: true, state: { from: location.pathname } });
//         return;
//       }

//       if (validatedPathsRef.current.has(location.pathname)) {
//         setChecking(false);
//         return;
//       }

//       setChecking(true);
//       try {
//         const res = await getRole({
//           session_id: authData.session_id,
//           session_token: authData.session_token,
//         });
//         if (cancelled) return;

//         // Treat presence of these fields as success
//         if (res?.Globalsessionid && res?.Globalsessiontoken) {
//           // Normalize into your AuthContext shape
//           login({
//             session_id: res.Globalsessionid,
//             session_token: res.Globalsessiontoken,
//             role_id: res.RoleId ?? authData.role_id ?? null,
//             user: {
//               id: res.Globaluserid ?? authData?.user?.id ?? null,
//               username: res.user_name ?? authData?.user?.username ?? null,
//               full_name: res.full_name ?? authData?.user?.full_name ?? null,
//             },
//             // keep anything else you store (document_key, etc.)
//             document_key: authData.document_key ?? null,
//           });

//           validatedPathsRef.current.add(location.pathname);
//           setChecking(false);
//         } else {
//           // invalid -> clear and bounce to login
//           logout();
//           navigate("/", { replace: true });
//         }
//       } catch {
//         if (!cancelled) {
//           logout();
//           navigate("/", { replace: true });
//         }
//       }
//     };

//     run();
//     return () => {
//       cancelled = true;
//     };
//   }, [
//     location.pathname,
//     authData?.session_id,
//     authData?.session_token,
//     navigate,
//     login,
//     logout,
//   ]);

//   if (!authData?.session_id || !authData?.session_token) {
//     return <Navigate to="/" replace />;
//   }

//   if (checking) {
//     return (
//       <div style={{ minHeight: "40vh", display: "grid", placeItems: "center" }}>
//         <div
//           className="spinner-border"
//           role="status"
//           aria-label="Validating session..."
//         />
//       </div>
//     );
//   }

//   return children;
// };

// export default function App() {
//   return (
//     <BrowserRouter>
//       <Header />
//       <Routes>
//         {/* Public */}
//         <Route path="/" element={<Login />} />

//         {/* Protected */}
//         <Route
//           path="/dashboard"
//           element={
//             <ProtectedRoute>
//               <Dashboard />
//             </ProtectedRoute>
//           }
//         />

//         {/* Fallback */}
//         <Route path="*" element={<Navigate to="/" replace />} />
//       </Routes>
//       <Footer />
//     </BrowserRouter>
//   );
// }

// // src/App.jsx working
// import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
// import Header from "./pages/Header";
// import Footer from "./pages/Footer";
// import Login from "./pages/Login";
// import Dashboard from "./pages/Dashboard";
// import AddSlot from "./pages/AddSlot";
// import PriorityCases from "./pages/PriorityCases";
// // import { useAuth } from "./context/AuthContext";
// import ProtectedRoute from "./components/ProtectedRoute";

// export default function App() {
//   return (
//     <BrowserRouter>
//       <Header />
//       <Routes>
//         <Route path="/" element={<Login />} />

//         <Route
//           path="/dashboard"
//           element={
//             <ProtectedRoute>
//               <Dashboard />
//             </ProtectedRoute>
//           }
//         />
//         <Route
//           path="/AddSlot"
//           element={
//             <ProtectedRoute>
//               <AddSlot />
//             </ProtectedRoute>
//           }
//         />
//         <Route
//           path="/PriorityCases"
//           element={
//             <ProtectedRoute>
//               <PriorityCases />
//             </ProtectedRoute>
//           }
//         />

//         <Route path="*" element={<Navigate to="/" replace />} />
//       </Routes>
//       <Footer />
//     </BrowserRouter>
//   );
// }

// App.jsx
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Header from "./pages/Header";
import Footer from "./pages/Footer";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import CaseList from "./pages/CaseList";
import AddSlot from "./pages/AddSlot";
import SlotList from "./pages/SlotList";
import Holiday from "./pages/Holiday";
import Manifest from "./pages/Manifest";
import AgentReport from "./pages/AgentReport";
import PriorityCases from "./pages/PriorityCases";
import ProtectedRoute from "./components/ProtectedRoute";
import NormalCases from "./pages/NormalCases";

export default function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/" element={<Login />} />

        {/* role 1 pages (and others) */}
        <Route
          path="/CaseList"
          element={
            <ProtectedRoute>
              <CaseList />
            </ProtectedRoute>
          }
        />
        <Route
          path="/AddSlot"
          element={
            <ProtectedRoute>
              <AddSlot />
            </ProtectedRoute>
          }
        />
        <Route
          path="/SlotList"
          element={
            <ProtectedRoute>
              <SlotList />
            </ProtectedRoute>
          }
        />
        <Route
          path="/Holiday"
          element={
            <ProtectedRoute>
              <Holiday />
            </ProtectedRoute>
          }
        />
        <Route
          path="/Manifest"
          element={
            <ProtectedRoute>
              <Manifest />
            </ProtectedRoute>
          }
        />
        <Route
          path="/AgentReport"
          element={
            <ProtectedRoute>
              <AgentReport />
            </ProtectedRoute>
          }
        />

        {/* common */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/PriorityCases"
          element={
            <ProtectedRoute>
              <PriorityCases />
            </ProtectedRoute>
          }
        />

            <Route
          path="/NormalCases"
          element={
            <ProtectedRoute>
              <NormalCases />
            </ProtectedRoute>
          }
        />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}
