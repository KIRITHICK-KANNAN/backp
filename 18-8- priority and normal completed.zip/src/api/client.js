import api from "./axios";
import CryptoJS from "crypto-js";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";

const Base = "https://vfseu.mioot.com/forms/UAT/ITAIND/admin/api/";
const Dashboard = Base + "dashBoard/";
const Webform = Base + "Webform/";
const HolidayList = Base + "HolidayList/";

const ManifestAPI =
  "https://vfseu.mioot.com/forms/UAT/ITAIND/admin/api/Manifest/";

function encryptPasswordEcbHex(plain, keyHexStr) {
  if (!keyHexStr) throw new Error("Missing encryption_key");
  const key = CryptoJS.enc.Hex.parse(keyHexStr); // << match jQuery
  const encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(plain), key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7,
  });
  return encrypted.toString(); // Base64
}

export async function getSession({ username }) {
  const res = await api.post("api/GetSession/", { username });
  return res.data; // { status, session_id, session_token, encryption_key }
}

/** Step 2: Login (encrypt inside) */
export async function loginValidation({
  session_id,
  session_token,
  username,
  passwordPlain,
  encryption_key,
}) {
  const password = encryptPasswordEcbHex(passwordPlain, encryption_key);
  const res = await api.post("api/Login/", {
    session_id,
    session_token,
    username,
    password,
  });
  return res.data; // { status, session_id?, session_token?, msg? }
}

export async function reLogin({
  session_id,
  session_token,
  username,
  passwordPlain,
  encryption_key,
}) {
  const password = encryptPasswordEcbHex(passwordPlain, encryption_key);
  const res = await api.post("api/ReLogin/", {
    session_id,
    session_token,
    username,
    password,
  });
  return res.data;
}

export async function validateOTP({ session_id, session_token, otp_number }) {
  const res = await api.post("api/ValidateOtp/", {
    session_id,
    session_token,
    otp_number,
  });
  return res.data;
}

export async function ajaxValidation(payload) {
  const res = await api.post("ajaxvalidation.php", {
    Globalsessionid: String(payload.Globalsessionid || payload.session_id),
    Globalsessiontoken: String(
      payload.Globalsessiontoken || payload.session_token
    ),
  });
  return res.data;
}

export async function getRole({ session_id, session_token }) {
  // Backend expects these exact field names
  const res = await api.post("getRole.php", {
    Globalsessionid: String(session_id),
    Globalsessiontoken: String(session_token),
  });
  return res.data; // e.g. { Globaluserid, Globalsessionid, Globalsessiontoken, RoleId, user_name, full_name }
}

export async function sessionPing({
  session_id,
  session_token,
  activity_time,
}) {
  const res = await api.post(
    "api/SessionPing/",
    {
      session_id: String(session_id),
      session_token: String(session_token),
      activity_time: activity_time, // e.g., "2025-8-12 9:49:32"
    },
    {
      headers: { "Content-Type": "text/plain" },
      timeout: 30000,
    }
  );
  return res.data;
}

export function encryptPassword(plainText, keyHexStr) {
  if (!keyHexStr) throw new Error("Missing encryption_key");
  const key = CryptoJS.enc.Hex.parse(keyHexStr); // Match server's hex key
  const encrypted = CryptoJS.AES.encrypt(
    CryptoJS.enc.Utf8.parse(plainText),
    key,
    {
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.Pkcs7,
    }
  );
  return encrypted.toString(); // Base64
}

/**
 * Call backend logout API
 */
export async function logoutUser({ session_id, session_token }) {
  try {
    const res = await api.post("api/Logout/", {
      session_id: String(session_id),
      session_token: String(session_token),
    });
    return res.data; // expected { status: 1, msg: "Logged out" }
  } catch (error) {
    console.error("Logout API error:", error);
    return { status: 0, message: "Logout failed" };
  }
}

/**
 * Update password API
 */
export async function updatePassword({
  session_id,
  session_token,
  oldPassword,
  newPassword,
  confirmPassword,
  encryption_key,
}) {
  try {
    const payload = {
      session_id,
      session_token,
      old_password: encryptPassword(oldPassword, encryption_key),
      new_password: encryptPassword(newPassword, encryption_key),
      confirm_password: encryptPassword(confirmPassword, encryption_key),
    };

    const res = await api.post("api/UpdatePassword/", payload);
    return res.data; // { status: 1, message: "Password updated" }
  } catch (error) {
    console.error("Update Password Error:", error);
    return { status: 0, message: "Request failed" };
  }
}

// /src/api/client.js
export async function searchCases(payload) {
  const res = await fetch(
    "https://vfseu.mioot.com/forms/UAT/ITAIND/admin/api/SearchCases/",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }
  );
  if (!res.ok) throw new Error("Failed to fetch cases");
  return res.json();
}

export async function slotProcess(payload) {
  // payload should contain:
  // {
  //   usrtid, usrsid, usrstkn,
  //   Date1, Date2, Time1, Time2,
  //   BTime1, BTime2, Inrvl, NoOf,
  //   vac, RoleId, priority, type
  // }
  const res = await api.post("api/SlotProcess/", payload);
  return res.data;
}

const slotListAPI =
  "https://vfseu.mioot.com/forms/UAT/ITAIND/admin/api/SlotList/";

export async function fetchSlots({
  user_id,
  session_id,
  session_token, // you can also pass sessionToken (camelCase); we'll map below
  sessionToken,
  vac, // "0" or a VAC id
  vac_id,
  status, // "0"=All, "1"=Available, "2"=Booked
  slot_status,
  priority = "", // "" | "0" | "1"
  from,
  from_date,
  to,
  to_date,
  startRecord = 1,
  rows = 1,
  type = 1, // list
} = {}) {
  const payload = {
    user_id,
    session_id,
    session_token: session_token ?? sessionToken ?? "",
    from_date: from_date ?? from ?? "",
    to_date: to_date ?? to ?? "",
    vac_id: vac_id ?? vac ?? "0",
    slot_status: slot_status ?? status ?? "0",
    priority: priority ?? "",
    type, // 1 = list
    startRecord,
    rows,
  };

  const res = await fetch(slotListAPI, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok)
    throw new Error(`SlotList fetch failed: ${res.status} ${res.statusText}`);

  const data = await res.json();

  // Normalize possible shapes
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.list)) return data.list;
  return [];
}

export async function deleteSlots({
  user_id,
  session_id,
  session_token,
  sessionToken,
  ids, // string OR array of ids
}) {
  const payload = {
    user_id,
    session_id,
    session_token: session_token ?? sessionToken ?? "",
    type: 2,
    ids: Array.isArray(ids) ? ids.join(",") : String(ids || ""),
  };

  const res = await fetch(slotListAPI, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Delete failed: ${res.status}`);

  return res.json().catch(() => ({}));
}

export async function fetchManifest({
  user_id,
  session_id,
  session_token,
  vac_id = "0", // "0" = all VACs
  priority = "", // "" required by your spec before search; pass "0" or "1"
  from_date, // yyyy-mm-dd
  to_date, // yyyy-mm-dd
  startRecord = 1,
  rows = 1,
  type = 1,
  project = "ITAIND",
}) {
  const payload = {
    user_id,
    session_id,
    session_token,
    from_date,
    to_date,
    vac_id,
    priority,
    type,
    startRecord,
    rows,
    project,
  };

  const res = await fetch(ManifestAPI, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok) throw new Error(`Manifest fetch failed: ${res.status}`);

  const data = await res.json();
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.list)) return data.list;
  return [];
}

export async function exportManifestExcel(rows) {
  if (!rows?.length) {
    alert("No data to export.");
    return;
  }

  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("Manifest");

  ws.columns = [
    { header: "Request ID", key: "request_id", width: 12 },
    { header: "Child Reference No", key: "child_id", width: 18 },
    { header: "Added On", key: "added_on", width: 20 },
    { header: "Submitted On", key: "submitted_on", width: 20 },
    { header: "Full Name", key: "full_name", width: 22 },
    { header: "Email Id", key: "email_id", width: 26 },
    { header: "Passport Number", key: "passport_number", width: 18 },
    { header: "Nulla osta No", key: "work_permit_number", width: 18 },
    { header: "Issue Date", key: "work_permit_issue_date", width: 14 },
    { header: "VAC", key: "vac", width: 16 },
    { header: "Amount", key: "total_amount", width: 10 },
    { header: "Tracking ID", key: "tracking_id", width: 18 },
    { header: "Payment Reference No", key: "bank_ref_no", width: 24 },
    { header: "Slot Type", key: "slot_type", width: 12 },
    { header: "Slot Date", key: "slot_date", width: 14 },
    { header: "Slot Time", key: "slot_time", width: 12 },
  ];

  // Header style
  ws.getRow(1).eachCell((c) => {
    c.font = { bold: true };
    c.alignment = { horizontal: "center", vertical: "middle" };
    c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "D9E1F2" } };
    c.border = {
      top: { style: "thin", color: { argb: "CCCCCC" } },
      left: { style: "thin", color: { argb: "CCCCCC" } },
      bottom: { style: "thin", color: { argb: "CCCCCC" } },
      right: { style: "thin", color: { argb: "CCCCCC" } },
    };
  });

  // Massage + add rows
  rows.forEach((r) => {
    const fullName =
      r.full_name ||
      [r.first_name, r.last_name].filter(Boolean).join(" ") ||
      "-";

    const pri =
      r.priority === 1 || String(r.priority) === "1" ? "Priority" : "Normal";

    const record = {
      request_id: r.request_id ?? r.reqId ?? r.req_id ?? "-",
      child_id: r.child_id ?? r.child_reference ?? r.child_no ?? "-",
      added_on: r.added_on ?? r.addOn ?? r.addedOn ?? "-",
      submitted_on: r.submitted_on ?? r.submitOn ?? "-",
      full_name: fullName,
      email_id: r.email_id ?? r.email ?? "-",
      passport_number: r.passport_number ?? r.passport_no ?? r.ppn ?? "-",
      work_permit_number:
        r.work_permit_number ?? r.null_osta_no ?? r.wpn ?? r.nulla ?? "-",
      work_permit_issue_date: r.work_permit_issue_date ?? "-",
      vac: r.vac_name ?? r.vac ?? "-",
      total_amount: r.total_amount ?? 0,
      tracking_id: r.tracking_id ?? "-",
      bank_ref_no: r.bank_ref_no ?? r.payment_ref_no ?? "-",
      slot_type: pri,
      slot_date: r.slot_date ?? "-",
      slot_time: r.slot_time ?? "-",
    };

    const row = ws.addRow(record);
    row.eachCell((cell) => {
      cell.alignment = {
        horizontal: "left",
        vertical: "middle",
        wrapText: true,
      };
      cell.border = {
        top: { style: "thin", color: { argb: "AAAAAA" } },
        left: { style: "thin", color: { argb: "AAAAAA" } },
        bottom: { style: "thin", color: { argb: "AAAAAA" } },
        right: { style: "thin", color: { argb: "AAAAAA" } },
      };
    });
  });

  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
  });
  saveAs(blob, `Manifest_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

export async function fetchDashboard(payload) {
  const res = await fetch(Dashboard, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

// WEBFORM (open/close overview)
export async function fetchWebform({
  session_id,
  session_token,
  user_id,
  priority_is_form_off = "",
  vac_id = "0",
  project = "italy",
  type = 1,
}) {
  const body = {
    priority_is_form_off,
    vac_id,
    session_id,
    session_token,
    user_id,
    project,
    type,
  };

  const res = await fetch(Webform, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error("Webform API failed");
  return res.json();
}

// HOLIDAY LIST
export async function fetchHolidayList({
  user_id,
  session_id,
  session_token,
  type = 1,
}) {
  const body = { user_id, session_id, session_token, type };
  const res = await fetch(HolidayList, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error("HolidayList API failed");
  return res.json();
}

export async function adminCases({ session_id, session_token, priority = 0 }) {
  const { data } = await api.post("api/AdminCases/", {
    session_id,
    sessionToken: session_token, // API expects sessionToken
    priority,
  });
  return data;
}

// ---- SearchCases (filters/pagination) ----
export async function searchCasesNormal(payload) {
  const {
    session_id,
    session_token,
    keyword = "",
    keyType = "0",
    dateType = "2",
    vac = "0",
    status = "0",
    from,
    to,
    startRecord = 1,
    rows = 100,
    priority = 0,
  } = payload;

  const { data } = await api.post("api/SearchCases/", {
    session_id,
    sessionToken: session_token,
    keyword,
    keyType,
    dateType, // important per your note
    vac,
    status,
    from,
    to,
    startRecord,
    rows,
    priority,
  });
  return data;
}

// ---- UpdtVrdct (single / multiple) ----
export async function updtVerdict({ session_id, session_token, actionIds }) {
  const { data } = await api.post("api/UpdtVrdct/", {
    session_id,
    sessionToken: session_token,
    actionIds, // [{ Id, sts }]
  });
  return data;
}
