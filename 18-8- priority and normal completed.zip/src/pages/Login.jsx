// import { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import {
//   getSession,
//   loginValidation,
//   reLogin,
//   validateOTP,
// } from "../api/client";
// import { useAuth } from "../context/AuthContext";

// export default function Login() {
//   const navigate = useNavigate();
//   const { login } = useAuth();

//   // form
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [otp, setOtp] = useState("");

//   // UI state
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState("");
//   const [showOtp, setShowOtp] = useState(false);
//   const [showConfirm, setShowConfirm] = useState(false);

//   // session state
//   const [sessionId, setSessionId] = useState("");
//   const [sessionToken, setSessionToken] = useState("");
//   const [encryptionKey, setEncryptionKey] = useState(""); // HEX

//   // clear error on input change
//   useEffect(() => {
//     if (error) setError("");
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [username, password, otp]);

//   const handleLogin = async () => {
//     setError("");
//     const u = username.trim();
//     const p = password.trim();
//     if (!u || !p) {
//       setError("Username and password are required.");
//       return;
//     }

//     setLoading(true);
//     try {
//       // 1) Start session
//       const sess = await getSession({ username: u });
//       if (!sess?.session_id || !sess?.session_token || !sess?.encryption_key) {
//         setError("Unable to start login session.");
//         return;
//       }
//       setSessionId(sess.session_id);
//       setSessionToken(sess.session_token);
//       setEncryptionKey(sess.encryption_key);

//       // 2) Validate login
//       const loginRes = await loginValidation({
//         session_id: sess.session_id,
//         session_token: sess.session_token,
//         username: u,
//         passwordPlain: p,
//         encryption_key: sess.encryption_key,
//       });

//       // 3) Handle statuses
//       if (loginRes?.status === 4) {
//         if (loginRes.session_id) setSessionId(loginRes.session_id);
//         if (loginRes.session_token) setSessionToken(loginRes.session_token);
//         setOtp("");
//         setShowConfirm(true);
//       } else if (loginRes?.status === 1) {
//         if (loginRes.session_id) setSessionId(loginRes.session_id);
//         if (loginRes.session_token) setSessionToken(loginRes.session_token);
//         setOtp("");
//         setShowOtp(true);
//       } else if (loginRes?.status === 2 && loginRes.session_token) {
//         // Direct success
//         login({
//           session_id: loginRes.session_id,
//           session_token: loginRes.session_token,
//           user_id: loginRes.user_id,
//           user_name: loginRes.user_name,
//           full_name: loginRes.full_name,
//           role_id: loginRes.RoleId,
//           encryption_key: sess.encryption_key,
//         });
//         navigate("/dashboard", { replace: true });
//       } else if (loginRes?.status === 5) {
//         setError("Account locked due to multiple wrong attempts.");
//       } else {
//         setError(loginRes?.msg || loginRes?.message || "Invalid credentials.");
//       }
//     } catch (e) {
//       setError("Error during login.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   // const handleConfirm = async (yes) => {
//   //   setShowConfirm(false);
//   //   if (!yes) return;

//   //   setLoading(true);
//   //   try {
//   //     const reLoginRes = await reLogin({
//   //       session_id: sessionId,
//   //       session_token: sessionToken, // keep if your API expects it; harmless if ignored
//   //       username: username.trim(),
//   //     });

//   //     if (reLoginRes?.status === 1) {
//   //       if (reLoginRes.session_id) setSessionId(reLoginRes.session_id);
//   //       if (reLoginRes.session_token) setSessionToken(reLoginRes.session_token);
//   //       setOtp("");
//   //       setShowOtp(true);
//   //     } else {
//   //       setError(
//   //         reLoginRes?.msg || reLoginRes?.message || "Unable to re-login."
//   //       );
//   //     }
//   //   } catch (e) {
//   //     setError("Error during re-login.");
//   //   } finally {
//   //     setLoading(false);
//   //   }
//   // };
//   const handleConfirm = async (yes) => {
//     setShowConfirm(false);
//     if (!yes) return;
//     setLoading(true);
//     try {
//       // ReLogin (same AES-ECB + HEX key)
//       const reLoginRes = await reLogin({
//         session_id: sessionId,
//         session_token: sessionToken,
//         username: username.trim(),
//         passwordPlain: password.trim(),
//         encryption_key: encryptionKey,
//       });

//       if (reLoginRes.status === 1) {
//         if (reLoginRes.session_id) setSessionId(reLoginRes.session_id);
//         if (reLoginRes.session_token) setSessionToken(reLoginRes.session_token);
//         setOtp("");
//         setShowOtp(true);
//       } else {
//         setError(reLoginRes.msg || reLoginRes.message || "Unable to re-login.");
//       }
//     } catch (e) {
//       setError("Error during re-login.");
//     } finally {
//       setLoading(false);
//     }
//   };
//   const handleValidateOtp = async () => {
//     setError("");
//     const code = otp.trim();
//     if (!code) return setError("Please enter OTP.");
//     setLoading(true);
//     try {
//       const res = await validateOTP({
//         session_id: sessionId,
//         session_token: sessionToken,
//         otp_number: code,
//       });

//       if (res?.status === 1) {
//         login({
//           session_id: sessionId,
//           session_token: res.session_token,
//           user_id: res.user_id,
//           user_name: res.user_name,
//           full_name: res.full_name,
//           role_id: res.RoleId,
//           encryption_key: encryptionKey,
//         });
//         navigate("/dashboard", { replace: true });
//       } else if (res?.status === 6) {
//         setError("OTP expired. Please login again.");
//       } else if (res?.status === 5) {
//         setError("Account locked due to multiple wrong attempts.");
//       } else {
//         setError(res?.msg || res?.message || "Invalid OTP.");
//       }
//     } catch (e) {
//       setError("Error validating OTP.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="login_card_section py-5">
//       <div className="container">
//         <div className="row justify-content-center">
//           <div className="col-md-8">
//             <div className="login_form_card p-4 shadow-sm bg-white rounded">
//               <h4 className="mb-3 text-center">Family Reunion - Italy</h4>

//               {error && <div className="alert alert-danger">{error}</div>}

//               {!showOtp && (
//                 <>
//                   <div className="mb-3">
//                     <label className="form-label">
//                       Username <span className="text-danger">*</span>
//                     </label>
//                     <input
//                       type="text"
//                       className="form-control"
//                       value={username}
//                       disabled={loading}
//                       onChange={(e) => setUsername(e.target.value)}
//                       autoComplete="username"
//                     />
//                   </div>
//                   <div className="mb-3">
//                     <label className="form-label">
//                       Password <span className="text-danger">*</span>
//                     </label>
//                     <input
//                       type="password"
//                       className="form-control"
//                       value={password}
//                       disabled={loading}
//                       onChange={(e) => setPassword(e.target.value)}
//                       autoComplete="current-password"
//                     />
//                   </div>
//                   <button
//                     type="button"
//                     className="btn btn-primary w-100"
//                     disabled={loading}
//                     onClick={handleLogin}
//                   >
//                     {loading ? "Login" : "Login"}
//                   </button>
//                 </>
//               )}

//               {showOtp && (
//                 <>
//                   <div className="mb-3">
//                     <label className="form-label">
//                       Enter OTP <span className="text-danger">*</span>
//                     </label>
//                     <input
//                       type="password"
//                       className="form-control"
//                       value={otp}
//                       disabled={loading}
//                       onChange={(e) => setOtp(e.target.value)}
//                       autoComplete="one-time-code"
//                       maxLength={6}
//                       inputMode="numeric"
//                     />
//                   </div>
//                   <button
//                     type="button"
//                     className="btn btn-success w-100"
//                     disabled={loading}
//                     onClick={handleValidateOtp}
//                   >
//                     {loading ? "Validate OTP" : "Validate OTP"}
//                   </button>
//                 </>
//               )}
//             </div>
//           </div>
//         </div>
//       </div>

//       {showConfirm && (
//         <div
//           className="modal fade show"
//           style={{ display: "block", background: "rgba(0,0,0,0.5)" }}
//         >
//           <div className="modal-dialog">
//             <div className="modal-content" style={{ width: "30rem" }}>
//               <div className="modal-body">
//                 <span className="model_title">Confirmation Message</span>
//                 <hr />
//                 You have an active login session already. Terminate the old
//                 session?
//               </div>
//               <div className="modal-footer">
//                 <button
//                   className="btn btn-danger"
//                   onClick={() => handleConfirm(true)}
//                 >
//                   Yes
//                 </button>
//                 <button
//                   className="btn btn-secondary"
//                   onClick={() => handleConfirm(false)}
//                 >
//                   No
//                 </button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

// import { useEffect, useMemo, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import {
//   getSession,
//   loginValidation,
//   reLogin,
//   validateOTP,
// } from "../api/client";

// export default function Login() {
//   const navigate = useNavigate();

//   // === change this if your login route is different ===
//   const LOGIN_ROUTE = "/Login";

//   // Form
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [otp, setOtp] = useState("");

//   // Session
//   const [sessionId, setSessionId] = useState("");
//   const [sessionToken, setSessionToken] = useState("");
//   const [encryptionKey, setEncryptionKey] = useState(""); // HEX key

//   // UI state
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState("");
//   const [showOtp, setShowOtp] = useState(false);
//   const [showConfirm, setShowConfirm] = useState(false);

//   // Reset everything and navigate to login
//   const resetToLogin = () => {
//     setUsername("");
//     setPassword("");
//     setOtp("");
//     setSessionId("");
//     setSessionToken("");
//     setEncryptionKey("");
//     setShowOtp(false);
//     setShowConfirm(false);
//     setError("");
//     navigate(LOGIN_ROUTE, { replace: true });
//   };

//   // OTP Timer (300s = 5:00)
//   const OTP_SECONDS = 300;
//   const [remaining, setRemaining] = useState(OTP_SECONDS);
//   const timeLeft = useMemo(() => {
//     const m = String(Math.floor(remaining / 60)).padStart(2, "0");
//     const s = String(remaining % 60).padStart(2, "0");
//     return `${m}:${s}`;
//   }, [remaining]);

//   useEffect(() => {
//     if (!showOtp) return;
//     setRemaining(OTP_SECONDS);
//     const t = setInterval(() => {
//       setRemaining((r) => {
//         if (r <= 1) {
//           clearInterval(t);
//           // OTP EXPIRED → go back to login and clear everything
//           resetToLogin();
//           return OTP_SECONDS;
//         }
//         return r - 1;
//       });
//     }, 1000);
//     return () => clearInterval(t);
//   }, [showOtp]); // eslint-disable-line react-hooks/exhaustive-deps

//   const handleLogin = async () => {
//     setError("");
//     const u = username.trim();
//     const p = password.trim();
//     if (!u || !p) {
//       setError("Username and password are required.");
//       return;
//     }
//     setLoading(true);
//     try {
//       // Step 1: Get session (encryption_key HEX)
//       const sess = await getSession({ username: u });
//       if (!sess?.session_id || !sess?.session_token || !sess?.encryption_key) {
//         setError("Unable to start login session.");
//         return;
//       }
//       setSessionId(sess.session_id);
//       setSessionToken(sess.session_token);
//       setEncryptionKey(sess.encryption_key);

//       // Step 2: Login (encrypts inside API client)
//       const loginRes = await loginValidation({
//         session_id: sess.session_id,
//         session_token: sess.session_token,
//         username: u,
//         passwordPlain: p,
//         encryption_key: sess.encryption_key,
//       });

//       if (loginRes.status === 1) {
//         // OTP sent — stay on same page and show OTP box
//         if (loginRes.session_id) setSessionId(loginRes.session_id);
//         if (loginRes.session_token) setSessionToken(loginRes.session_token);
//         setOtp("");
//         setShowOtp(true);
//       } else if (loginRes.status === 4) {
//         // Already logged in — ask to terminate old session
//         if (loginRes.session_id) setSessionId(loginRes.session_id);
//         if (loginRes.session_token) setSessionToken(loginRes.session_token);
//         setShowConfirm(true);
//       } else if (loginRes.status === 5) {
//         setError("Account has been blocked due to max attempts.");
//       } else {
//         setError(loginRes.msg || loginRes.message || "Invalid credentials.");
//       }
//     } catch {
//       setError("Error during login.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const confirmRelogin = async (yes) => {
//     setShowConfirm(false);
//     if (!yes) return;
//     setLoading(true);
//     try {
//       const reLoginRes = await reLogin({
//         session_id: sessionId,
//         session_token: sessionToken,
//         username: username.trim(),
//         passwordPlain: password.trim(),
//         encryption_key: encryptionKey,
//       });

//       if (reLoginRes.status === 1) {
//         if (reLoginRes.session_id) setSessionId(reLoginRes.session_id);
//         if (reLoginRes.session_token) setSessionToken(reLoginRes.session_token);
//         setOtp("");
//         setShowOtp(true);
//       } else if (reLoginRes.status === 5) {
//         setError("Account has been blocked due to max attempts.");
//       } else {
//         setError(reLoginRes.msg || reLoginRes.message || "Unable to re-login.");
//       }
//     } catch {
//       setError("Error during re-login.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleValidateOtp = async () => {
//     setError("");
//     if (!otp.trim()) {
//       setError("Please enter OTP.");
//       return;
//     }
//     setLoading(true);
//     try {
//       const res = await validateOTP({
//         session_id: sessionId,
//         session_token: sessionToken,
//         otp_number: otp.trim(),
//       });

//       if (res.status === 1) {
//         navigate("/dashboard", { replace: true });
//       } else if (res.status === 6) {
//         // OTP EXPIRED from server → go back to login and clear all
//         resetToLogin();
//       } else if (res.status === 5) {
//         setError("Account locked due to multiple wrong attempts.");
//         setShowOtp(false);
//       } else if (res.status === 2) {
//         setError("Invalid session.");
//         setShowOtp(false);
//       } else {
//         setError(res.msg || res.message || "Invalid OTP.");
//       }
//     } catch {
//       setError("Error validating OTP.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="py-5">
//       {/* Loader overlay */}
//       {loading && (
//         <div
//           style={{
//             position: "fixed",
//             inset: 0,
//             background: "rgba(0,0,0,0.35)",
//             zIndex: 1050,
//             display: "grid",
//             placeItems: "center",
//           }}
//         >
//           <div className="spinner-border text-light" role="status" />
//         </div>
//       )}

//       <div className="container">
//         <div className="row justify-content-center">
//           <div className="col-lg-7">
//             <div className="p-4 bg-white rounded shadow-sm">
//               <h3 className="text-center mb-3">Family Reunion - Italy</h3>

//               {/* Important note (only when OTP step visible) */}
//               {showOtp && (
//                 <div className="alert ">
//                   <span>Important Note!</span>
//                   <p style={{ fontSize: ".82rem", marginBottom: 0 }}>
//                     To adhere to the enhanced login security and directed by our
//                     information security team, we have enabled the Two-Factor
//                     authentication (Email) for all login processes. Please share
//                     the email IDs associated with each login credential to{" "}
//                     <a href="mailto:vfssupport@mioot.com">
//                       vfssupport@mioot.com
//                     </a>{" "}
//                     and{" "}
//                     <a href="mailto:rajkumar@neesoft.com">
//                       rajkumar@neesoft.com
//                     </a>
//                     . We will do the necessary configurations and confirm.
//                     <b> PLEASE IGNORE IF SHARED / CONFIGURED ALREADY.</b>
//                     <br />
//                     Apologies for the inconvenience.
//                   </p>
//                 </div>
//               )}

//               {error && <div className="alert alert-danger">{error}</div>}

//               {/* Credentials */}
//               <div className="mb-3">
//                 <label className="form-label">
//                   Username <span className="text-danger">*</span>
//                 </label>
//                 <input
//                   type="text"
//                   className="form-control"
//                   value={username}
//                   onChange={(e) => setUsername(e.target.value)}
//                   autoComplete="username"
//                   disabled={showOtp}
//                 />
//               </div>
//               <div className="mb-3">
//                 <label className="form-label">
//                   Password <span className="text-danger">*</span>
//                 </label>
//                 <input
//                   type="password"
//                   className="form-control"
//                   value={password}
//                   onChange={(e) => setPassword(e.target.value)}
//                   autoComplete="current-password"
//                   disabled={showOtp}
//                 />
//               </div>

//               {/* Primary button area */}
//               {!showOtp ? (
//                 <button
//                   id="btnValLog"
//                   className="btn btn-warning w-100"
//                   onClick={handleLogin}
//                   disabled={loading}
//                   style={{
//                     color: "#fff",
//                     backgroundColor: "#ea6a1c",
//                     border: "none",
//                   }}
//                 >
//                   Login
//                 </button>
//               ) : (
//                 <>
//                   <div className="mb-3 mt-3">
//                     <label className="form-label">
//                       Enter OTP <span className="text-danger">*</span>
//                     </label>
//                     <input
//                       type="password"
//                       className="form-control"
//                       value={otp}
//                       onChange={(e) => setOtp(e.target.value)}
//                       autoComplete="one-time-code"
//                       maxLength={6}
//                     />
//                   </div>

//                   <div className="mb-2">
//                     <span id="timer" className="text-muted">
//                       Time left : {timeLeft}
//                     </span>
//                   </div>

//                   <button
//                     id="btnValOTP"
//                     className="btn btn-warning w-100"
//                     onClick={handleValidateOtp}
//                     disabled={loading}
//                     style={{
//                       color: "#fff",
//                       backgroundColor: "#ea6a1c",
//                       border: "none",
//                     }}
//                   >
//                     Validate OTP
//                   </button>
//                 </>
//               )}
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Re-login confirmation modal (status 4) */}
//       {showConfirm && (
//         <div
//           className="modal fade show"
//           style={{ display: "block", background: "rgba(0,0,0,0.5)" }}
//         >
//           <div className="modal-dialog">
//             <div className="modal-content" style={{ width: "30rem" }}>
//               <div className="modal-body">
//                 <span className="model_title">Confirmation Message</span>
//                 <hr />
//                 You have an active login session already. Terminate the old
//                 session?
//               </div>
//               <div className="modal-footer">
//                 <button
//                   className="btn btn-danger"
//                   onClick={() => confirmRelogin(true)}
//                 >
//                   Yes
//                 </button>
//                 <button
//                   className="btn btn-secondary"
//                   onClick={() => confirmRelogin(false)}
//                 >
//                   No
//                 </button>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }

import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  getSession,
  loginValidation,
  reLogin,
  validateOTP,
  getRole,
} from "../api/client";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();

  // === change this if your login route is different ===
  const LOGIN_ROUTE = "/Login";

  // Form
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");

  // Field-level errors (border highlight)
  const [errors, setErrors] = useState({
    username: false,
    password: false,
    otp: false,
  });

  // Session
  const [sessionId, setSessionId] = useState("");
  const [sessionToken, setSessionToken] = useState("");
  const [encryptionKey, setEncryptionKey] = useState(""); // HEX key

  // UI state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showOtp, setShowOtp] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // Reset everything and navigate to login
  const resetToLogin = () => {
    setUsername("");
    setPassword("");
    setOtp("");
    setSessionId("");
    setSessionToken("");
    setEncryptionKey("");
    setShowOtp(false);
    setShowConfirm(false);
    setError("");
    setErrors({ username: false, password: false, otp: false });
    navigate(LOGIN_ROUTE, { replace: true });
  };

  // OTP Timer (300s = 5:00)
  const OTP_SECONDS = 300;
  const [remaining, setRemaining] = useState(OTP_SECONDS);
  const timeLeft = useMemo(() => {
    const m = String(Math.floor(remaining / 60)).padStart(2, "0");
    const s = String(remaining % 60).padStart(2, "0");
    return `${m}:${s}`;
  }, [remaining]);

  useEffect(() => {
    if (!showOtp) return;
    setRemaining(OTP_SECONDS);
    const t = setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          clearInterval(t);
          // OTP EXPIRED → go back to login and clear everything
          resetToLogin();
          return OTP_SECONDS;
        }
        return r - 1;
      });
    }, 1000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showOtp]);

  // -----------------------------
  // Validation helpers (like sample)
  // -----------------------------
  const restrictedChars = /[<|>()'"*;:={}]/g;
  const usernameRe = /^[A-Za-z0-9]+$/; // PHP expects alphanumeric
  const otpRe = /^[0-9]{0,6}$/; // allow typing up to 6; final check uses {6}

  const validateCredentials = () => {
    const u = username.trim();
    const p = password.trim();
    const errs = {
      username: !(
        u &&
        usernameRe.test(u) &&
        u.length >= 3 &&
        u.length <= 25 &&
        !restrictedChars.test(u)
      ),
      password: !(p && !restrictedChars.test(p) && p.length >= 3),
      otp: false,
    };
    setErrors(errs);
    return !errs.username && !errs.password;
  };

  const validateOtpField = () => {
    const o = otp.trim();
    const errs = {
      ...errors,
      otp: !(o && /^[0-9]{6}$/.test(o) && !restrictedChars.test(o)),
    };
    setErrors(errs);
    return !errs.otp;
  };

  // Restrictive onChange similar to your example
  const onChangeUsername = (e) => {
    const val = e.target.value;
    // allow only alphanumeric while typing
    if (/^[A-Za-z0-9]*$/.test(val) && !restrictedChars.test(val)) {
      setUsername(val);
      if (errors.username) setErrors((pr) => ({ ...pr, username: false }));
    }
  };

  const onChangePassword = (e) => {
    const val = e.target.value;
    if (!restrictedChars.test(val)) {
      setPassword(val);
      if (errors.password) setErrors((pr) => ({ ...pr, password: false }));
    }
  };

  const onChangeOtp = (e) => {
    const val = e.target.value;
    if (otpRe.test(val)) {
      setOtp(val);
      if (errors.otp) setErrors((pr) => ({ ...pr, otp: false }));
    }
  };

  // Submit handlers
  const handleLogin = async () => {
    setError("");
    if (!validateCredentials()) return;

    const u = username.trim();
    const p = password.trim();

    setLoading(true);
    try {
      // Step 1: Get session (encryption_key HEX)
      const sess = await getSession({ username: u });
      if (!sess?.session_id || !sess?.session_token || !sess?.encryption_key) {
        // setError("Unable to start login session.");
        alert("Invalid Credentials");
        return;
      }
      setSessionId(sess.session_id);
      setSessionToken(sess.session_token);
      setEncryptionKey(sess.encryption_key);

      // Step 2: Login (encrypts inside API client)
      const loginRes = await loginValidation({
        session_id: sess.session_id,
        session_token: sess.session_token,
        username: u,
        passwordPlain: p,
        encryption_key: sess.encryption_key,
      });

      if (loginRes.status === 1) {
        // OTP sent — stay on same page and show OTP box
        if (loginRes.session_id) setSessionId(loginRes.session_id);
        if (loginRes.session_token) setSessionToken(loginRes.session_token);
        setOtp("");
        setErrors((pr) => ({ ...pr, otp: false }));
        setShowOtp(true);
      } else if (loginRes.status === 4) {
        // Already logged in — ask to terminate old session
        if (loginRes.session_id) setSessionId(loginRes.session_id);
        if (loginRes.session_token) setSessionToken(loginRes.session_token);
        setShowConfirm(true);
      } else if (loginRes.status === 5) {
        setError("Account has been blocked due to max attempts.");
      } else {
        setError(loginRes.msg || loginRes.message || "Invalid credentials.");
      }
    } catch {
      setError("Error during login.");
    } finally {
      setLoading(false);
    }
  };

  const confirmRelogin = async (yes) => {
    setShowConfirm(false);
    if (!yes) return;
    setLoading(true);
    try {
      const reLoginRes = await reLogin({
        session_id: sessionId,
        session_token: sessionToken,
        username: username.trim(),
        passwordPlain: password.trim(),
        encryption_key: encryptionKey,
      });

      if (reLoginRes.status === 1) {
        if (reLoginRes.session_id) setSessionId(reLoginRes.session_id);
        if (reLoginRes.session_token) setSessionToken(reLoginRes.session_token);
        setOtp("");
        setErrors((pr) => ({ ...pr, otp: false }));
        setShowOtp(true);
      } else if (reLoginRes.status === 5) {
        setError("Account has been blocked due to max attempts.");
      } else {
        setError(reLoginRes.msg || reLoginRes.message || "Unable to re-login.");
      }
    } catch {
      setError("Error during re-login.");
    } finally {
      setLoading(false);
    }
  };

  const handleValidateOtp = async () => {
    setError("");
    if (!validateOtpField()) return;

    setLoading(true);
    try {
      const res = await validateOTP({
        session_id: sessionId,
        session_token: sessionToken,
        otp_number: otp.trim(),
      });

      if (res.status === 1) {
        const roleRes = await getRole({
          session_id: res.session_id || sessionId,
          session_token: res.session_token || sessionToken,
        });

        login({
          session_id: String(
            roleRes?.Globalsessionid || res.session_id || sessionId
          ),
          session_token: String(
            roleRes?.Globalsessiontoken || res.session_token || sessionToken
          ),
          role_id: String(roleRes?.RoleId || ""),
          user: {
            id: String(roleRes?.Globaluserid || "") || null,
            username: roleRes?.user_name || null,
            full_name: roleRes?.full_name || null,
          },
          // DO NOT set ajaxPayload here
        });

        // ✅ Role-based redirect
        switch (String(roleRes?.RoleId || "")) {
          case "1":
            navigate("/CaseList", { replace: true });
            break;
          case "2":
            navigate("/PriorityCases", { replace: true });
            break;
          case "3":
            navigate("PriorityCases", { replace: true });
            break;
          case "4":
            navigate("PriorityCases", { replace: true });
            break;
          default:
            navigate("/dashboard", { replace: true });
        }
      } else if (res.status === 6) {
        // OTP expired (server) → back to login + clear all
        resetToLogin();
      } else if (res.status === 5) {
        setError("Account locked due to multiple wrong attempts.");
        setShowOtp(false);
      } else if (res.status === 2) {
        setError("Invalid session.");
        setShowOtp(false);
      } else {
        setError(res.msg || res.message || "Invalid OTP.");
      }
    } catch {
      setError("Error validating OTP.");
    } finally {
      setLoading(false);
    }
  };

  // Submit on Enter (nice UX)
  const onKeyDown = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      if (!showOtp) handleLogin();
      else handleValidateOtp();
    }
  };

  return (
    <div className="py-5" onKeyDown={onKeyDown}>
      {/* Loader overlay */}
      {loading && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.35)",
            zIndex: 1050,
            display: "grid",
            placeItems: "center",
          }}
        >
          <div className="spinner-border text-light" role="status" />
        </div>
      )}

      <main className="flex-shrink-0">
        <section className="dash_section">
          <div className="container">
            <div className="row ">
              <div className="col-md-8 offset-md-2">
                <div className="login_form_card">
                  <h5 className="text-center mb-1">Family Reunion - Italy</h5>

                  {/* Important note (only when OTP step visible) */}
                  {showOtp && (
                    <div className="alert_message">
                      <span className="star_required">
                        <b>Important Note!</b>
                      </span>
                      <p
                        style={{
                          fontSize: ".82rem",
                          marginBottom: 0,
                          lineHeight: 1.5,
                        }}
                      >
                        To adhere to the enhanced login security and directed by
                        our information security team, we have enabled the
                        Two-Factor authentication (Email) for all login
                        processes. Please share the email IDs associated with
                        each login credential to{" "}
                        <a href="mailto:vfssupport@mioot.com">
                          vfssupport@mioot.com
                        </a>{" "}
                        and{" "}
                        <a href="mailto:rajkumar@neesoft.com">
                          rajkumar@neesoft.com
                        </a>
                        . We will do the necessary configurations and confirm.
                        <b> PLEASE IGNORE IF SHARED / CONFIGURED ALREADY.</b>
                        <br />
                        Apologies for the inconvenience.
                      </p>
                    </div>
                  )}

                  {error && <div className="alert alert-danger">{error}</div>}

                  {/* Credentials */}
                  <div className="">
                    <label className="form-label">
                      Username <span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      className={`form-control ${
                        errors.username ? "border-danger" : ""
                      }`}
                      value={username}
                      onChange={onChangeUsername}
                      autoComplete="username"
                      disabled={showOtp}
                      minLength={3}
                      maxLength={25}
                    />
                  </div>
                  <div className="">
                    <label className="form-label">
                      Password <span className="text-danger">*</span>
                    </label>
                    <input
                      type="password"
                      className={`form-control ${
                        errors.password ? "border-danger" : ""
                      }`}
                      value={password}
                      onChange={onChangePassword}
                      autoComplete="current-password"
                      disabled={showOtp}
                      minLength={3}
                    />
                  </div>

                  {/* Primary button area */}
                  {!showOtp ? (
                    <button
                      id="btnValLog"
                      className="btn login-btn w-100 mt-3"
                      onClick={handleLogin}
                      disabled={loading}
                    >
                      Login
                    </button>
                  ) : (
                    <>
                      <div className="">
                        <label className="form-label">
                          Enter OTP <span className="text-danger">*</span>
                        </label>
                        <input
                          type="password"
                          className={`form-control ${
                            errors.otp ? "border-danger" : ""
                          }`}
                          value={otp}
                          onChange={onChangeOtp}
                          autoComplete="one-time-code"
                          maxLength={6}
                          inputMode="numeric"
                          pattern="[0-9]*"
                        />
                      </div>

                      <div className="mt-1 mb-1">
                        <span id="timer">Time left : {timeLeft}</span>
                      </div>

                      <button
                        id="btnValOTP"
                        className="btn login-btn w-100"
                        onClick={handleValidateOtp}
                        disabled={loading}
                      >
                        Validate OTP
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Re-login confirmation modal (status 4) */}
      {showConfirm && (
        <div
          className="modal fade show"
          style={{ display: "block", background: "rgba(0,0,0,0.5)" }}
        >
          <div className="modal-dialog login-confirm-dialog">
            <div className="modal-content">
              <div className="modal-body">
                <span className="model_title">Confirmation Message</span>
                <hr />
                You have an active login session already. Terminate the old
                session?
              </div>
              <div className="modal-footer">
                <button
                  className="btn login-btn"
                  onClick={() => confirmRelogin(true)}
                >
                  Yes
                </button>
                <button
                  className="btn login-btn"
                  onClick={() => confirmRelogin(false)}
                >
                  No
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
