import React, { useMemo, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import AjaxValidation from "../hooks/AjaxValidation";
import { useAuth } from "../context/AuthContext";
import { slotProcess } from "../api/client";
import { Navigate, useNavigate } from "react-router-dom";

/* ------------ Helpers ------------ */
function toDate_DDMonYYYY(d) {
  if (!d) return "";
  const dd = String(d.getDate()).padStart(2, "0");
  const mmm = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ][d.getMonth()];
  const yyyy = d.getFullYear();
  return `${dd}-${mmm}-${yyyy}`;
}
function fmtHHmm(d) {
  if (!d) return "";
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${hh}:${mm}`;
}
function minutesOf(d) {
  return d.getHours() * 60 + d.getMinutes();
}
function dayValue(d) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

/* Show only ONE error at a time (top priority first) */
const ERROR_ORDER = [
  "vac",
  "startDate",
  "endDate",
  "startTime",
  "endTime",
  "breakPair",
  "intervalMin",
  "noOfSlot",
  "priority",
];

export default function AddSlot() {
  const { authData } = useAuth();
  const vacOptions = authData?.ajaxPayload?.vac_list || [];
  const navigate = useNavigate();
  // Form state
  const [vac, setVac] = useState("0");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);

  const [startTime, setStartTime] = useState(null); // Date
  const [endTime, setEndTime] = useState(null); // Date
  const [breakStart, setBreakStart] = useState(null); // Date | null
  const [breakEnd, setBreakEnd] = useState(null); // Date | null

  const [intervalMin, setIntervalMin] = useState("0");
  const [noOfSlot, setNoOfSlot] = useState("");
  const [priority, setPriority] = useState(""); // "0" | "1"

  // UI state
  const [errors, setErrors] = useState({}); // holds ONE field only
  // const [serverMsg, setServerMsg] = useState("");

  const minDate = useMemo(() => new Date("2000-01-01"), []);
  const maxDate = useMemo(() => new Date("2100-12-31"), []);
  const timeStep = Number(intervalMin || 5);
  const invalidStyle = { borderColor: "#dc3545" };

  /* Build a full error map, then pick only the first key by ERROR_ORDER */
  function computeErrorMap() {
    const e = {};
    if (vac === "0") e.vac = "Please select a VAC.";

    if (!startDate) e.startDate = "Please choose Start Date.";
    if (!endDate) e.endDate = "Please choose End Date.";
    if (startDate && endDate && dayValue(startDate) > dayValue(endDate)) {
      e.endDate = "End Date must be after Start Date.";
    }

    if (!startTime) e.startTime = "Choose Start Time.";
    if (!endTime) e.endTime = "Choose End Time.";
    if (startTime && endTime && minutesOf(startTime) >= minutesOf(endTime)) {
      e.endTime = "End Time must be after Start Time.";
    }

    // Break validations (treated as a single logical error "breakPair")
    const hasB1 = !!breakStart;
    const hasB2 = !!breakEnd;
    if ((hasB1 && !hasB2) || (!hasB1 && hasB2)) {
      e.breakPair =
        "Provide both Break Start and Break End or leave both empty.";
    } else if (hasB1 && hasB2) {
      if (minutesOf(breakStart) >= minutesOf(breakEnd)) {
        e.breakPair = "Break End Time must be after Break Start Time.";
      } else if (
        (startTime && minutesOf(breakStart) < minutesOf(startTime)) ||
        (endTime && minutesOf(breakEnd) > minutesOf(endTime))
      ) {
        e.breakPair = "Break must lie within Start–End time.";
      }
    }

    if (!intervalMin || intervalMin === "0")
      e.intervalMin = "Choose a Time Interval.";

    const n = Number(noOfSlot);
    if (!Number.isFinite(n) || n <= 0)
      e.noOfSlot = "No of Slot must be a positive number.";

    if (priority !== "0" && priority !== "1") e.priority = "Choose a Priority.";

    return e;
  }

  function pickFirstError(eMap) {
    for (const k of ERROR_ORDER) {
      if (eMap[k]) return { key: k, msg: eMap[k] };
    }
    return null;
  }

  async function handleAdd(ev) {
    ev.preventDefault();
    // setServerMsg("");

    // 1) compute all, 2) show only first in the defined order
    const all = computeErrorMap();
    const first = pickFirstError(all);
    if (first) {
      // Map the composite break error onto a single visible field (breakStart)
      const visualKey = first.key === "breakPair" ? "breakStart" : first.key;
      setErrors({ [visualKey]: first.msg });

      // scroll into view
      const el = document.querySelector(`[data-field="${visualKey}"]`);
      if (el?.scrollIntoView)
        el.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    setErrors({}); // clear

    const payload = {
      usrtid: String(authData?.user_id ?? authData?.role_id ?? ""),
      usrsid: String(authData?.session_id ?? ""),
      usrstkn: String(authData?.session_token ?? ""),
      Date1: toDate_DDMonYYYY(startDate),
      Date2: toDate_DDMonYYYY(endDate),
      Time1: fmtHHmm(startTime),
      Time2: fmtHHmm(endTime),
      BTime1: breakStart ? fmtHHmm(breakStart) : "",
      BTime2: breakEnd ? fmtHHmm(breakEnd) : "",
      Inrvl: String(intervalMin),
      NoOf: String(noOfSlot),
      vac: String(vac),
      RoleId: String(authData?.role_id ?? ""),
      priority: String(priority),
      type: 3,
    };

    try {
      const res = await slotProcess(payload);
      if (res?.status === 2) {
        alert("Slot added successfully");
        // redirect to slot list
        // redirect to slot list
        // reset (keep VAC)
        setStartDate(null);
        setEndDate(null);
        setStartTime(null);
        setEndTime(null);
        setBreakStart(null);
        setBreakEnd(null);
        setIntervalMin("5");
        setNoOfSlot("");
        setPriority("");
        navigate("/SlotList");
      } else {
        alert(res?.msg || "Failed to add slot(s).");
      }
    } catch (err) {
      console.error("SlotProcess error:", err);
      alert(err?.message || "Slot creation failed.");
    }
  }

  // Clear the single visible error when editing its field
  const clearErr = (k) => setErrors((prev) => (prev[k] ? {} : prev));

  return (
    <AjaxValidation>
      <div id="dash">
        <section>
          <div className="container-fluid">
            <div className="row">
              <div className="col-md-12">
                <div className="admin_form_section">
                  <div className="admin_form_card data_table_view">
                    <div className="head_title">
                      <div className="row">
                        <div className="col-md-12">
                          <h5 className="p-0 m-0">Add Slot</h5>
                        </div>
                      </div>

                      {/* {serverMsg ? (
                        <div className="alert alert-info mt-2 mb-0 py-2">
                          {serverMsg}
                        </div>
                      ) : null} */}

                      <form
                        className="mt-2 mb-3"
                        onSubmit={handleAdd}
                        style={{ padding: "0 10px", background: "#d8d8d820" }}
                      >
                        <div className="privacy_list p-2 ">
                          <div className="form-group row pt-1">
                            {/* VAC */}
                            <div
                              className="col-sm-3 col-md-4 col-lg-3"
                              data-field="vac"
                            >
                              <label className="form-label">VAC List</label>
                              <select
                                className={`form-control ${
                                  errors.vac ? "is-invalid" : ""
                                }`}
                                style={errors.vac ? invalidStyle : undefined}
                                value={vac}
                                onChange={(e) => {
                                  setVac(e.target.value);
                                  clearErr("vac");
                                }}
                              >
                                <option value="0">---Select VAC---</option>
                                {vacOptions.map((v) => (
                                  <option
                                    key={v.vac_id}
                                    value={String(v.vac_id)}
                                  >
                                    {v.vac_name}
                                  </option>
                                ))}
                              </select>
                              {/* {errors.vac && (
                                <div className="invalid-feedback d-block">
                                  {errors.vac}
                                </div>
                              )} */}
                            </div>

                            {/* Start Date */}
                            <div
                              className="col-sm-3 col-md-4 col-lg-3"
                              data-field="startDate"
                            >
                              <label className="form-label">Start Date</label>
                              <div className="input-group date ">
                                <DatePicker
                                  selected={startDate}
                                  onChange={(d) => {
                                    setStartDate(d);
                                    clearErr("startDate");
                                  }}
                                  className={`form-control ${
                                    errors.startDate ? "is-invalid" : ""
                                  }`}
                                  style={
                                    errors.startDate ? invalidStyle : undefined
                                  }
                                  placeholderText="Start Date"
                                  dateFormat="dd-MM-yyyy"
                                  minDate={minDate}
                                  maxDate={maxDate}
                                />
                              </div>
                              {/* {errors.startDate && (
                                <div className="invalid-feedback d-block">
                                  {errors.startDate}
                                </div>
                              )} */}
                            </div>

                            {/* End Date */}
                            <div
                              className="col-sm-3 col-md-4 col-lg-3"
                              data-field="endDate"
                            >
                              <label className="form-label">End Date</label>
                              <div className="input-group date">
                                <DatePicker
                                  selected={endDate}
                                  onChange={(d) => {
                                    setEndDate(d);
                                    clearErr("endDate");
                                  }}
                                  className={`form-control ${
                                    errors.endDate ? "is-invalid" : ""
                                  }`}
                                  style={
                                    errors.endDate ? invalidStyle : undefined
                                  }
                                  placeholderText="End Date"
                                  dateFormat="dd-MM-yyyy"
                                  minDate={minDate}
                                  maxDate={maxDate}
                                />
                              </div>
                              {/* {errors.endDate && (
                                <div className="invalid-feedback d-block">
                                  {errors.endDate}
                                </div>
                              )} */}
                            </div>

                            {/* Start Time */}
                            <div
                              className="col-sm-3 col-md-4 col-lg-3"
                              data-field="startTime"
                            >
                              <label className="form-label">Start Time</label>
                              <DatePicker
                                selected={startTime}
                                onChange={(d) => {
                                  setStartTime(d);
                                  clearErr("startTime");
                                }}
                                showTimeSelect
                                showTimeSelectOnly
                                timeIntervals={timeStep}
                                timeCaption="Time"
                                dateFormat="HH:mm"
                                placeholderText="00:00"
                                className={`form-control ${
                                  errors.startTime ? "is-invalid" : ""
                                }`}
                                style={
                                  errors.startTime ? invalidStyle : undefined
                                }
                                isClearable
                              />
                              {/* {errors.startTime && (
                                <div className="invalid-feedback d-block">
                                  {errors.startTime}
                                </div>
                              )} */}
                            </div>
                          </div>

                          <div className="form-group row pt-2">
                            {/* End Time */}
                            <div
                              className="col-sm-3 col-md-4 col-lg-3"
                              data-field="endTime"
                            >
                              <label className="form-label">End Time</label>
                              <DatePicker
                                selected={endTime}
                                onChange={(d) => {
                                  setEndTime(d);
                                  clearErr("endTime");
                                }}
                                showTimeSelect
                                showTimeSelectOnly
                                timeIntervals={timeStep}
                                timeCaption="Time"
                                dateFormat="HH:mm"
                                placeholderText="00:00"
                                className={`form-control ${
                                  errors.endTime ? "is-invalid" : ""
                                }`}
                                style={
                                  errors.endTime ? invalidStyle : undefined
                                }
                                isClearable
                              />
                              {/* {errors.endTime && (
                                <div className="invalid-feedback d-block">
                                  {errors.endTime}
                                </div>
                              )} */}
                            </div>

                            {/* Break Start (maps all break errors to this field) */}
                            <div
                              className="col-sm-3 col-md-4 col-lg-3"
                              data-field="breakStart"
                            >
                              <label className="form-label">
                                Break Start Time
                              </label>
                              <DatePicker
                                selected={breakStart}
                                onChange={(d) => {
                                  setBreakStart(d);
                                  clearErr("breakStart");
                                }}
                                showTimeSelect
                                showTimeSelectOnly
                                timeIntervals={timeStep}
                                timeCaption="Time"
                                dateFormat="HH:mm"
                                placeholderText="00:00"
                                className={`form-control ${
                                  errors.breakStart ? "is-invalid" : ""
                                }`}
                                style={
                                  errors.breakStart ? invalidStyle : undefined
                                }
                                isClearable
                              />
                              {/* {errors.breakStart && (
                                <div className="invalid-feedback d-block">
                                  {errors.breakStart}
                                </div>
                              )} */}
                            </div>

                            {/* Break End */}
                            <div
                              className="col-sm-3 col-md-4 col-lg-3"
                              data-field="breakEnd"
                            >
                              <label className="form-label">
                                Break End Time
                              </label>
                              <DatePicker
                                selected={breakEnd}
                                onChange={(d) => {
                                  setBreakEnd(d);
                                  // note: break errors are mapped to breakStart
                                }}
                                showTimeSelect
                                showTimeSelectOnly
                                timeIntervals={timeStep}
                                timeCaption="Time"
                                dateFormat="HH:mm"
                                placeholderText="00:00"
                                className="form-control"
                                isClearable
                              />
                            </div>

                            {/* Interval */}
                            <div
                              className="col-sm-3 col-md-4 col-lg-3"
                              data-field="intervalMin"
                            >
                              <label className="form-label">
                                Time Interval
                              </label>
                              <select
                                className={`form-control ${
                                  errors.intervalMin ? "is-invalid" : ""
                                }`}
                                style={
                                  errors.intervalMin ? invalidStyle : undefined
                                }
                                value={intervalMin}
                                onChange={(e) => {
                                  setIntervalMin(e.target.value);
                                  clearErr("intervalMin");
                                }}
                              >
                                <option value="0">---Select Interval---</option>
                                {Array.from(
                                  { length: 9 },
                                  (_, i) => 5 * (i + 1)
                                ).map((n) => (
                                  <option key={n} value={String(n)}>
                                    {n}
                                  </option>
                                ))}
                              </select>
                              {/* {errors.intervalMin && (
                                <div className="invalid-feedback d-block">
                                  {errors.intervalMin}
                                </div>
                              )} */}
                            </div>
                          </div>

                          <div className="form-group row pt-2 justify-content-start d-flex align-items-center">
                            {/* No of Slot */}
                            <div
                              className="col-sm-3 col-md-4 col-lg-3"
                              data-field="noOfSlot"
                            >
                              <label className="form-label">No of Slot</label>
                              <input
                                type="text"
                                min="1"
                                className={`form-control ${
                                  errors.noOfSlot ? "is-invalid" : ""
                                }`}
                                style={
                                  errors.noOfSlot ? invalidStyle : undefined
                                }
                                id="NoOfSlot"
                                placeholder="0"
                                value={noOfSlot}
                                onChange={(e) => {
                                  setNoOfSlot(e.target.value);
                                  clearErr("noOfSlot");
                                }}
                                maxLength={2}
                              />
                              {/* {errors.noOfSlot && (
                                <div className="invalid-feedback d-block">
                                  {errors.noOfSlot}
                                </div>
                              )} */}
                            </div>

                            {/* Priority */}
                            <div
                              className="col-sm-3 col-md-4 col-lg-3"
                              data-field="priority"
                            >
                              <label className="form-label">Priority</label>
                              <select
                                className={`form-control ${
                                  errors.priority ? "is-invalid" : ""
                                }`}
                                style={
                                  errors.priority ? invalidStyle : undefined
                                }
                                value={priority}
                                onChange={(e) => {
                                  setPriority(e.target.value);
                                  clearErr("priority");
                                }}
                              >
                                <option value="">---Select Priority---</option>
                                <option value="0">Normal</option>
                                <option value="1">Priority</option>
                              </select>
                              {/* {errors.priority && (
                                <div className="invalid-feedback d-block">
                                  {errors.priority}
                                </div>
                              )} */}
                            </div>

                            {/* Submit */}
                            <div className="col-sm-3 col-md-4 col-lg-3">
                              <button
                                className="btn btn-primary btn-lg login-btn w-100 mt-4"
                                id="btnBookSlot"
                                type="submit"
                              >
                                Add
                              </button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </AjaxValidation>
  );
}
