import React from "react";
import { useAuth } from "../context/AuthContext";
import AjaxValidation from "../hooks/AjaxValidation";

/* ================= endpoints ================= */
const WEBFORM_URL =
  "https://vfseu.mioot.com/forms/UAT/ITAIND/admin/api/Webform/";
const HOLIDAY_URL =
  "https://vfseu.mioot.com/forms/UAT/ITAIND/admin/api/HolidayList/";

/* ================= helpers ================= */
async function postJSON(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Network error (${res.status})`);
  try {
    return await res.json();
  } catch {
    return {};
  }
}

// function normalizeWebformList(res) {
//   const list = Array.isArray(res?.data)
//     ? res.data
//     : Array.isArray(res)
//     ? res
//     : [];
//   return list.map((r, i) => {
//     const vac_id = r.vac_id ?? r.id ?? r.vacid ?? r.vac ?? String(i + 1);
//     const vac_name = r.vac_name ?? r.vac ?? `VAC-${vac_id}`;

//     const normRaw =
//       r.normal ?? r.queue_normal ?? r.normal_status ?? r.is_normal_closed;
//     const priRaw =
//       r.priority ??
//       r.queue_priority ??
//       r.priority_status ??
//       r.is_priority_closed;

//     return {
//       vac_id: String(vac_id),
//       vac_name: String(vac_name),
//       normalClosed: String(normRaw) === "1", // 1 = Close
//       priorityClosed: String(priRaw) === "1", // 1 = Close
//     };
//   });
// }
function normalizeWebformList(res) {
  const list = Array.isArray(res?.data)
    ? res.data
    : Array.isArray(res)
    ? res
    : [];
  return list.map((r, i) => {
    const vac_id = r.vac_id ?? r.id ?? r.vacid ?? r.vac ?? String(i + 1);
    const vac_name = r.vac_name ?? r.vac ?? `VAC-${vac_id}`;

    // 👇 add is_form_off and priority_is_form_off as final fallbacks
    const normRaw =
      r.normal ??
      r.queue_normal ??
      r.normal_status ??
      r.is_normal_closed ??
      r.is_form_off;

    const priRaw =
      r.priority ??
      r.queue_priority ??
      r.priority_status ??
      r.is_priority_closed ??
      r.priority_is_form_off;

    return {
      vac_id: String(vac_id),
      vac_name: String(vac_name),
      normalClosed: String(normRaw) === "1", // 1 = Close
      priorityClosed: String(priRaw) === "1", // 1 = Close
    };
  });
}

/** Prefer server-provided formatted date */
function pickHolidayDate(row) {
  const cand =
    row?.formatted_holiday_date ??
    row?.holidayDate ??
    row?.holiday_date ??
    row?.created_date;
  return cand ?? "-";
}

function normalizeHolidays(res) {
  const list = Array.isArray(res?.data)
    ? res.data
    : Array.isArray(res)
    ? res
    : [];
  return list.map((r, i) => ({
    id: r.id ?? r.holiday_id ?? `${r.vac_id || ""}-${i + 1}`,
    vac_id: String(r.vac_id ?? ""),
    vac_name: r.vac_name ?? r.vac ?? "-",
    name: r.holiday_name ?? r.name ?? "-",
    date: pickHolidayDate(r),
  }));
}

/* ================= page ================= */
export default function Holiday() {
  const { authData } = useAuth();

  const user_id = authData?.user_id ?? authData?.userid ?? authData?.id ?? "";
  const session_id = authData?.session_id || "";
  const session_token = authData?.session_token || "";
  const vacOptions = authData?.ajaxPayload?.vac_list || [];

  // page state
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState("");

  const [webformRows, setWebformRows] = React.useState([]);
  const [holidayRows, setHolidayRows] = React.useState([]);

  // ---- Webform controls ----
  // "" = All, "0" = Normal, "1" = Priority
  const [wfQueueType, setWfQueueType] = React.useState("");
  // "0" = All VACs, otherwise a vac_id
  const [wfVacId, setWfVacId] = React.useState("0");
  // "" (empty on mount), "0" = Open, "1" = Close
  const [wfOpenClose, setWfOpenClose] = React.useState("");

  // ---- Working Plan (Mon..Sun -> 1..7) ----
  const [workingDays, setWorkingDays] = React.useState(
    new Set([1, 2, 3, 4, 5])
  );

  // ---- Add Holiday controls ----
  const [addVacId, setAddVacId] = React.useState("0");
  const [addHolidayName, setAddHolidayName] = React.useState("");
  const [addHolidayDate, setAddHolidayDate] = React.useState("");

  /* -------- loaders (split so we can reload just webform after update) -------- */
  const loadWebform = React.useCallback(
    async (opts) => {
      const vacIdForList = opts?.vacId ?? "0"; // "0" => all
      const queueForList = opts?.queueType ?? ""; // "" => all
      const payload = {
        priority_is_form_off: queueForList, // filter by queue type when provided
        vac_id: vacIdForList, // filter by vac when provided
        session_id,
        session_token,
        user_id,
        project: "italy",
        type: 1,
      };
      const wf = await postJSON(WEBFORM_URL, payload);
      setWebformRows(normalizeWebformList(wf));
    },
    [session_id, session_token, user_id]
  );

  const loadHolidays = React.useCallback(async () => {
    const h = await postJSON(HOLIDAY_URL, {
      user_id,
      session_id,
      session_token,
      type: 1,
    });
    setHolidayRows(normalizeHolidays(h));
  }, [session_id, session_token, user_id]);

  const loadAll = React.useCallback(async () => {
    if (!session_id || !session_token) return;
    setLoading(true);
    setError("");
    try {
      await loadWebform({ vacId: "0", queueType: "" }); // all on first load
      await loadHolidays();
    } catch (e) {
      setError(e.message || "Failed to load data.");
      setWebformRows([]);
      setHolidayRows([]);
    } finally {
      setLoading(false);
    }
  }, [session_id, session_token, loadWebform, loadHolidays]);

  React.useEffect(() => {
    loadAll();
  }, [loadAll]);

  /* -------- actions -------- */

  // Update webform — supports All queue types & All VACs, then reloads with *current* filters
  // async function updateWebform() {
  //   if (wfOpenClose === "") {
  //     alert("Please choose Close/Open.");
  //     return;
  //   }

  //   const vacIds =
  //     wfVacId !== "0" ? [wfVacId] : vacOptions.map((v) => String(v.vac_id));
  //   if (!vacIds.length) {
  //     alert("No VACs available to update.");
  //     return;
  //   }

  //   const queues = wfQueueType === "" ? ["0", "1"] : [wfQueueType];

  //   setLoading(true);
  //   setError("");
  //   try {
  //     for (const vid of vacIds) {
  //       for (const q of queues) {
  //         const payload = {
  //           priority_is_form_off: q, // "0" normal / "1" priority
  //           web_form_on_of: wfOpenClose, // "0" open / "1" close
  //           vac_id: vid,
  //           session_id,
  //           session_token,
  //           user_id,
  //           project: "italy",
  //           type: 2,
  //         };
  //         // eslint-disable-next-line no-await-in-loop
  //         await postJSON(WEBFORM_URL, payload);
  //       }
  //     }

  //     // 🔁 show the latest records *for the current selections*
  //     await loadWebform({
  //       vacId: wfVacId, // "0" (All) or specific VAC
  //       queueType: wfQueueType, // "" (All), "0", "1"
  //     });

  //     alert("Webform status updated.");
  //   } catch (e) {
  //     setError(e.message || "Failed to update webform.");
  //   } finally {
  //     setLoading(false);
  //   }
  // }
  async function updateWebform() {
    if (wfOpenClose === "") {
      alert("Please choose Close/Open.");
      return;
    }

    // VACs to update: specific VAC or ALL VACs
    const vacIds =
      wfVacId !== "0" ? [wfVacId] : vacOptions.map((v) => String(v.vac_id));
    if (!vacIds.length) {
      alert("No VACs available to update.");
      return;
    }

    // Queues to update: specific or BOTH (Normal + Priority)
    const queues = wfQueueType === "" ? ["0", "1"] : [wfQueueType];

    setLoading(true);
    setError("");

    try {
      let lastRes = null;

      // sequential updates (gentle on backend)
      for (const vid of vacIds) {
        for (const q of queues) {
          const payload = {
            priority_is_form_off: q, // "0" = Normal, "1" = Priority
            web_form_on_of: wfOpenClose, // "0" = Open,   "1" = Close
            vac_id: vid,
            session_id,
            session_token,
            user_id,
            project: "italy",
            type: 2,
          };
          // eslint-disable-next-line no-await-in-loop
          lastRes = await postJSON(WEBFORM_URL, payload);
        }
      }

      // Prefer the API's latest list if it came back with the update
      if (Array.isArray(lastRes?.data)) {
        let rows = normalizeWebformList(lastRes);
        if (wfVacId && wfVacId !== "0") {
          rows = rows.filter((r) => String(r.vac_id) === String(wfVacId));
        }
        setWebformRows(rows);
      } else {
        // Fallback: re-fetch list and render for the current filters
        await loadWebform({ vacId: wfVacId, queueType: wfQueueType });
      }

      alert("Webform status updated.");
    } catch (e) {
      setError(e.message || "Failed to update webform.");
    } finally {
      setLoading(false);
    }
  }
  function toggleDay(val) {
    setWorkingDays((prev) => {
      const n = new Set(prev);
      n.has(val) ? n.delete(val) : n.add(val);
      return n;
    });
  }

  async function updateWorkingPlan() {
    const csv = Array.from(workingDays)
      .sort((a, b) => a - b)
      .join(",");
    if (!csv) {
      alert("Please select at least one working day.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await postJSON(HOLIDAY_URL, {
        days: csv,
        user_id,
        session_id,
        session_token,
        type: 2,
      });
      alert("Working plan updated.");
    } catch (e) {
      setError(e.message || "Failed to update working plan.");
    } finally {
      setLoading(false);
    }
  }

  async function addHoliday() {
    if (!addVacId || addVacId === "0") {
      alert("Please select a VAC for the holiday.");
      return;
    }
    if (!addHolidayName.trim()) {
      alert("Please enter a Holiday Name.");
      return;
    }
    if (!addHolidayDate) {
      alert("Please pick a Holiday Date.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await postJSON(HOLIDAY_URL, {
        user_id,
        session_id,
        session_token,
        type: 4,
        vac_id: addVacId,
        holiday_date: addHolidayDate, // yyyy-mm-dd
        holiday_name: addHolidayName.trim(),
      });
      setAddHolidayName("");
      setAddHolidayDate("");
      setAddVacId("0");
      await loadHolidays(); // only reload holidays
      alert("Holiday added.");
    } catch (e) {
      setError(e.message || "Failed to add holiday.");
    } finally {
      setLoading(false);
    }
  }

  async function deleteHoliday(holiday_id) {
    if (!holiday_id) return;
    if (!window.confirm("Delete this holiday?")) return;
    setLoading(true);
    setError("");
    try {
      await postJSON(HOLIDAY_URL, {
        user_id,
        session_id,
        session_token,
        type: 3,
        holiday_id,
      });
      await loadHolidays();
      alert("Holiday deleted.");
    } catch (e) {
      setError(e.message || "Failed to delete holiday.");
    } finally {
      setLoading(false);
    }
  }

  /* -------- derived views -------- */
  const dayRows = [
    { label: "Sunday", value: 7 },
    { label: "Monday", value: 1 },
    { label: "Tuesday", value: 2 },
    { label: "Wednesday", value: 3 },
    { label: "Thursday", value: 4 },
    { label: "Friday", value: 5 },
    { label: "Saturday", value: 6 },
  ];

  return (
    <AjaxValidation>
      <div className="container-fluid py-3">
        <h4 className="mb-3">Close Customer Webform</h4>

        {/* === Webform Controls === */}
        <div className="card shadow-sm mb-4">
          <div className="card-body d-flex flex-wrap gap-3 align-items-center">
            <div className="d-flex align-items-center gap-2">
              <span className="text-muted">Queue Type</span>
              <select
                className="form-select"
                style={{ width: 180 }}
                value={wfQueueType}
                onChange={(e) => setWfQueueType(e.target.value)}
              >
                <option value="">All</option>
                <option value="0">Normal</option>
                <option value="1">Priority</option>
              </select>
            </div>

            <div className="d-flex align-items-center gap-2">
              <span className="text-muted">VAC Name</span>
              <select
                className="form-select"
                style={{ width: 240 }}
                value={wfVacId}
                onChange={(e) => setWfVacId(e.target.value)}
              >
                <option value="0">All</option>
                {vacOptions.map((v) => (
                  <option key={v.vac_id} value={v.vac_id}>
                    {v.vac_name}
                  </option>
                ))}
              </select>
            </div>

            <div className="d-flex align-items-center gap-3">
              <label className="d-flex align-items-center gap-2">
                <input
                  type="radio"
                  name="wfStatus"
                  value="1"
                  checked={wfOpenClose === "1"}
                  onChange={(e) => setWfOpenClose(e.target.value)}
                />
                Close
              </label>
              <label className="d-flex align-items-center gap-2">
                <input
                  type="radio"
                  name="wfStatus"
                  value="0"
                  checked={wfOpenClose === "0"}
                  onChange={(e) => setWfOpenClose(e.target.value)}
                />
                Open
              </label>
              {/* empty on mount; user must choose */}
            </div>

            <button
              className="btn text-white ms-auto"
              style={{ backgroundColor: "#f26722", minWidth: 110 }}
              onClick={updateWebform}
              disabled={loading}
            >
              Update
            </button>
          </div>
        </div>

        {/* === Webform Overview Table === */}
        <div className="card shadow-sm mb-4">
          <div className="card-body p-2">
            <div className="table-responsive">
              <table className="table table-bordered mb-0">
                <thead className="table-light">
                  <tr>
                    <th style={{ width: 80 }}>S.No</th>
                    <th>VAC Name</th>
                    <th style={{ width: 160 }}>Normal</th>
                    <th style={{ width: 160 }}>Priority</th>
                  </tr>
                </thead>
                <tbody>
                  {loading && webformRows.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="text-center py-4">
                        Loading...
                      </td>
                    </tr>
                  ) : webformRows.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="text-center text-muted py-4">
                        No data found
                      </td>
                    </tr>
                  ) : (
                    webformRows.map((r, i) => (
                      <tr key={r.vac_id ?? i}>
                        <td>{i + 1}</td>
                        <td>{r.vac_name}</td>
                        <td>{r.normalClosed ? "Close" : "Open"}</td>
                        <td>{r.priorityClosed ? "Close" : "Open"}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* === Working Plan === */}
        <h4 className="mb-3">Working Plan</h4>
        <div className="card shadow-sm mb-4">
          <div className="card-body p-2">
            <div className="table-responsive">
              <table className="table table-bordered mb-0">
                <thead className="table-light">
                  <tr>
                    <th style={{ width: 80 }}>S.No</th>
                    <th>Days</th>
                    <th style={{ width: 60, textAlign: "center" }}>#</th>
                  </tr>
                </thead>
                <tbody>
                  {dayRows.map((d, i) => (
                    <tr key={d.value}>
                      <td>{i + 1}</td>
                      <td>{d.label}</td>
                      <td className="text-center">
                        <input
                          type="checkbox"
                          checked={workingDays.has(d.value)}
                          onChange={() => toggleDay(d.value)}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="text-end mt-3">
              <button
                className="btn text-white"
                style={{ backgroundColor: "#f26722", minWidth: 110 }}
                onClick={updateWorkingPlan}
                disabled={loading}
              >
                Update
              </button>
            </div>
          </div>
        </div>

        {/* === Holiday (Add + List) === */}
        <h4 className="mb-3">Holiday</h4>

        {/* Add form */}
        <div className="card shadow-sm mb-3">
          <div className="card-body d-flex flex-wrap gap-3 align-items-center">
            <div className="d-flex align-items-center gap-2">
              <span className="text-muted">VAC Name</span>
              <select
                className="form-select"
                style={{ width: 240 }}
                value={addVacId}
                onChange={(e) => setAddVacId(e.target.value)}
              >
                <option value="0">All</option>
                {vacOptions.map((v) => (
                  <option key={v.vac_id} value={v.vac_id}>
                    {v.vac_name}
                  </option>
                ))}
              </select>
            </div>

            <div className="d-flex align-items-center gap-2">
              <span className="text-muted">Holiday Name</span>
              <input
                className="form-control"
                style={{ width: 260 }}
                value={addHolidayName}
                onChange={(e) => setAddHolidayName(e.target.value)}
                placeholder="Holiday Name"
              />
            </div>

            <div className="d-flex align-items-center gap-2">
              <span className="text-muted">Holiday Date</span>
              <input
                type="date"
                className="form-control"
                style={{ width: 200 }}
                value={addHolidayDate}
                onChange={(e) => setAddHolidayDate(e.target.value)}
                placeholder="YYYY-MM-DD"
              />
            </div>

            <button
              className="btn text-white ms-auto"
              style={{ backgroundColor: "#f26722", minWidth: 140 }}
              onClick={addHoliday}
              disabled={loading}
            >
              Add Holiday
            </button>
          </div>
        </div>

        {/* Holiday list */}
        <div className="card shadow-sm">
          <div className="card-body p-2">
            <div className="table-responsive">
              <table className="table table-bordered mb-0">
                <thead className="table-light">
                  <tr>
                    <th style={{ width: 80 }}>S.No</th>
                    <th>VAC</th>
                    <th>Holiday Name</th>
                    <th style={{ width: 160 }}>Holiday Date</th>
                    <th style={{ width: 120 }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {loading && holidayRows.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-4">
                        Loading...
                      </td>
                    </tr>
                  ) : holidayRows.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center text-muted py-4">
                        No holidays found.
                      </td>
                    </tr>
                  ) : (
                    holidayRows.map((h, i) => (
                      <tr key={h.id ?? i}>
                        <td>{i + 1}</td>
                        <td>{h.vac_name}</td>
                        <td>{h.name}</td>
                        <td>{h.date}</td>
                        <td>
                          <button
                            className="btn btn-sm text-white"
                            style={{ backgroundColor: "#f26722" }}
                            onClick={() => deleteHoliday(h.id)}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {error && (
              <div className="text-danger mt-2" role="alert">
                {error}
              </div>
            )}
          </div>
        </div>
      </div>
    </AjaxValidation>
  );
}
