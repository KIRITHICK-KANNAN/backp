function Footer() {
  return (
    <>
      <footer className="footer mt-auto py-3 bg-light">
        <div className="container">
          <div className="row">
            <div className="col-sm-12 text-center">
              <p className="mb-0 footer-title">
                Copyright © 2025. All Rights Reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}

export default Footer;
